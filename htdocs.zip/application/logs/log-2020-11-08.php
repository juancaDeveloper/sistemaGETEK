<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-08 21:05:00 --> Config Class Initialized
INFO - 2020-11-08 21:05:00 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:00 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:00 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:00 --> URI Class Initialized
DEBUG - 2020-11-08 21:05:00 --> No URI present. Default controller set.
INFO - 2020-11-08 21:05:00 --> Router Class Initialized
INFO - 2020-11-08 21:05:00 --> Output Class Initialized
INFO - 2020-11-08 21:05:00 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:00 --> Input Class Initialized
INFO - 2020-11-08 21:05:00 --> Language Class Initialized
INFO - 2020-11-08 21:05:00 --> Loader Class Initialized
INFO - 2020-11-08 21:05:00 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:00 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:00 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:00 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:00 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:00 --> Table Class Initialized
INFO - 2020-11-08 21:05:00 --> Upload Class Initialized
INFO - 2020-11-08 21:05:00 --> Controller Class Initialized
INFO - 2020-11-08 21:05:00 --> Model "Usuarios_model" initialized
INFO - 2020-11-08 21:05:00 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-08 21:05:00 --> Final output sent to browser
DEBUG - 2020-11-08 21:05:00 --> Total execution time: 0.1101
INFO - 2020-11-08 21:05:01 --> Config Class Initialized
INFO - 2020-11-08 21:05:01 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:01 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:01 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:01 --> URI Class Initialized
INFO - 2020-11-08 21:05:01 --> Router Class Initialized
INFO - 2020-11-08 21:05:01 --> Output Class Initialized
INFO - 2020-11-08 21:05:01 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:01 --> Input Class Initialized
INFO - 2020-11-08 21:05:01 --> Language Class Initialized
ERROR - 2020-11-08 21:05:01 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-11-08 21:05:08 --> Config Class Initialized
INFO - 2020-11-08 21:05:08 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:08 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:08 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:08 --> URI Class Initialized
INFO - 2020-11-08 21:05:08 --> Router Class Initialized
INFO - 2020-11-08 21:05:08 --> Output Class Initialized
INFO - 2020-11-08 21:05:08 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:08 --> Input Class Initialized
INFO - 2020-11-08 21:05:08 --> Language Class Initialized
INFO - 2020-11-08 21:05:08 --> Loader Class Initialized
INFO - 2020-11-08 21:05:08 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:08 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:08 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:08 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:08 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:08 --> Table Class Initialized
INFO - 2020-11-08 21:05:08 --> Upload Class Initialized
INFO - 2020-11-08 21:05:08 --> Controller Class Initialized
INFO - 2020-11-08 21:05:08 --> Model "Usuarios_model" initialized
INFO - 2020-11-08 21:05:08 --> Config Class Initialized
INFO - 2020-11-08 21:05:08 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:08 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:08 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:08 --> URI Class Initialized
DEBUG - 2020-11-08 21:05:08 --> No URI present. Default controller set.
INFO - 2020-11-08 21:05:08 --> Router Class Initialized
INFO - 2020-11-08 21:05:08 --> Output Class Initialized
INFO - 2020-11-08 21:05:08 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:08 --> Input Class Initialized
INFO - 2020-11-08 21:05:08 --> Language Class Initialized
INFO - 2020-11-08 21:05:08 --> Loader Class Initialized
INFO - 2020-11-08 21:05:08 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:08 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:08 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:08 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:08 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:08 --> Table Class Initialized
INFO - 2020-11-08 21:05:08 --> Upload Class Initialized
INFO - 2020-11-08 21:05:08 --> Controller Class Initialized
INFO - 2020-11-08 21:05:08 --> Model "Usuarios_model" initialized
INFO - 2020-11-08 21:05:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-08 21:05:08 --> Final output sent to browser
DEBUG - 2020-11-08 21:05:08 --> Total execution time: 0.0445
INFO - 2020-11-08 21:05:15 --> Config Class Initialized
INFO - 2020-11-08 21:05:15 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:15 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:15 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:15 --> URI Class Initialized
INFO - 2020-11-08 21:05:15 --> Router Class Initialized
INFO - 2020-11-08 21:05:15 --> Output Class Initialized
INFO - 2020-11-08 21:05:15 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:15 --> Input Class Initialized
INFO - 2020-11-08 21:05:15 --> Language Class Initialized
INFO - 2020-11-08 21:05:15 --> Loader Class Initialized
INFO - 2020-11-08 21:05:15 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:15 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:15 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:15 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:15 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:15 --> Table Class Initialized
INFO - 2020-11-08 21:05:15 --> Upload Class Initialized
INFO - 2020-11-08 21:05:15 --> Controller Class Initialized
INFO - 2020-11-08 21:05:15 --> Model "Usuarios_model" initialized
INFO - 2020-11-08 21:05:15 --> Config Class Initialized
INFO - 2020-11-08 21:05:15 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:15 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:15 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:15 --> URI Class Initialized
INFO - 2020-11-08 21:05:15 --> Router Class Initialized
INFO - 2020-11-08 21:05:15 --> Output Class Initialized
INFO - 2020-11-08 21:05:15 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:15 --> Input Class Initialized
INFO - 2020-11-08 21:05:15 --> Language Class Initialized
INFO - 2020-11-08 21:05:15 --> Loader Class Initialized
INFO - 2020-11-08 21:05:15 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:15 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:15 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:15 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:15 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:15 --> Table Class Initialized
INFO - 2020-11-08 21:05:15 --> Upload Class Initialized
INFO - 2020-11-08 21:05:15 --> Controller Class Initialized
INFO - 2020-11-08 21:05:15 --> Form Validation Class Initialized
INFO - 2020-11-08 21:05:15 --> Model "Crud_model" initialized
INFO - 2020-11-08 21:05:15 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-11-08 21:05:15 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-11-08 21:05:15 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-11-08 21:05:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-11-08 21:05:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-11-08 21:05:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-11-08 21:05:15 --> Final output sent to browser
DEBUG - 2020-11-08 21:05:15 --> Total execution time: 0.0631
INFO - 2020-11-08 21:05:15 --> Config Class Initialized
INFO - 2020-11-08 21:05:15 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:15 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:16 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:16 --> URI Class Initialized
INFO - 2020-11-08 21:05:16 --> Router Class Initialized
INFO - 2020-11-08 21:05:16 --> Output Class Initialized
INFO - 2020-11-08 21:05:16 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:16 --> Input Class Initialized
INFO - 2020-11-08 21:05:16 --> Language Class Initialized
ERROR - 2020-11-08 21:05:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-08 21:05:16 --> Config Class Initialized
INFO - 2020-11-08 21:05:16 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:16 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:16 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:16 --> URI Class Initialized
INFO - 2020-11-08 21:05:16 --> Router Class Initialized
INFO - 2020-11-08 21:05:16 --> Output Class Initialized
INFO - 2020-11-08 21:05:16 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:16 --> Input Class Initialized
INFO - 2020-11-08 21:05:16 --> Language Class Initialized
INFO - 2020-11-08 21:05:16 --> Loader Class Initialized
INFO - 2020-11-08 21:05:16 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:16 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:16 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:16 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:16 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:16 --> Table Class Initialized
INFO - 2020-11-08 21:05:16 --> Upload Class Initialized
INFO - 2020-11-08 21:05:16 --> Controller Class Initialized
INFO - 2020-11-08 21:05:16 --> Form Validation Class Initialized
INFO - 2020-11-08 21:05:16 --> Model "Crud_model" initialized
ERROR - 2020-11-08 21:05:16 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-11-08 21:05:16 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-08 21:05:17 --> Config Class Initialized
INFO - 2020-11-08 21:05:17 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:17 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:17 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:17 --> URI Class Initialized
INFO - 2020-11-08 21:05:17 --> Router Class Initialized
INFO - 2020-11-08 21:05:17 --> Output Class Initialized
INFO - 2020-11-08 21:05:17 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:17 --> Input Class Initialized
INFO - 2020-11-08 21:05:17 --> Language Class Initialized
ERROR - 2020-11-08 21:05:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-08 21:05:38 --> Config Class Initialized
INFO - 2020-11-08 21:05:38 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:38 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:38 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:38 --> URI Class Initialized
INFO - 2020-11-08 21:05:38 --> Router Class Initialized
INFO - 2020-11-08 21:05:38 --> Output Class Initialized
INFO - 2020-11-08 21:05:38 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:38 --> Input Class Initialized
INFO - 2020-11-08 21:05:38 --> Language Class Initialized
INFO - 2020-11-08 21:05:38 --> Loader Class Initialized
INFO - 2020-11-08 21:05:38 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:38 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:38 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:38 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:38 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:38 --> Table Class Initialized
INFO - 2020-11-08 21:05:38 --> Upload Class Initialized
INFO - 2020-11-08 21:05:38 --> Controller Class Initialized
INFO - 2020-11-08 21:05:38 --> Model "Usuarios_model" initialized
INFO - 2020-11-08 21:05:38 --> Config Class Initialized
INFO - 2020-11-08 21:05:38 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:38 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:38 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:38 --> URI Class Initialized
DEBUG - 2020-11-08 21:05:38 --> No URI present. Default controller set.
INFO - 2020-11-08 21:05:38 --> Router Class Initialized
INFO - 2020-11-08 21:05:38 --> Output Class Initialized
INFO - 2020-11-08 21:05:38 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:38 --> Input Class Initialized
INFO - 2020-11-08 21:05:38 --> Language Class Initialized
INFO - 2020-11-08 21:05:38 --> Loader Class Initialized
INFO - 2020-11-08 21:05:38 --> Helper loaded: url_helper
INFO - 2020-11-08 21:05:38 --> Helper loaded: form_helper
INFO - 2020-11-08 21:05:38 --> Helper loaded: html_helper
INFO - 2020-11-08 21:05:38 --> Helper loaded: date_helper
INFO - 2020-11-08 21:05:38 --> Database Driver Class Initialized
INFO - 2020-11-08 21:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-08 21:05:38 --> Table Class Initialized
INFO - 2020-11-08 21:05:38 --> Upload Class Initialized
INFO - 2020-11-08 21:05:38 --> Controller Class Initialized
INFO - 2020-11-08 21:05:38 --> Model "Usuarios_model" initialized
INFO - 2020-11-08 21:05:38 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-08 21:05:38 --> Final output sent to browser
DEBUG - 2020-11-08 21:05:38 --> Total execution time: 0.0464
INFO - 2020-11-08 21:05:57 --> Config Class Initialized
INFO - 2020-11-08 21:05:57 --> Hooks Class Initialized
DEBUG - 2020-11-08 21:05:57 --> UTF-8 Support Enabled
INFO - 2020-11-08 21:05:57 --> Utf8 Class Initialized
INFO - 2020-11-08 21:05:57 --> URI Class Initialized
INFO - 2020-11-08 21:05:57 --> Router Class Initialized
INFO - 2020-11-08 21:05:57 --> Output Class Initialized
INFO - 2020-11-08 21:05:57 --> Security Class Initialized
DEBUG - 2020-11-08 21:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-08 21:05:57 --> Input Class Initialized
INFO - 2020-11-08 21:05:57 --> Language Class Initialized
ERROR - 2020-11-08 21:05:57 --> 404 Page Not Found: Tracking/tracking.js

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-24 00:00:49 --> Config Class Initialized
INFO - 2020-10-24 00:00:49 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:00:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:49 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:49 --> URI Class Initialized
INFO - 2020-10-24 00:00:49 --> Router Class Initialized
INFO - 2020-10-24 00:00:49 --> Output Class Initialized
INFO - 2020-10-24 00:00:49 --> Security Class Initialized
DEBUG - 2020-10-24 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:49 --> Input Class Initialized
INFO - 2020-10-24 00:00:49 --> Language Class Initialized
INFO - 2020-10-24 00:00:49 --> Loader Class Initialized
INFO - 2020-10-24 00:00:49 --> Helper loaded: url_helper
INFO - 2020-10-24 00:00:49 --> Helper loaded: form_helper
INFO - 2020-10-24 00:00:49 --> Helper loaded: html_helper
INFO - 2020-10-24 00:00:49 --> Helper loaded: date_helper
INFO - 2020-10-24 00:00:49 --> Database Driver Class Initialized
INFO - 2020-10-24 00:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:00:49 --> Table Class Initialized
INFO - 2020-10-24 00:00:49 --> Upload Class Initialized
INFO - 2020-10-24 00:00:49 --> Controller Class Initialized
INFO - 2020-10-24 00:00:49 --> Form Validation Class Initialized
INFO - 2020-10-24 00:00:49 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:00:49 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:00:49 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:00:49 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:00:49 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:00:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:00:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:00:49 --> Final output sent to browser
DEBUG - 2020-10-24 00:00:49 --> Total execution time: 0.1014
INFO - 2020-10-24 00:00:49 --> Config Class Initialized
INFO - 2020-10-24 00:00:49 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:00:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:49 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:49 --> URI Class Initialized
INFO - 2020-10-24 00:00:49 --> Router Class Initialized
INFO - 2020-10-24 00:00:49 --> Output Class Initialized
INFO - 2020-10-24 00:00:49 --> Security Class Initialized
DEBUG - 2020-10-24 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:49 --> Input Class Initialized
INFO - 2020-10-24 00:00:49 --> Language Class Initialized
ERROR - 2020-10-24 00:00:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:00:49 --> Config Class Initialized
INFO - 2020-10-24 00:00:49 --> Hooks Class Initialized
INFO - 2020-10-24 00:00:49 --> Config Class Initialized
DEBUG - 2020-10-24 00:00:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:49 --> Hooks Class Initialized
INFO - 2020-10-24 00:00:49 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:49 --> URI Class Initialized
DEBUG - 2020-10-24 00:00:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:49 --> Router Class Initialized
INFO - 2020-10-24 00:00:49 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:49 --> Output Class Initialized
INFO - 2020-10-24 00:00:49 --> URI Class Initialized
INFO - 2020-10-24 00:00:49 --> Security Class Initialized
INFO - 2020-10-24 00:00:49 --> Router Class Initialized
DEBUG - 2020-10-24 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:49 --> Input Class Initialized
INFO - 2020-10-24 00:00:49 --> Output Class Initialized
INFO - 2020-10-24 00:00:49 --> Language Class Initialized
INFO - 2020-10-24 00:00:49 --> Security Class Initialized
ERROR - 2020-10-24 00:00:49 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:49 --> Input Class Initialized
INFO - 2020-10-24 00:00:49 --> Language Class Initialized
ERROR - 2020-10-24 00:00:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:00:49 --> Config Class Initialized
INFO - 2020-10-24 00:00:49 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:00:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:49 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:49 --> URI Class Initialized
INFO - 2020-10-24 00:00:49 --> Router Class Initialized
INFO - 2020-10-24 00:00:49 --> Output Class Initialized
INFO - 2020-10-24 00:00:49 --> Security Class Initialized
DEBUG - 2020-10-24 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:49 --> Input Class Initialized
INFO - 2020-10-24 00:00:49 --> Language Class Initialized
ERROR - 2020-10-24 00:00:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:00:49 --> Config Class Initialized
INFO - 2020-10-24 00:00:49 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:00:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:49 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:49 --> URI Class Initialized
INFO - 2020-10-24 00:00:49 --> Router Class Initialized
INFO - 2020-10-24 00:00:49 --> Output Class Initialized
INFO - 2020-10-24 00:00:49 --> Security Class Initialized
DEBUG - 2020-10-24 00:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:49 --> Input Class Initialized
INFO - 2020-10-24 00:00:49 --> Language Class Initialized
INFO - 2020-10-24 00:00:49 --> Loader Class Initialized
INFO - 2020-10-24 00:00:49 --> Helper loaded: url_helper
INFO - 2020-10-24 00:00:49 --> Helper loaded: form_helper
INFO - 2020-10-24 00:00:49 --> Helper loaded: html_helper
INFO - 2020-10-24 00:00:49 --> Helper loaded: date_helper
INFO - 2020-10-24 00:00:49 --> Database Driver Class Initialized
INFO - 2020-10-24 00:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:00:49 --> Table Class Initialized
INFO - 2020-10-24 00:00:49 --> Upload Class Initialized
INFO - 2020-10-24 00:00:49 --> Controller Class Initialized
INFO - 2020-10-24 00:00:49 --> Form Validation Class Initialized
INFO - 2020-10-24 00:00:49 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:00:49 --> Final output sent to browser
DEBUG - 2020-10-24 00:00:49 --> Total execution time: 0.0653
INFO - 2020-10-24 00:00:50 --> Config Class Initialized
INFO - 2020-10-24 00:00:50 --> Config Class Initialized
INFO - 2020-10-24 00:00:50 --> Hooks Class Initialized
INFO - 2020-10-24 00:00:50 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:00:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:50 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:00:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:50 --> URI Class Initialized
INFO - 2020-10-24 00:00:50 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:50 --> URI Class Initialized
INFO - 2020-10-24 00:00:50 --> Router Class Initialized
INFO - 2020-10-24 00:00:50 --> Router Class Initialized
INFO - 2020-10-24 00:00:50 --> Output Class Initialized
INFO - 2020-10-24 00:00:50 --> Output Class Initialized
INFO - 2020-10-24 00:00:50 --> Security Class Initialized
INFO - 2020-10-24 00:00:50 --> Security Class Initialized
DEBUG - 2020-10-24 00:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:50 --> Input Class Initialized
INFO - 2020-10-24 00:00:50 --> Input Class Initialized
INFO - 2020-10-24 00:00:50 --> Language Class Initialized
INFO - 2020-10-24 00:00:50 --> Language Class Initialized
ERROR - 2020-10-24 00:00:50 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:00:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:00:50 --> Config Class Initialized
INFO - 2020-10-24 00:00:50 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:00:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:00:50 --> Utf8 Class Initialized
INFO - 2020-10-24 00:00:50 --> URI Class Initialized
INFO - 2020-10-24 00:00:50 --> Router Class Initialized
INFO - 2020-10-24 00:00:50 --> Output Class Initialized
INFO - 2020-10-24 00:00:50 --> Security Class Initialized
DEBUG - 2020-10-24 00:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:00:50 --> Input Class Initialized
INFO - 2020-10-24 00:00:50 --> Language Class Initialized
ERROR - 2020-10-24 00:00:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
INFO - 2020-10-24 00:03:53 --> Loader Class Initialized
INFO - 2020-10-24 00:03:53 --> Helper loaded: url_helper
INFO - 2020-10-24 00:03:53 --> Helper loaded: form_helper
INFO - 2020-10-24 00:03:53 --> Helper loaded: html_helper
INFO - 2020-10-24 00:03:53 --> Helper loaded: date_helper
INFO - 2020-10-24 00:03:53 --> Database Driver Class Initialized
INFO - 2020-10-24 00:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:03:53 --> Table Class Initialized
INFO - 2020-10-24 00:03:53 --> Upload Class Initialized
INFO - 2020-10-24 00:03:53 --> Controller Class Initialized
INFO - 2020-10-24 00:03:53 --> Form Validation Class Initialized
INFO - 2020-10-24 00:03:53 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:03:53 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:03:53 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:03:53 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:03:53 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:03:53 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:03:53 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:03:53 --> Final output sent to browser
DEBUG - 2020-10-24 00:03:53 --> Total execution time: 0.1105
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
ERROR - 2020-10-24 00:03:53 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
ERROR - 2020-10-24 00:03:53 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:03:53 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
INFO - 2020-10-24 00:03:53 --> Loader Class Initialized
INFO - 2020-10-24 00:03:53 --> Helper loaded: url_helper
INFO - 2020-10-24 00:03:53 --> Helper loaded: form_helper
INFO - 2020-10-24 00:03:53 --> Helper loaded: html_helper
INFO - 2020-10-24 00:03:53 --> Helper loaded: date_helper
INFO - 2020-10-24 00:03:53 --> Database Driver Class Initialized
INFO - 2020-10-24 00:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:03:53 --> Table Class Initialized
INFO - 2020-10-24 00:03:53 --> Upload Class Initialized
INFO - 2020-10-24 00:03:53 --> Controller Class Initialized
INFO - 2020-10-24 00:03:53 --> Form Validation Class Initialized
INFO - 2020-10-24 00:03:53 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:03:53 --> Final output sent to browser
DEBUG - 2020-10-24 00:03:53 --> Total execution time: 0.0717
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
INFO - 2020-10-24 00:03:53 --> Config Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
INFO - 2020-10-24 00:03:53 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:03:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> URI Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Router Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Output Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
INFO - 2020-10-24 00:03:53 --> Security Class Initialized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Input Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
INFO - 2020-10-24 00:03:53 --> Language Class Initialized
ERROR - 2020-10-24 00:03:53 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:03:53 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:03:53 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:26 --> Config Class Initialized
INFO - 2020-10-24 00:04:26 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:26 --> URI Class Initialized
INFO - 2020-10-24 00:04:26 --> Router Class Initialized
INFO - 2020-10-24 00:04:26 --> Output Class Initialized
INFO - 2020-10-24 00:04:26 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:26 --> Input Class Initialized
INFO - 2020-10-24 00:04:26 --> Language Class Initialized
INFO - 2020-10-24 00:04:26 --> Loader Class Initialized
INFO - 2020-10-24 00:04:26 --> Helper loaded: url_helper
INFO - 2020-10-24 00:04:26 --> Helper loaded: form_helper
INFO - 2020-10-24 00:04:26 --> Helper loaded: html_helper
INFO - 2020-10-24 00:04:26 --> Helper loaded: date_helper
INFO - 2020-10-24 00:04:26 --> Database Driver Class Initialized
INFO - 2020-10-24 00:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:04:26 --> Table Class Initialized
INFO - 2020-10-24 00:04:26 --> Upload Class Initialized
INFO - 2020-10-24 00:04:26 --> Controller Class Initialized
INFO - 2020-10-24 00:04:26 --> Form Validation Class Initialized
INFO - 2020-10-24 00:04:26 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:04:26 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:04:26 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:04:26 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:04:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:04:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:04:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:04:26 --> Final output sent to browser
DEBUG - 2020-10-24 00:04:26 --> Total execution time: 0.1280
INFO - 2020-10-24 00:04:26 --> Config Class Initialized
INFO - 2020-10-24 00:04:26 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:26 --> URI Class Initialized
INFO - 2020-10-24 00:04:26 --> Router Class Initialized
INFO - 2020-10-24 00:04:26 --> Output Class Initialized
INFO - 2020-10-24 00:04:26 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:26 --> Input Class Initialized
INFO - 2020-10-24 00:04:26 --> Language Class Initialized
ERROR - 2020-10-24 00:04:26 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:04:26 --> Config Class Initialized
INFO - 2020-10-24 00:04:26 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:26 --> Config Class Initialized
INFO - 2020-10-24 00:04:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:26 --> URI Class Initialized
INFO - 2020-10-24 00:04:26 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:26 --> Router Class Initialized
INFO - 2020-10-24 00:04:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:26 --> Output Class Initialized
INFO - 2020-10-24 00:04:26 --> URI Class Initialized
INFO - 2020-10-24 00:04:26 --> Security Class Initialized
INFO - 2020-10-24 00:04:26 --> Router Class Initialized
DEBUG - 2020-10-24 00:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:26 --> Input Class Initialized
INFO - 2020-10-24 00:04:26 --> Output Class Initialized
INFO - 2020-10-24 00:04:26 --> Language Class Initialized
INFO - 2020-10-24 00:04:26 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 00:04:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:26 --> Input Class Initialized
INFO - 2020-10-24 00:04:26 --> Language Class Initialized
ERROR - 2020-10-24 00:04:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:26 --> Config Class Initialized
INFO - 2020-10-24 00:04:26 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:26 --> URI Class Initialized
INFO - 2020-10-24 00:04:26 --> Router Class Initialized
INFO - 2020-10-24 00:04:26 --> Output Class Initialized
INFO - 2020-10-24 00:04:26 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:27 --> Input Class Initialized
INFO - 2020-10-24 00:04:27 --> Language Class Initialized
INFO - 2020-10-24 00:04:27 --> Loader Class Initialized
INFO - 2020-10-24 00:04:27 --> Helper loaded: url_helper
INFO - 2020-10-24 00:04:27 --> Helper loaded: form_helper
INFO - 2020-10-24 00:04:27 --> Helper loaded: html_helper
INFO - 2020-10-24 00:04:27 --> Helper loaded: date_helper
INFO - 2020-10-24 00:04:27 --> Database Driver Class Initialized
INFO - 2020-10-24 00:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:04:27 --> Table Class Initialized
INFO - 2020-10-24 00:04:27 --> Upload Class Initialized
INFO - 2020-10-24 00:04:27 --> Controller Class Initialized
INFO - 2020-10-24 00:04:27 --> Form Validation Class Initialized
INFO - 2020-10-24 00:04:27 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:04:27 --> Final output sent to browser
DEBUG - 2020-10-24 00:04:27 --> Total execution time: 0.0762
INFO - 2020-10-24 00:04:27 --> Config Class Initialized
INFO - 2020-10-24 00:04:27 --> Config Class Initialized
INFO - 2020-10-24 00:04:27 --> Config Class Initialized
INFO - 2020-10-24 00:04:27 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:27 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:27 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:04:27 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:27 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:27 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:04:27 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:27 --> URI Class Initialized
INFO - 2020-10-24 00:04:27 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:27 --> URI Class Initialized
INFO - 2020-10-24 00:04:27 --> Router Class Initialized
INFO - 2020-10-24 00:04:27 --> URI Class Initialized
INFO - 2020-10-24 00:04:27 --> Router Class Initialized
INFO - 2020-10-24 00:04:27 --> Output Class Initialized
INFO - 2020-10-24 00:04:27 --> Output Class Initialized
INFO - 2020-10-24 00:04:27 --> Router Class Initialized
INFO - 2020-10-24 00:04:27 --> Security Class Initialized
INFO - 2020-10-24 00:04:27 --> Output Class Initialized
DEBUG - 2020-10-24 00:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:27 --> Security Class Initialized
INFO - 2020-10-24 00:04:27 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:27 --> Input Class Initialized
DEBUG - 2020-10-24 00:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:27 --> Input Class Initialized
INFO - 2020-10-24 00:04:27 --> Language Class Initialized
INFO - 2020-10-24 00:04:27 --> Input Class Initialized
INFO - 2020-10-24 00:04:27 --> Language Class Initialized
ERROR - 2020-10-24 00:04:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:27 --> Language Class Initialized
ERROR - 2020-10-24 00:04:27 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:04:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:39 --> Config Class Initialized
INFO - 2020-10-24 00:04:39 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:39 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:39 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:39 --> URI Class Initialized
INFO - 2020-10-24 00:04:39 --> Router Class Initialized
INFO - 2020-10-24 00:04:39 --> Output Class Initialized
INFO - 2020-10-24 00:04:39 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:39 --> Input Class Initialized
INFO - 2020-10-24 00:04:39 --> Language Class Initialized
INFO - 2020-10-24 00:04:39 --> Loader Class Initialized
INFO - 2020-10-24 00:04:39 --> Helper loaded: url_helper
INFO - 2020-10-24 00:04:39 --> Helper loaded: form_helper
INFO - 2020-10-24 00:04:39 --> Helper loaded: html_helper
INFO - 2020-10-24 00:04:39 --> Helper loaded: date_helper
INFO - 2020-10-24 00:04:39 --> Database Driver Class Initialized
INFO - 2020-10-24 00:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:04:39 --> Table Class Initialized
INFO - 2020-10-24 00:04:39 --> Upload Class Initialized
INFO - 2020-10-24 00:04:39 --> Controller Class Initialized
INFO - 2020-10-24 00:04:39 --> Form Validation Class Initialized
INFO - 2020-10-24 00:04:39 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:04:39 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:04:39 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:04:39 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:04:39 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:04:39 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:04:39 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:04:39 --> Final output sent to browser
DEBUG - 2020-10-24 00:04:39 --> Total execution time: 0.1985
INFO - 2020-10-24 00:04:39 --> Config Class Initialized
INFO - 2020-10-24 00:04:39 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:39 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:39 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:39 --> URI Class Initialized
INFO - 2020-10-24 00:04:39 --> Router Class Initialized
INFO - 2020-10-24 00:04:39 --> Output Class Initialized
INFO - 2020-10-24 00:04:39 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:39 --> Input Class Initialized
INFO - 2020-10-24 00:04:39 --> Language Class Initialized
ERROR - 2020-10-24 00:04:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:04:39 --> Config Class Initialized
INFO - 2020-10-24 00:04:39 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:39 --> Config Class Initialized
INFO - 2020-10-24 00:04:39 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:39 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:39 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:39 --> URI Class Initialized
DEBUG - 2020-10-24 00:04:39 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:39 --> Router Class Initialized
INFO - 2020-10-24 00:04:39 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:39 --> URI Class Initialized
INFO - 2020-10-24 00:04:39 --> Output Class Initialized
INFO - 2020-10-24 00:04:39 --> Router Class Initialized
INFO - 2020-10-24 00:04:39 --> Output Class Initialized
INFO - 2020-10-24 00:04:39 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:39 --> Input Class Initialized
INFO - 2020-10-24 00:04:39 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:39 --> Language Class Initialized
ERROR - 2020-10-24 00:04:39 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:39 --> Input Class Initialized
INFO - 2020-10-24 00:04:39 --> Language Class Initialized
ERROR - 2020-10-24 00:04:39 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:39 --> Config Class Initialized
INFO - 2020-10-24 00:04:39 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:39 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:39 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:39 --> URI Class Initialized
INFO - 2020-10-24 00:04:39 --> Router Class Initialized
INFO - 2020-10-24 00:04:39 --> Output Class Initialized
INFO - 2020-10-24 00:04:39 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:39 --> Input Class Initialized
INFO - 2020-10-24 00:04:39 --> Language Class Initialized
INFO - 2020-10-24 00:04:39 --> Loader Class Initialized
INFO - 2020-10-24 00:04:39 --> Helper loaded: url_helper
INFO - 2020-10-24 00:04:39 --> Helper loaded: form_helper
INFO - 2020-10-24 00:04:39 --> Helper loaded: html_helper
INFO - 2020-10-24 00:04:39 --> Helper loaded: date_helper
INFO - 2020-10-24 00:04:39 --> Database Driver Class Initialized
INFO - 2020-10-24 00:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:04:39 --> Table Class Initialized
INFO - 2020-10-24 00:04:39 --> Upload Class Initialized
INFO - 2020-10-24 00:04:39 --> Controller Class Initialized
INFO - 2020-10-24 00:04:39 --> Form Validation Class Initialized
INFO - 2020-10-24 00:04:39 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:04:39 --> Final output sent to browser
DEBUG - 2020-10-24 00:04:39 --> Total execution time: 0.0842
INFO - 2020-10-24 00:04:40 --> Config Class Initialized
INFO - 2020-10-24 00:04:40 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:40 --> Config Class Initialized
INFO - 2020-10-24 00:04:40 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:04:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:40 --> URI Class Initialized
INFO - 2020-10-24 00:04:40 --> URI Class Initialized
INFO - 2020-10-24 00:04:40 --> Config Class Initialized
INFO - 2020-10-24 00:04:40 --> Router Class Initialized
INFO - 2020-10-24 00:04:40 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:40 --> Router Class Initialized
INFO - 2020-10-24 00:04:40 --> Config Class Initialized
INFO - 2020-10-24 00:04:40 --> Output Class Initialized
INFO - 2020-10-24 00:04:40 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:40 --> Output Class Initialized
INFO - 2020-10-24 00:04:40 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:40 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:40 --> Input Class Initialized
INFO - 2020-10-24 00:04:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:40 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:40 --> Input Class Initialized
INFO - 2020-10-24 00:04:40 --> URI Class Initialized
INFO - 2020-10-24 00:04:40 --> Language Class Initialized
INFO - 2020-10-24 00:04:40 --> URI Class Initialized
INFO - 2020-10-24 00:04:40 --> Router Class Initialized
INFO - 2020-10-24 00:04:40 --> Language Class Initialized
INFO - 2020-10-24 00:04:40 --> Router Class Initialized
ERROR - 2020-10-24 00:04:40 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:04:40 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:40 --> Output Class Initialized
INFO - 2020-10-24 00:04:40 --> Output Class Initialized
INFO - 2020-10-24 00:04:40 --> Security Class Initialized
INFO - 2020-10-24 00:04:40 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:40 --> Input Class Initialized
INFO - 2020-10-24 00:04:40 --> Input Class Initialized
INFO - 2020-10-24 00:04:40 --> Language Class Initialized
INFO - 2020-10-24 00:04:40 --> Language Class Initialized
ERROR - 2020-10-24 00:04:40 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:04:40 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:50 --> Config Class Initialized
INFO - 2020-10-24 00:04:50 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:50 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:50 --> URI Class Initialized
INFO - 2020-10-24 00:04:50 --> Router Class Initialized
INFO - 2020-10-24 00:04:50 --> Output Class Initialized
INFO - 2020-10-24 00:04:50 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:50 --> Input Class Initialized
INFO - 2020-10-24 00:04:50 --> Language Class Initialized
INFO - 2020-10-24 00:04:50 --> Loader Class Initialized
INFO - 2020-10-24 00:04:50 --> Helper loaded: url_helper
INFO - 2020-10-24 00:04:50 --> Helper loaded: form_helper
INFO - 2020-10-24 00:04:50 --> Helper loaded: html_helper
INFO - 2020-10-24 00:04:50 --> Helper loaded: date_helper
INFO - 2020-10-24 00:04:50 --> Database Driver Class Initialized
INFO - 2020-10-24 00:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:04:50 --> Table Class Initialized
INFO - 2020-10-24 00:04:50 --> Upload Class Initialized
INFO - 2020-10-24 00:04:50 --> Controller Class Initialized
INFO - 2020-10-24 00:04:50 --> Form Validation Class Initialized
INFO - 2020-10-24 00:04:50 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:04:50 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:04:50 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:04:50 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:04:50 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:04:50 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:04:50 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:04:50 --> Final output sent to browser
DEBUG - 2020-10-24 00:04:50 --> Total execution time: 0.1796
INFO - 2020-10-24 00:04:50 --> Config Class Initialized
INFO - 2020-10-24 00:04:50 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:50 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:50 --> URI Class Initialized
INFO - 2020-10-24 00:04:50 --> Router Class Initialized
INFO - 2020-10-24 00:04:50 --> Output Class Initialized
INFO - 2020-10-24 00:04:50 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:50 --> Input Class Initialized
INFO - 2020-10-24 00:04:50 --> Language Class Initialized
ERROR - 2020-10-24 00:04:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:04:50 --> Config Class Initialized
INFO - 2020-10-24 00:04:50 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:50 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:50 --> URI Class Initialized
INFO - 2020-10-24 00:04:50 --> Router Class Initialized
INFO - 2020-10-24 00:04:50 --> Output Class Initialized
INFO - 2020-10-24 00:04:50 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:50 --> Input Class Initialized
INFO - 2020-10-24 00:04:50 --> Language Class Initialized
ERROR - 2020-10-24 00:04:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:50 --> Config Class Initialized
INFO - 2020-10-24 00:04:50 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:50 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:50 --> URI Class Initialized
INFO - 2020-10-24 00:04:50 --> Router Class Initialized
INFO - 2020-10-24 00:04:50 --> Output Class Initialized
INFO - 2020-10-24 00:04:50 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:50 --> Input Class Initialized
INFO - 2020-10-24 00:04:50 --> Language Class Initialized
ERROR - 2020-10-24 00:04:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:50 --> Config Class Initialized
INFO - 2020-10-24 00:04:50 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:50 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:50 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:50 --> URI Class Initialized
INFO - 2020-10-24 00:04:50 --> Router Class Initialized
INFO - 2020-10-24 00:04:50 --> Output Class Initialized
INFO - 2020-10-24 00:04:50 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:50 --> Input Class Initialized
INFO - 2020-10-24 00:04:50 --> Language Class Initialized
INFO - 2020-10-24 00:04:50 --> Loader Class Initialized
INFO - 2020-10-24 00:04:50 --> Helper loaded: url_helper
INFO - 2020-10-24 00:04:50 --> Helper loaded: form_helper
INFO - 2020-10-24 00:04:50 --> Helper loaded: html_helper
INFO - 2020-10-24 00:04:50 --> Helper loaded: date_helper
INFO - 2020-10-24 00:04:50 --> Database Driver Class Initialized
INFO - 2020-10-24 00:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:04:50 --> Table Class Initialized
INFO - 2020-10-24 00:04:50 --> Upload Class Initialized
INFO - 2020-10-24 00:04:50 --> Controller Class Initialized
INFO - 2020-10-24 00:04:50 --> Form Validation Class Initialized
INFO - 2020-10-24 00:04:50 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:04:50 --> Final output sent to browser
DEBUG - 2020-10-24 00:04:50 --> Total execution time: 0.0905
INFO - 2020-10-24 00:04:51 --> Config Class Initialized
INFO - 2020-10-24 00:04:51 --> Config Class Initialized
INFO - 2020-10-24 00:04:51 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:51 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:04:51 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:51 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:51 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:51 --> Config Class Initialized
INFO - 2020-10-24 00:04:51 --> URI Class Initialized
INFO - 2020-10-24 00:04:51 --> URI Class Initialized
INFO - 2020-10-24 00:04:51 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:51 --> Router Class Initialized
INFO - 2020-10-24 00:04:51 --> Router Class Initialized
DEBUG - 2020-10-24 00:04:51 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:04:51 --> Output Class Initialized
INFO - 2020-10-24 00:04:51 --> Config Class Initialized
INFO - 2020-10-24 00:04:51 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:51 --> Output Class Initialized
INFO - 2020-10-24 00:04:51 --> URI Class Initialized
INFO - 2020-10-24 00:04:51 --> Hooks Class Initialized
INFO - 2020-10-24 00:04:51 --> Security Class Initialized
INFO - 2020-10-24 00:04:51 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:51 --> Router Class Initialized
DEBUG - 2020-10-24 00:04:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:51 --> Input Class Initialized
INFO - 2020-10-24 00:04:51 --> Utf8 Class Initialized
INFO - 2020-10-24 00:04:51 --> Input Class Initialized
INFO - 2020-10-24 00:04:51 --> Output Class Initialized
INFO - 2020-10-24 00:04:51 --> URI Class Initialized
INFO - 2020-10-24 00:04:51 --> Language Class Initialized
INFO - 2020-10-24 00:04:51 --> Security Class Initialized
INFO - 2020-10-24 00:04:51 --> Language Class Initialized
ERROR - 2020-10-24 00:04:51 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:51 --> Router Class Initialized
ERROR - 2020-10-24 00:04:51 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 00:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:04:51 --> Input Class Initialized
INFO - 2020-10-24 00:04:51 --> Output Class Initialized
INFO - 2020-10-24 00:04:51 --> Language Class Initialized
INFO - 2020-10-24 00:04:51 --> Security Class Initialized
DEBUG - 2020-10-24 00:04:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 00:04:51 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:04:51 --> Input Class Initialized
INFO - 2020-10-24 00:04:51 --> Language Class Initialized
ERROR - 2020-10-24 00:04:51 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:03 --> Config Class Initialized
INFO - 2020-10-24 00:05:03 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:03 --> URI Class Initialized
INFO - 2020-10-24 00:05:03 --> Router Class Initialized
INFO - 2020-10-24 00:05:03 --> Output Class Initialized
INFO - 2020-10-24 00:05:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:03 --> Input Class Initialized
INFO - 2020-10-24 00:05:03 --> Language Class Initialized
INFO - 2020-10-24 00:05:03 --> Loader Class Initialized
INFO - 2020-10-24 00:05:03 --> Helper loaded: url_helper
INFO - 2020-10-24 00:05:03 --> Helper loaded: form_helper
INFO - 2020-10-24 00:05:03 --> Helper loaded: html_helper
INFO - 2020-10-24 00:05:03 --> Helper loaded: date_helper
INFO - 2020-10-24 00:05:03 --> Database Driver Class Initialized
INFO - 2020-10-24 00:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:05:03 --> Table Class Initialized
INFO - 2020-10-24 00:05:03 --> Upload Class Initialized
INFO - 2020-10-24 00:05:03 --> Controller Class Initialized
INFO - 2020-10-24 00:05:03 --> Form Validation Class Initialized
INFO - 2020-10-24 00:05:03 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:05:03 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:05:03 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:05:03 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:05:03 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:05:03 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:05:03 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:05:03 --> Final output sent to browser
DEBUG - 2020-10-24 00:05:03 --> Total execution time: 0.2296
INFO - 2020-10-24 00:05:03 --> Config Class Initialized
INFO - 2020-10-24 00:05:03 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:03 --> URI Class Initialized
INFO - 2020-10-24 00:05:03 --> Router Class Initialized
INFO - 2020-10-24 00:05:03 --> Output Class Initialized
INFO - 2020-10-24 00:05:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:03 --> Input Class Initialized
INFO - 2020-10-24 00:05:03 --> Language Class Initialized
ERROR - 2020-10-24 00:05:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:05:04 --> Config Class Initialized
INFO - 2020-10-24 00:05:04 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:04 --> Config Class Initialized
INFO - 2020-10-24 00:05:04 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:04 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:04 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:04 --> URI Class Initialized
DEBUG - 2020-10-24 00:05:04 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:04 --> Router Class Initialized
INFO - 2020-10-24 00:05:04 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:04 --> Output Class Initialized
INFO - 2020-10-24 00:05:04 --> URI Class Initialized
INFO - 2020-10-24 00:05:04 --> Security Class Initialized
INFO - 2020-10-24 00:05:04 --> Router Class Initialized
DEBUG - 2020-10-24 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:04 --> Output Class Initialized
INFO - 2020-10-24 00:05:04 --> Input Class Initialized
INFO - 2020-10-24 00:05:04 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:04 --> Language Class Initialized
INFO - 2020-10-24 00:05:04 --> Input Class Initialized
ERROR - 2020-10-24 00:05:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:04 --> Language Class Initialized
ERROR - 2020-10-24 00:05:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:04 --> Config Class Initialized
INFO - 2020-10-24 00:05:04 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:04 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:04 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:04 --> URI Class Initialized
INFO - 2020-10-24 00:05:04 --> Router Class Initialized
INFO - 2020-10-24 00:05:04 --> Output Class Initialized
INFO - 2020-10-24 00:05:04 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:04 --> Input Class Initialized
INFO - 2020-10-24 00:05:04 --> Language Class Initialized
INFO - 2020-10-24 00:05:04 --> Loader Class Initialized
INFO - 2020-10-24 00:05:04 --> Helper loaded: url_helper
INFO - 2020-10-24 00:05:04 --> Helper loaded: form_helper
INFO - 2020-10-24 00:05:04 --> Helper loaded: html_helper
INFO - 2020-10-24 00:05:04 --> Helper loaded: date_helper
INFO - 2020-10-24 00:05:04 --> Database Driver Class Initialized
INFO - 2020-10-24 00:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:05:04 --> Table Class Initialized
INFO - 2020-10-24 00:05:04 --> Upload Class Initialized
INFO - 2020-10-24 00:05:04 --> Controller Class Initialized
INFO - 2020-10-24 00:05:04 --> Form Validation Class Initialized
INFO - 2020-10-24 00:05:04 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:05:04 --> Final output sent to browser
DEBUG - 2020-10-24 00:05:04 --> Total execution time: 0.1137
INFO - 2020-10-24 00:05:04 --> Config Class Initialized
INFO - 2020-10-24 00:05:04 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:04 --> Config Class Initialized
DEBUG - 2020-10-24 00:05:04 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:04 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:04 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:05:04 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:04 --> Config Class Initialized
INFO - 2020-10-24 00:05:04 --> URI Class Initialized
INFO - 2020-10-24 00:05:04 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:04 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:04 --> Router Class Initialized
INFO - 2020-10-24 00:05:04 --> Config Class Initialized
INFO - 2020-10-24 00:05:04 --> URI Class Initialized
DEBUG - 2020-10-24 00:05:04 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:04 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:04 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:04 --> Output Class Initialized
INFO - 2020-10-24 00:05:04 --> Router Class Initialized
INFO - 2020-10-24 00:05:04 --> Output Class Initialized
INFO - 2020-10-24 00:05:04 --> URI Class Initialized
INFO - 2020-10-24 00:05:04 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:04 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:04 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:04 --> Router Class Initialized
INFO - 2020-10-24 00:05:04 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:04 --> Output Class Initialized
DEBUG - 2020-10-24 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:04 --> URI Class Initialized
INFO - 2020-10-24 00:05:04 --> Input Class Initialized
INFO - 2020-10-24 00:05:04 --> Router Class Initialized
INFO - 2020-10-24 00:05:04 --> Security Class Initialized
INFO - 2020-10-24 00:05:04 --> Input Class Initialized
INFO - 2020-10-24 00:05:04 --> Language Class Initialized
DEBUG - 2020-10-24 00:05:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 00:05:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:04 --> Language Class Initialized
INFO - 2020-10-24 00:05:04 --> Output Class Initialized
INFO - 2020-10-24 00:05:04 --> Security Class Initialized
INFO - 2020-10-24 00:05:04 --> Input Class Initialized
ERROR - 2020-10-24 00:05:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:04 --> Language Class Initialized
DEBUG - 2020-10-24 00:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:04 --> Input Class Initialized
ERROR - 2020-10-24 00:05:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:04 --> Language Class Initialized
ERROR - 2020-10-24 00:05:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:11 --> Config Class Initialized
INFO - 2020-10-24 00:05:11 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:11 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:11 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:11 --> URI Class Initialized
INFO - 2020-10-24 00:05:11 --> Router Class Initialized
INFO - 2020-10-24 00:05:11 --> Output Class Initialized
INFO - 2020-10-24 00:05:11 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:11 --> Input Class Initialized
INFO - 2020-10-24 00:05:11 --> Language Class Initialized
INFO - 2020-10-24 00:05:11 --> Loader Class Initialized
INFO - 2020-10-24 00:05:11 --> Helper loaded: url_helper
INFO - 2020-10-24 00:05:11 --> Helper loaded: form_helper
INFO - 2020-10-24 00:05:11 --> Helper loaded: html_helper
INFO - 2020-10-24 00:05:11 --> Helper loaded: date_helper
INFO - 2020-10-24 00:05:11 --> Database Driver Class Initialized
INFO - 2020-10-24 00:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:05:11 --> Table Class Initialized
INFO - 2020-10-24 00:05:11 --> Upload Class Initialized
INFO - 2020-10-24 00:05:11 --> Controller Class Initialized
INFO - 2020-10-24 00:05:11 --> Form Validation Class Initialized
INFO - 2020-10-24 00:05:11 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:05:11 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:05:11 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:05:11 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:05:11 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:05:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:05:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:05:11 --> Final output sent to browser
DEBUG - 2020-10-24 00:05:11 --> Total execution time: 0.1655
INFO - 2020-10-24 00:05:11 --> Config Class Initialized
INFO - 2020-10-24 00:05:11 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:11 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:11 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:11 --> URI Class Initialized
INFO - 2020-10-24 00:05:11 --> Router Class Initialized
INFO - 2020-10-24 00:05:11 --> Output Class Initialized
INFO - 2020-10-24 00:05:11 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:11 --> Input Class Initialized
INFO - 2020-10-24 00:05:11 --> Language Class Initialized
ERROR - 2020-10-24 00:05:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:05:12 --> Config Class Initialized
INFO - 2020-10-24 00:05:12 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:12 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:12 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:12 --> URI Class Initialized
INFO - 2020-10-24 00:05:12 --> Router Class Initialized
INFO - 2020-10-24 00:05:12 --> Output Class Initialized
INFO - 2020-10-24 00:05:12 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:12 --> Input Class Initialized
INFO - 2020-10-24 00:05:12 --> Language Class Initialized
INFO - 2020-10-24 00:05:12 --> Loader Class Initialized
INFO - 2020-10-24 00:05:12 --> Helper loaded: url_helper
INFO - 2020-10-24 00:05:12 --> Helper loaded: form_helper
INFO - 2020-10-24 00:05:12 --> Helper loaded: html_helper
INFO - 2020-10-24 00:05:12 --> Helper loaded: date_helper
INFO - 2020-10-24 00:05:12 --> Database Driver Class Initialized
INFO - 2020-10-24 00:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:05:12 --> Table Class Initialized
INFO - 2020-10-24 00:05:12 --> Upload Class Initialized
INFO - 2020-10-24 00:05:12 --> Controller Class Initialized
INFO - 2020-10-24 00:05:12 --> Form Validation Class Initialized
INFO - 2020-10-24 00:05:12 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:05:12 --> Final output sent to browser
DEBUG - 2020-10-24 00:05:12 --> Total execution time: 0.1279
INFO - 2020-10-24 00:05:13 --> Config Class Initialized
INFO - 2020-10-24 00:05:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:13 --> URI Class Initialized
INFO - 2020-10-24 00:05:13 --> Router Class Initialized
INFO - 2020-10-24 00:05:13 --> Output Class Initialized
INFO - 2020-10-24 00:05:13 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:13 --> Input Class Initialized
INFO - 2020-10-24 00:05:13 --> Language Class Initialized
ERROR - 2020-10-24 00:05:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:13 --> Config Class Initialized
INFO - 2020-10-24 00:05:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:13 --> URI Class Initialized
INFO - 2020-10-24 00:05:13 --> Config Class Initialized
INFO - 2020-10-24 00:05:13 --> Config Class Initialized
INFO - 2020-10-24 00:05:13 --> Config Class Initialized
INFO - 2020-10-24 00:05:13 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:13 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:13 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:13 --> Router Class Initialized
INFO - 2020-10-24 00:05:13 --> Output Class Initialized
DEBUG - 2020-10-24 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:05:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:05:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:13 --> Security Class Initialized
INFO - 2020-10-24 00:05:13 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:13 --> URI Class Initialized
INFO - 2020-10-24 00:05:13 --> URI Class Initialized
INFO - 2020-10-24 00:05:13 --> URI Class Initialized
INFO - 2020-10-24 00:05:13 --> Input Class Initialized
INFO - 2020-10-24 00:05:13 --> Router Class Initialized
INFO - 2020-10-24 00:05:13 --> Router Class Initialized
INFO - 2020-10-24 00:05:13 --> Router Class Initialized
INFO - 2020-10-24 00:05:13 --> Language Class Initialized
INFO - 2020-10-24 00:05:13 --> Output Class Initialized
INFO - 2020-10-24 00:05:13 --> Output Class Initialized
INFO - 2020-10-24 00:05:13 --> Security Class Initialized
ERROR - 2020-10-24 00:05:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:13 --> Security Class Initialized
INFO - 2020-10-24 00:05:13 --> Output Class Initialized
DEBUG - 2020-10-24 00:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:14 --> Security Class Initialized
INFO - 2020-10-24 00:05:14 --> Input Class Initialized
INFO - 2020-10-24 00:05:14 --> Input Class Initialized
DEBUG - 2020-10-24 00:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:14 --> Input Class Initialized
INFO - 2020-10-24 00:05:14 --> Language Class Initialized
INFO - 2020-10-24 00:05:14 --> Language Class Initialized
INFO - 2020-10-24 00:05:14 --> Language Class Initialized
ERROR - 2020-10-24 00:05:14 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:05:14 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:05:14 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:14 --> Config Class Initialized
INFO - 2020-10-24 00:05:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:14 --> URI Class Initialized
INFO - 2020-10-24 00:05:14 --> Router Class Initialized
INFO - 2020-10-24 00:05:14 --> Output Class Initialized
INFO - 2020-10-24 00:05:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:14 --> Input Class Initialized
INFO - 2020-10-24 00:05:14 --> Language Class Initialized
ERROR - 2020-10-24 00:05:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:05:40 --> Config Class Initialized
INFO - 2020-10-24 00:05:40 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:40 --> URI Class Initialized
INFO - 2020-10-24 00:05:40 --> Router Class Initialized
INFO - 2020-10-24 00:05:40 --> Output Class Initialized
INFO - 2020-10-24 00:05:40 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:40 --> Input Class Initialized
INFO - 2020-10-24 00:05:40 --> Language Class Initialized
INFO - 2020-10-24 00:05:40 --> Loader Class Initialized
INFO - 2020-10-24 00:05:40 --> Helper loaded: url_helper
INFO - 2020-10-24 00:05:40 --> Helper loaded: form_helper
INFO - 2020-10-24 00:05:40 --> Helper loaded: html_helper
INFO - 2020-10-24 00:05:40 --> Helper loaded: date_helper
INFO - 2020-10-24 00:05:40 --> Database Driver Class Initialized
INFO - 2020-10-24 00:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:05:40 --> Table Class Initialized
INFO - 2020-10-24 00:05:40 --> Upload Class Initialized
INFO - 2020-10-24 00:05:40 --> Controller Class Initialized
INFO - 2020-10-24 00:05:40 --> Form Validation Class Initialized
INFO - 2020-10-24 00:05:40 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:05:40 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:05:40 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:05:40 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:05:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:05:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:05:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:05:40 --> Final output sent to browser
DEBUG - 2020-10-24 00:05:40 --> Total execution time: 0.2153
INFO - 2020-10-24 00:05:41 --> Config Class Initialized
INFO - 2020-10-24 00:05:41 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:41 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:41 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:41 --> URI Class Initialized
INFO - 2020-10-24 00:05:41 --> Router Class Initialized
INFO - 2020-10-24 00:05:41 --> Output Class Initialized
INFO - 2020-10-24 00:05:41 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:41 --> Input Class Initialized
INFO - 2020-10-24 00:05:41 --> Language Class Initialized
ERROR - 2020-10-24 00:05:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:05:42 --> Config Class Initialized
INFO - 2020-10-24 00:05:42 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:42 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:42 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:42 --> URI Class Initialized
INFO - 2020-10-24 00:05:42 --> Config Class Initialized
INFO - 2020-10-24 00:05:42 --> Hooks Class Initialized
INFO - 2020-10-24 00:05:42 --> Router Class Initialized
DEBUG - 2020-10-24 00:05:42 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:42 --> Output Class Initialized
INFO - 2020-10-24 00:05:42 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:42 --> Security Class Initialized
INFO - 2020-10-24 00:05:42 --> URI Class Initialized
DEBUG - 2020-10-24 00:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:42 --> Router Class Initialized
INFO - 2020-10-24 00:05:42 --> Input Class Initialized
INFO - 2020-10-24 00:05:42 --> Language Class Initialized
INFO - 2020-10-24 00:05:42 --> Output Class Initialized
INFO - 2020-10-24 00:05:42 --> Security Class Initialized
INFO - 2020-10-24 00:05:42 --> Loader Class Initialized
INFO - 2020-10-24 00:05:42 --> Helper loaded: url_helper
DEBUG - 2020-10-24 00:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:42 --> Input Class Initialized
INFO - 2020-10-24 00:05:42 --> Helper loaded: form_helper
INFO - 2020-10-24 00:05:42 --> Helper loaded: html_helper
INFO - 2020-10-24 00:05:42 --> Language Class Initialized
ERROR - 2020-10-24 00:05:42 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:42 --> Helper loaded: date_helper
INFO - 2020-10-24 00:05:42 --> Database Driver Class Initialized
INFO - 2020-10-24 00:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:05:42 --> Table Class Initialized
INFO - 2020-10-24 00:05:42 --> Upload Class Initialized
INFO - 2020-10-24 00:05:42 --> Controller Class Initialized
INFO - 2020-10-24 00:05:42 --> Form Validation Class Initialized
INFO - 2020-10-24 00:05:42 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:05:42 --> Final output sent to browser
DEBUG - 2020-10-24 00:05:42 --> Total execution time: 0.1557
INFO - 2020-10-24 00:05:43 --> Config Class Initialized
INFO - 2020-10-24 00:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:43 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:43 --> URI Class Initialized
INFO - 2020-10-24 00:05:43 --> Router Class Initialized
INFO - 2020-10-24 00:05:43 --> Output Class Initialized
INFO - 2020-10-24 00:05:43 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:43 --> Input Class Initialized
INFO - 2020-10-24 00:05:43 --> Language Class Initialized
ERROR - 2020-10-24 00:05:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:43 --> Config Class Initialized
INFO - 2020-10-24 00:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:43 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:43 --> URI Class Initialized
INFO - 2020-10-24 00:05:43 --> Router Class Initialized
INFO - 2020-10-24 00:05:43 --> Output Class Initialized
INFO - 2020-10-24 00:05:43 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:43 --> Input Class Initialized
INFO - 2020-10-24 00:05:43 --> Language Class Initialized
ERROR - 2020-10-24 00:05:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:43 --> Config Class Initialized
INFO - 2020-10-24 00:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:43 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:43 --> URI Class Initialized
INFO - 2020-10-24 00:05:43 --> Router Class Initialized
INFO - 2020-10-24 00:05:43 --> Output Class Initialized
INFO - 2020-10-24 00:05:43 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:43 --> Input Class Initialized
INFO - 2020-10-24 00:05:43 --> Language Class Initialized
ERROR - 2020-10-24 00:05:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:43 --> Config Class Initialized
INFO - 2020-10-24 00:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:43 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:43 --> URI Class Initialized
INFO - 2020-10-24 00:05:43 --> Router Class Initialized
INFO - 2020-10-24 00:05:43 --> Output Class Initialized
INFO - 2020-10-24 00:05:43 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:43 --> Input Class Initialized
INFO - 2020-10-24 00:05:43 --> Language Class Initialized
ERROR - 2020-10-24 00:05:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:43 --> Config Class Initialized
INFO - 2020-10-24 00:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:43 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:43 --> URI Class Initialized
INFO - 2020-10-24 00:05:43 --> Router Class Initialized
INFO - 2020-10-24 00:05:43 --> Output Class Initialized
INFO - 2020-10-24 00:05:43 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:43 --> Input Class Initialized
INFO - 2020-10-24 00:05:43 --> Language Class Initialized
ERROR - 2020-10-24 00:05:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:05:43 --> Config Class Initialized
INFO - 2020-10-24 00:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:05:43 --> Utf8 Class Initialized
INFO - 2020-10-24 00:05:43 --> URI Class Initialized
INFO - 2020-10-24 00:05:43 --> Router Class Initialized
INFO - 2020-10-24 00:05:43 --> Output Class Initialized
INFO - 2020-10-24 00:05:43 --> Security Class Initialized
DEBUG - 2020-10-24 00:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:05:43 --> Input Class Initialized
INFO - 2020-10-24 00:05:43 --> Language Class Initialized
ERROR - 2020-10-24 00:05:43 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:13 --> Config Class Initialized
INFO - 2020-10-24 00:06:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:13 --> URI Class Initialized
INFO - 2020-10-24 00:06:13 --> Router Class Initialized
INFO - 2020-10-24 00:06:13 --> Output Class Initialized
INFO - 2020-10-24 00:06:13 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:13 --> Input Class Initialized
INFO - 2020-10-24 00:06:13 --> Language Class Initialized
INFO - 2020-10-24 00:06:13 --> Loader Class Initialized
INFO - 2020-10-24 00:06:13 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:13 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:13 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:13 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:13 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:13 --> Table Class Initialized
INFO - 2020-10-24 00:06:13 --> Upload Class Initialized
INFO - 2020-10-24 00:06:13 --> Controller Class Initialized
INFO - 2020-10-24 00:06:13 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:13 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:13 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:06:13 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:06:13 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:06:13 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:06:13 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:06:13 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:06:13 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:13 --> Total execution time: 0.3848
INFO - 2020-10-24 00:06:13 --> Config Class Initialized
INFO - 2020-10-24 00:06:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:13 --> URI Class Initialized
INFO - 2020-10-24 00:06:13 --> Router Class Initialized
INFO - 2020-10-24 00:06:13 --> Output Class Initialized
INFO - 2020-10-24 00:06:13 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:13 --> Input Class Initialized
INFO - 2020-10-24 00:06:13 --> Language Class Initialized
ERROR - 2020-10-24 00:06:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:13 --> Config Class Initialized
INFO - 2020-10-24 00:06:13 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:13 --> Config Class Initialized
DEBUG - 2020-10-24 00:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:13 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:13 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:13 --> URI Class Initialized
INFO - 2020-10-24 00:06:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:13 --> URI Class Initialized
INFO - 2020-10-24 00:06:13 --> Router Class Initialized
INFO - 2020-10-24 00:06:13 --> Router Class Initialized
INFO - 2020-10-24 00:06:13 --> Output Class Initialized
INFO - 2020-10-24 00:06:13 --> Security Class Initialized
INFO - 2020-10-24 00:06:13 --> Output Class Initialized
DEBUG - 2020-10-24 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:13 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:13 --> Input Class Initialized
INFO - 2020-10-24 00:06:13 --> Language Class Initialized
INFO - 2020-10-24 00:06:13 --> Input Class Initialized
INFO - 2020-10-24 00:06:13 --> Language Class Initialized
ERROR - 2020-10-24 00:06:13 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:06:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:13 --> Config Class Initialized
INFO - 2020-10-24 00:06:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:13 --> URI Class Initialized
INFO - 2020-10-24 00:06:13 --> Router Class Initialized
INFO - 2020-10-24 00:06:13 --> Output Class Initialized
INFO - 2020-10-24 00:06:13 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:13 --> Input Class Initialized
INFO - 2020-10-24 00:06:13 --> Language Class Initialized
INFO - 2020-10-24 00:06:13 --> Loader Class Initialized
INFO - 2020-10-24 00:06:14 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:14 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:14 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:14 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:14 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:14 --> Table Class Initialized
INFO - 2020-10-24 00:06:14 --> Upload Class Initialized
INFO - 2020-10-24 00:06:14 --> Controller Class Initialized
INFO - 2020-10-24 00:06:14 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:14 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:14 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:14 --> Total execution time: 0.1112
INFO - 2020-10-24 00:06:14 --> Config Class Initialized
INFO - 2020-10-24 00:06:14 --> Config Class Initialized
INFO - 2020-10-24 00:06:14 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:14 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:06:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:14 --> URI Class Initialized
INFO - 2020-10-24 00:06:14 --> Router Class Initialized
INFO - 2020-10-24 00:06:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:14 --> Output Class Initialized
INFO - 2020-10-24 00:06:14 --> URI Class Initialized
INFO - 2020-10-24 00:06:14 --> Router Class Initialized
INFO - 2020-10-24 00:06:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:14 --> Output Class Initialized
INFO - 2020-10-24 00:06:14 --> Input Class Initialized
INFO - 2020-10-24 00:06:14 --> Security Class Initialized
INFO - 2020-10-24 00:06:14 --> Language Class Initialized
INFO - 2020-10-24 00:06:14 --> Config Class Initialized
DEBUG - 2020-10-24 00:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:14 --> Hooks Class Initialized
ERROR - 2020-10-24 00:06:14 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:14 --> Input Class Initialized
INFO - 2020-10-24 00:06:14 --> Config Class Initialized
INFO - 2020-10-24 00:06:14 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:14 --> Language Class Initialized
DEBUG - 2020-10-24 00:06:14 --> UTF-8 Support Enabled
ERROR - 2020-10-24 00:06:14 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:14 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:06:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:14 --> URI Class Initialized
INFO - 2020-10-24 00:06:14 --> URI Class Initialized
INFO - 2020-10-24 00:06:14 --> Router Class Initialized
INFO - 2020-10-24 00:06:14 --> Router Class Initialized
INFO - 2020-10-24 00:06:14 --> Output Class Initialized
INFO - 2020-10-24 00:06:14 --> Output Class Initialized
INFO - 2020-10-24 00:06:14 --> Security Class Initialized
INFO - 2020-10-24 00:06:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:14 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:14 --> Input Class Initialized
INFO - 2020-10-24 00:06:14 --> Language Class Initialized
INFO - 2020-10-24 00:06:14 --> Language Class Initialized
ERROR - 2020-10-24 00:06:14 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:06:14 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:23 --> Config Class Initialized
INFO - 2020-10-24 00:06:23 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:23 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:23 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:23 --> URI Class Initialized
INFO - 2020-10-24 00:06:23 --> Router Class Initialized
INFO - 2020-10-24 00:06:23 --> Output Class Initialized
INFO - 2020-10-24 00:06:23 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:23 --> Input Class Initialized
INFO - 2020-10-24 00:06:23 --> Language Class Initialized
INFO - 2020-10-24 00:06:23 --> Loader Class Initialized
INFO - 2020-10-24 00:06:23 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:23 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:23 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:23 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:23 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:23 --> Table Class Initialized
INFO - 2020-10-24 00:06:23 --> Upload Class Initialized
INFO - 2020-10-24 00:06:23 --> Controller Class Initialized
INFO - 2020-10-24 00:06:23 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:23 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:23 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:06:23 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:06:23 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:06:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:06:23 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:06:23 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:06:23 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:23 --> Total execution time: 0.2390
INFO - 2020-10-24 00:06:23 --> Config Class Initialized
INFO - 2020-10-24 00:06:23 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:23 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:23 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:23 --> URI Class Initialized
INFO - 2020-10-24 00:06:23 --> Router Class Initialized
INFO - 2020-10-24 00:06:23 --> Output Class Initialized
INFO - 2020-10-24 00:06:23 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:23 --> Input Class Initialized
INFO - 2020-10-24 00:06:23 --> Language Class Initialized
ERROR - 2020-10-24 00:06:23 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:25 --> Config Class Initialized
INFO - 2020-10-24 00:06:25 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:25 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:25 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:25 --> URI Class Initialized
INFO - 2020-10-24 00:06:25 --> Router Class Initialized
INFO - 2020-10-24 00:06:25 --> Output Class Initialized
INFO - 2020-10-24 00:06:25 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:25 --> Input Class Initialized
INFO - 2020-10-24 00:06:25 --> Language Class Initialized
INFO - 2020-10-24 00:06:25 --> Loader Class Initialized
INFO - 2020-10-24 00:06:25 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:25 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:25 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:25 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:25 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:25 --> Table Class Initialized
INFO - 2020-10-24 00:06:25 --> Upload Class Initialized
INFO - 2020-10-24 00:06:25 --> Controller Class Initialized
INFO - 2020-10-24 00:06:25 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:25 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:25 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:25 --> Total execution time: 0.2003
INFO - 2020-10-24 00:06:25 --> Config Class Initialized
INFO - 2020-10-24 00:06:25 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:25 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:25 --> Config Class Initialized
INFO - 2020-10-24 00:06:25 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:25 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:25 --> URI Class Initialized
DEBUG - 2020-10-24 00:06:25 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:25 --> Router Class Initialized
INFO - 2020-10-24 00:06:25 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:25 --> URI Class Initialized
INFO - 2020-10-24 00:06:25 --> Output Class Initialized
INFO - 2020-10-24 00:06:25 --> Security Class Initialized
INFO - 2020-10-24 00:06:25 --> Router Class Initialized
INFO - 2020-10-24 00:06:25 --> Output Class Initialized
DEBUG - 2020-10-24 00:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:25 --> Input Class Initialized
INFO - 2020-10-24 00:06:25 --> Security Class Initialized
INFO - 2020-10-24 00:06:25 --> Language Class Initialized
DEBUG - 2020-10-24 00:06:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 00:06:25 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:25 --> Input Class Initialized
INFO - 2020-10-24 00:06:25 --> Language Class Initialized
ERROR - 2020-10-24 00:06:25 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:26 --> Config Class Initialized
INFO - 2020-10-24 00:06:26 --> Config Class Initialized
INFO - 2020-10-24 00:06:26 --> Config Class Initialized
INFO - 2020-10-24 00:06:26 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:26 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:06:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:26 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:26 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:06:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:26 --> URI Class Initialized
INFO - 2020-10-24 00:06:26 --> URI Class Initialized
INFO - 2020-10-24 00:06:26 --> Router Class Initialized
INFO - 2020-10-24 00:06:26 --> Router Class Initialized
INFO - 2020-10-24 00:06:26 --> URI Class Initialized
INFO - 2020-10-24 00:06:26 --> Output Class Initialized
INFO - 2020-10-24 00:06:26 --> Router Class Initialized
INFO - 2020-10-24 00:06:26 --> Output Class Initialized
INFO - 2020-10-24 00:06:26 --> Security Class Initialized
INFO - 2020-10-24 00:06:26 --> Output Class Initialized
INFO - 2020-10-24 00:06:26 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:26 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:26 --> Input Class Initialized
INFO - 2020-10-24 00:06:26 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:26 --> Language Class Initialized
INFO - 2020-10-24 00:06:26 --> Input Class Initialized
INFO - 2020-10-24 00:06:26 --> Language Class Initialized
INFO - 2020-10-24 00:06:26 --> Language Class Initialized
ERROR - 2020-10-24 00:06:26 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:06:26 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:06:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:26 --> Config Class Initialized
INFO - 2020-10-24 00:06:26 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:26 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:26 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:26 --> URI Class Initialized
INFO - 2020-10-24 00:06:26 --> Router Class Initialized
INFO - 2020-10-24 00:06:26 --> Output Class Initialized
INFO - 2020-10-24 00:06:26 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:26 --> Input Class Initialized
INFO - 2020-10-24 00:06:26 --> Language Class Initialized
ERROR - 2020-10-24 00:06:26 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:32 --> Config Class Initialized
INFO - 2020-10-24 00:06:32 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:32 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:32 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:32 --> URI Class Initialized
INFO - 2020-10-24 00:06:32 --> Router Class Initialized
INFO - 2020-10-24 00:06:32 --> Output Class Initialized
INFO - 2020-10-24 00:06:32 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:32 --> Input Class Initialized
INFO - 2020-10-24 00:06:32 --> Language Class Initialized
INFO - 2020-10-24 00:06:32 --> Loader Class Initialized
INFO - 2020-10-24 00:06:32 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:32 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:32 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:32 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:32 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:32 --> Table Class Initialized
INFO - 2020-10-24 00:06:32 --> Upload Class Initialized
INFO - 2020-10-24 00:06:32 --> Controller Class Initialized
INFO - 2020-10-24 00:06:32 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:32 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:32 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:06:32 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:06:32 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:06:32 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:06:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:06:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:06:32 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:32 --> Total execution time: 0.1554
INFO - 2020-10-24 00:06:32 --> Config Class Initialized
INFO - 2020-10-24 00:06:32 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:32 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:32 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:32 --> URI Class Initialized
INFO - 2020-10-24 00:06:32 --> Router Class Initialized
INFO - 2020-10-24 00:06:32 --> Output Class Initialized
INFO - 2020-10-24 00:06:32 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:32 --> Input Class Initialized
INFO - 2020-10-24 00:06:32 --> Language Class Initialized
ERROR - 2020-10-24 00:06:32 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:32 --> Config Class Initialized
INFO - 2020-10-24 00:06:32 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:32 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:32 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:32 --> URI Class Initialized
INFO - 2020-10-24 00:06:32 --> Router Class Initialized
INFO - 2020-10-24 00:06:32 --> Output Class Initialized
INFO - 2020-10-24 00:06:32 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:32 --> Input Class Initialized
INFO - 2020-10-24 00:06:32 --> Language Class Initialized
ERROR - 2020-10-24 00:06:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:32 --> Config Class Initialized
INFO - 2020-10-24 00:06:32 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:32 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:32 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:32 --> URI Class Initialized
INFO - 2020-10-24 00:06:33 --> Router Class Initialized
INFO - 2020-10-24 00:06:33 --> Output Class Initialized
INFO - 2020-10-24 00:06:33 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:33 --> Config Class Initialized
INFO - 2020-10-24 00:06:33 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:33 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:33 --> Language Class Initialized
INFO - 2020-10-24 00:06:33 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:33 --> Loader Class Initialized
INFO - 2020-10-24 00:06:33 --> URI Class Initialized
INFO - 2020-10-24 00:06:33 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:33 --> Router Class Initialized
INFO - 2020-10-24 00:06:33 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:33 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:33 --> Output Class Initialized
INFO - 2020-10-24 00:06:33 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:33 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:33 --> Input Class Initialized
INFO - 2020-10-24 00:06:33 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:33 --> Language Class Initialized
ERROR - 2020-10-24 00:06:33 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:33 --> Table Class Initialized
INFO - 2020-10-24 00:06:33 --> Upload Class Initialized
INFO - 2020-10-24 00:06:33 --> Controller Class Initialized
INFO - 2020-10-24 00:06:33 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:33 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:33 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:33 --> Total execution time: 0.1335
INFO - 2020-10-24 00:06:33 --> Config Class Initialized
INFO - 2020-10-24 00:06:33 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:33 --> Config Class Initialized
INFO - 2020-10-24 00:06:33 --> Config Class Initialized
DEBUG - 2020-10-24 00:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:33 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:33 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:33 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:33 --> URI Class Initialized
INFO - 2020-10-24 00:06:33 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:33 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:33 --> URI Class Initialized
INFO - 2020-10-24 00:06:33 --> URI Class Initialized
INFO - 2020-10-24 00:06:33 --> Router Class Initialized
INFO - 2020-10-24 00:06:34 --> Router Class Initialized
INFO - 2020-10-24 00:06:34 --> Router Class Initialized
INFO - 2020-10-24 00:06:34 --> Output Class Initialized
INFO - 2020-10-24 00:06:34 --> Security Class Initialized
INFO - 2020-10-24 00:06:34 --> Output Class Initialized
INFO - 2020-10-24 00:06:34 --> Output Class Initialized
INFO - 2020-10-24 00:06:34 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:34 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:34 --> Input Class Initialized
INFO - 2020-10-24 00:06:34 --> Input Class Initialized
INFO - 2020-10-24 00:06:34 --> Language Class Initialized
INFO - 2020-10-24 00:06:34 --> Input Class Initialized
ERROR - 2020-10-24 00:06:34 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:34 --> Language Class Initialized
INFO - 2020-10-24 00:06:34 --> Language Class Initialized
ERROR - 2020-10-24 00:06:34 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:06:34 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:34 --> Config Class Initialized
INFO - 2020-10-24 00:06:34 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:34 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:34 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:34 --> URI Class Initialized
INFO - 2020-10-24 00:06:34 --> Router Class Initialized
INFO - 2020-10-24 00:06:34 --> Output Class Initialized
INFO - 2020-10-24 00:06:34 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:34 --> Input Class Initialized
INFO - 2020-10-24 00:06:34 --> Language Class Initialized
ERROR - 2020-10-24 00:06:34 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:54 --> Config Class Initialized
INFO - 2020-10-24 00:06:54 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:54 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:54 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:54 --> URI Class Initialized
INFO - 2020-10-24 00:06:54 --> Router Class Initialized
INFO - 2020-10-24 00:06:54 --> Output Class Initialized
INFO - 2020-10-24 00:06:54 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:55 --> Input Class Initialized
INFO - 2020-10-24 00:06:55 --> Language Class Initialized
INFO - 2020-10-24 00:06:55 --> Loader Class Initialized
INFO - 2020-10-24 00:06:55 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:55 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:55 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:55 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:55 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:55 --> Table Class Initialized
INFO - 2020-10-24 00:06:55 --> Upload Class Initialized
INFO - 2020-10-24 00:06:55 --> Controller Class Initialized
INFO - 2020-10-24 00:06:55 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:55 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:55 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:06:55 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:06:55 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:06:55 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:06:55 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:06:55 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:06:55 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:55 --> Total execution time: 0.4227
INFO - 2020-10-24 00:06:55 --> Config Class Initialized
INFO - 2020-10-24 00:06:55 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:55 --> URI Class Initialized
INFO - 2020-10-24 00:06:55 --> Router Class Initialized
INFO - 2020-10-24 00:06:55 --> Output Class Initialized
INFO - 2020-10-24 00:06:55 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:55 --> Input Class Initialized
INFO - 2020-10-24 00:06:55 --> Language Class Initialized
ERROR - 2020-10-24 00:06:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:55 --> Config Class Initialized
INFO - 2020-10-24 00:06:55 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:55 --> URI Class Initialized
INFO - 2020-10-24 00:06:55 --> Router Class Initialized
INFO - 2020-10-24 00:06:55 --> Output Class Initialized
INFO - 2020-10-24 00:06:55 --> Config Class Initialized
INFO - 2020-10-24 00:06:55 --> Security Class Initialized
INFO - 2020-10-24 00:06:55 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:55 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:55 --> Language Class Initialized
ERROR - 2020-10-24 00:06:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:55 --> URI Class Initialized
INFO - 2020-10-24 00:06:55 --> Router Class Initialized
INFO - 2020-10-24 00:06:55 --> Output Class Initialized
INFO - 2020-10-24 00:06:55 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:55 --> Input Class Initialized
INFO - 2020-10-24 00:06:55 --> Language Class Initialized
ERROR - 2020-10-24 00:06:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:55 --> Config Class Initialized
INFO - 2020-10-24 00:06:55 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:55 --> URI Class Initialized
INFO - 2020-10-24 00:06:55 --> Router Class Initialized
INFO - 2020-10-24 00:06:55 --> Output Class Initialized
INFO - 2020-10-24 00:06:55 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:55 --> Input Class Initialized
INFO - 2020-10-24 00:06:55 --> Language Class Initialized
INFO - 2020-10-24 00:06:55 --> Loader Class Initialized
INFO - 2020-10-24 00:06:55 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:55 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:55 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:55 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:55 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:55 --> Table Class Initialized
INFO - 2020-10-24 00:06:55 --> Upload Class Initialized
INFO - 2020-10-24 00:06:55 --> Controller Class Initialized
INFO - 2020-10-24 00:06:55 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:55 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:55 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:55 --> Total execution time: 0.1349
INFO - 2020-10-24 00:06:56 --> Config Class Initialized
INFO - 2020-10-24 00:06:56 --> Config Class Initialized
INFO - 2020-10-24 00:06:56 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:56 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:56 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:56 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:06:56 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:56 --> URI Class Initialized
INFO - 2020-10-24 00:06:56 --> Config Class Initialized
INFO - 2020-10-24 00:06:56 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:56 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:56 --> Router Class Initialized
INFO - 2020-10-24 00:06:56 --> Config Class Initialized
INFO - 2020-10-24 00:06:56 --> URI Class Initialized
INFO - 2020-10-24 00:06:56 --> Router Class Initialized
INFO - 2020-10-24 00:06:56 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:56 --> Output Class Initialized
DEBUG - 2020-10-24 00:06:56 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:56 --> Security Class Initialized
INFO - 2020-10-24 00:06:56 --> Output Class Initialized
DEBUG - 2020-10-24 00:06:56 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:56 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:56 --> URI Class Initialized
INFO - 2020-10-24 00:06:56 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:56 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:56 --> URI Class Initialized
INFO - 2020-10-24 00:06:56 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:56 --> Router Class Initialized
INFO - 2020-10-24 00:06:56 --> Language Class Initialized
INFO - 2020-10-24 00:06:56 --> Input Class Initialized
INFO - 2020-10-24 00:06:56 --> Output Class Initialized
INFO - 2020-10-24 00:06:56 --> Router Class Initialized
INFO - 2020-10-24 00:06:56 --> Security Class Initialized
INFO - 2020-10-24 00:06:56 --> Language Class Initialized
ERROR - 2020-10-24 00:06:56 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:56 --> Output Class Initialized
ERROR - 2020-10-24 00:06:56 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 00:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:56 --> Security Class Initialized
INFO - 2020-10-24 00:06:56 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:56 --> Input Class Initialized
INFO - 2020-10-24 00:06:56 --> Language Class Initialized
INFO - 2020-10-24 00:06:56 --> Language Class Initialized
ERROR - 2020-10-24 00:06:56 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:06:56 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:58 --> Config Class Initialized
INFO - 2020-10-24 00:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:58 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:58 --> URI Class Initialized
INFO - 2020-10-24 00:06:58 --> Router Class Initialized
INFO - 2020-10-24 00:06:58 --> Output Class Initialized
INFO - 2020-10-24 00:06:58 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:58 --> Input Class Initialized
INFO - 2020-10-24 00:06:58 --> Language Class Initialized
INFO - 2020-10-24 00:06:58 --> Loader Class Initialized
INFO - 2020-10-24 00:06:58 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:58 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:58 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:58 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:58 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:58 --> Table Class Initialized
INFO - 2020-10-24 00:06:58 --> Upload Class Initialized
INFO - 2020-10-24 00:06:58 --> Controller Class Initialized
INFO - 2020-10-24 00:06:58 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:58 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:58 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:06:58 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:06:58 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:06:58 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:06:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:06:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:06:58 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:58 --> Total execution time: 0.2079
INFO - 2020-10-24 00:06:58 --> Config Class Initialized
INFO - 2020-10-24 00:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:58 --> Config Class Initialized
INFO - 2020-10-24 00:06:58 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:58 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:58 --> URI Class Initialized
DEBUG - 2020-10-24 00:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:58 --> Router Class Initialized
INFO - 2020-10-24 00:06:58 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:58 --> Output Class Initialized
INFO - 2020-10-24 00:06:58 --> URI Class Initialized
INFO - 2020-10-24 00:06:58 --> Security Class Initialized
INFO - 2020-10-24 00:06:58 --> Router Class Initialized
INFO - 2020-10-24 00:06:58 --> Output Class Initialized
DEBUG - 2020-10-24 00:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:58 --> Security Class Initialized
INFO - 2020-10-24 00:06:58 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:58 --> Language Class Initialized
ERROR - 2020-10-24 00:06:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:06:58 --> Input Class Initialized
INFO - 2020-10-24 00:06:58 --> Language Class Initialized
ERROR - 2020-10-24 00:06:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:58 --> Config Class Initialized
INFO - 2020-10-24 00:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:58 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:59 --> URI Class Initialized
INFO - 2020-10-24 00:06:59 --> Config Class Initialized
INFO - 2020-10-24 00:06:59 --> Router Class Initialized
INFO - 2020-10-24 00:06:59 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:59 --> Output Class Initialized
DEBUG - 2020-10-24 00:06:59 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:59 --> Security Class Initialized
INFO - 2020-10-24 00:06:59 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:59 --> URI Class Initialized
INFO - 2020-10-24 00:06:59 --> Input Class Initialized
INFO - 2020-10-24 00:06:59 --> Router Class Initialized
INFO - 2020-10-24 00:06:59 --> Language Class Initialized
INFO - 2020-10-24 00:06:59 --> Output Class Initialized
ERROR - 2020-10-24 00:06:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:59 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:59 --> Input Class Initialized
INFO - 2020-10-24 00:06:59 --> Language Class Initialized
INFO - 2020-10-24 00:06:59 --> Loader Class Initialized
INFO - 2020-10-24 00:06:59 --> Helper loaded: url_helper
INFO - 2020-10-24 00:06:59 --> Helper loaded: form_helper
INFO - 2020-10-24 00:06:59 --> Helper loaded: html_helper
INFO - 2020-10-24 00:06:59 --> Helper loaded: date_helper
INFO - 2020-10-24 00:06:59 --> Database Driver Class Initialized
INFO - 2020-10-24 00:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:06:59 --> Table Class Initialized
INFO - 2020-10-24 00:06:59 --> Upload Class Initialized
INFO - 2020-10-24 00:06:59 --> Controller Class Initialized
INFO - 2020-10-24 00:06:59 --> Form Validation Class Initialized
INFO - 2020-10-24 00:06:59 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:06:59 --> Final output sent to browser
DEBUG - 2020-10-24 00:06:59 --> Total execution time: 0.1932
INFO - 2020-10-24 00:06:59 --> Config Class Initialized
INFO - 2020-10-24 00:06:59 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:59 --> Config Class Initialized
DEBUG - 2020-10-24 00:06:59 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:59 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:59 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:59 --> Config Class Initialized
INFO - 2020-10-24 00:06:59 --> Config Class Initialized
DEBUG - 2020-10-24 00:06:59 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:59 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:59 --> URI Class Initialized
INFO - 2020-10-24 00:06:59 --> Hooks Class Initialized
INFO - 2020-10-24 00:06:59 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:59 --> URI Class Initialized
DEBUG - 2020-10-24 00:06:59 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:59 --> Router Class Initialized
DEBUG - 2020-10-24 00:06:59 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:06:59 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:59 --> Utf8 Class Initialized
INFO - 2020-10-24 00:06:59 --> Router Class Initialized
INFO - 2020-10-24 00:06:59 --> Output Class Initialized
INFO - 2020-10-24 00:06:59 --> URI Class Initialized
INFO - 2020-10-24 00:06:59 --> URI Class Initialized
INFO - 2020-10-24 00:06:59 --> Security Class Initialized
INFO - 2020-10-24 00:06:59 --> Output Class Initialized
INFO - 2020-10-24 00:06:59 --> Router Class Initialized
INFO - 2020-10-24 00:06:59 --> Router Class Initialized
INFO - 2020-10-24 00:06:59 --> Security Class Initialized
DEBUG - 2020-10-24 00:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:59 --> Input Class Initialized
DEBUG - 2020-10-24 00:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:59 --> Output Class Initialized
INFO - 2020-10-24 00:06:59 --> Output Class Initialized
INFO - 2020-10-24 00:06:59 --> Input Class Initialized
INFO - 2020-10-24 00:06:59 --> Security Class Initialized
INFO - 2020-10-24 00:06:59 --> Security Class Initialized
INFO - 2020-10-24 00:06:59 --> Language Class Initialized
DEBUG - 2020-10-24 00:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:06:59 --> Language Class Initialized
ERROR - 2020-10-24 00:06:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:59 --> Input Class Initialized
ERROR - 2020-10-24 00:06:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:06:59 --> Input Class Initialized
INFO - 2020-10-24 00:06:59 --> Language Class Initialized
INFO - 2020-10-24 00:06:59 --> Language Class Initialized
ERROR - 2020-10-24 00:06:59 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:06:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:07:13 --> Config Class Initialized
INFO - 2020-10-24 00:07:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:07:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:07:13 --> Utf8 Class Initialized
INFO - 2020-10-24 00:07:13 --> URI Class Initialized
INFO - 2020-10-24 00:07:13 --> Router Class Initialized
INFO - 2020-10-24 00:07:13 --> Output Class Initialized
INFO - 2020-10-24 00:07:13 --> Security Class Initialized
DEBUG - 2020-10-24 00:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:07:13 --> Input Class Initialized
INFO - 2020-10-24 00:07:13 --> Language Class Initialized
INFO - 2020-10-24 00:07:13 --> Loader Class Initialized
INFO - 2020-10-24 00:07:13 --> Helper loaded: url_helper
INFO - 2020-10-24 00:07:13 --> Helper loaded: form_helper
INFO - 2020-10-24 00:07:13 --> Helper loaded: html_helper
INFO - 2020-10-24 00:07:13 --> Helper loaded: date_helper
INFO - 2020-10-24 00:07:13 --> Database Driver Class Initialized
INFO - 2020-10-24 00:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:07:13 --> Table Class Initialized
INFO - 2020-10-24 00:07:13 --> Upload Class Initialized
INFO - 2020-10-24 00:07:13 --> Controller Class Initialized
INFO - 2020-10-24 00:07:13 --> Form Validation Class Initialized
INFO - 2020-10-24 00:07:13 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:07:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-10-24 00:07:13 --> Final output sent to browser
DEBUG - 2020-10-24 00:07:13 --> Total execution time: 0.2743
INFO - 2020-10-24 00:07:14 --> Config Class Initialized
INFO - 2020-10-24 00:07:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:07:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:07:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:07:14 --> URI Class Initialized
INFO - 2020-10-24 00:07:14 --> Router Class Initialized
INFO - 2020-10-24 00:07:14 --> Output Class Initialized
INFO - 2020-10-24 00:07:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:07:14 --> Input Class Initialized
INFO - 2020-10-24 00:07:14 --> Language Class Initialized
INFO - 2020-10-24 00:07:14 --> Loader Class Initialized
INFO - 2020-10-24 00:07:14 --> Helper loaded: url_helper
INFO - 2020-10-24 00:07:14 --> Helper loaded: form_helper
INFO - 2020-10-24 00:07:14 --> Helper loaded: html_helper
INFO - 2020-10-24 00:07:14 --> Helper loaded: date_helper
INFO - 2020-10-24 00:07:14 --> Database Driver Class Initialized
INFO - 2020-10-24 00:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:07:14 --> Table Class Initialized
INFO - 2020-10-24 00:07:14 --> Upload Class Initialized
INFO - 2020-10-24 00:07:14 --> Controller Class Initialized
INFO - 2020-10-24 00:07:14 --> Form Validation Class Initialized
INFO - 2020-10-24 00:07:14 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:07:14 --> Final output sent to browser
DEBUG - 2020-10-24 00:07:14 --> Total execution time: 0.1591
INFO - 2020-10-24 00:09:07 --> Config Class Initialized
INFO - 2020-10-24 00:09:07 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:07 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:07 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:07 --> URI Class Initialized
INFO - 2020-10-24 00:09:07 --> Router Class Initialized
INFO - 2020-10-24 00:09:07 --> Output Class Initialized
INFO - 2020-10-24 00:09:07 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:07 --> Input Class Initialized
INFO - 2020-10-24 00:09:07 --> Language Class Initialized
INFO - 2020-10-24 00:09:07 --> Loader Class Initialized
INFO - 2020-10-24 00:09:07 --> Helper loaded: url_helper
INFO - 2020-10-24 00:09:07 --> Helper loaded: form_helper
INFO - 2020-10-24 00:09:07 --> Helper loaded: html_helper
INFO - 2020-10-24 00:09:07 --> Helper loaded: date_helper
INFO - 2020-10-24 00:09:07 --> Database Driver Class Initialized
INFO - 2020-10-24 00:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:09:07 --> Table Class Initialized
INFO - 2020-10-24 00:09:07 --> Upload Class Initialized
INFO - 2020-10-24 00:09:07 --> Controller Class Initialized
INFO - 2020-10-24 00:09:07 --> Form Validation Class Initialized
INFO - 2020-10-24 00:09:07 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:09:07 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:09:07 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:09:07 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:09:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:09:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:09:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:09:07 --> Final output sent to browser
DEBUG - 2020-10-24 00:09:07 --> Total execution time: 0.4052
INFO - 2020-10-24 00:09:07 --> Config Class Initialized
INFO - 2020-10-24 00:09:07 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:07 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:07 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:07 --> URI Class Initialized
INFO - 2020-10-24 00:09:07 --> Router Class Initialized
INFO - 2020-10-24 00:09:07 --> Output Class Initialized
INFO - 2020-10-24 00:09:07 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:07 --> Config Class Initialized
INFO - 2020-10-24 00:09:07 --> Input Class Initialized
INFO - 2020-10-24 00:09:07 --> Language Class Initialized
INFO - 2020-10-24 00:09:07 --> Hooks Class Initialized
ERROR - 2020-10-24 00:09:07 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-24 00:09:07 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:07 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:07 --> URI Class Initialized
INFO - 2020-10-24 00:09:07 --> Router Class Initialized
INFO - 2020-10-24 00:09:07 --> Config Class Initialized
INFO - 2020-10-24 00:09:07 --> Output Class Initialized
INFO - 2020-10-24 00:09:07 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:07 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:07 --> Security Class Initialized
INFO - 2020-10-24 00:09:07 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:07 --> URI Class Initialized
INFO - 2020-10-24 00:09:07 --> Input Class Initialized
INFO - 2020-10-24 00:09:07 --> Language Class Initialized
INFO - 2020-10-24 00:09:07 --> Router Class Initialized
INFO - 2020-10-24 00:09:07 --> Output Class Initialized
ERROR - 2020-10-24 00:09:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:09:07 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:07 --> Input Class Initialized
INFO - 2020-10-24 00:09:07 --> Language Class Initialized
ERROR - 2020-10-24 00:09:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:09:07 --> Config Class Initialized
INFO - 2020-10-24 00:09:07 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:07 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:07 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:07 --> URI Class Initialized
INFO - 2020-10-24 00:09:07 --> Router Class Initialized
INFO - 2020-10-24 00:09:07 --> Output Class Initialized
INFO - 2020-10-24 00:09:07 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:07 --> Input Class Initialized
INFO - 2020-10-24 00:09:07 --> Language Class Initialized
INFO - 2020-10-24 00:09:07 --> Loader Class Initialized
INFO - 2020-10-24 00:09:07 --> Helper loaded: url_helper
INFO - 2020-10-24 00:09:07 --> Helper loaded: form_helper
INFO - 2020-10-24 00:09:07 --> Helper loaded: html_helper
INFO - 2020-10-24 00:09:07 --> Helper loaded: date_helper
INFO - 2020-10-24 00:09:07 --> Database Driver Class Initialized
INFO - 2020-10-24 00:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:09:07 --> Table Class Initialized
INFO - 2020-10-24 00:09:07 --> Upload Class Initialized
INFO - 2020-10-24 00:09:07 --> Controller Class Initialized
INFO - 2020-10-24 00:09:07 --> Form Validation Class Initialized
INFO - 2020-10-24 00:09:07 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:09:07 --> Final output sent to browser
DEBUG - 2020-10-24 00:09:07 --> Total execution time: 0.1503
INFO - 2020-10-24 00:09:08 --> Config Class Initialized
INFO - 2020-10-24 00:09:08 --> Hooks Class Initialized
INFO - 2020-10-24 00:09:08 --> Config Class Initialized
INFO - 2020-10-24 00:09:08 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:09:08 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:08 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:08 --> Config Class Initialized
INFO - 2020-10-24 00:09:08 --> Hooks Class Initialized
INFO - 2020-10-24 00:09:08 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:08 --> URI Class Initialized
INFO - 2020-10-24 00:09:08 --> URI Class Initialized
DEBUG - 2020-10-24 00:09:08 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:08 --> Router Class Initialized
INFO - 2020-10-24 00:09:08 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:08 --> Router Class Initialized
INFO - 2020-10-24 00:09:08 --> Output Class Initialized
INFO - 2020-10-24 00:09:08 --> URI Class Initialized
INFO - 2020-10-24 00:09:08 --> Output Class Initialized
INFO - 2020-10-24 00:09:08 --> Security Class Initialized
INFO - 2020-10-24 00:09:08 --> Router Class Initialized
DEBUG - 2020-10-24 00:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:08 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:08 --> Input Class Initialized
INFO - 2020-10-24 00:09:08 --> Output Class Initialized
INFO - 2020-10-24 00:09:08 --> Language Class Initialized
INFO - 2020-10-24 00:09:08 --> Input Class Initialized
INFO - 2020-10-24 00:09:08 --> Security Class Initialized
ERROR - 2020-10-24 00:09:08 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 00:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:08 --> Language Class Initialized
INFO - 2020-10-24 00:09:08 --> Input Class Initialized
ERROR - 2020-10-24 00:09:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:09:08 --> Language Class Initialized
ERROR - 2020-10-24 00:09:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:09:14 --> Config Class Initialized
INFO - 2020-10-24 00:09:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:14 --> URI Class Initialized
INFO - 2020-10-24 00:09:14 --> Router Class Initialized
INFO - 2020-10-24 00:09:14 --> Output Class Initialized
INFO - 2020-10-24 00:09:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:14 --> Input Class Initialized
INFO - 2020-10-24 00:09:14 --> Language Class Initialized
INFO - 2020-10-24 00:09:14 --> Loader Class Initialized
INFO - 2020-10-24 00:09:14 --> Helper loaded: url_helper
INFO - 2020-10-24 00:09:14 --> Helper loaded: form_helper
INFO - 2020-10-24 00:09:14 --> Helper loaded: html_helper
INFO - 2020-10-24 00:09:14 --> Helper loaded: date_helper
INFO - 2020-10-24 00:09:14 --> Database Driver Class Initialized
INFO - 2020-10-24 00:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:09:14 --> Table Class Initialized
INFO - 2020-10-24 00:09:14 --> Upload Class Initialized
INFO - 2020-10-24 00:09:14 --> Controller Class Initialized
INFO - 2020-10-24 00:09:14 --> Form Validation Class Initialized
INFO - 2020-10-24 00:09:14 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:09:14 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:09:14 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:09:14 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:09:14 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:09:14 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:09:14 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:09:14 --> Final output sent to browser
DEBUG - 2020-10-24 00:09:14 --> Total execution time: 0.3089
INFO - 2020-10-24 00:09:14 --> Config Class Initialized
INFO - 2020-10-24 00:09:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:14 --> URI Class Initialized
INFO - 2020-10-24 00:09:14 --> Router Class Initialized
INFO - 2020-10-24 00:09:14 --> Output Class Initialized
INFO - 2020-10-24 00:09:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:14 --> Input Class Initialized
INFO - 2020-10-24 00:09:14 --> Language Class Initialized
ERROR - 2020-10-24 00:09:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:09:15 --> Config Class Initialized
INFO - 2020-10-24 00:09:15 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:15 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:15 --> URI Class Initialized
INFO - 2020-10-24 00:09:15 --> Router Class Initialized
INFO - 2020-10-24 00:09:15 --> Output Class Initialized
INFO - 2020-10-24 00:09:15 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:15 --> Input Class Initialized
INFO - 2020-10-24 00:09:15 --> Language Class Initialized
INFO - 2020-10-24 00:09:15 --> Loader Class Initialized
INFO - 2020-10-24 00:09:15 --> Helper loaded: url_helper
INFO - 2020-10-24 00:09:15 --> Helper loaded: form_helper
INFO - 2020-10-24 00:09:15 --> Helper loaded: html_helper
INFO - 2020-10-24 00:09:15 --> Helper loaded: date_helper
INFO - 2020-10-24 00:09:15 --> Database Driver Class Initialized
INFO - 2020-10-24 00:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:09:15 --> Table Class Initialized
INFO - 2020-10-24 00:09:15 --> Upload Class Initialized
INFO - 2020-10-24 00:09:15 --> Controller Class Initialized
INFO - 2020-10-24 00:09:15 --> Form Validation Class Initialized
INFO - 2020-10-24 00:09:15 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:09:16 --> Final output sent to browser
DEBUG - 2020-10-24 00:09:16 --> Total execution time: 0.3272
INFO - 2020-10-24 00:09:16 --> Config Class Initialized
INFO - 2020-10-24 00:09:16 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:16 --> Config Class Initialized
INFO - 2020-10-24 00:09:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:16 --> Hooks Class Initialized
INFO - 2020-10-24 00:09:16 --> URI Class Initialized
DEBUG - 2020-10-24 00:09:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:16 --> Router Class Initialized
INFO - 2020-10-24 00:09:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:16 --> Output Class Initialized
INFO - 2020-10-24 00:09:16 --> URI Class Initialized
INFO - 2020-10-24 00:09:16 --> Router Class Initialized
INFO - 2020-10-24 00:09:16 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:16 --> Output Class Initialized
INFO - 2020-10-24 00:09:16 --> Input Class Initialized
INFO - 2020-10-24 00:09:16 --> Security Class Initialized
INFO - 2020-10-24 00:09:16 --> Language Class Initialized
DEBUG - 2020-10-24 00:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 00:09:16 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:09:16 --> Input Class Initialized
INFO - 2020-10-24 00:09:16 --> Language Class Initialized
ERROR - 2020-10-24 00:09:16 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:09:16 --> Config Class Initialized
INFO - 2020-10-24 00:09:16 --> Config Class Initialized
INFO - 2020-10-24 00:09:16 --> Hooks Class Initialized
INFO - 2020-10-24 00:09:16 --> Hooks Class Initialized
INFO - 2020-10-24 00:09:16 --> Config Class Initialized
DEBUG - 2020-10-24 00:09:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:09:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:16 --> Hooks Class Initialized
INFO - 2020-10-24 00:09:16 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:09:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:16 --> URI Class Initialized
INFO - 2020-10-24 00:09:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:16 --> URI Class Initialized
INFO - 2020-10-24 00:09:16 --> Router Class Initialized
INFO - 2020-10-24 00:09:16 --> URI Class Initialized
INFO - 2020-10-24 00:09:16 --> Router Class Initialized
INFO - 2020-10-24 00:09:16 --> Output Class Initialized
INFO - 2020-10-24 00:09:16 --> Output Class Initialized
INFO - 2020-10-24 00:09:16 --> Router Class Initialized
INFO - 2020-10-24 00:09:16 --> Security Class Initialized
INFO - 2020-10-24 00:09:16 --> Output Class Initialized
INFO - 2020-10-24 00:09:16 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:16 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:16 --> Input Class Initialized
INFO - 2020-10-24 00:09:16 --> Input Class Initialized
DEBUG - 2020-10-24 00:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:16 --> Language Class Initialized
INFO - 2020-10-24 00:09:16 --> Input Class Initialized
INFO - 2020-10-24 00:09:16 --> Language Class Initialized
INFO - 2020-10-24 00:09:16 --> Language Class Initialized
ERROR - 2020-10-24 00:09:16 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:09:16 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:09:16 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:09:16 --> Config Class Initialized
INFO - 2020-10-24 00:09:16 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:09:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:09:17 --> Utf8 Class Initialized
INFO - 2020-10-24 00:09:17 --> URI Class Initialized
INFO - 2020-10-24 00:09:17 --> Router Class Initialized
INFO - 2020-10-24 00:09:17 --> Output Class Initialized
INFO - 2020-10-24 00:09:17 --> Security Class Initialized
DEBUG - 2020-10-24 00:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:09:17 --> Input Class Initialized
INFO - 2020-10-24 00:09:17 --> Language Class Initialized
ERROR - 2020-10-24 00:09:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:10:16 --> Config Class Initialized
INFO - 2020-10-24 00:10:16 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:16 --> URI Class Initialized
INFO - 2020-10-24 00:10:16 --> Router Class Initialized
INFO - 2020-10-24 00:10:16 --> Output Class Initialized
INFO - 2020-10-24 00:10:16 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:16 --> Input Class Initialized
INFO - 2020-10-24 00:10:16 --> Language Class Initialized
INFO - 2020-10-24 00:10:16 --> Loader Class Initialized
INFO - 2020-10-24 00:10:16 --> Helper loaded: url_helper
INFO - 2020-10-24 00:10:16 --> Helper loaded: form_helper
INFO - 2020-10-24 00:10:16 --> Helper loaded: html_helper
INFO - 2020-10-24 00:10:16 --> Helper loaded: date_helper
INFO - 2020-10-24 00:10:16 --> Database Driver Class Initialized
INFO - 2020-10-24 00:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:10:16 --> Table Class Initialized
INFO - 2020-10-24 00:10:16 --> Upload Class Initialized
INFO - 2020-10-24 00:10:16 --> Controller Class Initialized
INFO - 2020-10-24 00:10:16 --> Form Validation Class Initialized
INFO - 2020-10-24 00:10:16 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:10:16 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:10:16 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:10:16 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:10:16 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:10:16 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:10:16 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:10:16 --> Final output sent to browser
DEBUG - 2020-10-24 00:10:16 --> Total execution time: 0.3729
INFO - 2020-10-24 00:10:16 --> Config Class Initialized
INFO - 2020-10-24 00:10:16 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:16 --> URI Class Initialized
INFO - 2020-10-24 00:10:17 --> Router Class Initialized
INFO - 2020-10-24 00:10:17 --> Output Class Initialized
INFO - 2020-10-24 00:10:17 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:17 --> Input Class Initialized
INFO - 2020-10-24 00:10:17 --> Language Class Initialized
ERROR - 2020-10-24 00:10:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:10:17 --> Config Class Initialized
INFO - 2020-10-24 00:10:17 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:17 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:17 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:17 --> URI Class Initialized
INFO - 2020-10-24 00:10:17 --> Router Class Initialized
INFO - 2020-10-24 00:10:17 --> Output Class Initialized
INFO - 2020-10-24 00:10:17 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:17 --> Input Class Initialized
INFO - 2020-10-24 00:10:17 --> Language Class Initialized
INFO - 2020-10-24 00:10:17 --> Loader Class Initialized
INFO - 2020-10-24 00:10:17 --> Helper loaded: url_helper
INFO - 2020-10-24 00:10:17 --> Helper loaded: form_helper
INFO - 2020-10-24 00:10:17 --> Helper loaded: html_helper
INFO - 2020-10-24 00:10:17 --> Helper loaded: date_helper
INFO - 2020-10-24 00:10:17 --> Database Driver Class Initialized
INFO - 2020-10-24 00:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:10:17 --> Table Class Initialized
INFO - 2020-10-24 00:10:17 --> Upload Class Initialized
INFO - 2020-10-24 00:10:17 --> Controller Class Initialized
INFO - 2020-10-24 00:10:17 --> Form Validation Class Initialized
INFO - 2020-10-24 00:10:17 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:10:17 --> Final output sent to browser
DEBUG - 2020-10-24 00:10:17 --> Total execution time: 0.2651
INFO - 2020-10-24 00:10:18 --> Config Class Initialized
INFO - 2020-10-24 00:10:18 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:18 --> Config Class Initialized
DEBUG - 2020-10-24 00:10:18 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:18 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:18 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:18 --> URI Class Initialized
DEBUG - 2020-10-24 00:10:18 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:18 --> Router Class Initialized
INFO - 2020-10-24 00:10:18 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:18 --> URI Class Initialized
INFO - 2020-10-24 00:10:18 --> Output Class Initialized
INFO - 2020-10-24 00:10:18 --> Security Class Initialized
INFO - 2020-10-24 00:10:18 --> Router Class Initialized
DEBUG - 2020-10-24 00:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:18 --> Output Class Initialized
INFO - 2020-10-24 00:10:18 --> Input Class Initialized
INFO - 2020-10-24 00:10:18 --> Security Class Initialized
INFO - 2020-10-24 00:10:18 --> Language Class Initialized
DEBUG - 2020-10-24 00:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:18 --> Input Class Initialized
ERROR - 2020-10-24 00:10:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:10:18 --> Language Class Initialized
ERROR - 2020-10-24 00:10:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:10:18 --> Config Class Initialized
INFO - 2020-10-24 00:10:18 --> Config Class Initialized
INFO - 2020-10-24 00:10:18 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:18 --> Config Class Initialized
DEBUG - 2020-10-24 00:10:18 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:18 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:18 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:18 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:10:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:10:18 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:18 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:18 --> URI Class Initialized
INFO - 2020-10-24 00:10:18 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:18 --> URI Class Initialized
INFO - 2020-10-24 00:10:18 --> URI Class Initialized
INFO - 2020-10-24 00:10:18 --> Router Class Initialized
INFO - 2020-10-24 00:10:19 --> Router Class Initialized
INFO - 2020-10-24 00:10:19 --> Router Class Initialized
INFO - 2020-10-24 00:10:19 --> Output Class Initialized
INFO - 2020-10-24 00:10:19 --> Security Class Initialized
INFO - 2020-10-24 00:10:19 --> Output Class Initialized
INFO - 2020-10-24 00:10:19 --> Output Class Initialized
INFO - 2020-10-24 00:10:19 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:19 --> Security Class Initialized
INFO - 2020-10-24 00:10:19 --> Input Class Initialized
DEBUG - 2020-10-24 00:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:19 --> Input Class Initialized
INFO - 2020-10-24 00:10:19 --> Language Class Initialized
INFO - 2020-10-24 00:10:19 --> Input Class Initialized
INFO - 2020-10-24 00:10:19 --> Language Class Initialized
INFO - 2020-10-24 00:10:19 --> Language Class Initialized
ERROR - 2020-10-24 00:10:19 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:19 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:10:19 --> Config Class Initialized
INFO - 2020-10-24 00:10:19 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:19 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:19 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:19 --> URI Class Initialized
INFO - 2020-10-24 00:10:19 --> Router Class Initialized
INFO - 2020-10-24 00:10:19 --> Output Class Initialized
INFO - 2020-10-24 00:10:19 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:19 --> Input Class Initialized
INFO - 2020-10-24 00:10:19 --> Language Class Initialized
ERROR - 2020-10-24 00:10:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:10:52 --> Config Class Initialized
INFO - 2020-10-24 00:10:52 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:52 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:52 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:52 --> URI Class Initialized
INFO - 2020-10-24 00:10:52 --> Router Class Initialized
INFO - 2020-10-24 00:10:52 --> Output Class Initialized
INFO - 2020-10-24 00:10:52 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:52 --> Input Class Initialized
INFO - 2020-10-24 00:10:52 --> Language Class Initialized
INFO - 2020-10-24 00:10:52 --> Loader Class Initialized
INFO - 2020-10-24 00:10:52 --> Helper loaded: url_helper
INFO - 2020-10-24 00:10:52 --> Helper loaded: form_helper
INFO - 2020-10-24 00:10:52 --> Helper loaded: html_helper
INFO - 2020-10-24 00:10:52 --> Helper loaded: date_helper
INFO - 2020-10-24 00:10:52 --> Database Driver Class Initialized
INFO - 2020-10-24 00:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:10:52 --> Table Class Initialized
INFO - 2020-10-24 00:10:52 --> Upload Class Initialized
INFO - 2020-10-24 00:10:52 --> Controller Class Initialized
INFO - 2020-10-24 00:10:52 --> Form Validation Class Initialized
INFO - 2020-10-24 00:10:52 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:10:52 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:10:52 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:10:52 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:10:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:10:52 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:10:52 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:10:52 --> Final output sent to browser
DEBUG - 2020-10-24 00:10:52 --> Total execution time: 0.2829
INFO - 2020-10-24 00:10:53 --> Config Class Initialized
INFO - 2020-10-24 00:10:53 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:53 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:53 --> URI Class Initialized
INFO - 2020-10-24 00:10:53 --> Router Class Initialized
INFO - 2020-10-24 00:10:53 --> Output Class Initialized
INFO - 2020-10-24 00:10:53 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:53 --> Input Class Initialized
INFO - 2020-10-24 00:10:53 --> Language Class Initialized
ERROR - 2020-10-24 00:10:53 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:10:54 --> Config Class Initialized
INFO - 2020-10-24 00:10:54 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:54 --> Config Class Initialized
INFO - 2020-10-24 00:10:54 --> Config Class Initialized
INFO - 2020-10-24 00:10:54 --> Config Class Initialized
INFO - 2020-10-24 00:10:54 --> Config Class Initialized
INFO - 2020-10-24 00:10:54 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:54 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:54 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:54 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:10:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:10:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:10:54 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:54 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:10:54 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:54 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:54 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:54 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:54 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:54 --> URI Class Initialized
INFO - 2020-10-24 00:10:54 --> URI Class Initialized
INFO - 2020-10-24 00:10:54 --> URI Class Initialized
INFO - 2020-10-24 00:10:54 --> URI Class Initialized
INFO - 2020-10-24 00:10:54 --> Router Class Initialized
INFO - 2020-10-24 00:10:54 --> URI Class Initialized
INFO - 2020-10-24 00:10:54 --> Router Class Initialized
INFO - 2020-10-24 00:10:54 --> Router Class Initialized
INFO - 2020-10-24 00:10:54 --> Router Class Initialized
INFO - 2020-10-24 00:10:54 --> Router Class Initialized
INFO - 2020-10-24 00:10:54 --> Output Class Initialized
INFO - 2020-10-24 00:10:54 --> Output Class Initialized
INFO - 2020-10-24 00:10:54 --> Output Class Initialized
INFO - 2020-10-24 00:10:54 --> Security Class Initialized
INFO - 2020-10-24 00:10:54 --> Output Class Initialized
INFO - 2020-10-24 00:10:54 --> Output Class Initialized
INFO - 2020-10-24 00:10:54 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:54 --> Security Class Initialized
INFO - 2020-10-24 00:10:54 --> Security Class Initialized
INFO - 2020-10-24 00:10:54 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:54 --> Input Class Initialized
DEBUG - 2020-10-24 00:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:54 --> Input Class Initialized
INFO - 2020-10-24 00:10:54 --> Input Class Initialized
INFO - 2020-10-24 00:10:54 --> Input Class Initialized
INFO - 2020-10-24 00:10:54 --> Input Class Initialized
INFO - 2020-10-24 00:10:54 --> Language Class Initialized
INFO - 2020-10-24 00:10:54 --> Language Class Initialized
INFO - 2020-10-24 00:10:54 --> Language Class Initialized
INFO - 2020-10-24 00:10:54 --> Language Class Initialized
INFO - 2020-10-24 00:10:54 --> Language Class Initialized
ERROR - 2020-10-24 00:10:54 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:54 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:54 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:54 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:54 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:10:54 --> Config Class Initialized
INFO - 2020-10-24 00:10:54 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:54 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:54 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:54 --> URI Class Initialized
INFO - 2020-10-24 00:10:54 --> Router Class Initialized
INFO - 2020-10-24 00:10:54 --> Output Class Initialized
INFO - 2020-10-24 00:10:54 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:54 --> Input Class Initialized
INFO - 2020-10-24 00:10:54 --> Language Class Initialized
INFO - 2020-10-24 00:10:54 --> Loader Class Initialized
INFO - 2020-10-24 00:10:54 --> Helper loaded: url_helper
INFO - 2020-10-24 00:10:54 --> Helper loaded: form_helper
INFO - 2020-10-24 00:10:54 --> Helper loaded: html_helper
INFO - 2020-10-24 00:10:54 --> Helper loaded: date_helper
INFO - 2020-10-24 00:10:54 --> Database Driver Class Initialized
INFO - 2020-10-24 00:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:10:54 --> Table Class Initialized
INFO - 2020-10-24 00:10:54 --> Upload Class Initialized
INFO - 2020-10-24 00:10:54 --> Controller Class Initialized
INFO - 2020-10-24 00:10:54 --> Form Validation Class Initialized
INFO - 2020-10-24 00:10:54 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:10:54 --> Final output sent to browser
DEBUG - 2020-10-24 00:10:54 --> Total execution time: 0.2432
INFO - 2020-10-24 00:10:55 --> Config Class Initialized
INFO - 2020-10-24 00:10:55 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:55 --> Config Class Initialized
INFO - 2020-10-24 00:10:55 --> Config Class Initialized
INFO - 2020-10-24 00:10:55 --> Config Class Initialized
INFO - 2020-10-24 00:10:55 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:55 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:55 --> Config Class Initialized
INFO - 2020-10-24 00:10:55 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:55 --> Hooks Class Initialized
INFO - 2020-10-24 00:10:55 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:10:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:10:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:10:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:55 --> URI Class Initialized
DEBUG - 2020-10-24 00:10:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:55 --> Router Class Initialized
INFO - 2020-10-24 00:10:55 --> URI Class Initialized
INFO - 2020-10-24 00:10:55 --> URI Class Initialized
INFO - 2020-10-24 00:10:55 --> URI Class Initialized
INFO - 2020-10-24 00:10:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:55 --> Router Class Initialized
INFO - 2020-10-24 00:10:55 --> Router Class Initialized
INFO - 2020-10-24 00:10:55 --> Output Class Initialized
INFO - 2020-10-24 00:10:55 --> Router Class Initialized
INFO - 2020-10-24 00:10:55 --> URI Class Initialized
INFO - 2020-10-24 00:10:55 --> Output Class Initialized
INFO - 2020-10-24 00:10:55 --> Router Class Initialized
INFO - 2020-10-24 00:10:55 --> Security Class Initialized
INFO - 2020-10-24 00:10:55 --> Output Class Initialized
INFO - 2020-10-24 00:10:55 --> Output Class Initialized
INFO - 2020-10-24 00:10:55 --> Security Class Initialized
INFO - 2020-10-24 00:10:55 --> Security Class Initialized
INFO - 2020-10-24 00:10:55 --> Output Class Initialized
INFO - 2020-10-24 00:10:55 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:55 --> Input Class Initialized
INFO - 2020-10-24 00:10:55 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:55 --> Input Class Initialized
INFO - 2020-10-24 00:10:55 --> Input Class Initialized
INFO - 2020-10-24 00:10:55 --> Input Class Initialized
INFO - 2020-10-24 00:10:55 --> Language Class Initialized
DEBUG - 2020-10-24 00:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:55 --> Input Class Initialized
INFO - 2020-10-24 00:10:55 --> Language Class Initialized
INFO - 2020-10-24 00:10:55 --> Language Class Initialized
INFO - 2020-10-24 00:10:55 --> Language Class Initialized
ERROR - 2020-10-24 00:10:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:10:55 --> Language Class Initialized
ERROR - 2020-10-24 00:10:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:10:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:10:55 --> Config Class Initialized
INFO - 2020-10-24 00:10:55 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:10:55 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:10:55 --> Utf8 Class Initialized
INFO - 2020-10-24 00:10:55 --> URI Class Initialized
INFO - 2020-10-24 00:10:55 --> Router Class Initialized
INFO - 2020-10-24 00:10:55 --> Output Class Initialized
INFO - 2020-10-24 00:10:55 --> Security Class Initialized
DEBUG - 2020-10-24 00:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:10:55 --> Input Class Initialized
INFO - 2020-10-24 00:10:55 --> Language Class Initialized
ERROR - 2020-10-24 00:10:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:11:02 --> Config Class Initialized
INFO - 2020-10-24 00:11:02 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:02 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:02 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:02 --> URI Class Initialized
INFO - 2020-10-24 00:11:02 --> Router Class Initialized
INFO - 2020-10-24 00:11:02 --> Output Class Initialized
INFO - 2020-10-24 00:11:02 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:02 --> Input Class Initialized
INFO - 2020-10-24 00:11:02 --> Language Class Initialized
INFO - 2020-10-24 00:11:02 --> Loader Class Initialized
INFO - 2020-10-24 00:11:02 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:02 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:02 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:02 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:02 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:02 --> Table Class Initialized
INFO - 2020-10-24 00:11:02 --> Upload Class Initialized
INFO - 2020-10-24 00:11:02 --> Controller Class Initialized
INFO - 2020-10-24 00:11:02 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:02 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:02 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:11:02 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:11:02 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:11:02 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:11:02 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:11:02 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:11:02 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:02 --> Total execution time: 0.1941
INFO - 2020-10-24 00:11:02 --> Config Class Initialized
INFO - 2020-10-24 00:11:02 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:02 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:02 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:02 --> URI Class Initialized
INFO - 2020-10-24 00:11:02 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
INFO - 2020-10-24 00:11:03 --> Loader Class Initialized
INFO - 2020-10-24 00:11:03 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:03 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:03 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:03 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:03 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:03 --> Table Class Initialized
INFO - 2020-10-24 00:11:03 --> Upload Class Initialized
INFO - 2020-10-24 00:11:03 --> Controller Class Initialized
INFO - 2020-10-24 00:11:03 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:03 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:03 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:03 --> Total execution time: 0.2758
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Config Class Initialized
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:11:03 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> URI Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Router Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Output Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Security Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
DEBUG - 2020-10-24 00:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Input Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
INFO - 2020-10-24 00:11:03 --> Language Class Initialized
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:03 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:11:16 --> Config Class Initialized
INFO - 2020-10-24 00:11:16 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:16 --> URI Class Initialized
INFO - 2020-10-24 00:11:16 --> Router Class Initialized
INFO - 2020-10-24 00:11:16 --> Output Class Initialized
INFO - 2020-10-24 00:11:16 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:16 --> Input Class Initialized
INFO - 2020-10-24 00:11:16 --> Language Class Initialized
INFO - 2020-10-24 00:11:16 --> Loader Class Initialized
INFO - 2020-10-24 00:11:16 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:16 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:16 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:16 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:16 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:16 --> Table Class Initialized
INFO - 2020-10-24 00:11:16 --> Upload Class Initialized
INFO - 2020-10-24 00:11:16 --> Controller Class Initialized
INFO - 2020-10-24 00:11:16 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:16 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-10-24 00:11:16 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:16 --> Total execution time: 0.3296
INFO - 2020-10-24 00:11:16 --> Config Class Initialized
INFO - 2020-10-24 00:11:16 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:16 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:16 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:16 --> URI Class Initialized
INFO - 2020-10-24 00:11:17 --> Router Class Initialized
INFO - 2020-10-24 00:11:17 --> Output Class Initialized
INFO - 2020-10-24 00:11:17 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:17 --> Input Class Initialized
INFO - 2020-10-24 00:11:17 --> Language Class Initialized
INFO - 2020-10-24 00:11:17 --> Loader Class Initialized
INFO - 2020-10-24 00:11:17 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:17 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:17 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:17 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:17 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:17 --> Table Class Initialized
INFO - 2020-10-24 00:11:17 --> Upload Class Initialized
INFO - 2020-10-24 00:11:17 --> Controller Class Initialized
INFO - 2020-10-24 00:11:17 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:17 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:17 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:17 --> Total execution time: 0.2764
INFO - 2020-10-24 00:11:33 --> Config Class Initialized
INFO - 2020-10-24 00:11:33 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:33 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:33 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:33 --> URI Class Initialized
INFO - 2020-10-24 00:11:33 --> Router Class Initialized
INFO - 2020-10-24 00:11:33 --> Output Class Initialized
INFO - 2020-10-24 00:11:33 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:33 --> Input Class Initialized
INFO - 2020-10-24 00:11:33 --> Language Class Initialized
INFO - 2020-10-24 00:11:33 --> Loader Class Initialized
INFO - 2020-10-24 00:11:33 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:33 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:33 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:33 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:33 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:33 --> Table Class Initialized
INFO - 2020-10-24 00:11:33 --> Upload Class Initialized
INFO - 2020-10-24 00:11:33 --> Controller Class Initialized
INFO - 2020-10-24 00:11:33 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:33 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:33 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:33 --> Total execution time: 0.3178
INFO - 2020-10-24 00:11:33 --> Config Class Initialized
INFO - 2020-10-24 00:11:33 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:33 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:33 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:33 --> URI Class Initialized
INFO - 2020-10-24 00:11:33 --> Router Class Initialized
INFO - 2020-10-24 00:11:33 --> Output Class Initialized
INFO - 2020-10-24 00:11:33 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:33 --> Input Class Initialized
INFO - 2020-10-24 00:11:34 --> Language Class Initialized
INFO - 2020-10-24 00:11:34 --> Loader Class Initialized
INFO - 2020-10-24 00:11:34 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:34 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:34 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:34 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:34 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:34 --> Table Class Initialized
INFO - 2020-10-24 00:11:34 --> Upload Class Initialized
INFO - 2020-10-24 00:11:34 --> Controller Class Initialized
INFO - 2020-10-24 00:11:34 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:34 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:34 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:34 --> Total execution time: 0.2757
INFO - 2020-10-24 00:11:40 --> Config Class Initialized
INFO - 2020-10-24 00:11:40 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:40 --> URI Class Initialized
INFO - 2020-10-24 00:11:40 --> Router Class Initialized
INFO - 2020-10-24 00:11:40 --> Output Class Initialized
INFO - 2020-10-24 00:11:40 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:40 --> Input Class Initialized
INFO - 2020-10-24 00:11:40 --> Language Class Initialized
INFO - 2020-10-24 00:11:40 --> Loader Class Initialized
INFO - 2020-10-24 00:11:40 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:40 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:40 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:40 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:40 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:40 --> Table Class Initialized
INFO - 2020-10-24 00:11:40 --> Upload Class Initialized
INFO - 2020-10-24 00:11:40 --> Controller Class Initialized
INFO - 2020-10-24 00:11:40 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:40 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:40 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:11:40 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:11:40 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:11:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:11:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:11:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:11:40 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:40 --> Total execution time: 0.4767
INFO - 2020-10-24 00:11:40 --> Config Class Initialized
INFO - 2020-10-24 00:11:40 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:40 --> URI Class Initialized
INFO - 2020-10-24 00:11:40 --> Router Class Initialized
INFO - 2020-10-24 00:11:40 --> Output Class Initialized
INFO - 2020-10-24 00:11:40 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:40 --> Input Class Initialized
INFO - 2020-10-24 00:11:40 --> Language Class Initialized
ERROR - 2020-10-24 00:11:40 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:11:40 --> Config Class Initialized
INFO - 2020-10-24 00:11:40 --> Config Class Initialized
INFO - 2020-10-24 00:11:40 --> Config Class Initialized
INFO - 2020-10-24 00:11:40 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:40 --> Config Class Initialized
INFO - 2020-10-24 00:11:40 --> Config Class Initialized
INFO - 2020-10-24 00:11:40 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:40 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:40 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:40 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:40 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:40 --> URI Class Initialized
INFO - 2020-10-24 00:11:40 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:40 --> URI Class Initialized
INFO - 2020-10-24 00:11:40 --> URI Class Initialized
INFO - 2020-10-24 00:11:40 --> URI Class Initialized
INFO - 2020-10-24 00:11:40 --> Router Class Initialized
INFO - 2020-10-24 00:11:40 --> URI Class Initialized
INFO - 2020-10-24 00:11:40 --> Router Class Initialized
INFO - 2020-10-24 00:11:40 --> Router Class Initialized
INFO - 2020-10-24 00:11:40 --> Router Class Initialized
INFO - 2020-10-24 00:11:40 --> Router Class Initialized
INFO - 2020-10-24 00:11:40 --> Output Class Initialized
INFO - 2020-10-24 00:11:40 --> Output Class Initialized
INFO - 2020-10-24 00:11:40 --> Output Class Initialized
INFO - 2020-10-24 00:11:40 --> Output Class Initialized
INFO - 2020-10-24 00:11:40 --> Security Class Initialized
INFO - 2020-10-24 00:11:40 --> Output Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:11:41 --> Config Class Initialized
INFO - 2020-10-24 00:11:41 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:41 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:41 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:41 --> URI Class Initialized
INFO - 2020-10-24 00:11:41 --> Router Class Initialized
INFO - 2020-10-24 00:11:41 --> Output Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Loader Class Initialized
INFO - 2020-10-24 00:11:41 --> Helper loaded: url_helper
INFO - 2020-10-24 00:11:41 --> Helper loaded: form_helper
INFO - 2020-10-24 00:11:41 --> Helper loaded: html_helper
INFO - 2020-10-24 00:11:41 --> Helper loaded: date_helper
INFO - 2020-10-24 00:11:41 --> Database Driver Class Initialized
INFO - 2020-10-24 00:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:11:41 --> Table Class Initialized
INFO - 2020-10-24 00:11:41 --> Upload Class Initialized
INFO - 2020-10-24 00:11:41 --> Controller Class Initialized
INFO - 2020-10-24 00:11:41 --> Form Validation Class Initialized
INFO - 2020-10-24 00:11:41 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:11:41 --> Final output sent to browser
DEBUG - 2020-10-24 00:11:41 --> Total execution time: 0.2274
INFO - 2020-10-24 00:11:41 --> Config Class Initialized
INFO - 2020-10-24 00:11:41 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:41 --> Config Class Initialized
INFO - 2020-10-24 00:11:41 --> Config Class Initialized
INFO - 2020-10-24 00:11:41 --> Config Class Initialized
INFO - 2020-10-24 00:11:41 --> Config Class Initialized
INFO - 2020-10-24 00:11:41 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:41 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:41 --> Hooks Class Initialized
INFO - 2020-10-24 00:11:41 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:11:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 00:11:41 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:11:41 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:41 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:41 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:41 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:41 --> Utf8 Class Initialized
INFO - 2020-10-24 00:11:41 --> URI Class Initialized
INFO - 2020-10-24 00:11:41 --> URI Class Initialized
INFO - 2020-10-24 00:11:41 --> URI Class Initialized
INFO - 2020-10-24 00:11:41 --> URI Class Initialized
INFO - 2020-10-24 00:11:41 --> URI Class Initialized
INFO - 2020-10-24 00:11:41 --> Router Class Initialized
INFO - 2020-10-24 00:11:41 --> Router Class Initialized
INFO - 2020-10-24 00:11:41 --> Router Class Initialized
INFO - 2020-10-24 00:11:41 --> Router Class Initialized
INFO - 2020-10-24 00:11:41 --> Router Class Initialized
INFO - 2020-10-24 00:11:41 --> Output Class Initialized
INFO - 2020-10-24 00:11:41 --> Output Class Initialized
INFO - 2020-10-24 00:11:41 --> Output Class Initialized
INFO - 2020-10-24 00:11:41 --> Output Class Initialized
INFO - 2020-10-24 00:11:41 --> Output Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
INFO - 2020-10-24 00:11:41 --> Security Class Initialized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Input Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
INFO - 2020-10-24 00:11:41 --> Language Class Initialized
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 00:11:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:12:14 --> Config Class Initialized
INFO - 2020-10-24 00:12:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:12:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:14 --> URI Class Initialized
INFO - 2020-10-24 00:12:14 --> Router Class Initialized
INFO - 2020-10-24 00:12:14 --> Output Class Initialized
INFO - 2020-10-24 00:12:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:12:14 --> Input Class Initialized
INFO - 2020-10-24 00:12:14 --> Language Class Initialized
INFO - 2020-10-24 00:12:14 --> Loader Class Initialized
INFO - 2020-10-24 00:12:14 --> Helper loaded: url_helper
INFO - 2020-10-24 00:12:14 --> Helper loaded: form_helper
INFO - 2020-10-24 00:12:14 --> Helper loaded: html_helper
INFO - 2020-10-24 00:12:14 --> Helper loaded: date_helper
INFO - 2020-10-24 00:12:14 --> Database Driver Class Initialized
INFO - 2020-10-24 00:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:12:14 --> Table Class Initialized
INFO - 2020-10-24 00:12:14 --> Upload Class Initialized
INFO - 2020-10-24 00:12:14 --> Controller Class Initialized
INFO - 2020-10-24 00:12:14 --> Form Validation Class Initialized
INFO - 2020-10-24 00:12:14 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:12:14 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 00:12:14 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 00:12:14 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 00:12:14 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 00:12:14 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 00:12:14 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 00:12:14 --> Final output sent to browser
DEBUG - 2020-10-24 00:12:14 --> Total execution time: 0.2065
INFO - 2020-10-24 00:12:14 --> Config Class Initialized
INFO - 2020-10-24 00:12:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:12:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:14 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:14 --> URI Class Initialized
INFO - 2020-10-24 00:12:14 --> Router Class Initialized
INFO - 2020-10-24 00:12:14 --> Output Class Initialized
INFO - 2020-10-24 00:12:14 --> Security Class Initialized
DEBUG - 2020-10-24 00:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:12:15 --> Input Class Initialized
INFO - 2020-10-24 00:12:15 --> Config Class Initialized
INFO - 2020-10-24 00:12:15 --> Hooks Class Initialized
INFO - 2020-10-24 00:12:15 --> Language Class Initialized
DEBUG - 2020-10-24 00:12:15 --> UTF-8 Support Enabled
ERROR - 2020-10-24 00:12:15 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 00:12:15 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:15 --> URI Class Initialized
INFO - 2020-10-24 00:12:15 --> Router Class Initialized
INFO - 2020-10-24 00:12:15 --> Output Class Initialized
INFO - 2020-10-24 00:12:15 --> Security Class Initialized
INFO - 2020-10-24 00:12:15 --> Config Class Initialized
INFO - 2020-10-24 00:12:15 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:12:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:15 --> Input Class Initialized
INFO - 2020-10-24 00:12:15 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:15 --> Language Class Initialized
INFO - 2020-10-24 00:12:15 --> URI Class Initialized
ERROR - 2020-10-24 00:12:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:12:15 --> Router Class Initialized
INFO - 2020-10-24 00:12:15 --> Output Class Initialized
INFO - 2020-10-24 00:12:15 --> Security Class Initialized
DEBUG - 2020-10-24 00:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:12:15 --> Input Class Initialized
INFO - 2020-10-24 00:12:15 --> Language Class Initialized
ERROR - 2020-10-24 00:12:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:12:15 --> Config Class Initialized
INFO - 2020-10-24 00:12:15 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:12:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:15 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:15 --> URI Class Initialized
INFO - 2020-10-24 00:12:15 --> Router Class Initialized
INFO - 2020-10-24 00:12:15 --> Output Class Initialized
INFO - 2020-10-24 00:12:15 --> Security Class Initialized
DEBUG - 2020-10-24 00:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:12:15 --> Input Class Initialized
INFO - 2020-10-24 00:12:15 --> Language Class Initialized
INFO - 2020-10-24 00:12:15 --> Loader Class Initialized
INFO - 2020-10-24 00:12:15 --> Helper loaded: url_helper
INFO - 2020-10-24 00:12:15 --> Helper loaded: form_helper
INFO - 2020-10-24 00:12:15 --> Helper loaded: html_helper
INFO - 2020-10-24 00:12:15 --> Helper loaded: date_helper
INFO - 2020-10-24 00:12:15 --> Database Driver Class Initialized
INFO - 2020-10-24 00:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 00:12:15 --> Table Class Initialized
INFO - 2020-10-24 00:12:15 --> Upload Class Initialized
INFO - 2020-10-24 00:12:15 --> Controller Class Initialized
INFO - 2020-10-24 00:12:15 --> Form Validation Class Initialized
INFO - 2020-10-24 00:12:15 --> Model "Crud_model" initialized
INFO - 2020-10-24 00:12:15 --> Final output sent to browser
DEBUG - 2020-10-24 00:12:15 --> Total execution time: 0.1796
INFO - 2020-10-24 00:12:15 --> Config Class Initialized
INFO - 2020-10-24 00:12:15 --> Hooks Class Initialized
INFO - 2020-10-24 00:12:15 --> Config Class Initialized
INFO - 2020-10-24 00:12:15 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:12:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:15 --> Utf8 Class Initialized
DEBUG - 2020-10-24 00:12:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:15 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:15 --> URI Class Initialized
INFO - 2020-10-24 00:12:15 --> Config Class Initialized
INFO - 2020-10-24 00:12:15 --> Hooks Class Initialized
INFO - 2020-10-24 00:12:15 --> Router Class Initialized
INFO - 2020-10-24 00:12:15 --> URI Class Initialized
DEBUG - 2020-10-24 00:12:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:15 --> Router Class Initialized
INFO - 2020-10-24 00:12:15 --> Output Class Initialized
INFO - 2020-10-24 00:12:15 --> Security Class Initialized
INFO - 2020-10-24 00:12:15 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:15 --> Output Class Initialized
INFO - 2020-10-24 00:12:15 --> Security Class Initialized
INFO - 2020-10-24 00:12:15 --> URI Class Initialized
DEBUG - 2020-10-24 00:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 00:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:12:15 --> Input Class Initialized
INFO - 2020-10-24 00:12:15 --> Router Class Initialized
INFO - 2020-10-24 00:12:15 --> Input Class Initialized
INFO - 2020-10-24 00:12:15 --> Output Class Initialized
INFO - 2020-10-24 00:12:15 --> Language Class Initialized
INFO - 2020-10-24 00:12:15 --> Security Class Initialized
INFO - 2020-10-24 00:12:15 --> Language Class Initialized
ERROR - 2020-10-24 00:12:15 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 00:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 00:12:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:12:15 --> Input Class Initialized
INFO - 2020-10-24 00:12:15 --> Language Class Initialized
ERROR - 2020-10-24 00:12:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 00:12:15 --> Config Class Initialized
INFO - 2020-10-24 00:12:15 --> Hooks Class Initialized
DEBUG - 2020-10-24 00:12:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 00:12:15 --> Utf8 Class Initialized
INFO - 2020-10-24 00:12:15 --> URI Class Initialized
INFO - 2020-10-24 00:12:15 --> Router Class Initialized
INFO - 2020-10-24 00:12:16 --> Output Class Initialized
INFO - 2020-10-24 00:12:16 --> Security Class Initialized
DEBUG - 2020-10-24 00:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 00:12:16 --> Input Class Initialized
INFO - 2020-10-24 00:12:16 --> Language Class Initialized
ERROR - 2020-10-24 00:12:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:13 --> Config Class Initialized
INFO - 2020-10-24 15:03:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:13 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:13 --> URI Class Initialized
INFO - 2020-10-24 15:03:13 --> Router Class Initialized
INFO - 2020-10-24 15:03:13 --> Output Class Initialized
INFO - 2020-10-24 15:03:13 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:13 --> Input Class Initialized
INFO - 2020-10-24 15:03:13 --> Language Class Initialized
INFO - 2020-10-24 15:03:13 --> Loader Class Initialized
INFO - 2020-10-24 15:03:13 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:13 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:13 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:13 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:13 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:13 --> Table Class Initialized
INFO - 2020-10-24 15:03:13 --> Upload Class Initialized
INFO - 2020-10-24 15:03:13 --> Controller Class Initialized
INFO - 2020-10-24 15:03:13 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:13 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:13 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:03:13 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:03:13 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:03:13 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:03:13 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:03:13 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:03:13 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:13 --> Total execution time: 0.3823
INFO - 2020-10-24 15:03:13 --> Config Class Initialized
INFO - 2020-10-24 15:03:13 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:13 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:13 --> URI Class Initialized
INFO - 2020-10-24 15:03:13 --> Router Class Initialized
INFO - 2020-10-24 15:03:13 --> Output Class Initialized
INFO - 2020-10-24 15:03:13 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:13 --> Input Class Initialized
INFO - 2020-10-24 15:03:13 --> Config Class Initialized
INFO - 2020-10-24 15:03:13 --> Language Class Initialized
INFO - 2020-10-24 15:03:13 --> Hooks Class Initialized
ERROR - 2020-10-24 15:03:13 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-24 15:03:13 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:14 --> Config Class Initialized
INFO - 2020-10-24 15:03:14 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:14 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:14 --> URI Class Initialized
INFO - 2020-10-24 15:03:14 --> Router Class Initialized
DEBUG - 2020-10-24 15:03:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:14 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:14 --> Output Class Initialized
INFO - 2020-10-24 15:03:14 --> Security Class Initialized
INFO - 2020-10-24 15:03:14 --> URI Class Initialized
INFO - 2020-10-24 15:03:14 --> Router Class Initialized
DEBUG - 2020-10-24 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:14 --> Output Class Initialized
INFO - 2020-10-24 15:03:14 --> Input Class Initialized
INFO - 2020-10-24 15:03:14 --> Security Class Initialized
INFO - 2020-10-24 15:03:14 --> Language Class Initialized
ERROR - 2020-10-24 15:03:14 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:14 --> Input Class Initialized
INFO - 2020-10-24 15:03:14 --> Language Class Initialized
ERROR - 2020-10-24 15:03:14 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:14 --> Config Class Initialized
INFO - 2020-10-24 15:03:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:14 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:14 --> URI Class Initialized
INFO - 2020-10-24 15:03:14 --> Router Class Initialized
INFO - 2020-10-24 15:03:14 --> Output Class Initialized
INFO - 2020-10-24 15:03:14 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:14 --> Input Class Initialized
INFO - 2020-10-24 15:03:14 --> Language Class Initialized
INFO - 2020-10-24 15:03:14 --> Loader Class Initialized
INFO - 2020-10-24 15:03:14 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:14 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:14 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:14 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:14 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:14 --> Table Class Initialized
INFO - 2020-10-24 15:03:14 --> Upload Class Initialized
INFO - 2020-10-24 15:03:14 --> Controller Class Initialized
INFO - 2020-10-24 15:03:14 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:14 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:14 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:14 --> Total execution time: 0.2079
INFO - 2020-10-24 15:03:14 --> Config Class Initialized
INFO - 2020-10-24 15:03:14 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:14 --> Config Class Initialized
INFO - 2020-10-24 15:03:14 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:14 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:14 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:14 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:14 --> URI Class Initialized
INFO - 2020-10-24 15:03:14 --> Router Class Initialized
INFO - 2020-10-24 15:03:14 --> URI Class Initialized
INFO - 2020-10-24 15:03:14 --> Router Class Initialized
INFO - 2020-10-24 15:03:14 --> Output Class Initialized
INFO - 2020-10-24 15:03:14 --> Output Class Initialized
INFO - 2020-10-24 15:03:14 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:14 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:14 --> Input Class Initialized
INFO - 2020-10-24 15:03:14 --> Input Class Initialized
INFO - 2020-10-24 15:03:14 --> Language Class Initialized
INFO - 2020-10-24 15:03:15 --> Config Class Initialized
ERROR - 2020-10-24 15:03:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:15 --> Language Class Initialized
INFO - 2020-10-24 15:03:15 --> Hooks Class Initialized
ERROR - 2020-10-24 15:03:15 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 15:03:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:15 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:15 --> URI Class Initialized
INFO - 2020-10-24 15:03:15 --> Router Class Initialized
INFO - 2020-10-24 15:03:15 --> Output Class Initialized
INFO - 2020-10-24 15:03:15 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:15 --> Input Class Initialized
INFO - 2020-10-24 15:03:15 --> Language Class Initialized
ERROR - 2020-10-24 15:03:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:15 --> Config Class Initialized
INFO - 2020-10-24 15:03:15 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:15 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:15 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:15 --> URI Class Initialized
INFO - 2020-10-24 15:03:15 --> Router Class Initialized
INFO - 2020-10-24 15:03:15 --> Output Class Initialized
INFO - 2020-10-24 15:03:15 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:15 --> Input Class Initialized
INFO - 2020-10-24 15:03:15 --> Language Class Initialized
ERROR - 2020-10-24 15:03:15 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:21 --> Config Class Initialized
INFO - 2020-10-24 15:03:21 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:21 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:21 --> URI Class Initialized
INFO - 2020-10-24 15:03:21 --> Router Class Initialized
INFO - 2020-10-24 15:03:21 --> Output Class Initialized
INFO - 2020-10-24 15:03:21 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:21 --> Input Class Initialized
INFO - 2020-10-24 15:03:21 --> Language Class Initialized
INFO - 2020-10-24 15:03:21 --> Loader Class Initialized
INFO - 2020-10-24 15:03:21 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:21 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:21 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:21 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:21 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:21 --> Table Class Initialized
INFO - 2020-10-24 15:03:21 --> Upload Class Initialized
INFO - 2020-10-24 15:03:21 --> Controller Class Initialized
INFO - 2020-10-24 15:03:21 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:21 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:21 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:03:21 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:03:21 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:03:21 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:03:21 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:03:21 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:03:21 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:21 --> Total execution time: 0.6073
INFO - 2020-10-24 15:03:21 --> Config Class Initialized
INFO - 2020-10-24 15:03:21 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:21 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:21 --> Config Class Initialized
INFO - 2020-10-24 15:03:21 --> URI Class Initialized
INFO - 2020-10-24 15:03:21 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:21 --> Router Class Initialized
DEBUG - 2020-10-24 15:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:21 --> Output Class Initialized
INFO - 2020-10-24 15:03:21 --> Security Class Initialized
INFO - 2020-10-24 15:03:21 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:21 --> URI Class Initialized
INFO - 2020-10-24 15:03:21 --> Router Class Initialized
INFO - 2020-10-24 15:03:21 --> Input Class Initialized
INFO - 2020-10-24 15:03:21 --> Language Class Initialized
INFO - 2020-10-24 15:03:21 --> Output Class Initialized
ERROR - 2020-10-24 15:03:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:21 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:21 --> Input Class Initialized
INFO - 2020-10-24 15:03:21 --> Language Class Initialized
INFO - 2020-10-24 15:03:21 --> Config Class Initialized
ERROR - 2020-10-24 15:03:21 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:21 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:21 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:21 --> URI Class Initialized
INFO - 2020-10-24 15:03:21 --> Router Class Initialized
INFO - 2020-10-24 15:03:21 --> Output Class Initialized
INFO - 2020-10-24 15:03:21 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:22 --> Config Class Initialized
INFO - 2020-10-24 15:03:22 --> Input Class Initialized
INFO - 2020-10-24 15:03:22 --> Language Class Initialized
INFO - 2020-10-24 15:03:22 --> Hooks Class Initialized
ERROR - 2020-10-24 15:03:22 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 15:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:22 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:22 --> URI Class Initialized
INFO - 2020-10-24 15:03:22 --> Router Class Initialized
INFO - 2020-10-24 15:03:22 --> Output Class Initialized
INFO - 2020-10-24 15:03:22 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:22 --> Input Class Initialized
INFO - 2020-10-24 15:03:22 --> Language Class Initialized
INFO - 2020-10-24 15:03:22 --> Loader Class Initialized
INFO - 2020-10-24 15:03:22 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:22 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:22 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:22 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:22 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:22 --> Table Class Initialized
INFO - 2020-10-24 15:03:22 --> Upload Class Initialized
INFO - 2020-10-24 15:03:22 --> Controller Class Initialized
INFO - 2020-10-24 15:03:22 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:22 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:22 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:22 --> Total execution time: 0.2454
INFO - 2020-10-24 15:03:22 --> Config Class Initialized
INFO - 2020-10-24 15:03:22 --> Config Class Initialized
INFO - 2020-10-24 15:03:22 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:22 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:22 --> Config Class Initialized
DEBUG - 2020-10-24 15:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:22 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:22 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:22 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:22 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:22 --> URI Class Initialized
INFO - 2020-10-24 15:03:22 --> Router Class Initialized
INFO - 2020-10-24 15:03:22 --> URI Class Initialized
INFO - 2020-10-24 15:03:22 --> URI Class Initialized
INFO - 2020-10-24 15:03:22 --> Output Class Initialized
INFO - 2020-10-24 15:03:22 --> Router Class Initialized
INFO - 2020-10-24 15:03:22 --> Router Class Initialized
INFO - 2020-10-24 15:03:22 --> Output Class Initialized
INFO - 2020-10-24 15:03:22 --> Output Class Initialized
INFO - 2020-10-24 15:03:22 --> Security Class Initialized
INFO - 2020-10-24 15:03:22 --> Security Class Initialized
INFO - 2020-10-24 15:03:22 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:22 --> Input Class Initialized
DEBUG - 2020-10-24 15:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:22 --> Input Class Initialized
INFO - 2020-10-24 15:03:22 --> Input Class Initialized
INFO - 2020-10-24 15:03:22 --> Language Class Initialized
INFO - 2020-10-24 15:03:22 --> Language Class Initialized
INFO - 2020-10-24 15:03:22 --> Language Class Initialized
ERROR - 2020-10-24 15:03:22 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:03:22 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:03:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:35 --> Config Class Initialized
INFO - 2020-10-24 15:03:35 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:35 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:35 --> URI Class Initialized
INFO - 2020-10-24 15:03:35 --> Router Class Initialized
INFO - 2020-10-24 15:03:35 --> Output Class Initialized
INFO - 2020-10-24 15:03:35 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:35 --> Input Class Initialized
INFO - 2020-10-24 15:03:35 --> Language Class Initialized
INFO - 2020-10-24 15:03:35 --> Loader Class Initialized
INFO - 2020-10-24 15:03:35 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:35 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:35 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:35 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:35 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:35 --> Table Class Initialized
INFO - 2020-10-24 15:03:35 --> Upload Class Initialized
INFO - 2020-10-24 15:03:35 --> Controller Class Initialized
INFO - 2020-10-24 15:03:35 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:35 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:35 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:03:36 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:03:36 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:03:36 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:03:36 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:03:36 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:03:36 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:36 --> Total execution time: 0.3728
INFO - 2020-10-24 15:03:36 --> Config Class Initialized
INFO - 2020-10-24 15:03:36 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:36 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:36 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:36 --> URI Class Initialized
INFO - 2020-10-24 15:03:36 --> Router Class Initialized
INFO - 2020-10-24 15:03:36 --> Output Class Initialized
INFO - 2020-10-24 15:03:36 --> Security Class Initialized
INFO - 2020-10-24 15:03:36 --> Config Class Initialized
DEBUG - 2020-10-24 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:36 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:36 --> Input Class Initialized
DEBUG - 2020-10-24 15:03:36 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:36 --> Language Class Initialized
INFO - 2020-10-24 15:03:36 --> Utf8 Class Initialized
ERROR - 2020-10-24 15:03:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:36 --> URI Class Initialized
INFO - 2020-10-24 15:03:36 --> Config Class Initialized
INFO - 2020-10-24 15:03:36 --> Router Class Initialized
INFO - 2020-10-24 15:03:36 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:36 --> Output Class Initialized
DEBUG - 2020-10-24 15:03:36 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:36 --> Security Class Initialized
INFO - 2020-10-24 15:03:36 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:36 --> URI Class Initialized
INFO - 2020-10-24 15:03:36 --> Input Class Initialized
INFO - 2020-10-24 15:03:36 --> Language Class Initialized
INFO - 2020-10-24 15:03:36 --> Router Class Initialized
INFO - 2020-10-24 15:03:36 --> Output Class Initialized
ERROR - 2020-10-24 15:03:36 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:36 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:36 --> Input Class Initialized
INFO - 2020-10-24 15:03:36 --> Language Class Initialized
ERROR - 2020-10-24 15:03:36 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:36 --> Config Class Initialized
INFO - 2020-10-24 15:03:36 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:36 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:36 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:36 --> URI Class Initialized
INFO - 2020-10-24 15:03:36 --> Router Class Initialized
INFO - 2020-10-24 15:03:36 --> Output Class Initialized
INFO - 2020-10-24 15:03:36 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:36 --> Input Class Initialized
INFO - 2020-10-24 15:03:36 --> Language Class Initialized
INFO - 2020-10-24 15:03:36 --> Loader Class Initialized
INFO - 2020-10-24 15:03:36 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:36 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:36 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:36 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:36 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:36 --> Table Class Initialized
INFO - 2020-10-24 15:03:36 --> Upload Class Initialized
INFO - 2020-10-24 15:03:36 --> Controller Class Initialized
INFO - 2020-10-24 15:03:36 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:36 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:36 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:36 --> Total execution time: 0.1847
INFO - 2020-10-24 15:03:37 --> Config Class Initialized
INFO - 2020-10-24 15:03:37 --> Config Class Initialized
INFO - 2020-10-24 15:03:37 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:37 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:37 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:37 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:37 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:37 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:37 --> URI Class Initialized
INFO - 2020-10-24 15:03:37 --> URI Class Initialized
INFO - 2020-10-24 15:03:37 --> Router Class Initialized
INFO - 2020-10-24 15:03:37 --> Config Class Initialized
INFO - 2020-10-24 15:03:37 --> Router Class Initialized
INFO - 2020-10-24 15:03:37 --> Output Class Initialized
INFO - 2020-10-24 15:03:37 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:37 --> Output Class Initialized
INFO - 2020-10-24 15:03:37 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:37 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:37 --> Security Class Initialized
INFO - 2020-10-24 15:03:37 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:37 --> URI Class Initialized
INFO - 2020-10-24 15:03:37 --> Input Class Initialized
INFO - 2020-10-24 15:03:37 --> Input Class Initialized
INFO - 2020-10-24 15:03:37 --> Router Class Initialized
INFO - 2020-10-24 15:03:37 --> Language Class Initialized
INFO - 2020-10-24 15:03:37 --> Language Class Initialized
ERROR - 2020-10-24 15:03:37 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:03:37 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:37 --> Output Class Initialized
INFO - 2020-10-24 15:03:37 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:37 --> Input Class Initialized
INFO - 2020-10-24 15:03:37 --> Language Class Initialized
ERROR - 2020-10-24 15:03:37 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:37 --> Config Class Initialized
INFO - 2020-10-24 15:03:37 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:37 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:37 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:37 --> URI Class Initialized
INFO - 2020-10-24 15:03:37 --> Router Class Initialized
INFO - 2020-10-24 15:03:37 --> Output Class Initialized
INFO - 2020-10-24 15:03:37 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:37 --> Input Class Initialized
INFO - 2020-10-24 15:03:37 --> Language Class Initialized
ERROR - 2020-10-24 15:03:37 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:42 --> Config Class Initialized
INFO - 2020-10-24 15:03:42 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:42 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:42 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:42 --> URI Class Initialized
INFO - 2020-10-24 15:03:42 --> Router Class Initialized
INFO - 2020-10-24 15:03:42 --> Output Class Initialized
INFO - 2020-10-24 15:03:42 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:42 --> Input Class Initialized
INFO - 2020-10-24 15:03:42 --> Language Class Initialized
ERROR - 2020-10-24 15:03:42 --> 404 Page Not Found: Welcome/index.html
INFO - 2020-10-24 15:03:43 --> Config Class Initialized
INFO - 2020-10-24 15:03:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:43 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:43 --> URI Class Initialized
INFO - 2020-10-24 15:03:43 --> Router Class Initialized
INFO - 2020-10-24 15:03:43 --> Output Class Initialized
INFO - 2020-10-24 15:03:43 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:43 --> Input Class Initialized
INFO - 2020-10-24 15:03:43 --> Language Class Initialized
ERROR - 2020-10-24 15:03:43 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-24 15:03:44 --> Config Class Initialized
INFO - 2020-10-24 15:03:44 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:44 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:44 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:44 --> URI Class Initialized
INFO - 2020-10-24 15:03:44 --> Router Class Initialized
INFO - 2020-10-24 15:03:44 --> Output Class Initialized
INFO - 2020-10-24 15:03:44 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:44 --> Input Class Initialized
INFO - 2020-10-24 15:03:44 --> Language Class Initialized
INFO - 2020-10-24 15:03:44 --> Loader Class Initialized
INFO - 2020-10-24 15:03:44 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:44 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:44 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:44 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:44 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:44 --> Table Class Initialized
INFO - 2020-10-24 15:03:44 --> Upload Class Initialized
INFO - 2020-10-24 15:03:44 --> Controller Class Initialized
INFO - 2020-10-24 15:03:44 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:44 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:44 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:03:44 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:03:44 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:03:44 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:03:44 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:03:44 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:03:44 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:44 --> Total execution time: 0.4211
INFO - 2020-10-24 15:03:44 --> Config Class Initialized
INFO - 2020-10-24 15:03:44 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:44 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:44 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:44 --> URI Class Initialized
INFO - 2020-10-24 15:03:44 --> Router Class Initialized
INFO - 2020-10-24 15:03:45 --> Output Class Initialized
INFO - 2020-10-24 15:03:45 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:45 --> Input Class Initialized
INFO - 2020-10-24 15:03:45 --> Language Class Initialized
INFO - 2020-10-24 15:03:45 --> Loader Class Initialized
INFO - 2020-10-24 15:03:45 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:45 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:45 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:45 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:45 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:45 --> Table Class Initialized
INFO - 2020-10-24 15:03:45 --> Upload Class Initialized
INFO - 2020-10-24 15:03:45 --> Controller Class Initialized
INFO - 2020-10-24 15:03:45 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:45 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:45 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:45 --> Total execution time: 0.3319
INFO - 2020-10-24 15:03:48 --> Config Class Initialized
INFO - 2020-10-24 15:03:48 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:48 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:48 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:48 --> URI Class Initialized
INFO - 2020-10-24 15:03:48 --> Router Class Initialized
INFO - 2020-10-24 15:03:48 --> Output Class Initialized
INFO - 2020-10-24 15:03:48 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:48 --> Input Class Initialized
INFO - 2020-10-24 15:03:48 --> Language Class Initialized
INFO - 2020-10-24 15:03:48 --> Loader Class Initialized
INFO - 2020-10-24 15:03:48 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:48 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:48 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:48 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:48 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:48 --> Table Class Initialized
INFO - 2020-10-24 15:03:48 --> Upload Class Initialized
INFO - 2020-10-24 15:03:48 --> Controller Class Initialized
INFO - 2020-10-24 15:03:48 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:48 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:48 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:03:48 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:03:48 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:03:48 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:03:48 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:03:48 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:03:48 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:48 --> Total execution time: 0.3895
INFO - 2020-10-24 15:03:48 --> Config Class Initialized
INFO - 2020-10-24 15:03:48 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:48 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:48 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:48 --> Config Class Initialized
INFO - 2020-10-24 15:03:48 --> URI Class Initialized
INFO - 2020-10-24 15:03:48 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:48 --> Router Class Initialized
DEBUG - 2020-10-24 15:03:48 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:48 --> Output Class Initialized
INFO - 2020-10-24 15:03:48 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:48 --> Security Class Initialized
INFO - 2020-10-24 15:03:48 --> URI Class Initialized
DEBUG - 2020-10-24 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:48 --> Router Class Initialized
INFO - 2020-10-24 15:03:48 --> Output Class Initialized
INFO - 2020-10-24 15:03:48 --> Input Class Initialized
INFO - 2020-10-24 15:03:48 --> Language Class Initialized
INFO - 2020-10-24 15:03:48 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 15:03:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:48 --> Input Class Initialized
INFO - 2020-10-24 15:03:48 --> Language Class Initialized
INFO - 2020-10-24 15:03:48 --> Config Class Initialized
ERROR - 2020-10-24 15:03:48 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:48 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:48 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:48 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:48 --> URI Class Initialized
INFO - 2020-10-24 15:03:48 --> Router Class Initialized
INFO - 2020-10-24 15:03:48 --> Config Class Initialized
INFO - 2020-10-24 15:03:48 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:48 --> Output Class Initialized
INFO - 2020-10-24 15:03:48 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:48 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:48 --> Input Class Initialized
INFO - 2020-10-24 15:03:48 --> URI Class Initialized
INFO - 2020-10-24 15:03:48 --> Language Class Initialized
INFO - 2020-10-24 15:03:48 --> Router Class Initialized
ERROR - 2020-10-24 15:03:48 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:48 --> Output Class Initialized
INFO - 2020-10-24 15:03:48 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:48 --> Input Class Initialized
INFO - 2020-10-24 15:03:48 --> Language Class Initialized
INFO - 2020-10-24 15:03:48 --> Loader Class Initialized
INFO - 2020-10-24 15:03:48 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:48 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:48 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:48 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:48 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:48 --> Table Class Initialized
INFO - 2020-10-24 15:03:48 --> Upload Class Initialized
INFO - 2020-10-24 15:03:49 --> Controller Class Initialized
INFO - 2020-10-24 15:03:49 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:49 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:49 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:49 --> Total execution time: 0.3002
INFO - 2020-10-24 15:03:49 --> Config Class Initialized
INFO - 2020-10-24 15:03:49 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:49 --> Config Class Initialized
INFO - 2020-10-24 15:03:49 --> Config Class Initialized
INFO - 2020-10-24 15:03:49 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:49 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:49 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:49 --> URI Class Initialized
INFO - 2020-10-24 15:03:49 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:49 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:49 --> URI Class Initialized
INFO - 2020-10-24 15:03:49 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:49 --> Router Class Initialized
INFO - 2020-10-24 15:03:49 --> Router Class Initialized
INFO - 2020-10-24 15:03:49 --> URI Class Initialized
INFO - 2020-10-24 15:03:49 --> Output Class Initialized
INFO - 2020-10-24 15:03:49 --> Security Class Initialized
INFO - 2020-10-24 15:03:49 --> Router Class Initialized
INFO - 2020-10-24 15:03:49 --> Output Class Initialized
INFO - 2020-10-24 15:03:49 --> Output Class Initialized
DEBUG - 2020-10-24 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:49 --> Security Class Initialized
INFO - 2020-10-24 15:03:49 --> Input Class Initialized
DEBUG - 2020-10-24 15:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:49 --> Security Class Initialized
INFO - 2020-10-24 15:03:49 --> Language Class Initialized
INFO - 2020-10-24 15:03:49 --> Input Class Initialized
DEBUG - 2020-10-24 15:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 15:03:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:49 --> Language Class Initialized
INFO - 2020-10-24 15:03:49 --> Input Class Initialized
INFO - 2020-10-24 15:03:49 --> Language Class Initialized
ERROR - 2020-10-24 15:03:49 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:03:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:51 --> Config Class Initialized
INFO - 2020-10-24 15:03:51 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:51 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:51 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:51 --> URI Class Initialized
INFO - 2020-10-24 15:03:51 --> Router Class Initialized
INFO - 2020-10-24 15:03:51 --> Output Class Initialized
INFO - 2020-10-24 15:03:51 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:51 --> Input Class Initialized
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
INFO - 2020-10-24 15:03:52 --> Loader Class Initialized
INFO - 2020-10-24 15:03:52 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:52 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:52 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:52 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:52 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:52 --> Table Class Initialized
INFO - 2020-10-24 15:03:52 --> Upload Class Initialized
INFO - 2020-10-24 15:03:52 --> Controller Class Initialized
INFO - 2020-10-24 15:03:52 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:52 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:52 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:03:52 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:03:52 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:03:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:03:52 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:03:52 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:03:52 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:52 --> Total execution time: 0.4465
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
INFO - 2020-10-24 15:03:52 --> Router Class Initialized
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:52 --> Output Class Initialized
INFO - 2020-10-24 15:03:52 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
INFO - 2020-10-24 15:03:52 --> Input Class Initialized
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
INFO - 2020-10-24 15:03:52 --> Router Class Initialized
INFO - 2020-10-24 15:03:52 --> Output Class Initialized
ERROR - 2020-10-24 15:03:52 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:52 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:52 --> Input Class Initialized
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
ERROR - 2020-10-24 15:03:52 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
INFO - 2020-10-24 15:03:52 --> Router Class Initialized
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Output Class Initialized
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Security Class Initialized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:52 --> Input Class Initialized
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
INFO - 2020-10-24 15:03:52 --> Router Class Initialized
INFO - 2020-10-24 15:03:52 --> Router Class Initialized
INFO - 2020-10-24 15:03:52 --> Router Class Initialized
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
ERROR - 2020-10-24 15:03:52 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:52 --> Output Class Initialized
INFO - 2020-10-24 15:03:52 --> Output Class Initialized
INFO - 2020-10-24 15:03:52 --> Output Class Initialized
INFO - 2020-10-24 15:03:52 --> Router Class Initialized
INFO - 2020-10-24 15:03:52 --> Security Class Initialized
INFO - 2020-10-24 15:03:52 --> Security Class Initialized
INFO - 2020-10-24 15:03:52 --> Output Class Initialized
INFO - 2020-10-24 15:03:52 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:52 --> Security Class Initialized
INFO - 2020-10-24 15:03:52 --> Input Class Initialized
INFO - 2020-10-24 15:03:52 --> Input Class Initialized
INFO - 2020-10-24 15:03:52 --> Input Class Initialized
DEBUG - 2020-10-24 15:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
INFO - 2020-10-24 15:03:52 --> Input Class Initialized
INFO - 2020-10-24 15:03:52 --> Loader Class Initialized
ERROR - 2020-10-24 15:03:52 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:03:52 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:52 --> Language Class Initialized
INFO - 2020-10-24 15:03:52 --> Helper loaded: url_helper
ERROR - 2020-10-24 15:03:52 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:52 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:52 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:52 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:52 --> Config Class Initialized
INFO - 2020-10-24 15:03:52 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:52 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:52 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:52 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:52 --> Table Class Initialized
INFO - 2020-10-24 15:03:52 --> Upload Class Initialized
INFO - 2020-10-24 15:03:52 --> URI Class Initialized
INFO - 2020-10-24 15:03:53 --> Router Class Initialized
INFO - 2020-10-24 15:03:53 --> Controller Class Initialized
INFO - 2020-10-24 15:03:53 --> Output Class Initialized
INFO - 2020-10-24 15:03:53 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:53 --> Security Class Initialized
INFO - 2020-10-24 15:03:53 --> Model "Crud_model" initialized
DEBUG - 2020-10-24 15:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:53 --> Final output sent to browser
INFO - 2020-10-24 15:03:53 --> Input Class Initialized
DEBUG - 2020-10-24 15:03:53 --> Total execution time: 0.3798
INFO - 2020-10-24 15:03:53 --> Language Class Initialized
ERROR - 2020-10-24 15:03:53 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:57 --> Config Class Initialized
INFO - 2020-10-24 15:03:57 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:57 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:57 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:57 --> URI Class Initialized
INFO - 2020-10-24 15:03:57 --> Router Class Initialized
INFO - 2020-10-24 15:03:57 --> Output Class Initialized
INFO - 2020-10-24 15:03:57 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:57 --> Input Class Initialized
INFO - 2020-10-24 15:03:57 --> Language Class Initialized
INFO - 2020-10-24 15:03:57 --> Loader Class Initialized
INFO - 2020-10-24 15:03:57 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:57 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:57 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:57 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:57 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:57 --> Table Class Initialized
INFO - 2020-10-24 15:03:58 --> Upload Class Initialized
INFO - 2020-10-24 15:03:58 --> Controller Class Initialized
INFO - 2020-10-24 15:03:58 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:58 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:58 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:03:58 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:03:58 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:03:58 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:03:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:03:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:03:58 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:58 --> Total execution time: 0.6675
INFO - 2020-10-24 15:03:58 --> Config Class Initialized
INFO - 2020-10-24 15:03:58 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:58 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:58 --> URI Class Initialized
INFO - 2020-10-24 15:03:58 --> Config Class Initialized
INFO - 2020-10-24 15:03:58 --> Router Class Initialized
INFO - 2020-10-24 15:03:58 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:58 --> Output Class Initialized
DEBUG - 2020-10-24 15:03:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:58 --> Security Class Initialized
INFO - 2020-10-24 15:03:58 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:58 --> Input Class Initialized
INFO - 2020-10-24 15:03:58 --> URI Class Initialized
INFO - 2020-10-24 15:03:58 --> Language Class Initialized
INFO - 2020-10-24 15:03:58 --> Router Class Initialized
INFO - 2020-10-24 15:03:58 --> Output Class Initialized
ERROR - 2020-10-24 15:03:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:03:58 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:58 --> Config Class Initialized
INFO - 2020-10-24 15:03:58 --> Input Class Initialized
INFO - 2020-10-24 15:03:58 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:03:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:58 --> Language Class Initialized
ERROR - 2020-10-24 15:03:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:58 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:58 --> URI Class Initialized
INFO - 2020-10-24 15:03:58 --> Router Class Initialized
INFO - 2020-10-24 15:03:58 --> Config Class Initialized
INFO - 2020-10-24 15:03:58 --> Config Class Initialized
INFO - 2020-10-24 15:03:58 --> Output Class Initialized
INFO - 2020-10-24 15:03:58 --> Config Class Initialized
INFO - 2020-10-24 15:03:58 --> Config Class Initialized
INFO - 2020-10-24 15:03:58 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:58 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:58 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:58 --> Hooks Class Initialized
INFO - 2020-10-24 15:03:58 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:03:58 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:03:58 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:58 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:58 --> Utf8 Class Initialized
INFO - 2020-10-24 15:03:58 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:58 --> URI Class Initialized
INFO - 2020-10-24 15:03:58 --> Input Class Initialized
INFO - 2020-10-24 15:03:58 --> URI Class Initialized
INFO - 2020-10-24 15:03:58 --> URI Class Initialized
INFO - 2020-10-24 15:03:58 --> URI Class Initialized
INFO - 2020-10-24 15:03:58 --> Language Class Initialized
INFO - 2020-10-24 15:03:58 --> Router Class Initialized
INFO - 2020-10-24 15:03:58 --> Router Class Initialized
INFO - 2020-10-24 15:03:58 --> Router Class Initialized
INFO - 2020-10-24 15:03:58 --> Router Class Initialized
ERROR - 2020-10-24 15:03:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:58 --> Output Class Initialized
INFO - 2020-10-24 15:03:58 --> Output Class Initialized
INFO - 2020-10-24 15:03:58 --> Output Class Initialized
INFO - 2020-10-24 15:03:58 --> Output Class Initialized
INFO - 2020-10-24 15:03:58 --> Security Class Initialized
INFO - 2020-10-24 15:03:58 --> Security Class Initialized
INFO - 2020-10-24 15:03:58 --> Security Class Initialized
INFO - 2020-10-24 15:03:58 --> Security Class Initialized
DEBUG - 2020-10-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:03:58 --> Input Class Initialized
INFO - 2020-10-24 15:03:58 --> Input Class Initialized
INFO - 2020-10-24 15:03:58 --> Input Class Initialized
INFO - 2020-10-24 15:03:58 --> Input Class Initialized
INFO - 2020-10-24 15:03:58 --> Language Class Initialized
INFO - 2020-10-24 15:03:58 --> Language Class Initialized
INFO - 2020-10-24 15:03:58 --> Language Class Initialized
INFO - 2020-10-24 15:03:58 --> Language Class Initialized
ERROR - 2020-10-24 15:03:58 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:03:58 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:03:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:03:58 --> Loader Class Initialized
INFO - 2020-10-24 15:03:58 --> Helper loaded: url_helper
INFO - 2020-10-24 15:03:58 --> Helper loaded: form_helper
INFO - 2020-10-24 15:03:58 --> Helper loaded: html_helper
INFO - 2020-10-24 15:03:58 --> Helper loaded: date_helper
INFO - 2020-10-24 15:03:58 --> Database Driver Class Initialized
INFO - 2020-10-24 15:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:03:59 --> Table Class Initialized
INFO - 2020-10-24 15:03:59 --> Upload Class Initialized
INFO - 2020-10-24 15:03:59 --> Controller Class Initialized
INFO - 2020-10-24 15:03:59 --> Form Validation Class Initialized
INFO - 2020-10-24 15:03:59 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:03:59 --> Final output sent to browser
DEBUG - 2020-10-24 15:03:59 --> Total execution time: 0.4074
INFO - 2020-10-24 15:04:08 --> Config Class Initialized
INFO - 2020-10-24 15:04:08 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:08 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:08 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:08 --> URI Class Initialized
INFO - 2020-10-24 15:04:08 --> Router Class Initialized
INFO - 2020-10-24 15:04:08 --> Output Class Initialized
INFO - 2020-10-24 15:04:08 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:08 --> Input Class Initialized
INFO - 2020-10-24 15:04:08 --> Language Class Initialized
INFO - 2020-10-24 15:04:08 --> Loader Class Initialized
INFO - 2020-10-24 15:04:08 --> Helper loaded: url_helper
INFO - 2020-10-24 15:04:08 --> Helper loaded: form_helper
INFO - 2020-10-24 15:04:08 --> Helper loaded: html_helper
INFO - 2020-10-24 15:04:08 --> Helper loaded: date_helper
INFO - 2020-10-24 15:04:08 --> Database Driver Class Initialized
INFO - 2020-10-24 15:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:04:08 --> Table Class Initialized
INFO - 2020-10-24 15:04:08 --> Upload Class Initialized
INFO - 2020-10-24 15:04:08 --> Controller Class Initialized
INFO - 2020-10-24 15:04:08 --> Form Validation Class Initialized
INFO - 2020-10-24 15:04:08 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:04:08 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:04:08 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:04:08 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:04:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:04:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:04:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:04:08 --> Final output sent to browser
DEBUG - 2020-10-24 15:04:08 --> Total execution time: 0.4715
INFO - 2020-10-24 15:04:09 --> Config Class Initialized
INFO - 2020-10-24 15:04:09 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:09 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:09 --> Config Class Initialized
INFO - 2020-10-24 15:04:09 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:09 --> URI Class Initialized
INFO - 2020-10-24 15:04:09 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:09 --> Router Class Initialized
DEBUG - 2020-10-24 15:04:09 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:09 --> Output Class Initialized
INFO - 2020-10-24 15:04:09 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:09 --> Security Class Initialized
INFO - 2020-10-24 15:04:09 --> URI Class Initialized
DEBUG - 2020-10-24 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:09 --> Router Class Initialized
INFO - 2020-10-24 15:04:09 --> Input Class Initialized
INFO - 2020-10-24 15:04:09 --> Output Class Initialized
INFO - 2020-10-24 15:04:09 --> Security Class Initialized
INFO - 2020-10-24 15:04:09 --> Language Class Initialized
DEBUG - 2020-10-24 15:04:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 15:04:09 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:04:09 --> Input Class Initialized
INFO - 2020-10-24 15:04:09 --> Config Class Initialized
INFO - 2020-10-24 15:04:09 --> Language Class Initialized
INFO - 2020-10-24 15:04:09 --> Hooks Class Initialized
ERROR - 2020-10-24 15:04:09 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 15:04:09 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:09 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:09 --> URI Class Initialized
INFO - 2020-10-24 15:04:09 --> Config Class Initialized
INFO - 2020-10-24 15:04:09 --> Config Class Initialized
INFO - 2020-10-24 15:04:09 --> Config Class Initialized
INFO - 2020-10-24 15:04:09 --> Router Class Initialized
INFO - 2020-10-24 15:04:09 --> Config Class Initialized
INFO - 2020-10-24 15:04:09 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:09 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:09 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:09 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:09 --> Output Class Initialized
DEBUG - 2020-10-24 15:04:09 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:09 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:04:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:04:09 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:09 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:09 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:09 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:09 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:09 --> URI Class Initialized
INFO - 2020-10-24 15:04:09 --> Input Class Initialized
INFO - 2020-10-24 15:04:09 --> URI Class Initialized
INFO - 2020-10-24 15:04:09 --> URI Class Initialized
INFO - 2020-10-24 15:04:09 --> URI Class Initialized
INFO - 2020-10-24 15:04:09 --> Router Class Initialized
INFO - 2020-10-24 15:04:09 --> Router Class Initialized
INFO - 2020-10-24 15:04:09 --> Router Class Initialized
INFO - 2020-10-24 15:04:09 --> Language Class Initialized
INFO - 2020-10-24 15:04:09 --> Router Class Initialized
INFO - 2020-10-24 15:04:09 --> Output Class Initialized
INFO - 2020-10-24 15:04:09 --> Output Class Initialized
ERROR - 2020-10-24 15:04:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:09 --> Output Class Initialized
INFO - 2020-10-24 15:04:09 --> Output Class Initialized
INFO - 2020-10-24 15:04:09 --> Security Class Initialized
INFO - 2020-10-24 15:04:09 --> Security Class Initialized
INFO - 2020-10-24 15:04:09 --> Security Class Initialized
INFO - 2020-10-24 15:04:09 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:09 --> Input Class Initialized
INFO - 2020-10-24 15:04:09 --> Input Class Initialized
INFO - 2020-10-24 15:04:09 --> Input Class Initialized
INFO - 2020-10-24 15:04:09 --> Input Class Initialized
INFO - 2020-10-24 15:04:09 --> Language Class Initialized
INFO - 2020-10-24 15:04:09 --> Language Class Initialized
INFO - 2020-10-24 15:04:09 --> Language Class Initialized
INFO - 2020-10-24 15:04:09 --> Language Class Initialized
ERROR - 2020-10-24 15:04:09 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:04:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:09 --> Loader Class Initialized
ERROR - 2020-10-24 15:04:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:09 --> Helper loaded: url_helper
INFO - 2020-10-24 15:04:09 --> Helper loaded: form_helper
INFO - 2020-10-24 15:04:09 --> Helper loaded: html_helper
INFO - 2020-10-24 15:04:09 --> Helper loaded: date_helper
INFO - 2020-10-24 15:04:09 --> Database Driver Class Initialized
INFO - 2020-10-24 15:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:04:09 --> Table Class Initialized
INFO - 2020-10-24 15:04:09 --> Upload Class Initialized
INFO - 2020-10-24 15:04:09 --> Controller Class Initialized
INFO - 2020-10-24 15:04:09 --> Form Validation Class Initialized
INFO - 2020-10-24 15:04:09 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:04:09 --> Final output sent to browser
DEBUG - 2020-10-24 15:04:09 --> Total execution time: 0.4082
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:17 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:17 --> URI Class Initialized
INFO - 2020-10-24 15:04:17 --> Router Class Initialized
INFO - 2020-10-24 15:04:17 --> Output Class Initialized
INFO - 2020-10-24 15:04:17 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:17 --> Input Class Initialized
INFO - 2020-10-24 15:04:17 --> Language Class Initialized
INFO - 2020-10-24 15:04:17 --> Loader Class Initialized
INFO - 2020-10-24 15:04:17 --> Helper loaded: url_helper
INFO - 2020-10-24 15:04:17 --> Helper loaded: form_helper
INFO - 2020-10-24 15:04:17 --> Helper loaded: html_helper
INFO - 2020-10-24 15:04:17 --> Helper loaded: date_helper
INFO - 2020-10-24 15:04:17 --> Database Driver Class Initialized
INFO - 2020-10-24 15:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:04:17 --> Table Class Initialized
INFO - 2020-10-24 15:04:17 --> Upload Class Initialized
INFO - 2020-10-24 15:04:17 --> Controller Class Initialized
INFO - 2020-10-24 15:04:17 --> Form Validation Class Initialized
INFO - 2020-10-24 15:04:17 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:04:17 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:04:17 --> Final output sent to browser
DEBUG - 2020-10-24 15:04:17 --> Total execution time: 0.4184
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:17 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:17 --> URI Class Initialized
INFO - 2020-10-24 15:04:17 --> Router Class Initialized
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:17 --> Output Class Initialized
INFO - 2020-10-24 15:04:17 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:17 --> Security Class Initialized
INFO - 2020-10-24 15:04:17 --> URI Class Initialized
DEBUG - 2020-10-24 15:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:17 --> Router Class Initialized
INFO - 2020-10-24 15:04:17 --> Output Class Initialized
INFO - 2020-10-24 15:04:17 --> Input Class Initialized
INFO - 2020-10-24 15:04:17 --> Language Class Initialized
INFO - 2020-10-24 15:04:17 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 15:04:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:04:17 --> Input Class Initialized
INFO - 2020-10-24 15:04:17 --> Language Class Initialized
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
ERROR - 2020-10-24 15:04:17 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:17 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:17 --> URI Class Initialized
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Router Class Initialized
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Config Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:17 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:17 --> Output Class Initialized
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:17 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:18 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:18 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:18 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:18 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:18 --> URI Class Initialized
INFO - 2020-10-24 15:04:18 --> URI Class Initialized
INFO - 2020-10-24 15:04:18 --> URI Class Initialized
INFO - 2020-10-24 15:04:18 --> Input Class Initialized
INFO - 2020-10-24 15:04:18 --> URI Class Initialized
INFO - 2020-10-24 15:04:18 --> Language Class Initialized
INFO - 2020-10-24 15:04:18 --> Router Class Initialized
INFO - 2020-10-24 15:04:18 --> Router Class Initialized
INFO - 2020-10-24 15:04:18 --> Router Class Initialized
INFO - 2020-10-24 15:04:18 --> Router Class Initialized
ERROR - 2020-10-24 15:04:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:18 --> Output Class Initialized
INFO - 2020-10-24 15:04:18 --> Output Class Initialized
INFO - 2020-10-24 15:04:18 --> Output Class Initialized
INFO - 2020-10-24 15:04:18 --> Output Class Initialized
INFO - 2020-10-24 15:04:18 --> Security Class Initialized
INFO - 2020-10-24 15:04:18 --> Security Class Initialized
INFO - 2020-10-24 15:04:18 --> Security Class Initialized
INFO - 2020-10-24 15:04:18 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:18 --> Input Class Initialized
INFO - 2020-10-24 15:04:18 --> Input Class Initialized
INFO - 2020-10-24 15:04:18 --> Input Class Initialized
INFO - 2020-10-24 15:04:18 --> Input Class Initialized
INFO - 2020-10-24 15:04:18 --> Language Class Initialized
INFO - 2020-10-24 15:04:18 --> Language Class Initialized
INFO - 2020-10-24 15:04:18 --> Language Class Initialized
INFO - 2020-10-24 15:04:18 --> Language Class Initialized
ERROR - 2020-10-24 15:04:18 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:04:18 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:04:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:18 --> Loader Class Initialized
INFO - 2020-10-24 15:04:18 --> Helper loaded: url_helper
INFO - 2020-10-24 15:04:18 --> Helper loaded: form_helper
INFO - 2020-10-24 15:04:18 --> Helper loaded: html_helper
INFO - 2020-10-24 15:04:18 --> Helper loaded: date_helper
INFO - 2020-10-24 15:04:18 --> Database Driver Class Initialized
INFO - 2020-10-24 15:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:04:18 --> Table Class Initialized
INFO - 2020-10-24 15:04:18 --> Upload Class Initialized
INFO - 2020-10-24 15:04:18 --> Controller Class Initialized
INFO - 2020-10-24 15:04:18 --> Form Validation Class Initialized
INFO - 2020-10-24 15:04:18 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:04:18 --> Final output sent to browser
DEBUG - 2020-10-24 15:04:18 --> Total execution time: 0.4512
INFO - 2020-10-24 15:04:21 --> Config Class Initialized
INFO - 2020-10-24 15:04:21 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:22 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:22 --> URI Class Initialized
INFO - 2020-10-24 15:04:22 --> Router Class Initialized
INFO - 2020-10-24 15:04:22 --> Output Class Initialized
INFO - 2020-10-24 15:04:22 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:22 --> Input Class Initialized
INFO - 2020-10-24 15:04:22 --> Language Class Initialized
INFO - 2020-10-24 15:04:22 --> Loader Class Initialized
INFO - 2020-10-24 15:04:22 --> Helper loaded: url_helper
INFO - 2020-10-24 15:04:22 --> Helper loaded: form_helper
INFO - 2020-10-24 15:04:22 --> Helper loaded: html_helper
INFO - 2020-10-24 15:04:22 --> Helper loaded: date_helper
INFO - 2020-10-24 15:04:22 --> Database Driver Class Initialized
INFO - 2020-10-24 15:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:04:22 --> Table Class Initialized
INFO - 2020-10-24 15:04:22 --> Upload Class Initialized
INFO - 2020-10-24 15:04:22 --> Controller Class Initialized
INFO - 2020-10-24 15:04:22 --> Form Validation Class Initialized
INFO - 2020-10-24 15:04:22 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:04:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:04:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:04:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:04:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:04:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:04:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:04:22 --> Final output sent to browser
DEBUG - 2020-10-24 15:04:22 --> Total execution time: 0.5743
INFO - 2020-10-24 15:04:22 --> Config Class Initialized
INFO - 2020-10-24 15:04:22 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:22 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:22 --> URI Class Initialized
INFO - 2020-10-24 15:04:22 --> Router Class Initialized
INFO - 2020-10-24 15:04:22 --> Config Class Initialized
INFO - 2020-10-24 15:04:22 --> Output Class Initialized
INFO - 2020-10-24 15:04:22 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:22 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:22 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:22 --> URI Class Initialized
INFO - 2020-10-24 15:04:22 --> Input Class Initialized
INFO - 2020-10-24 15:04:22 --> Language Class Initialized
INFO - 2020-10-24 15:04:22 --> Router Class Initialized
ERROR - 2020-10-24 15:04:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:04:22 --> Output Class Initialized
INFO - 2020-10-24 15:04:22 --> Security Class Initialized
INFO - 2020-10-24 15:04:22 --> Config Class Initialized
DEBUG - 2020-10-24 15:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:22 --> Input Class Initialized
INFO - 2020-10-24 15:04:22 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:22 --> Language Class Initialized
ERROR - 2020-10-24 15:04:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:22 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:22 --> URI Class Initialized
INFO - 2020-10-24 15:04:22 --> Router Class Initialized
INFO - 2020-10-24 15:04:22 --> Output Class Initialized
INFO - 2020-10-24 15:04:22 --> Security Class Initialized
INFO - 2020-10-24 15:04:22 --> Config Class Initialized
DEBUG - 2020-10-24 15:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:22 --> Input Class Initialized
INFO - 2020-10-24 15:04:22 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:22 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:22 --> Language Class Initialized
ERROR - 2020-10-24 15:04:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:22 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:22 --> URI Class Initialized
INFO - 2020-10-24 15:04:22 --> Router Class Initialized
INFO - 2020-10-24 15:04:22 --> Output Class Initialized
INFO - 2020-10-24 15:04:23 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:23 --> Input Class Initialized
INFO - 2020-10-24 15:04:23 --> Language Class Initialized
INFO - 2020-10-24 15:04:23 --> Loader Class Initialized
INFO - 2020-10-24 15:04:23 --> Helper loaded: url_helper
INFO - 2020-10-24 15:04:23 --> Helper loaded: form_helper
INFO - 2020-10-24 15:04:23 --> Helper loaded: html_helper
INFO - 2020-10-24 15:04:23 --> Helper loaded: date_helper
INFO - 2020-10-24 15:04:23 --> Database Driver Class Initialized
INFO - 2020-10-24 15:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:04:23 --> Table Class Initialized
INFO - 2020-10-24 15:04:23 --> Upload Class Initialized
INFO - 2020-10-24 15:04:23 --> Controller Class Initialized
INFO - 2020-10-24 15:04:23 --> Form Validation Class Initialized
INFO - 2020-10-24 15:04:23 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:04:23 --> Final output sent to browser
DEBUG - 2020-10-24 15:04:23 --> Total execution time: 0.2585
INFO - 2020-10-24 15:04:23 --> Config Class Initialized
INFO - 2020-10-24 15:04:23 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:23 --> Config Class Initialized
INFO - 2020-10-24 15:04:23 --> Config Class Initialized
DEBUG - 2020-10-24 15:04:23 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:23 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:23 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:23 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:04:23 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:23 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:23 --> URI Class Initialized
DEBUG - 2020-10-24 15:04:23 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:23 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:23 --> URI Class Initialized
INFO - 2020-10-24 15:04:23 --> Router Class Initialized
INFO - 2020-10-24 15:04:23 --> Output Class Initialized
INFO - 2020-10-24 15:04:23 --> URI Class Initialized
INFO - 2020-10-24 15:04:23 --> Router Class Initialized
INFO - 2020-10-24 15:04:23 --> Security Class Initialized
INFO - 2020-10-24 15:04:23 --> Router Class Initialized
INFO - 2020-10-24 15:04:23 --> Output Class Initialized
DEBUG - 2020-10-24 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:23 --> Output Class Initialized
INFO - 2020-10-24 15:04:23 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:23 --> Security Class Initialized
INFO - 2020-10-24 15:04:23 --> Input Class Initialized
DEBUG - 2020-10-24 15:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:23 --> Language Class Initialized
INFO - 2020-10-24 15:04:23 --> Input Class Initialized
INFO - 2020-10-24 15:04:23 --> Input Class Initialized
INFO - 2020-10-24 15:04:23 --> Language Class Initialized
ERROR - 2020-10-24 15:04:23 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:04:23 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:23 --> Language Class Initialized
ERROR - 2020-10-24 15:04:23 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:04:30 --> Config Class Initialized
INFO - 2020-10-24 15:04:30 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:30 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:30 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:30 --> URI Class Initialized
INFO - 2020-10-24 15:04:30 --> Router Class Initialized
INFO - 2020-10-24 15:04:30 --> Output Class Initialized
INFO - 2020-10-24 15:04:30 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:30 --> Input Class Initialized
INFO - 2020-10-24 15:04:30 --> Language Class Initialized
ERROR - 2020-10-24 15:04:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:04:56 --> Config Class Initialized
INFO - 2020-10-24 15:04:56 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:56 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:56 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:56 --> URI Class Initialized
INFO - 2020-10-24 15:04:56 --> Router Class Initialized
INFO - 2020-10-24 15:04:56 --> Output Class Initialized
INFO - 2020-10-24 15:04:56 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:56 --> Input Class Initialized
INFO - 2020-10-24 15:04:56 --> Language Class Initialized
INFO - 2020-10-24 15:04:56 --> Loader Class Initialized
INFO - 2020-10-24 15:04:56 --> Helper loaded: url_helper
INFO - 2020-10-24 15:04:56 --> Helper loaded: form_helper
INFO - 2020-10-24 15:04:56 --> Helper loaded: html_helper
INFO - 2020-10-24 15:04:56 --> Helper loaded: date_helper
INFO - 2020-10-24 15:04:56 --> Database Driver Class Initialized
INFO - 2020-10-24 15:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:04:56 --> Table Class Initialized
INFO - 2020-10-24 15:04:56 --> Upload Class Initialized
INFO - 2020-10-24 15:04:56 --> Controller Class Initialized
INFO - 2020-10-24 15:04:56 --> Form Validation Class Initialized
INFO - 2020-10-24 15:04:56 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:04:56 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:04:56 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:04:56 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:04:56 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:04:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:04:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:04:56 --> Final output sent to browser
DEBUG - 2020-10-24 15:04:56 --> Total execution time: 0.4966
INFO - 2020-10-24 15:04:57 --> Config Class Initialized
INFO - 2020-10-24 15:04:57 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:04:57 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:57 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:57 --> URI Class Initialized
INFO - 2020-10-24 15:04:57 --> Router Class Initialized
INFO - 2020-10-24 15:04:57 --> Output Class Initialized
INFO - 2020-10-24 15:04:57 --> Security Class Initialized
DEBUG - 2020-10-24 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:57 --> Config Class Initialized
INFO - 2020-10-24 15:04:57 --> Input Class Initialized
INFO - 2020-10-24 15:04:57 --> Language Class Initialized
INFO - 2020-10-24 15:04:57 --> Hooks Class Initialized
ERROR - 2020-10-24 15:04:57 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-24 15:04:57 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:57 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:57 --> Config Class Initialized
INFO - 2020-10-24 15:04:57 --> URI Class Initialized
INFO - 2020-10-24 15:04:57 --> Hooks Class Initialized
INFO - 2020-10-24 15:04:57 --> Router Class Initialized
DEBUG - 2020-10-24 15:04:57 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:04:57 --> Output Class Initialized
INFO - 2020-10-24 15:04:57 --> Utf8 Class Initialized
INFO - 2020-10-24 15:04:57 --> URI Class Initialized
INFO - 2020-10-24 15:04:57 --> Security Class Initialized
INFO - 2020-10-24 15:04:57 --> Router Class Initialized
DEBUG - 2020-10-24 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:57 --> Output Class Initialized
INFO - 2020-10-24 15:04:57 --> Input Class Initialized
INFO - 2020-10-24 15:04:57 --> Security Class Initialized
INFO - 2020-10-24 15:04:57 --> Language Class Initialized
ERROR - 2020-10-24 15:04:57 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-24 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:04:57 --> Input Class Initialized
INFO - 2020-10-24 15:04:57 --> Language Class Initialized
ERROR - 2020-10-24 15:04:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:00 --> Config Class Initialized
INFO - 2020-10-24 15:05:00 --> Hooks Class Initialized
INFO - 2020-10-24 15:05:00 --> Config Class Initialized
INFO - 2020-10-24 15:05:00 --> Config Class Initialized
INFO - 2020-10-24 15:05:00 --> Config Class Initialized
INFO - 2020-10-24 15:05:00 --> Hooks Class Initialized
INFO - 2020-10-24 15:05:00 --> Hooks Class Initialized
INFO - 2020-10-24 15:05:00 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:05:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:05:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:05:00 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:00 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:00 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:00 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:05:00 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:00 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:00 --> URI Class Initialized
INFO - 2020-10-24 15:05:00 --> URI Class Initialized
INFO - 2020-10-24 15:05:00 --> URI Class Initialized
INFO - 2020-10-24 15:05:00 --> Router Class Initialized
INFO - 2020-10-24 15:05:00 --> Router Class Initialized
INFO - 2020-10-24 15:05:00 --> Router Class Initialized
INFO - 2020-10-24 15:05:00 --> URI Class Initialized
INFO - 2020-10-24 15:05:00 --> Router Class Initialized
INFO - 2020-10-24 15:05:00 --> Output Class Initialized
INFO - 2020-10-24 15:05:00 --> Output Class Initialized
INFO - 2020-10-24 15:05:00 --> Output Class Initialized
INFO - 2020-10-24 15:05:00 --> Security Class Initialized
INFO - 2020-10-24 15:05:00 --> Security Class Initialized
INFO - 2020-10-24 15:05:00 --> Output Class Initialized
INFO - 2020-10-24 15:05:00 --> Security Class Initialized
DEBUG - 2020-10-24 15:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:00 --> Security Class Initialized
INFO - 2020-10-24 15:05:00 --> Input Class Initialized
INFO - 2020-10-24 15:05:00 --> Input Class Initialized
DEBUG - 2020-10-24 15:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:00 --> Input Class Initialized
INFO - 2020-10-24 15:05:00 --> Language Class Initialized
INFO - 2020-10-24 15:05:00 --> Input Class Initialized
INFO - 2020-10-24 15:05:00 --> Language Class Initialized
INFO - 2020-10-24 15:05:00 --> Language Class Initialized
ERROR - 2020-10-24 15:05:00 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:00 --> Loader Class Initialized
INFO - 2020-10-24 15:05:00 --> Language Class Initialized
ERROR - 2020-10-24 15:05:00 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:00 --> Helper loaded: url_helper
ERROR - 2020-10-24 15:05:00 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:00 --> Helper loaded: form_helper
INFO - 2020-10-24 15:05:00 --> Helper loaded: html_helper
INFO - 2020-10-24 15:05:00 --> Helper loaded: date_helper
INFO - 2020-10-24 15:05:00 --> Database Driver Class Initialized
INFO - 2020-10-24 15:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:05:00 --> Table Class Initialized
INFO - 2020-10-24 15:05:00 --> Upload Class Initialized
INFO - 2020-10-24 15:05:00 --> Controller Class Initialized
INFO - 2020-10-24 15:05:00 --> Form Validation Class Initialized
INFO - 2020-10-24 15:05:00 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:05:00 --> Final output sent to browser
DEBUG - 2020-10-24 15:05:00 --> Total execution time: 0.4818
INFO - 2020-10-24 15:05:40 --> Config Class Initialized
INFO - 2020-10-24 15:05:40 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:05:40 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:40 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:40 --> URI Class Initialized
INFO - 2020-10-24 15:05:40 --> Router Class Initialized
INFO - 2020-10-24 15:05:40 --> Output Class Initialized
INFO - 2020-10-24 15:05:40 --> Security Class Initialized
DEBUG - 2020-10-24 15:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:40 --> Input Class Initialized
INFO - 2020-10-24 15:05:40 --> Language Class Initialized
INFO - 2020-10-24 15:05:40 --> Loader Class Initialized
INFO - 2020-10-24 15:05:40 --> Helper loaded: url_helper
INFO - 2020-10-24 15:05:40 --> Helper loaded: form_helper
INFO - 2020-10-24 15:05:40 --> Helper loaded: html_helper
INFO - 2020-10-24 15:05:40 --> Helper loaded: date_helper
INFO - 2020-10-24 15:05:41 --> Database Driver Class Initialized
INFO - 2020-10-24 15:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:05:41 --> Table Class Initialized
INFO - 2020-10-24 15:05:41 --> Upload Class Initialized
INFO - 2020-10-24 15:05:41 --> Controller Class Initialized
INFO - 2020-10-24 15:05:41 --> Form Validation Class Initialized
INFO - 2020-10-24 15:05:41 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:05:41 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 15:05:41 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 15:05:41 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 15:05:41 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 15:05:41 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 15:05:41 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 15:05:41 --> Final output sent to browser
DEBUG - 2020-10-24 15:05:41 --> Total execution time: 0.4504
INFO - 2020-10-24 15:05:41 --> Config Class Initialized
INFO - 2020-10-24 15:05:41 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:05:41 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:41 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:41 --> URI Class Initialized
INFO - 2020-10-24 15:05:41 --> Router Class Initialized
INFO - 2020-10-24 15:05:41 --> Output Class Initialized
INFO - 2020-10-24 15:05:41 --> Security Class Initialized
DEBUG - 2020-10-24 15:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:41 --> Input Class Initialized
INFO - 2020-10-24 15:05:41 --> Language Class Initialized
ERROR - 2020-10-24 15:05:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 15:05:41 --> Config Class Initialized
INFO - 2020-10-24 15:05:41 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:05:41 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:41 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:41 --> Config Class Initialized
INFO - 2020-10-24 15:05:41 --> Hooks Class Initialized
INFO - 2020-10-24 15:05:41 --> URI Class Initialized
INFO - 2020-10-24 15:05:41 --> Router Class Initialized
DEBUG - 2020-10-24 15:05:41 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:41 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:41 --> Output Class Initialized
INFO - 2020-10-24 15:05:41 --> Security Class Initialized
INFO - 2020-10-24 15:05:41 --> URI Class Initialized
INFO - 2020-10-24 15:05:41 --> Router Class Initialized
DEBUG - 2020-10-24 15:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:41 --> Input Class Initialized
INFO - 2020-10-24 15:05:41 --> Output Class Initialized
INFO - 2020-10-24 15:05:41 --> Language Class Initialized
INFO - 2020-10-24 15:05:41 --> Security Class Initialized
INFO - 2020-10-24 15:05:41 --> Loader Class Initialized
DEBUG - 2020-10-24 15:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:41 --> Helper loaded: url_helper
INFO - 2020-10-24 15:05:41 --> Input Class Initialized
INFO - 2020-10-24 15:05:41 --> Helper loaded: form_helper
INFO - 2020-10-24 15:05:41 --> Language Class Initialized
INFO - 2020-10-24 15:05:41 --> Helper loaded: html_helper
ERROR - 2020-10-24 15:05:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:41 --> Helper loaded: date_helper
INFO - 2020-10-24 15:05:41 --> Database Driver Class Initialized
INFO - 2020-10-24 15:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 15:05:41 --> Table Class Initialized
INFO - 2020-10-24 15:05:41 --> Upload Class Initialized
INFO - 2020-10-24 15:05:41 --> Controller Class Initialized
INFO - 2020-10-24 15:05:41 --> Form Validation Class Initialized
INFO - 2020-10-24 15:05:41 --> Model "Crud_model" initialized
INFO - 2020-10-24 15:05:41 --> Final output sent to browser
DEBUG - 2020-10-24 15:05:42 --> Total execution time: 0.3366
INFO - 2020-10-24 15:05:42 --> Config Class Initialized
INFO - 2020-10-24 15:05:42 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:05:42 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:42 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:42 --> URI Class Initialized
INFO - 2020-10-24 15:05:42 --> Router Class Initialized
INFO - 2020-10-24 15:05:42 --> Output Class Initialized
INFO - 2020-10-24 15:05:42 --> Security Class Initialized
DEBUG - 2020-10-24 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:42 --> Config Class Initialized
INFO - 2020-10-24 15:05:42 --> Input Class Initialized
INFO - 2020-10-24 15:05:42 --> Hooks Class Initialized
INFO - 2020-10-24 15:05:42 --> Language Class Initialized
DEBUG - 2020-10-24 15:05:42 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:42 --> Config Class Initialized
INFO - 2020-10-24 15:05:42 --> Config Class Initialized
ERROR - 2020-10-24 15:05:42 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:42 --> Hooks Class Initialized
INFO - 2020-10-24 15:05:42 --> Hooks Class Initialized
INFO - 2020-10-24 15:05:42 --> Utf8 Class Initialized
DEBUG - 2020-10-24 15:05:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 15:05:42 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:42 --> URI Class Initialized
INFO - 2020-10-24 15:05:42 --> Router Class Initialized
INFO - 2020-10-24 15:05:42 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:42 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:42 --> URI Class Initialized
INFO - 2020-10-24 15:05:42 --> Output Class Initialized
INFO - 2020-10-24 15:05:42 --> URI Class Initialized
INFO - 2020-10-24 15:05:42 --> Security Class Initialized
INFO - 2020-10-24 15:05:42 --> Router Class Initialized
INFO - 2020-10-24 15:05:42 --> Router Class Initialized
INFO - 2020-10-24 15:05:42 --> Output Class Initialized
DEBUG - 2020-10-24 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:42 --> Output Class Initialized
INFO - 2020-10-24 15:05:42 --> Security Class Initialized
INFO - 2020-10-24 15:05:42 --> Input Class Initialized
INFO - 2020-10-24 15:05:42 --> Security Class Initialized
DEBUG - 2020-10-24 15:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-24 15:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:42 --> Language Class Initialized
INFO - 2020-10-24 15:05:42 --> Input Class Initialized
INFO - 2020-10-24 15:05:42 --> Input Class Initialized
ERROR - 2020-10-24 15:05:42 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:42 --> Language Class Initialized
INFO - 2020-10-24 15:05:42 --> Language Class Initialized
ERROR - 2020-10-24 15:05:42 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 15:05:42 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 15:05:42 --> Config Class Initialized
INFO - 2020-10-24 15:05:43 --> Hooks Class Initialized
DEBUG - 2020-10-24 15:05:43 --> UTF-8 Support Enabled
INFO - 2020-10-24 15:05:43 --> Utf8 Class Initialized
INFO - 2020-10-24 15:05:43 --> URI Class Initialized
INFO - 2020-10-24 15:05:43 --> Router Class Initialized
INFO - 2020-10-24 15:05:43 --> Output Class Initialized
INFO - 2020-10-24 15:05:43 --> Security Class Initialized
DEBUG - 2020-10-24 15:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 15:05:43 --> Input Class Initialized
INFO - 2020-10-24 15:05:43 --> Language Class Initialized
ERROR - 2020-10-24 15:05:43 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
INFO - 2020-10-24 23:34:35 --> Security Class Initialized
DEBUG - 2020-10-24 23:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:35 --> Input Class Initialized
INFO - 2020-10-24 23:34:35 --> Language Class Initialized
INFO - 2020-10-24 23:34:35 --> Loader Class Initialized
INFO - 2020-10-24 23:34:35 --> Helper loaded: url_helper
INFO - 2020-10-24 23:34:35 --> Helper loaded: form_helper
INFO - 2020-10-24 23:34:35 --> Helper loaded: html_helper
INFO - 2020-10-24 23:34:35 --> Helper loaded: date_helper
INFO - 2020-10-24 23:34:35 --> Database Driver Class Initialized
INFO - 2020-10-24 23:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:34:35 --> Table Class Initialized
INFO - 2020-10-24 23:34:35 --> Upload Class Initialized
INFO - 2020-10-24 23:34:35 --> Controller Class Initialized
INFO - 2020-10-24 23:34:35 --> Form Validation Class Initialized
INFO - 2020-10-24 23:34:35 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:34:35 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 23:34:35 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 23:34:35 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 23:34:35 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 23:34:35 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 23:34:35 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 23:34:35 --> Final output sent to browser
DEBUG - 2020-10-24 23:34:35 --> Total execution time: 0.5406
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Security Class Initialized
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
INFO - 2020-10-24 23:34:35 --> Input Class Initialized
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:35 --> Language Class Initialized
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
ERROR - 2020-10-24 23:34:35 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
INFO - 2020-10-24 23:34:35 --> Security Class Initialized
INFO - 2020-10-24 23:34:35 --> Security Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> Config Class Initialized
INFO - 2020-10-24 23:34:35 --> Security Class Initialized
DEBUG - 2020-10-24 23:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:35 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
DEBUG - 2020-10-24 23:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
INFO - 2020-10-24 23:34:35 --> Input Class Initialized
INFO - 2020-10-24 23:34:35 --> Input Class Initialized
INFO - 2020-10-24 23:34:35 --> Input Class Initialized
DEBUG - 2020-10-24 23:34:35 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:35 --> Security Class Initialized
INFO - 2020-10-24 23:34:35 --> Security Class Initialized
INFO - 2020-10-24 23:34:35 --> Language Class Initialized
INFO - 2020-10-24 23:34:35 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:35 --> Language Class Initialized
INFO - 2020-10-24 23:34:35 --> Language Class Initialized
DEBUG - 2020-10-24 23:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 23:34:35 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 23:34:35 --> URI Class Initialized
ERROR - 2020-10-24 23:34:35 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 23:34:35 --> Input Class Initialized
DEBUG - 2020-10-24 23:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-24 23:34:35 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 23:34:35 --> Language Class Initialized
INFO - 2020-10-24 23:34:35 --> Router Class Initialized
INFO - 2020-10-24 23:34:35 --> Input Class Initialized
INFO - 2020-10-24 23:34:35 --> Output Class Initialized
INFO - 2020-10-24 23:34:35 --> Language Class Initialized
ERROR - 2020-10-24 23:34:35 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-24 23:34:36 --> 404 Page Not Found: Dist/img
INFO - 2020-10-24 23:34:36 --> Security Class Initialized
DEBUG - 2020-10-24 23:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:36 --> Input Class Initialized
INFO - 2020-10-24 23:34:36 --> Language Class Initialized
INFO - 2020-10-24 23:34:36 --> Loader Class Initialized
INFO - 2020-10-24 23:34:36 --> Helper loaded: url_helper
INFO - 2020-10-24 23:34:36 --> Helper loaded: form_helper
INFO - 2020-10-24 23:34:36 --> Helper loaded: html_helper
INFO - 2020-10-24 23:34:36 --> Helper loaded: date_helper
INFO - 2020-10-24 23:34:36 --> Database Driver Class Initialized
INFO - 2020-10-24 23:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:34:36 --> Table Class Initialized
INFO - 2020-10-24 23:34:36 --> Upload Class Initialized
INFO - 2020-10-24 23:34:36 --> Controller Class Initialized
INFO - 2020-10-24 23:34:36 --> Form Validation Class Initialized
INFO - 2020-10-24 23:34:36 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:34:36 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-24 23:34:36 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-24 23:34:36 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-24 23:34:36 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-24 23:34:36 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-24 23:34:36 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-24 23:34:36 --> Final output sent to browser
DEBUG - 2020-10-24 23:34:36 --> Total execution time: 0.4685
INFO - 2020-10-24 23:34:36 --> Config Class Initialized
INFO - 2020-10-24 23:34:36 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:34:36 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:36 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:36 --> URI Class Initialized
INFO - 2020-10-24 23:34:36 --> Router Class Initialized
INFO - 2020-10-24 23:34:36 --> Output Class Initialized
INFO - 2020-10-24 23:34:36 --> Security Class Initialized
DEBUG - 2020-10-24 23:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:36 --> Input Class Initialized
INFO - 2020-10-24 23:34:36 --> Language Class Initialized
INFO - 2020-10-24 23:34:36 --> Loader Class Initialized
INFO - 2020-10-24 23:34:36 --> Helper loaded: url_helper
INFO - 2020-10-24 23:34:36 --> Helper loaded: form_helper
INFO - 2020-10-24 23:34:36 --> Helper loaded: html_helper
INFO - 2020-10-24 23:34:36 --> Helper loaded: date_helper
INFO - 2020-10-24 23:34:36 --> Database Driver Class Initialized
INFO - 2020-10-24 23:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:34:36 --> Table Class Initialized
INFO - 2020-10-24 23:34:36 --> Upload Class Initialized
INFO - 2020-10-24 23:34:36 --> Controller Class Initialized
INFO - 2020-10-24 23:34:36 --> Form Validation Class Initialized
INFO - 2020-10-24 23:34:36 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:34:37 --> Final output sent to browser
DEBUG - 2020-10-24 23:34:37 --> Total execution time: 0.3308
INFO - 2020-10-24 23:34:37 --> Config Class Initialized
INFO - 2020-10-24 23:34:37 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:34:37 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:34:37 --> Utf8 Class Initialized
INFO - 2020-10-24 23:34:37 --> URI Class Initialized
INFO - 2020-10-24 23:34:37 --> Router Class Initialized
INFO - 2020-10-24 23:34:37 --> Output Class Initialized
INFO - 2020-10-24 23:34:37 --> Security Class Initialized
DEBUG - 2020-10-24 23:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:34:37 --> Input Class Initialized
INFO - 2020-10-24 23:34:37 --> Language Class Initialized
ERROR - 2020-10-24 23:34:37 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-24 23:35:52 --> Config Class Initialized
INFO - 2020-10-24 23:35:52 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:35:52 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:35:52 --> Utf8 Class Initialized
INFO - 2020-10-24 23:35:52 --> URI Class Initialized
INFO - 2020-10-24 23:35:52 --> Router Class Initialized
INFO - 2020-10-24 23:35:52 --> Output Class Initialized
INFO - 2020-10-24 23:35:52 --> Security Class Initialized
DEBUG - 2020-10-24 23:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:35:52 --> Input Class Initialized
INFO - 2020-10-24 23:35:52 --> Language Class Initialized
INFO - 2020-10-24 23:35:52 --> Loader Class Initialized
INFO - 2020-10-24 23:35:52 --> Helper loaded: url_helper
INFO - 2020-10-24 23:35:52 --> Helper loaded: form_helper
INFO - 2020-10-24 23:35:52 --> Helper loaded: html_helper
INFO - 2020-10-24 23:35:52 --> Helper loaded: date_helper
INFO - 2020-10-24 23:35:52 --> Database Driver Class Initialized
INFO - 2020-10-24 23:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:35:52 --> Table Class Initialized
INFO - 2020-10-24 23:35:52 --> Upload Class Initialized
INFO - 2020-10-24 23:35:52 --> Controller Class Initialized
INFO - 2020-10-24 23:35:52 --> Form Validation Class Initialized
INFO - 2020-10-24 23:35:53 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:35:53 --> Final output sent to browser
DEBUG - 2020-10-24 23:35:53 --> Total execution time: 0.5129
INFO - 2020-10-24 23:35:53 --> Config Class Initialized
INFO - 2020-10-24 23:35:53 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:35:53 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:35:53 --> Utf8 Class Initialized
INFO - 2020-10-24 23:35:53 --> URI Class Initialized
INFO - 2020-10-24 23:35:53 --> Router Class Initialized
INFO - 2020-10-24 23:35:53 --> Output Class Initialized
INFO - 2020-10-24 23:35:53 --> Security Class Initialized
DEBUG - 2020-10-24 23:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:35:53 --> Input Class Initialized
INFO - 2020-10-24 23:35:53 --> Language Class Initialized
INFO - 2020-10-24 23:35:53 --> Loader Class Initialized
INFO - 2020-10-24 23:35:53 --> Helper loaded: url_helper
INFO - 2020-10-24 23:35:53 --> Helper loaded: form_helper
INFO - 2020-10-24 23:35:53 --> Helper loaded: html_helper
INFO - 2020-10-24 23:35:53 --> Helper loaded: date_helper
INFO - 2020-10-24 23:35:53 --> Database Driver Class Initialized
INFO - 2020-10-24 23:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:35:53 --> Table Class Initialized
INFO - 2020-10-24 23:35:53 --> Upload Class Initialized
INFO - 2020-10-24 23:35:53 --> Controller Class Initialized
INFO - 2020-10-24 23:35:53 --> Form Validation Class Initialized
INFO - 2020-10-24 23:35:53 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:35:53 --> Final output sent to browser
DEBUG - 2020-10-24 23:35:53 --> Total execution time: 0.4221
INFO - 2020-10-24 23:35:57 --> Config Class Initialized
INFO - 2020-10-24 23:35:57 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:35:57 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:35:57 --> Utf8 Class Initialized
INFO - 2020-10-24 23:35:57 --> URI Class Initialized
INFO - 2020-10-24 23:35:57 --> Router Class Initialized
INFO - 2020-10-24 23:35:57 --> Output Class Initialized
INFO - 2020-10-24 23:35:57 --> Security Class Initialized
DEBUG - 2020-10-24 23:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:35:57 --> Input Class Initialized
INFO - 2020-10-24 23:35:57 --> Language Class Initialized
INFO - 2020-10-24 23:35:57 --> Loader Class Initialized
INFO - 2020-10-24 23:35:57 --> Helper loaded: url_helper
INFO - 2020-10-24 23:35:57 --> Helper loaded: form_helper
INFO - 2020-10-24 23:35:57 --> Helper loaded: html_helper
INFO - 2020-10-24 23:35:57 --> Helper loaded: date_helper
INFO - 2020-10-24 23:35:57 --> Database Driver Class Initialized
INFO - 2020-10-24 23:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:35:57 --> Table Class Initialized
INFO - 2020-10-24 23:35:57 --> Upload Class Initialized
INFO - 2020-10-24 23:35:57 --> Controller Class Initialized
INFO - 2020-10-24 23:35:57 --> Form Validation Class Initialized
INFO - 2020-10-24 23:35:57 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:35:57 --> Final output sent to browser
DEBUG - 2020-10-24 23:35:57 --> Total execution time: 0.4206
INFO - 2020-10-24 23:36:00 --> Config Class Initialized
INFO - 2020-10-24 23:36:00 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:36:00 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:36:00 --> Utf8 Class Initialized
INFO - 2020-10-24 23:36:00 --> URI Class Initialized
INFO - 2020-10-24 23:36:00 --> Router Class Initialized
INFO - 2020-10-24 23:36:00 --> Output Class Initialized
INFO - 2020-10-24 23:36:00 --> Security Class Initialized
DEBUG - 2020-10-24 23:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:36:00 --> Input Class Initialized
INFO - 2020-10-24 23:36:00 --> Language Class Initialized
INFO - 2020-10-24 23:36:00 --> Loader Class Initialized
INFO - 2020-10-24 23:36:00 --> Helper loaded: url_helper
INFO - 2020-10-24 23:36:00 --> Helper loaded: form_helper
INFO - 2020-10-24 23:36:00 --> Helper loaded: html_helper
INFO - 2020-10-24 23:36:00 --> Helper loaded: date_helper
INFO - 2020-10-24 23:36:00 --> Database Driver Class Initialized
INFO - 2020-10-24 23:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:36:00 --> Table Class Initialized
INFO - 2020-10-24 23:36:00 --> Upload Class Initialized
INFO - 2020-10-24 23:36:00 --> Controller Class Initialized
INFO - 2020-10-24 23:36:00 --> Form Validation Class Initialized
INFO - 2020-10-24 23:36:00 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:36:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2020-10-24 23:36:00 --> Final output sent to browser
DEBUG - 2020-10-24 23:36:00 --> Total execution time: 0.4218
INFO - 2020-10-24 23:36:00 --> Config Class Initialized
INFO - 2020-10-24 23:36:00 --> Hooks Class Initialized
DEBUG - 2020-10-24 23:36:00 --> UTF-8 Support Enabled
INFO - 2020-10-24 23:36:00 --> Utf8 Class Initialized
INFO - 2020-10-24 23:36:00 --> URI Class Initialized
INFO - 2020-10-24 23:36:00 --> Router Class Initialized
INFO - 2020-10-24 23:36:00 --> Output Class Initialized
INFO - 2020-10-24 23:36:00 --> Security Class Initialized
DEBUG - 2020-10-24 23:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 23:36:00 --> Input Class Initialized
INFO - 2020-10-24 23:36:00 --> Language Class Initialized
INFO - 2020-10-24 23:36:00 --> Loader Class Initialized
INFO - 2020-10-24 23:36:00 --> Helper loaded: url_helper
INFO - 2020-10-24 23:36:00 --> Helper loaded: form_helper
INFO - 2020-10-24 23:36:00 --> Helper loaded: html_helper
INFO - 2020-10-24 23:36:00 --> Helper loaded: date_helper
INFO - 2020-10-24 23:36:00 --> Database Driver Class Initialized
INFO - 2020-10-24 23:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 23:36:00 --> Table Class Initialized
INFO - 2020-10-24 23:36:00 --> Upload Class Initialized
INFO - 2020-10-24 23:36:00 --> Controller Class Initialized
INFO - 2020-10-24 23:36:00 --> Form Validation Class Initialized
INFO - 2020-10-24 23:36:00 --> Model "Crud_model" initialized
INFO - 2020-10-24 23:36:00 --> Final output sent to browser
DEBUG - 2020-10-24 23:36:00 --> Total execution time: 0.4233

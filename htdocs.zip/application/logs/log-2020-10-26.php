<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-26 12:43:26 --> Config Class Initialized
INFO - 2020-10-26 12:43:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:43:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:26 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:26 --> URI Class Initialized
INFO - 2020-10-26 12:43:26 --> Router Class Initialized
INFO - 2020-10-26 12:43:26 --> Output Class Initialized
INFO - 2020-10-26 12:43:26 --> Security Class Initialized
DEBUG - 2020-10-26 12:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:26 --> Input Class Initialized
INFO - 2020-10-26 12:43:26 --> Language Class Initialized
INFO - 2020-10-26 12:43:26 --> Loader Class Initialized
INFO - 2020-10-26 12:43:26 --> Helper loaded: url_helper
INFO - 2020-10-26 12:43:26 --> Helper loaded: form_helper
INFO - 2020-10-26 12:43:26 --> Helper loaded: html_helper
INFO - 2020-10-26 12:43:26 --> Helper loaded: date_helper
INFO - 2020-10-26 12:43:26 --> Database Driver Class Initialized
INFO - 2020-10-26 12:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:43:26 --> Table Class Initialized
INFO - 2020-10-26 12:43:26 --> Upload Class Initialized
INFO - 2020-10-26 12:43:26 --> Controller Class Initialized
INFO - 2020-10-26 12:43:26 --> Form Validation Class Initialized
INFO - 2020-10-26 12:43:26 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:43:26 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 12:43:26 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 12:43:26 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 12:43:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 12:43:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 12:43:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 12:43:26 --> Final output sent to browser
DEBUG - 2020-10-26 12:43:26 --> Total execution time: 0.1156
INFO - 2020-10-26 12:43:26 --> Config Class Initialized
INFO - 2020-10-26 12:43:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:43:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:26 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:26 --> URI Class Initialized
INFO - 2020-10-26 12:43:26 --> Router Class Initialized
INFO - 2020-10-26 12:43:26 --> Output Class Initialized
INFO - 2020-10-26 12:43:26 --> Security Class Initialized
DEBUG - 2020-10-26 12:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:26 --> Input Class Initialized
INFO - 2020-10-26 12:43:26 --> Language Class Initialized
ERROR - 2020-10-26 12:43:26 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 12:43:26 --> Config Class Initialized
INFO - 2020-10-26 12:43:26 --> Hooks Class Initialized
INFO - 2020-10-26 12:43:26 --> Config Class Initialized
DEBUG - 2020-10-26 12:43:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:26 --> Hooks Class Initialized
INFO - 2020-10-26 12:43:26 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:26 --> URI Class Initialized
INFO - 2020-10-26 12:43:26 --> Config Class Initialized
DEBUG - 2020-10-26 12:43:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:26 --> Config Class Initialized
INFO - 2020-10-26 12:43:26 --> Hooks Class Initialized
INFO - 2020-10-26 12:43:26 --> Config Class Initialized
INFO - 2020-10-26 12:43:26 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:26 --> Router Class Initialized
INFO - 2020-10-26 12:43:26 --> Hooks Class Initialized
INFO - 2020-10-26 12:43:26 --> Hooks Class Initialized
INFO - 2020-10-26 12:43:26 --> URI Class Initialized
INFO - 2020-10-26 12:43:26 --> Output Class Initialized
DEBUG - 2020-10-26 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:43:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:43:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:26 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:26 --> Router Class Initialized
INFO - 2020-10-26 12:43:26 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:26 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:26 --> Security Class Initialized
INFO - 2020-10-26 12:43:26 --> URI Class Initialized
INFO - 2020-10-26 12:43:26 --> URI Class Initialized
DEBUG - 2020-10-26 12:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:26 --> Output Class Initialized
INFO - 2020-10-26 12:43:26 --> URI Class Initialized
INFO - 2020-10-26 12:43:26 --> Input Class Initialized
INFO - 2020-10-26 12:43:26 --> Router Class Initialized
INFO - 2020-10-26 12:43:26 --> Router Class Initialized
INFO - 2020-10-26 12:43:26 --> Security Class Initialized
DEBUG - 2020-10-26 12:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:26 --> Router Class Initialized
INFO - 2020-10-26 12:43:26 --> Output Class Initialized
INFO - 2020-10-26 12:43:26 --> Language Class Initialized
INFO - 2020-10-26 12:43:26 --> Output Class Initialized
INFO - 2020-10-26 12:43:26 --> Input Class Initialized
ERROR - 2020-10-26 12:43:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:43:26 --> Language Class Initialized
INFO - 2020-10-26 12:43:26 --> Security Class Initialized
INFO - 2020-10-26 12:43:26 --> Output Class Initialized
DEBUG - 2020-10-26 12:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:26 --> Security Class Initialized
ERROR - 2020-10-26 12:43:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:43:26 --> Security Class Initialized
INFO - 2020-10-26 12:43:26 --> Input Class Initialized
DEBUG - 2020-10-26 12:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 12:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:26 --> Language Class Initialized
INFO - 2020-10-26 12:43:26 --> Input Class Initialized
INFO - 2020-10-26 12:43:26 --> Input Class Initialized
INFO - 2020-10-26 12:43:26 --> Language Class Initialized
ERROR - 2020-10-26 12:43:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:43:26 --> Language Class Initialized
ERROR - 2020-10-26 12:43:26 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:43:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:43:27 --> Config Class Initialized
INFO - 2020-10-26 12:43:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:43:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:27 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:27 --> URI Class Initialized
INFO - 2020-10-26 12:43:27 --> Router Class Initialized
INFO - 2020-10-26 12:43:27 --> Output Class Initialized
INFO - 2020-10-26 12:43:27 --> Security Class Initialized
DEBUG - 2020-10-26 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:27 --> Input Class Initialized
INFO - 2020-10-26 12:43:27 --> Language Class Initialized
INFO - 2020-10-26 12:43:27 --> Loader Class Initialized
INFO - 2020-10-26 12:43:27 --> Helper loaded: url_helper
INFO - 2020-10-26 12:43:27 --> Helper loaded: form_helper
INFO - 2020-10-26 12:43:27 --> Helper loaded: html_helper
INFO - 2020-10-26 12:43:27 --> Helper loaded: date_helper
INFO - 2020-10-26 12:43:27 --> Database Driver Class Initialized
INFO - 2020-10-26 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:43:27 --> Table Class Initialized
INFO - 2020-10-26 12:43:27 --> Upload Class Initialized
INFO - 2020-10-26 12:43:27 --> Controller Class Initialized
INFO - 2020-10-26 12:43:27 --> Form Validation Class Initialized
INFO - 2020-10-26 12:43:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:43:27 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 12:43:27 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 12:43:27 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 12:43:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 12:43:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 12:43:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 12:43:27 --> Final output sent to browser
DEBUG - 2020-10-26 12:43:27 --> Total execution time: 0.0532
INFO - 2020-10-26 12:43:27 --> Config Class Initialized
INFO - 2020-10-26 12:43:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:43:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:27 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:27 --> URI Class Initialized
INFO - 2020-10-26 12:43:27 --> Router Class Initialized
INFO - 2020-10-26 12:43:27 --> Output Class Initialized
INFO - 2020-10-26 12:43:27 --> Security Class Initialized
DEBUG - 2020-10-26 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:27 --> Input Class Initialized
INFO - 2020-10-26 12:43:27 --> Language Class Initialized
INFO - 2020-10-26 12:43:27 --> Loader Class Initialized
INFO - 2020-10-26 12:43:27 --> Helper loaded: url_helper
INFO - 2020-10-26 12:43:27 --> Helper loaded: form_helper
INFO - 2020-10-26 12:43:27 --> Helper loaded: html_helper
INFO - 2020-10-26 12:43:27 --> Helper loaded: date_helper
INFO - 2020-10-26 12:43:27 --> Database Driver Class Initialized
INFO - 2020-10-26 12:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:43:27 --> Table Class Initialized
INFO - 2020-10-26 12:43:27 --> Upload Class Initialized
INFO - 2020-10-26 12:43:27 --> Controller Class Initialized
INFO - 2020-10-26 12:43:27 --> Form Validation Class Initialized
INFO - 2020-10-26 12:43:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:43:27 --> Final output sent to browser
DEBUG - 2020-10-26 12:43:27 --> Total execution time: 0.0536
INFO - 2020-10-26 12:43:27 --> Config Class Initialized
INFO - 2020-10-26 12:43:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:43:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:43:27 --> Utf8 Class Initialized
INFO - 2020-10-26 12:43:27 --> URI Class Initialized
INFO - 2020-10-26 12:43:27 --> Router Class Initialized
INFO - 2020-10-26 12:43:27 --> Output Class Initialized
INFO - 2020-10-26 12:43:27 --> Security Class Initialized
DEBUG - 2020-10-26 12:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:43:27 --> Input Class Initialized
INFO - 2020-10-26 12:43:27 --> Language Class Initialized
ERROR - 2020-10-26 12:43:27 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 12:44:37 --> Config Class Initialized
INFO - 2020-10-26 12:44:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:44:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:44:37 --> Utf8 Class Initialized
INFO - 2020-10-26 12:44:37 --> URI Class Initialized
INFO - 2020-10-26 12:44:37 --> Router Class Initialized
INFO - 2020-10-26 12:44:37 --> Output Class Initialized
INFO - 2020-10-26 12:44:37 --> Security Class Initialized
DEBUG - 2020-10-26 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:44:37 --> Input Class Initialized
INFO - 2020-10-26 12:44:37 --> Language Class Initialized
INFO - 2020-10-26 12:44:37 --> Loader Class Initialized
INFO - 2020-10-26 12:44:37 --> Helper loaded: url_helper
INFO - 2020-10-26 12:44:37 --> Helper loaded: form_helper
INFO - 2020-10-26 12:44:37 --> Helper loaded: html_helper
INFO - 2020-10-26 12:44:37 --> Helper loaded: date_helper
INFO - 2020-10-26 12:44:37 --> Database Driver Class Initialized
INFO - 2020-10-26 12:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:44:37 --> Table Class Initialized
INFO - 2020-10-26 12:44:37 --> Upload Class Initialized
INFO - 2020-10-26 12:44:37 --> Controller Class Initialized
INFO - 2020-10-26 12:44:37 --> Form Validation Class Initialized
INFO - 2020-10-26 12:44:37 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:44:37 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 12:44:37 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 12:44:37 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 12:44:37 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 12:44:37 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 12:44:37 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 12:44:37 --> Final output sent to browser
DEBUG - 2020-10-26 12:44:37 --> Total execution time: 0.0460
INFO - 2020-10-26 12:44:37 --> Config Class Initialized
INFO - 2020-10-26 12:44:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:44:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:44:37 --> Utf8 Class Initialized
INFO - 2020-10-26 12:44:37 --> URI Class Initialized
INFO - 2020-10-26 12:44:37 --> Router Class Initialized
INFO - 2020-10-26 12:44:37 --> Output Class Initialized
INFO - 2020-10-26 12:44:37 --> Security Class Initialized
DEBUG - 2020-10-26 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:44:37 --> Input Class Initialized
INFO - 2020-10-26 12:44:37 --> Language Class Initialized
ERROR - 2020-10-26 12:44:37 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 12:44:37 --> Config Class Initialized
INFO - 2020-10-26 12:44:37 --> Hooks Class Initialized
INFO - 2020-10-26 12:44:37 --> Config Class Initialized
INFO - 2020-10-26 12:44:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:44:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:44:37 --> Utf8 Class Initialized
DEBUG - 2020-10-26 12:44:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:44:37 --> URI Class Initialized
INFO - 2020-10-26 12:44:37 --> Utf8 Class Initialized
INFO - 2020-10-26 12:44:37 --> Router Class Initialized
INFO - 2020-10-26 12:44:37 --> URI Class Initialized
INFO - 2020-10-26 12:44:37 --> Router Class Initialized
INFO - 2020-10-26 12:44:37 --> Output Class Initialized
INFO - 2020-10-26 12:44:37 --> Output Class Initialized
INFO - 2020-10-26 12:44:37 --> Security Class Initialized
INFO - 2020-10-26 12:44:37 --> Security Class Initialized
DEBUG - 2020-10-26 12:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:44:37 --> Input Class Initialized
INFO - 2020-10-26 12:44:37 --> Language Class Initialized
INFO - 2020-10-26 12:44:37 --> Input Class Initialized
ERROR - 2020-10-26 12:44:37 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:44:37 --> Language Class Initialized
ERROR - 2020-10-26 12:44:37 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:44:37 --> Config Class Initialized
INFO - 2020-10-26 12:44:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:44:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:44:37 --> Utf8 Class Initialized
INFO - 2020-10-26 12:44:37 --> URI Class Initialized
INFO - 2020-10-26 12:44:37 --> Router Class Initialized
INFO - 2020-10-26 12:44:37 --> Output Class Initialized
INFO - 2020-10-26 12:44:37 --> Security Class Initialized
DEBUG - 2020-10-26 12:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:44:37 --> Input Class Initialized
INFO - 2020-10-26 12:44:37 --> Language Class Initialized
INFO - 2020-10-26 12:44:37 --> Loader Class Initialized
INFO - 2020-10-26 12:44:37 --> Helper loaded: url_helper
INFO - 2020-10-26 12:44:37 --> Helper loaded: form_helper
INFO - 2020-10-26 12:44:37 --> Helper loaded: html_helper
INFO - 2020-10-26 12:44:37 --> Helper loaded: date_helper
INFO - 2020-10-26 12:44:37 --> Database Driver Class Initialized
INFO - 2020-10-26 12:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:44:37 --> Table Class Initialized
INFO - 2020-10-26 12:44:37 --> Upload Class Initialized
INFO - 2020-10-26 12:44:37 --> Controller Class Initialized
INFO - 2020-10-26 12:44:37 --> Form Validation Class Initialized
INFO - 2020-10-26 12:44:37 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:44:37 --> Final output sent to browser
DEBUG - 2020-10-26 12:44:37 --> Total execution time: 0.0403
INFO - 2020-10-26 12:44:38 --> Config Class Initialized
INFO - 2020-10-26 12:44:38 --> Hooks Class Initialized
INFO - 2020-10-26 12:44:38 --> Config Class Initialized
INFO - 2020-10-26 12:44:38 --> Config Class Initialized
INFO - 2020-10-26 12:44:38 --> Hooks Class Initialized
INFO - 2020-10-26 12:44:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:44:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:44:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:44:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:44:38 --> Utf8 Class Initialized
INFO - 2020-10-26 12:44:38 --> Utf8 Class Initialized
INFO - 2020-10-26 12:44:38 --> Utf8 Class Initialized
INFO - 2020-10-26 12:44:38 --> URI Class Initialized
INFO - 2020-10-26 12:44:38 --> URI Class Initialized
INFO - 2020-10-26 12:44:38 --> URI Class Initialized
INFO - 2020-10-26 12:44:38 --> Router Class Initialized
INFO - 2020-10-26 12:44:38 --> Router Class Initialized
INFO - 2020-10-26 12:44:38 --> Router Class Initialized
INFO - 2020-10-26 12:44:38 --> Output Class Initialized
INFO - 2020-10-26 12:44:38 --> Output Class Initialized
INFO - 2020-10-26 12:44:38 --> Output Class Initialized
INFO - 2020-10-26 12:44:38 --> Security Class Initialized
INFO - 2020-10-26 12:44:38 --> Security Class Initialized
INFO - 2020-10-26 12:44:38 --> Security Class Initialized
DEBUG - 2020-10-26 12:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 12:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 12:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:44:38 --> Input Class Initialized
INFO - 2020-10-26 12:44:38 --> Input Class Initialized
INFO - 2020-10-26 12:44:38 --> Input Class Initialized
INFO - 2020-10-26 12:44:38 --> Language Class Initialized
INFO - 2020-10-26 12:44:38 --> Language Class Initialized
INFO - 2020-10-26 12:44:38 --> Language Class Initialized
ERROR - 2020-10-26 12:44:38 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:44:38 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:44:38 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:50:22 --> Config Class Initialized
INFO - 2020-10-26 12:50:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:50:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:22 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:22 --> URI Class Initialized
INFO - 2020-10-26 12:50:22 --> Router Class Initialized
INFO - 2020-10-26 12:50:22 --> Output Class Initialized
INFO - 2020-10-26 12:50:22 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:22 --> Input Class Initialized
INFO - 2020-10-26 12:50:22 --> Language Class Initialized
INFO - 2020-10-26 12:50:22 --> Loader Class Initialized
INFO - 2020-10-26 12:50:22 --> Helper loaded: url_helper
INFO - 2020-10-26 12:50:22 --> Helper loaded: form_helper
INFO - 2020-10-26 12:50:22 --> Helper loaded: html_helper
INFO - 2020-10-26 12:50:22 --> Helper loaded: date_helper
INFO - 2020-10-26 12:50:22 --> Database Driver Class Initialized
INFO - 2020-10-26 12:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:50:22 --> Table Class Initialized
INFO - 2020-10-26 12:50:22 --> Upload Class Initialized
INFO - 2020-10-26 12:50:22 --> Controller Class Initialized
INFO - 2020-10-26 12:50:22 --> Form Validation Class Initialized
INFO - 2020-10-26 12:50:22 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:50:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 12:50:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 12:50:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 12:50:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 12:50:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 12:50:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 12:50:22 --> Final output sent to browser
DEBUG - 2020-10-26 12:50:22 --> Total execution time: 0.0480
INFO - 2020-10-26 12:50:22 --> Config Class Initialized
INFO - 2020-10-26 12:50:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:50:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:22 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:22 --> URI Class Initialized
INFO - 2020-10-26 12:50:22 --> Router Class Initialized
INFO - 2020-10-26 12:50:22 --> Output Class Initialized
INFO - 2020-10-26 12:50:22 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:22 --> Input Class Initialized
INFO - 2020-10-26 12:50:22 --> Language Class Initialized
ERROR - 2020-10-26 12:50:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 12:50:22 --> Config Class Initialized
INFO - 2020-10-26 12:50:22 --> Hooks Class Initialized
INFO - 2020-10-26 12:50:22 --> Config Class Initialized
DEBUG - 2020-10-26 12:50:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:22 --> Config Class Initialized
INFO - 2020-10-26 12:50:22 --> Hooks Class Initialized
INFO - 2020-10-26 12:50:22 --> Config Class Initialized
INFO - 2020-10-26 12:50:22 --> Hooks Class Initialized
INFO - 2020-10-26 12:50:22 --> Hooks Class Initialized
INFO - 2020-10-26 12:50:22 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:22 --> Config Class Initialized
INFO - 2020-10-26 12:50:22 --> Hooks Class Initialized
INFO - 2020-10-26 12:50:22 --> URI Class Initialized
DEBUG - 2020-10-26 12:50:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:50:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:22 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:22 --> Router Class Initialized
DEBUG - 2020-10-26 12:50:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:50:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:22 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:22 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:22 --> URI Class Initialized
INFO - 2020-10-26 12:50:22 --> Output Class Initialized
INFO - 2020-10-26 12:50:22 --> URI Class Initialized
INFO - 2020-10-26 12:50:22 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:22 --> URI Class Initialized
INFO - 2020-10-26 12:50:22 --> Router Class Initialized
INFO - 2020-10-26 12:50:22 --> URI Class Initialized
INFO - 2020-10-26 12:50:22 --> Router Class Initialized
INFO - 2020-10-26 12:50:22 --> Router Class Initialized
INFO - 2020-10-26 12:50:22 --> Output Class Initialized
INFO - 2020-10-26 12:50:22 --> Router Class Initialized
INFO - 2020-10-26 12:50:22 --> Security Class Initialized
INFO - 2020-10-26 12:50:22 --> Output Class Initialized
DEBUG - 2020-10-26 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:22 --> Security Class Initialized
INFO - 2020-10-26 12:50:22 --> Output Class Initialized
INFO - 2020-10-26 12:50:22 --> Output Class Initialized
INFO - 2020-10-26 12:50:22 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:22 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:22 --> Input Class Initialized
INFO - 2020-10-26 12:50:22 --> Security Class Initialized
INFO - 2020-10-26 12:50:22 --> Input Class Initialized
INFO - 2020-10-26 12:50:22 --> Input Class Initialized
DEBUG - 2020-10-26 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:22 --> Language Class Initialized
DEBUG - 2020-10-26 12:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:22 --> Input Class Initialized
INFO - 2020-10-26 12:50:22 --> Language Class Initialized
INFO - 2020-10-26 12:50:22 --> Input Class Initialized
ERROR - 2020-10-26 12:50:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:50:22 --> Language Class Initialized
INFO - 2020-10-26 12:50:22 --> Language Class Initialized
INFO - 2020-10-26 12:50:22 --> Language Class Initialized
ERROR - 2020-10-26 12:50:22 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:50:22 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:50:22 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:50:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:50:23 --> Config Class Initialized
INFO - 2020-10-26 12:50:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:50:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:23 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:23 --> URI Class Initialized
INFO - 2020-10-26 12:50:23 --> Router Class Initialized
INFO - 2020-10-26 12:50:23 --> Output Class Initialized
INFO - 2020-10-26 12:50:23 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:23 --> Input Class Initialized
INFO - 2020-10-26 12:50:23 --> Language Class Initialized
INFO - 2020-10-26 12:50:23 --> Loader Class Initialized
INFO - 2020-10-26 12:50:23 --> Helper loaded: url_helper
INFO - 2020-10-26 12:50:23 --> Helper loaded: form_helper
INFO - 2020-10-26 12:50:23 --> Helper loaded: html_helper
INFO - 2020-10-26 12:50:23 --> Helper loaded: date_helper
INFO - 2020-10-26 12:50:23 --> Database Driver Class Initialized
INFO - 2020-10-26 12:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:50:23 --> Table Class Initialized
INFO - 2020-10-26 12:50:23 --> Upload Class Initialized
INFO - 2020-10-26 12:50:23 --> Controller Class Initialized
INFO - 2020-10-26 12:50:23 --> Form Validation Class Initialized
INFO - 2020-10-26 12:50:23 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:50:23 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 12:50:23 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 12:50:23 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 12:50:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 12:50:23 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 12:50:23 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 12:50:23 --> Final output sent to browser
DEBUG - 2020-10-26 12:50:23 --> Total execution time: 0.0564
INFO - 2020-10-26 12:50:23 --> Config Class Initialized
INFO - 2020-10-26 12:50:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:50:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:23 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:23 --> URI Class Initialized
INFO - 2020-10-26 12:50:23 --> Router Class Initialized
INFO - 2020-10-26 12:50:23 --> Output Class Initialized
INFO - 2020-10-26 12:50:23 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:23 --> Input Class Initialized
INFO - 2020-10-26 12:50:23 --> Language Class Initialized
INFO - 2020-10-26 12:50:23 --> Loader Class Initialized
INFO - 2020-10-26 12:50:23 --> Helper loaded: url_helper
INFO - 2020-10-26 12:50:23 --> Helper loaded: form_helper
INFO - 2020-10-26 12:50:23 --> Helper loaded: html_helper
INFO - 2020-10-26 12:50:23 --> Helper loaded: date_helper
INFO - 2020-10-26 12:50:23 --> Database Driver Class Initialized
INFO - 2020-10-26 12:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:50:23 --> Table Class Initialized
INFO - 2020-10-26 12:50:23 --> Upload Class Initialized
INFO - 2020-10-26 12:50:23 --> Controller Class Initialized
INFO - 2020-10-26 12:50:23 --> Form Validation Class Initialized
INFO - 2020-10-26 12:50:23 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:50:23 --> Final output sent to browser
DEBUG - 2020-10-26 12:50:23 --> Total execution time: 0.0449
INFO - 2020-10-26 12:50:23 --> Config Class Initialized
INFO - 2020-10-26 12:50:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:50:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:23 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:23 --> URI Class Initialized
INFO - 2020-10-26 12:50:23 --> Router Class Initialized
INFO - 2020-10-26 12:50:23 --> Output Class Initialized
INFO - 2020-10-26 12:50:23 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:23 --> Input Class Initialized
INFO - 2020-10-26 12:50:23 --> Language Class Initialized
ERROR - 2020-10-26 12:50:23 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:50:35 --> Config Class Initialized
INFO - 2020-10-26 12:50:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:50:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:50:35 --> Utf8 Class Initialized
INFO - 2020-10-26 12:50:35 --> URI Class Initialized
INFO - 2020-10-26 12:50:35 --> Router Class Initialized
INFO - 2020-10-26 12:50:35 --> Output Class Initialized
INFO - 2020-10-26 12:50:35 --> Security Class Initialized
DEBUG - 2020-10-26 12:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:50:35 --> Input Class Initialized
INFO - 2020-10-26 12:50:35 --> Language Class Initialized
ERROR - 2020-10-26 12:50:35 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
INFO - 2020-10-26 12:55:10 --> Language Class Initialized
INFO - 2020-10-26 12:55:10 --> Loader Class Initialized
INFO - 2020-10-26 12:55:10 --> Helper loaded: url_helper
INFO - 2020-10-26 12:55:10 --> Helper loaded: form_helper
INFO - 2020-10-26 12:55:10 --> Helper loaded: html_helper
INFO - 2020-10-26 12:55:10 --> Helper loaded: date_helper
INFO - 2020-10-26 12:55:10 --> Database Driver Class Initialized
INFO - 2020-10-26 12:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:55:10 --> Table Class Initialized
INFO - 2020-10-26 12:55:10 --> Upload Class Initialized
INFO - 2020-10-26 12:55:10 --> Controller Class Initialized
INFO - 2020-10-26 12:55:10 --> Form Validation Class Initialized
INFO - 2020-10-26 12:55:10 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:55:10 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 12:55:10 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 12:55:10 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 12:55:10 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 12:55:10 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 12:55:10 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 12:55:10 --> Final output sent to browser
DEBUG - 2020-10-26 12:55:10 --> Total execution time: 0.0545
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
INFO - 2020-10-26 12:55:10 --> Language Class Initialized
ERROR - 2020-10-26 12:55:10 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
INFO - 2020-10-26 12:55:10 --> Language Class Initialized
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
ERROR - 2020-10-26 12:55:10 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:55:10 --> Language Class Initialized
ERROR - 2020-10-26 12:55:10 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
INFO - 2020-10-26 12:55:10 --> Language Class Initialized
INFO - 2020-10-26 12:55:10 --> Loader Class Initialized
INFO - 2020-10-26 12:55:10 --> Helper loaded: url_helper
INFO - 2020-10-26 12:55:10 --> Helper loaded: form_helper
INFO - 2020-10-26 12:55:10 --> Helper loaded: html_helper
INFO - 2020-10-26 12:55:10 --> Helper loaded: date_helper
INFO - 2020-10-26 12:55:10 --> Database Driver Class Initialized
INFO - 2020-10-26 12:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:55:10 --> Table Class Initialized
INFO - 2020-10-26 12:55:10 --> Upload Class Initialized
INFO - 2020-10-26 12:55:10 --> Controller Class Initialized
INFO - 2020-10-26 12:55:10 --> Form Validation Class Initialized
INFO - 2020-10-26 12:55:10 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:55:10 --> Final output sent to browser
DEBUG - 2020-10-26 12:55:10 --> Total execution time: 0.0877
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> Config Class Initialized
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
INFO - 2020-10-26 12:55:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
DEBUG - 2020-10-26 12:55:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:55:10 --> Utf8 Class Initialized
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
INFO - 2020-10-26 12:55:10 --> URI Class Initialized
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Router Class Initialized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
INFO - 2020-10-26 12:55:10 --> Output Class Initialized
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Language Class Initialized
INFO - 2020-10-26 12:55:10 --> Security Class Initialized
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
ERROR - 2020-10-26 12:55:10 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 12:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:55:10 --> Language Class Initialized
ERROR - 2020-10-26 12:55:10 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:55:10 --> Input Class Initialized
INFO - 2020-10-26 12:55:11 --> Language Class Initialized
ERROR - 2020-10-26 12:55:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:58:23 --> Config Class Initialized
INFO - 2020-10-26 12:58:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:58:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:58:23 --> Utf8 Class Initialized
INFO - 2020-10-26 12:58:23 --> URI Class Initialized
INFO - 2020-10-26 12:58:23 --> Router Class Initialized
INFO - 2020-10-26 12:58:23 --> Output Class Initialized
INFO - 2020-10-26 12:58:23 --> Security Class Initialized
DEBUG - 2020-10-26 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:58:23 --> Input Class Initialized
INFO - 2020-10-26 12:58:23 --> Language Class Initialized
INFO - 2020-10-26 12:58:23 --> Loader Class Initialized
INFO - 2020-10-26 12:58:23 --> Helper loaded: url_helper
INFO - 2020-10-26 12:58:23 --> Helper loaded: form_helper
INFO - 2020-10-26 12:58:23 --> Helper loaded: html_helper
INFO - 2020-10-26 12:58:23 --> Helper loaded: date_helper
INFO - 2020-10-26 12:58:23 --> Database Driver Class Initialized
INFO - 2020-10-26 12:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:58:23 --> Table Class Initialized
INFO - 2020-10-26 12:58:23 --> Upload Class Initialized
INFO - 2020-10-26 12:58:23 --> Controller Class Initialized
INFO - 2020-10-26 12:58:23 --> Form Validation Class Initialized
INFO - 2020-10-26 12:58:23 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:58:23 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 12:58:23 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 12:58:23 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 12:58:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 12:58:23 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 12:58:23 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 12:58:23 --> Final output sent to browser
DEBUG - 2020-10-26 12:58:23 --> Total execution time: 0.0610
INFO - 2020-10-26 12:58:23 --> Config Class Initialized
INFO - 2020-10-26 12:58:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:58:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:58:23 --> Utf8 Class Initialized
INFO - 2020-10-26 12:58:23 --> URI Class Initialized
INFO - 2020-10-26 12:58:23 --> Router Class Initialized
INFO - 2020-10-26 12:58:23 --> Output Class Initialized
INFO - 2020-10-26 12:58:23 --> Security Class Initialized
DEBUG - 2020-10-26 12:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:58:23 --> Input Class Initialized
INFO - 2020-10-26 12:58:23 --> Language Class Initialized
ERROR - 2020-10-26 12:58:23 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 12:58:24 --> Config Class Initialized
INFO - 2020-10-26 12:58:24 --> Hooks Class Initialized
INFO - 2020-10-26 12:58:24 --> Config Class Initialized
INFO - 2020-10-26 12:58:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:58:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:58:24 --> Utf8 Class Initialized
INFO - 2020-10-26 12:58:24 --> Utf8 Class Initialized
INFO - 2020-10-26 12:58:24 --> URI Class Initialized
INFO - 2020-10-26 12:58:24 --> URI Class Initialized
INFO - 2020-10-26 12:58:24 --> Router Class Initialized
INFO - 2020-10-26 12:58:24 --> Router Class Initialized
INFO - 2020-10-26 12:58:24 --> Output Class Initialized
INFO - 2020-10-26 12:58:24 --> Output Class Initialized
INFO - 2020-10-26 12:58:24 --> Security Class Initialized
INFO - 2020-10-26 12:58:24 --> Security Class Initialized
DEBUG - 2020-10-26 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:58:24 --> Input Class Initialized
INFO - 2020-10-26 12:58:24 --> Input Class Initialized
INFO - 2020-10-26 12:58:24 --> Language Class Initialized
INFO - 2020-10-26 12:58:24 --> Language Class Initialized
ERROR - 2020-10-26 12:58:24 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:58:24 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 12:58:24 --> Config Class Initialized
INFO - 2020-10-26 12:58:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:58:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:58:24 --> Utf8 Class Initialized
INFO - 2020-10-26 12:58:24 --> URI Class Initialized
INFO - 2020-10-26 12:58:24 --> Router Class Initialized
INFO - 2020-10-26 12:58:24 --> Output Class Initialized
INFO - 2020-10-26 12:58:24 --> Security Class Initialized
DEBUG - 2020-10-26 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:58:24 --> Input Class Initialized
INFO - 2020-10-26 12:58:24 --> Language Class Initialized
INFO - 2020-10-26 12:58:24 --> Loader Class Initialized
INFO - 2020-10-26 12:58:24 --> Helper loaded: url_helper
INFO - 2020-10-26 12:58:24 --> Helper loaded: form_helper
INFO - 2020-10-26 12:58:24 --> Helper loaded: html_helper
INFO - 2020-10-26 12:58:24 --> Helper loaded: date_helper
INFO - 2020-10-26 12:58:24 --> Database Driver Class Initialized
INFO - 2020-10-26 12:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 12:58:24 --> Table Class Initialized
INFO - 2020-10-26 12:58:24 --> Upload Class Initialized
INFO - 2020-10-26 12:58:24 --> Controller Class Initialized
INFO - 2020-10-26 12:58:24 --> Form Validation Class Initialized
INFO - 2020-10-26 12:58:24 --> Model "Crud_model" initialized
INFO - 2020-10-26 12:58:24 --> Final output sent to browser
DEBUG - 2020-10-26 12:58:24 --> Total execution time: 0.0532
INFO - 2020-10-26 12:58:24 --> Config Class Initialized
INFO - 2020-10-26 12:58:24 --> Config Class Initialized
INFO - 2020-10-26 12:58:24 --> Config Class Initialized
INFO - 2020-10-26 12:58:24 --> Hooks Class Initialized
INFO - 2020-10-26 12:58:24 --> Hooks Class Initialized
INFO - 2020-10-26 12:58:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 12:58:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:58:24 --> Utf8 Class Initialized
DEBUG - 2020-10-26 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 12:58:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 12:58:24 --> Utf8 Class Initialized
INFO - 2020-10-26 12:58:24 --> URI Class Initialized
INFO - 2020-10-26 12:58:24 --> Utf8 Class Initialized
INFO - 2020-10-26 12:58:24 --> URI Class Initialized
INFO - 2020-10-26 12:58:24 --> URI Class Initialized
INFO - 2020-10-26 12:58:24 --> Router Class Initialized
INFO - 2020-10-26 12:58:24 --> Output Class Initialized
INFO - 2020-10-26 12:58:24 --> Router Class Initialized
INFO - 2020-10-26 12:58:24 --> Router Class Initialized
INFO - 2020-10-26 12:58:24 --> Security Class Initialized
INFO - 2020-10-26 12:58:24 --> Output Class Initialized
INFO - 2020-10-26 12:58:24 --> Output Class Initialized
INFO - 2020-10-26 12:58:24 --> Security Class Initialized
INFO - 2020-10-26 12:58:24 --> Security Class Initialized
DEBUG - 2020-10-26 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 12:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 12:58:24 --> Input Class Initialized
INFO - 2020-10-26 12:58:24 --> Language Class Initialized
INFO - 2020-10-26 12:58:24 --> Input Class Initialized
INFO - 2020-10-26 12:58:24 --> Input Class Initialized
INFO - 2020-10-26 12:58:24 --> Language Class Initialized
INFO - 2020-10-26 12:58:24 --> Language Class Initialized
ERROR - 2020-10-26 12:58:24 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:58:24 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 12:58:24 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
INFO - 2020-10-26 13:01:45 --> Loader Class Initialized
INFO - 2020-10-26 13:01:45 --> Helper loaded: url_helper
INFO - 2020-10-26 13:01:45 --> Helper loaded: form_helper
INFO - 2020-10-26 13:01:45 --> Helper loaded: html_helper
INFO - 2020-10-26 13:01:45 --> Helper loaded: date_helper
INFO - 2020-10-26 13:01:45 --> Database Driver Class Initialized
INFO - 2020-10-26 13:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:01:45 --> Table Class Initialized
INFO - 2020-10-26 13:01:45 --> Upload Class Initialized
INFO - 2020-10-26 13:01:45 --> Controller Class Initialized
INFO - 2020-10-26 13:01:45 --> Form Validation Class Initialized
INFO - 2020-10-26 13:01:45 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:01:45 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:01:45 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:01:45 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:01:45 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:01:45 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:01:45 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:01:45 --> Final output sent to browser
DEBUG - 2020-10-26 13:01:45 --> Total execution time: 0.0606
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
ERROR - 2020-10-26 13:01:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
ERROR - 2020-10-26 13:01:45 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:01:45 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
INFO - 2020-10-26 13:01:45 --> Loader Class Initialized
INFO - 2020-10-26 13:01:45 --> Helper loaded: url_helper
INFO - 2020-10-26 13:01:45 --> Helper loaded: form_helper
INFO - 2020-10-26 13:01:45 --> Helper loaded: html_helper
INFO - 2020-10-26 13:01:45 --> Helper loaded: date_helper
INFO - 2020-10-26 13:01:45 --> Database Driver Class Initialized
INFO - 2020-10-26 13:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:01:45 --> Table Class Initialized
INFO - 2020-10-26 13:01:45 --> Upload Class Initialized
INFO - 2020-10-26 13:01:45 --> Controller Class Initialized
INFO - 2020-10-26 13:01:45 --> Form Validation Class Initialized
INFO - 2020-10-26 13:01:45 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:01:45 --> Final output sent to browser
DEBUG - 2020-10-26 13:01:45 --> Total execution time: 0.0581
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
INFO - 2020-10-26 13:01:45 --> Config Class Initialized
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
INFO - 2020-10-26 13:01:45 --> Hooks Class Initialized
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:01:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
INFO - 2020-10-26 13:01:45 --> Utf8 Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> URI Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Router Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Output Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
INFO - 2020-10-26 13:01:45 --> Security Class Initialized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
DEBUG - 2020-10-26 13:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
INFO - 2020-10-26 13:01:45 --> Input Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
INFO - 2020-10-26 13:01:45 --> Language Class Initialized
ERROR - 2020-10-26 13:01:45 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:01:45 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:01:45 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
INFO - 2020-10-26 13:05:59 --> Loader Class Initialized
INFO - 2020-10-26 13:05:59 --> Helper loaded: url_helper
INFO - 2020-10-26 13:05:59 --> Helper loaded: form_helper
INFO - 2020-10-26 13:05:59 --> Helper loaded: html_helper
INFO - 2020-10-26 13:05:59 --> Helper loaded: date_helper
INFO - 2020-10-26 13:05:59 --> Database Driver Class Initialized
INFO - 2020-10-26 13:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:05:59 --> Table Class Initialized
INFO - 2020-10-26 13:05:59 --> Upload Class Initialized
INFO - 2020-10-26 13:05:59 --> Controller Class Initialized
INFO - 2020-10-26 13:05:59 --> Form Validation Class Initialized
INFO - 2020-10-26 13:05:59 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:05:59 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:05:59 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:05:59 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:05:59 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:05:59 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:05:59 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:05:59 --> Final output sent to browser
DEBUG - 2020-10-26 13:05:59 --> Total execution time: 0.0904
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
ERROR - 2020-10-26 13:05:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
ERROR - 2020-10-26 13:05:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
ERROR - 2020-10-26 13:05:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
INFO - 2020-10-26 13:05:59 --> Loader Class Initialized
INFO - 2020-10-26 13:05:59 --> Helper loaded: url_helper
INFO - 2020-10-26 13:05:59 --> Helper loaded: form_helper
INFO - 2020-10-26 13:05:59 --> Helper loaded: html_helper
INFO - 2020-10-26 13:05:59 --> Helper loaded: date_helper
INFO - 2020-10-26 13:05:59 --> Database Driver Class Initialized
INFO - 2020-10-26 13:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:05:59 --> Table Class Initialized
INFO - 2020-10-26 13:05:59 --> Upload Class Initialized
INFO - 2020-10-26 13:05:59 --> Controller Class Initialized
INFO - 2020-10-26 13:05:59 --> Form Validation Class Initialized
INFO - 2020-10-26 13:05:59 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:05:59 --> Final output sent to browser
DEBUG - 2020-10-26 13:05:59 --> Total execution time: 0.0592
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Config Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
INFO - 2020-10-26 13:05:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:05:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> Utf8 Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> URI Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Router Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Output Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
INFO - 2020-10-26 13:05:59 --> Security Class Initialized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Input Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
INFO - 2020-10-26 13:05:59 --> Language Class Initialized
ERROR - 2020-10-26 13:05:59 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:05:59 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:05:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:07:04 --> Config Class Initialized
INFO - 2020-10-26 13:07:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:04 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:04 --> URI Class Initialized
INFO - 2020-10-26 13:07:04 --> Router Class Initialized
INFO - 2020-10-26 13:07:04 --> Output Class Initialized
INFO - 2020-10-26 13:07:04 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:04 --> Input Class Initialized
INFO - 2020-10-26 13:07:04 --> Language Class Initialized
INFO - 2020-10-26 13:07:04 --> Loader Class Initialized
INFO - 2020-10-26 13:07:04 --> Helper loaded: url_helper
INFO - 2020-10-26 13:07:04 --> Helper loaded: form_helper
INFO - 2020-10-26 13:07:04 --> Helper loaded: html_helper
INFO - 2020-10-26 13:07:04 --> Helper loaded: date_helper
INFO - 2020-10-26 13:07:04 --> Database Driver Class Initialized
INFO - 2020-10-26 13:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:07:04 --> Table Class Initialized
INFO - 2020-10-26 13:07:04 --> Upload Class Initialized
INFO - 2020-10-26 13:07:04 --> Controller Class Initialized
INFO - 2020-10-26 13:07:04 --> Form Validation Class Initialized
INFO - 2020-10-26 13:07:04 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:07:04 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:07:04 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:07:04 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:07:04 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:07:04 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:07:04 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:07:04 --> Final output sent to browser
DEBUG - 2020-10-26 13:07:04 --> Total execution time: 0.0769
INFO - 2020-10-26 13:07:04 --> Config Class Initialized
INFO - 2020-10-26 13:07:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:04 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:04 --> URI Class Initialized
INFO - 2020-10-26 13:07:04 --> Router Class Initialized
INFO - 2020-10-26 13:07:04 --> Output Class Initialized
INFO - 2020-10-26 13:07:04 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:04 --> Input Class Initialized
INFO - 2020-10-26 13:07:04 --> Language Class Initialized
ERROR - 2020-10-26 13:07:04 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:07:04 --> Config Class Initialized
INFO - 2020-10-26 13:07:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:04 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:04 --> URI Class Initialized
INFO - 2020-10-26 13:07:04 --> Router Class Initialized
INFO - 2020-10-26 13:07:04 --> Output Class Initialized
INFO - 2020-10-26 13:07:04 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:04 --> Config Class Initialized
INFO - 2020-10-26 13:07:04 --> Input Class Initialized
INFO - 2020-10-26 13:07:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:04 --> Language Class Initialized
ERROR - 2020-10-26 13:07:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:07:04 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:04 --> URI Class Initialized
INFO - 2020-10-26 13:07:04 --> Router Class Initialized
INFO - 2020-10-26 13:07:04 --> Output Class Initialized
INFO - 2020-10-26 13:07:04 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:04 --> Input Class Initialized
INFO - 2020-10-26 13:07:04 --> Language Class Initialized
ERROR - 2020-10-26 13:07:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:07:05 --> Config Class Initialized
INFO - 2020-10-26 13:07:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:05 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:05 --> URI Class Initialized
INFO - 2020-10-26 13:07:05 --> Router Class Initialized
INFO - 2020-10-26 13:07:05 --> Output Class Initialized
INFO - 2020-10-26 13:07:05 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:05 --> Input Class Initialized
INFO - 2020-10-26 13:07:05 --> Language Class Initialized
INFO - 2020-10-26 13:07:05 --> Loader Class Initialized
INFO - 2020-10-26 13:07:05 --> Helper loaded: url_helper
INFO - 2020-10-26 13:07:05 --> Helper loaded: form_helper
INFO - 2020-10-26 13:07:05 --> Helper loaded: html_helper
INFO - 2020-10-26 13:07:05 --> Helper loaded: date_helper
INFO - 2020-10-26 13:07:05 --> Database Driver Class Initialized
INFO - 2020-10-26 13:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:07:05 --> Table Class Initialized
INFO - 2020-10-26 13:07:05 --> Upload Class Initialized
INFO - 2020-10-26 13:07:05 --> Controller Class Initialized
INFO - 2020-10-26 13:07:05 --> Form Validation Class Initialized
INFO - 2020-10-26 13:07:05 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:07:05 --> Final output sent to browser
DEBUG - 2020-10-26 13:07:05 --> Total execution time: 0.0639
INFO - 2020-10-26 13:07:05 --> Config Class Initialized
INFO - 2020-10-26 13:07:05 --> Config Class Initialized
INFO - 2020-10-26 13:07:05 --> Config Class Initialized
INFO - 2020-10-26 13:07:05 --> Hooks Class Initialized
INFO - 2020-10-26 13:07:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:05 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:07:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:05 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:05 --> URI Class Initialized
INFO - 2020-10-26 13:07:05 --> URI Class Initialized
INFO - 2020-10-26 13:07:05 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:05 --> URI Class Initialized
INFO - 2020-10-26 13:07:05 --> Router Class Initialized
INFO - 2020-10-26 13:07:05 --> Router Class Initialized
INFO - 2020-10-26 13:07:05 --> Router Class Initialized
INFO - 2020-10-26 13:07:05 --> Output Class Initialized
INFO - 2020-10-26 13:07:05 --> Output Class Initialized
INFO - 2020-10-26 13:07:05 --> Output Class Initialized
INFO - 2020-10-26 13:07:05 --> Security Class Initialized
INFO - 2020-10-26 13:07:05 --> Security Class Initialized
INFO - 2020-10-26 13:07:05 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:05 --> Input Class Initialized
INFO - 2020-10-26 13:07:05 --> Input Class Initialized
DEBUG - 2020-10-26 13:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:05 --> Input Class Initialized
INFO - 2020-10-26 13:07:05 --> Language Class Initialized
INFO - 2020-10-26 13:07:05 --> Language Class Initialized
ERROR - 2020-10-26 13:07:05 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:07:05 --> Language Class Initialized
ERROR - 2020-10-26 13:07:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:07:05 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:07:27 --> Config Class Initialized
INFO - 2020-10-26 13:07:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:27 --> URI Class Initialized
INFO - 2020-10-26 13:07:27 --> Router Class Initialized
INFO - 2020-10-26 13:07:27 --> Output Class Initialized
INFO - 2020-10-26 13:07:27 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:27 --> Input Class Initialized
INFO - 2020-10-26 13:07:27 --> Language Class Initialized
INFO - 2020-10-26 13:07:27 --> Loader Class Initialized
INFO - 2020-10-26 13:07:27 --> Helper loaded: url_helper
INFO - 2020-10-26 13:07:27 --> Helper loaded: form_helper
INFO - 2020-10-26 13:07:27 --> Helper loaded: html_helper
INFO - 2020-10-26 13:07:27 --> Helper loaded: date_helper
INFO - 2020-10-26 13:07:27 --> Database Driver Class Initialized
INFO - 2020-10-26 13:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:07:27 --> Table Class Initialized
INFO - 2020-10-26 13:07:27 --> Upload Class Initialized
INFO - 2020-10-26 13:07:27 --> Controller Class Initialized
INFO - 2020-10-26 13:07:27 --> Form Validation Class Initialized
INFO - 2020-10-26 13:07:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:07:27 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:07:27 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:07:27 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:07:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:07:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:07:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:07:27 --> Final output sent to browser
DEBUG - 2020-10-26 13:07:27 --> Total execution time: 0.0906
INFO - 2020-10-26 13:07:27 --> Config Class Initialized
INFO - 2020-10-26 13:07:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:07:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:07:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:07:27 --> URI Class Initialized
INFO - 2020-10-26 13:07:27 --> Router Class Initialized
INFO - 2020-10-26 13:07:27 --> Output Class Initialized
INFO - 2020-10-26 13:07:27 --> Security Class Initialized
DEBUG - 2020-10-26 13:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:07:27 --> Input Class Initialized
INFO - 2020-10-26 13:07:28 --> Language Class Initialized
ERROR - 2020-10-26 13:07:28 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 13:09:01 --> Config Class Initialized
INFO - 2020-10-26 13:09:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:09:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:09:01 --> Utf8 Class Initialized
INFO - 2020-10-26 13:09:01 --> URI Class Initialized
INFO - 2020-10-26 13:09:01 --> Router Class Initialized
INFO - 2020-10-26 13:09:01 --> Output Class Initialized
INFO - 2020-10-26 13:09:01 --> Security Class Initialized
DEBUG - 2020-10-26 13:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
INFO - 2020-10-26 13:09:02 --> Loader Class Initialized
INFO - 2020-10-26 13:09:02 --> Helper loaded: url_helper
INFO - 2020-10-26 13:09:02 --> Helper loaded: form_helper
INFO - 2020-10-26 13:09:02 --> Helper loaded: html_helper
INFO - 2020-10-26 13:09:02 --> Helper loaded: date_helper
INFO - 2020-10-26 13:09:02 --> Database Driver Class Initialized
INFO - 2020-10-26 13:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:09:02 --> Table Class Initialized
INFO - 2020-10-26 13:09:02 --> Upload Class Initialized
INFO - 2020-10-26 13:09:02 --> Controller Class Initialized
INFO - 2020-10-26 13:09:02 --> Form Validation Class Initialized
INFO - 2020-10-26 13:09:02 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:09:02 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:09:02 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:09:02 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:09:02 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:09:02 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:09:02 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:09:02 --> Final output sent to browser
DEBUG - 2020-10-26 13:09:02 --> Total execution time: 0.0863
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
ERROR - 2020-10-26 13:09:02 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
INFO - 2020-10-26 13:09:02 --> Loader Class Initialized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
INFO - 2020-10-26 13:09:02 --> Helper loaded: url_helper
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Helper loaded: form_helper
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
INFO - 2020-10-26 13:09:02 --> Helper loaded: html_helper
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
INFO - 2020-10-26 13:09:02 --> Helper loaded: date_helper
ERROR - 2020-10-26 13:09:02 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:09:02 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:09:02 --> Database Driver Class Initialized
INFO - 2020-10-26 13:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:09:02 --> Table Class Initialized
INFO - 2020-10-26 13:09:02 --> Upload Class Initialized
INFO - 2020-10-26 13:09:02 --> Controller Class Initialized
INFO - 2020-10-26 13:09:02 --> Form Validation Class Initialized
INFO - 2020-10-26 13:09:02 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:09:02 --> Final output sent to browser
DEBUG - 2020-10-26 13:09:02 --> Total execution time: 0.0792
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
ERROR - 2020-10-26 13:09:02 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
ERROR - 2020-10-26 13:09:02 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:09:02 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:09:02 --> Config Class Initialized
INFO - 2020-10-26 13:09:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:09:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:09:02 --> Utf8 Class Initialized
INFO - 2020-10-26 13:09:02 --> URI Class Initialized
INFO - 2020-10-26 13:09:02 --> Router Class Initialized
INFO - 2020-10-26 13:09:02 --> Output Class Initialized
INFO - 2020-10-26 13:09:02 --> Security Class Initialized
DEBUG - 2020-10-26 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:09:02 --> Input Class Initialized
INFO - 2020-10-26 13:09:02 --> Language Class Initialized
ERROR - 2020-10-26 13:09:02 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:10:32 --> Config Class Initialized
INFO - 2020-10-26 13:10:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:10:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:10:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:10:32 --> URI Class Initialized
INFO - 2020-10-26 13:10:32 --> Router Class Initialized
INFO - 2020-10-26 13:10:32 --> Output Class Initialized
INFO - 2020-10-26 13:10:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:10:32 --> Input Class Initialized
INFO - 2020-10-26 13:10:32 --> Language Class Initialized
INFO - 2020-10-26 13:10:32 --> Loader Class Initialized
INFO - 2020-10-26 13:10:32 --> Helper loaded: url_helper
INFO - 2020-10-26 13:10:32 --> Helper loaded: form_helper
INFO - 2020-10-26 13:10:32 --> Helper loaded: html_helper
INFO - 2020-10-26 13:10:32 --> Helper loaded: date_helper
INFO - 2020-10-26 13:10:32 --> Database Driver Class Initialized
INFO - 2020-10-26 13:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:10:32 --> Table Class Initialized
INFO - 2020-10-26 13:10:32 --> Upload Class Initialized
INFO - 2020-10-26 13:10:32 --> Controller Class Initialized
INFO - 2020-10-26 13:10:32 --> Form Validation Class Initialized
INFO - 2020-10-26 13:10:32 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:10:32 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:10:32 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:10:32 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:10:32 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:10:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:10:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:10:32 --> Final output sent to browser
DEBUG - 2020-10-26 13:10:32 --> Total execution time: 0.0994
INFO - 2020-10-26 13:10:32 --> Config Class Initialized
INFO - 2020-10-26 13:10:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:10:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:10:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:10:32 --> URI Class Initialized
INFO - 2020-10-26 13:10:32 --> Router Class Initialized
INFO - 2020-10-26 13:10:32 --> Output Class Initialized
INFO - 2020-10-26 13:10:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:10:32 --> Input Class Initialized
INFO - 2020-10-26 13:10:32 --> Language Class Initialized
ERROR - 2020-10-26 13:10:32 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
INFO - 2020-10-26 13:11:38 --> Loader Class Initialized
INFO - 2020-10-26 13:11:38 --> Helper loaded: url_helper
INFO - 2020-10-26 13:11:38 --> Helper loaded: form_helper
INFO - 2020-10-26 13:11:38 --> Helper loaded: html_helper
INFO - 2020-10-26 13:11:38 --> Helper loaded: date_helper
INFO - 2020-10-26 13:11:38 --> Database Driver Class Initialized
INFO - 2020-10-26 13:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:11:38 --> Table Class Initialized
INFO - 2020-10-26 13:11:38 --> Upload Class Initialized
INFO - 2020-10-26 13:11:38 --> Controller Class Initialized
INFO - 2020-10-26 13:11:38 --> Form Validation Class Initialized
INFO - 2020-10-26 13:11:38 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:11:38 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:11:38 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:11:38 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:11:38 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:11:38 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:11:38 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:11:38 --> Final output sent to browser
DEBUG - 2020-10-26 13:11:38 --> Total execution time: 0.0822
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
ERROR - 2020-10-26 13:11:38 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
ERROR - 2020-10-26 13:11:38 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
ERROR - 2020-10-26 13:11:38 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
INFO - 2020-10-26 13:11:38 --> Loader Class Initialized
INFO - 2020-10-26 13:11:38 --> Helper loaded: url_helper
INFO - 2020-10-26 13:11:38 --> Helper loaded: form_helper
INFO - 2020-10-26 13:11:38 --> Helper loaded: html_helper
INFO - 2020-10-26 13:11:38 --> Helper loaded: date_helper
INFO - 2020-10-26 13:11:38 --> Database Driver Class Initialized
INFO - 2020-10-26 13:11:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:11:38 --> Table Class Initialized
INFO - 2020-10-26 13:11:38 --> Upload Class Initialized
INFO - 2020-10-26 13:11:38 --> Controller Class Initialized
INFO - 2020-10-26 13:11:38 --> Form Validation Class Initialized
INFO - 2020-10-26 13:11:38 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:11:38 --> Final output sent to browser
DEBUG - 2020-10-26 13:11:38 --> Total execution time: 0.0748
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
INFO - 2020-10-26 13:11:38 --> Config Class Initialized
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
INFO - 2020-10-26 13:11:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:11:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> Utf8 Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> URI Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
INFO - 2020-10-26 13:11:38 --> Router Class Initialized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
INFO - 2020-10-26 13:11:38 --> Output Class Initialized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
INFO - 2020-10-26 13:11:38 --> Security Class Initialized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
INFO - 2020-10-26 13:11:38 --> Input Class Initialized
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
ERROR - 2020-10-26 13:11:38 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:11:38 --> Language Class Initialized
ERROR - 2020-10-26 13:11:38 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:11:38 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
INFO - 2020-10-26 13:12:57 --> Loader Class Initialized
INFO - 2020-10-26 13:12:57 --> Helper loaded: url_helper
INFO - 2020-10-26 13:12:57 --> Helper loaded: form_helper
INFO - 2020-10-26 13:12:57 --> Helper loaded: html_helper
INFO - 2020-10-26 13:12:57 --> Helper loaded: date_helper
INFO - 2020-10-26 13:12:57 --> Database Driver Class Initialized
INFO - 2020-10-26 13:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:12:57 --> Table Class Initialized
INFO - 2020-10-26 13:12:57 --> Upload Class Initialized
INFO - 2020-10-26 13:12:57 --> Controller Class Initialized
INFO - 2020-10-26 13:12:57 --> Form Validation Class Initialized
INFO - 2020-10-26 13:12:57 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:12:57 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:12:57 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:12:57 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:12:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:12:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:12:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:12:57 --> Final output sent to browser
DEBUG - 2020-10-26 13:12:57 --> Total execution time: 0.0811
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
ERROR - 2020-10-26 13:12:57 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Loader Class Initialized
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Helper loaded: url_helper
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
INFO - 2020-10-26 13:12:57 --> Helper loaded: form_helper
ERROR - 2020-10-26 13:12:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:12:57 --> Helper loaded: html_helper
INFO - 2020-10-26 13:12:57 --> Helper loaded: date_helper
INFO - 2020-10-26 13:12:57 --> Database Driver Class Initialized
INFO - 2020-10-26 13:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:12:57 --> Table Class Initialized
INFO - 2020-10-26 13:12:57 --> Upload Class Initialized
INFO - 2020-10-26 13:12:57 --> Controller Class Initialized
INFO - 2020-10-26 13:12:57 --> Form Validation Class Initialized
INFO - 2020-10-26 13:12:57 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:12:57 --> Final output sent to browser
DEBUG - 2020-10-26 13:12:57 --> Total execution time: 0.0812
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
ERROR - 2020-10-26 13:12:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
ERROR - 2020-10-26 13:12:57 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:12:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
ERROR - 2020-10-26 13:12:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:12:57 --> Config Class Initialized
INFO - 2020-10-26 13:12:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:12:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:12:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:12:57 --> URI Class Initialized
INFO - 2020-10-26 13:12:57 --> Router Class Initialized
INFO - 2020-10-26 13:12:57 --> Output Class Initialized
INFO - 2020-10-26 13:12:57 --> Security Class Initialized
DEBUG - 2020-10-26 13:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:12:57 --> Input Class Initialized
INFO - 2020-10-26 13:12:57 --> Language Class Initialized
ERROR - 2020-10-26 13:12:57 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
INFO - 2020-10-26 13:14:06 --> Loader Class Initialized
INFO - 2020-10-26 13:14:06 --> Helper loaded: url_helper
INFO - 2020-10-26 13:14:06 --> Helper loaded: form_helper
INFO - 2020-10-26 13:14:06 --> Helper loaded: html_helper
INFO - 2020-10-26 13:14:06 --> Helper loaded: date_helper
INFO - 2020-10-26 13:14:06 --> Database Driver Class Initialized
INFO - 2020-10-26 13:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:14:06 --> Table Class Initialized
INFO - 2020-10-26 13:14:06 --> Upload Class Initialized
INFO - 2020-10-26 13:14:06 --> Controller Class Initialized
INFO - 2020-10-26 13:14:06 --> Form Validation Class Initialized
INFO - 2020-10-26 13:14:06 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:14:06 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:14:06 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:14:06 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:14:06 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:14:06 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:14:06 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:14:06 --> Final output sent to browser
DEBUG - 2020-10-26 13:14:06 --> Total execution time: 0.0920
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
ERROR - 2020-10-26 13:14:06 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
ERROR - 2020-10-26 13:14:06 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
ERROR - 2020-10-26 13:14:06 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
INFO - 2020-10-26 13:14:06 --> Loader Class Initialized
INFO - 2020-10-26 13:14:06 --> Helper loaded: url_helper
INFO - 2020-10-26 13:14:06 --> Helper loaded: form_helper
INFO - 2020-10-26 13:14:06 --> Helper loaded: html_helper
INFO - 2020-10-26 13:14:06 --> Helper loaded: date_helper
INFO - 2020-10-26 13:14:06 --> Database Driver Class Initialized
INFO - 2020-10-26 13:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:14:06 --> Table Class Initialized
INFO - 2020-10-26 13:14:06 --> Upload Class Initialized
INFO - 2020-10-26 13:14:06 --> Controller Class Initialized
INFO - 2020-10-26 13:14:06 --> Form Validation Class Initialized
INFO - 2020-10-26 13:14:06 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:14:06 --> Final output sent to browser
DEBUG - 2020-10-26 13:14:06 --> Total execution time: 0.0834
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
INFO - 2020-10-26 13:14:06 --> Config Class Initialized
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
INFO - 2020-10-26 13:14:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:14:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> URI Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Router Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
INFO - 2020-10-26 13:14:06 --> Output Class Initialized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:14:06 --> Security Class Initialized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
DEBUG - 2020-10-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
INFO - 2020-10-26 13:14:06 --> Input Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
INFO - 2020-10-26 13:14:06 --> Language Class Initialized
ERROR - 2020-10-26 13:14:06 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:14:06 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:14:06 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
INFO - 2020-10-26 13:15:21 --> Loader Class Initialized
INFO - 2020-10-26 13:15:21 --> Helper loaded: url_helper
INFO - 2020-10-26 13:15:21 --> Helper loaded: form_helper
INFO - 2020-10-26 13:15:21 --> Helper loaded: html_helper
INFO - 2020-10-26 13:15:21 --> Helper loaded: date_helper
INFO - 2020-10-26 13:15:21 --> Database Driver Class Initialized
INFO - 2020-10-26 13:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:15:21 --> Table Class Initialized
INFO - 2020-10-26 13:15:21 --> Upload Class Initialized
INFO - 2020-10-26 13:15:21 --> Controller Class Initialized
INFO - 2020-10-26 13:15:21 --> Form Validation Class Initialized
INFO - 2020-10-26 13:15:21 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:15:21 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:15:21 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:15:21 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:15:21 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:15:21 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:15:21 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:15:21 --> Final output sent to browser
DEBUG - 2020-10-26 13:15:21 --> Total execution time: 0.0935
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
ERROR - 2020-10-26 13:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
ERROR - 2020-10-26 13:15:21 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
ERROR - 2020-10-26 13:15:21 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
INFO - 2020-10-26 13:15:21 --> Loader Class Initialized
INFO - 2020-10-26 13:15:21 --> Helper loaded: url_helper
INFO - 2020-10-26 13:15:21 --> Helper loaded: form_helper
INFO - 2020-10-26 13:15:21 --> Helper loaded: html_helper
INFO - 2020-10-26 13:15:21 --> Helper loaded: date_helper
INFO - 2020-10-26 13:15:21 --> Database Driver Class Initialized
INFO - 2020-10-26 13:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:15:21 --> Table Class Initialized
INFO - 2020-10-26 13:15:21 --> Upload Class Initialized
INFO - 2020-10-26 13:15:21 --> Controller Class Initialized
INFO - 2020-10-26 13:15:21 --> Form Validation Class Initialized
INFO - 2020-10-26 13:15:21 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:15:21 --> Final output sent to browser
DEBUG - 2020-10-26 13:15:21 --> Total execution time: 0.0870
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
INFO - 2020-10-26 13:15:21 --> Config Class Initialized
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
INFO - 2020-10-26 13:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> URI Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
INFO - 2020-10-26 13:15:21 --> Router Class Initialized
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Output Class Initialized
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
INFO - 2020-10-26 13:15:21 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Input Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
INFO - 2020-10-26 13:15:21 --> Language Class Initialized
ERROR - 2020-10-26 13:15:21 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:15:21 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:15:21 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:15:56 --> Config Class Initialized
INFO - 2020-10-26 13:15:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:56 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:56 --> URI Class Initialized
INFO - 2020-10-26 13:15:56 --> Router Class Initialized
INFO - 2020-10-26 13:15:56 --> Output Class Initialized
INFO - 2020-10-26 13:15:56 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:56 --> Input Class Initialized
INFO - 2020-10-26 13:15:56 --> Language Class Initialized
INFO - 2020-10-26 13:15:56 --> Loader Class Initialized
INFO - 2020-10-26 13:15:56 --> Helper loaded: url_helper
INFO - 2020-10-26 13:15:56 --> Helper loaded: form_helper
INFO - 2020-10-26 13:15:56 --> Helper loaded: html_helper
INFO - 2020-10-26 13:15:56 --> Helper loaded: date_helper
INFO - 2020-10-26 13:15:56 --> Database Driver Class Initialized
INFO - 2020-10-26 13:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:15:56 --> Table Class Initialized
INFO - 2020-10-26 13:15:56 --> Upload Class Initialized
INFO - 2020-10-26 13:15:56 --> Controller Class Initialized
INFO - 2020-10-26 13:15:56 --> Form Validation Class Initialized
INFO - 2020-10-26 13:15:56 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:15:56 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:15:56 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:15:56 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:15:56 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:15:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:15:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:15:56 --> Final output sent to browser
DEBUG - 2020-10-26 13:15:56 --> Total execution time: 0.1264
INFO - 2020-10-26 13:15:56 --> Config Class Initialized
INFO - 2020-10-26 13:15:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:56 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:56 --> URI Class Initialized
INFO - 2020-10-26 13:15:56 --> Router Class Initialized
INFO - 2020-10-26 13:15:56 --> Output Class Initialized
INFO - 2020-10-26 13:15:56 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:56 --> Input Class Initialized
INFO - 2020-10-26 13:15:56 --> Language Class Initialized
INFO - 2020-10-26 13:15:56 --> Config Class Initialized
ERROR - 2020-10-26 13:15:56 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:15:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:56 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:56 --> Config Class Initialized
INFO - 2020-10-26 13:15:56 --> URI Class Initialized
INFO - 2020-10-26 13:15:56 --> Hooks Class Initialized
INFO - 2020-10-26 13:15:56 --> Router Class Initialized
DEBUG - 2020-10-26 13:15:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:56 --> Output Class Initialized
INFO - 2020-10-26 13:15:56 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:56 --> Security Class Initialized
INFO - 2020-10-26 13:15:56 --> URI Class Initialized
DEBUG - 2020-10-26 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:56 --> Router Class Initialized
INFO - 2020-10-26 13:15:56 --> Input Class Initialized
INFO - 2020-10-26 13:15:56 --> Output Class Initialized
INFO - 2020-10-26 13:15:56 --> Language Class Initialized
INFO - 2020-10-26 13:15:56 --> Security Class Initialized
ERROR - 2020-10-26 13:15:56 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:56 --> Input Class Initialized
INFO - 2020-10-26 13:15:56 --> Language Class Initialized
ERROR - 2020-10-26 13:15:56 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:15:56 --> Config Class Initialized
INFO - 2020-10-26 13:15:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:56 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:56 --> URI Class Initialized
INFO - 2020-10-26 13:15:56 --> Router Class Initialized
INFO - 2020-10-26 13:15:56 --> Output Class Initialized
INFO - 2020-10-26 13:15:56 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:56 --> Input Class Initialized
INFO - 2020-10-26 13:15:56 --> Language Class Initialized
INFO - 2020-10-26 13:15:56 --> Loader Class Initialized
INFO - 2020-10-26 13:15:56 --> Helper loaded: url_helper
INFO - 2020-10-26 13:15:56 --> Helper loaded: form_helper
INFO - 2020-10-26 13:15:56 --> Helper loaded: html_helper
INFO - 2020-10-26 13:15:56 --> Helper loaded: date_helper
INFO - 2020-10-26 13:15:56 --> Database Driver Class Initialized
INFO - 2020-10-26 13:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:15:57 --> Table Class Initialized
INFO - 2020-10-26 13:15:57 --> Upload Class Initialized
INFO - 2020-10-26 13:15:57 --> Controller Class Initialized
INFO - 2020-10-26 13:15:57 --> Form Validation Class Initialized
INFO - 2020-10-26 13:15:57 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:15:57 --> Final output sent to browser
DEBUG - 2020-10-26 13:15:57 --> Total execution time: 0.0900
INFO - 2020-10-26 13:15:57 --> Config Class Initialized
INFO - 2020-10-26 13:15:57 --> Config Class Initialized
INFO - 2020-10-26 13:15:57 --> Hooks Class Initialized
INFO - 2020-10-26 13:15:57 --> Hooks Class Initialized
INFO - 2020-10-26 13:15:57 --> Config Class Initialized
DEBUG - 2020-10-26 13:15:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:15:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:57 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:15:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:15:57 --> URI Class Initialized
INFO - 2020-10-26 13:15:57 --> Utf8 Class Initialized
INFO - 2020-10-26 13:15:57 --> URI Class Initialized
INFO - 2020-10-26 13:15:57 --> URI Class Initialized
INFO - 2020-10-26 13:15:57 --> Router Class Initialized
INFO - 2020-10-26 13:15:57 --> Router Class Initialized
INFO - 2020-10-26 13:15:57 --> Output Class Initialized
INFO - 2020-10-26 13:15:57 --> Output Class Initialized
INFO - 2020-10-26 13:15:57 --> Router Class Initialized
INFO - 2020-10-26 13:15:57 --> Output Class Initialized
INFO - 2020-10-26 13:15:57 --> Security Class Initialized
INFO - 2020-10-26 13:15:57 --> Security Class Initialized
DEBUG - 2020-10-26 13:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:57 --> Security Class Initialized
INFO - 2020-10-26 13:15:57 --> Input Class Initialized
INFO - 2020-10-26 13:15:57 --> Input Class Initialized
DEBUG - 2020-10-26 13:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:15:57 --> Language Class Initialized
INFO - 2020-10-26 13:15:57 --> Language Class Initialized
INFO - 2020-10-26 13:15:57 --> Input Class Initialized
INFO - 2020-10-26 13:15:57 --> Language Class Initialized
ERROR - 2020-10-26 13:15:57 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:15:57 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:15:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:17:46 --> Config Class Initialized
INFO - 2020-10-26 13:17:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:17:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:17:46 --> Utf8 Class Initialized
INFO - 2020-10-26 13:17:46 --> URI Class Initialized
INFO - 2020-10-26 13:17:46 --> Router Class Initialized
INFO - 2020-10-26 13:17:46 --> Output Class Initialized
INFO - 2020-10-26 13:17:46 --> Security Class Initialized
DEBUG - 2020-10-26 13:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:17:46 --> Input Class Initialized
INFO - 2020-10-26 13:17:46 --> Language Class Initialized
INFO - 2020-10-26 13:17:46 --> Loader Class Initialized
INFO - 2020-10-26 13:17:46 --> Helper loaded: url_helper
INFO - 2020-10-26 13:17:46 --> Helper loaded: form_helper
INFO - 2020-10-26 13:17:46 --> Helper loaded: html_helper
INFO - 2020-10-26 13:17:47 --> Helper loaded: date_helper
INFO - 2020-10-26 13:17:47 --> Database Driver Class Initialized
INFO - 2020-10-26 13:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:17:47 --> Table Class Initialized
INFO - 2020-10-26 13:17:47 --> Upload Class Initialized
INFO - 2020-10-26 13:17:47 --> Controller Class Initialized
INFO - 2020-10-26 13:17:47 --> Form Validation Class Initialized
INFO - 2020-10-26 13:17:47 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:17:47 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:17:47 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:17:47 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:17:47 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:17:47 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:17:47 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:17:47 --> Final output sent to browser
DEBUG - 2020-10-26 13:17:47 --> Total execution time: 0.1057
INFO - 2020-10-26 13:17:47 --> Config Class Initialized
INFO - 2020-10-26 13:17:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:17:47 --> Utf8 Class Initialized
INFO - 2020-10-26 13:17:47 --> URI Class Initialized
INFO - 2020-10-26 13:17:47 --> Router Class Initialized
INFO - 2020-10-26 13:17:47 --> Output Class Initialized
INFO - 2020-10-26 13:17:47 --> Security Class Initialized
DEBUG - 2020-10-26 13:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:17:47 --> Config Class Initialized
INFO - 2020-10-26 13:17:47 --> Hooks Class Initialized
INFO - 2020-10-26 13:17:47 --> Input Class Initialized
INFO - 2020-10-26 13:17:47 --> Language Class Initialized
DEBUG - 2020-10-26 13:17:47 --> UTF-8 Support Enabled
ERROR - 2020-10-26 13:17:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:17:47 --> Utf8 Class Initialized
INFO - 2020-10-26 13:17:47 --> URI Class Initialized
INFO - 2020-10-26 13:17:47 --> Router Class Initialized
INFO - 2020-10-26 13:17:47 --> Output Class Initialized
INFO - 2020-10-26 13:17:47 --> Config Class Initialized
INFO - 2020-10-26 13:17:47 --> Hooks Class Initialized
INFO - 2020-10-26 13:17:47 --> Security Class Initialized
DEBUG - 2020-10-26 13:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:17:47 --> Utf8 Class Initialized
INFO - 2020-10-26 13:17:47 --> Input Class Initialized
INFO - 2020-10-26 13:17:47 --> URI Class Initialized
INFO - 2020-10-26 13:17:47 --> Language Class Initialized
ERROR - 2020-10-26 13:17:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:17:47 --> Router Class Initialized
INFO - 2020-10-26 13:17:47 --> Output Class Initialized
INFO - 2020-10-26 13:17:47 --> Security Class Initialized
DEBUG - 2020-10-26 13:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:17:47 --> Input Class Initialized
INFO - 2020-10-26 13:17:47 --> Language Class Initialized
ERROR - 2020-10-26 13:17:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:17:47 --> Config Class Initialized
INFO - 2020-10-26 13:17:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:17:47 --> Utf8 Class Initialized
INFO - 2020-10-26 13:17:47 --> URI Class Initialized
INFO - 2020-10-26 13:17:47 --> Router Class Initialized
INFO - 2020-10-26 13:17:47 --> Output Class Initialized
INFO - 2020-10-26 13:17:47 --> Security Class Initialized
DEBUG - 2020-10-26 13:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:17:47 --> Input Class Initialized
INFO - 2020-10-26 13:17:47 --> Language Class Initialized
INFO - 2020-10-26 13:17:47 --> Loader Class Initialized
INFO - 2020-10-26 13:17:47 --> Helper loaded: url_helper
INFO - 2020-10-26 13:17:47 --> Helper loaded: form_helper
INFO - 2020-10-26 13:17:47 --> Helper loaded: html_helper
INFO - 2020-10-26 13:17:47 --> Helper loaded: date_helper
INFO - 2020-10-26 13:17:47 --> Database Driver Class Initialized
INFO - 2020-10-26 13:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:17:47 --> Table Class Initialized
INFO - 2020-10-26 13:17:47 --> Upload Class Initialized
INFO - 2020-10-26 13:17:47 --> Controller Class Initialized
INFO - 2020-10-26 13:17:47 --> Form Validation Class Initialized
INFO - 2020-10-26 13:17:47 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:17:47 --> Final output sent to browser
DEBUG - 2020-10-26 13:17:47 --> Total execution time: 0.0953
INFO - 2020-10-26 13:17:47 --> Config Class Initialized
INFO - 2020-10-26 13:17:47 --> Config Class Initialized
INFO - 2020-10-26 13:17:47 --> Config Class Initialized
INFO - 2020-10-26 13:17:47 --> Hooks Class Initialized
INFO - 2020-10-26 13:17:47 --> Hooks Class Initialized
INFO - 2020-10-26 13:17:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:17:47 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:17:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:17:47 --> URI Class Initialized
INFO - 2020-10-26 13:17:47 --> Utf8 Class Initialized
INFO - 2020-10-26 13:17:47 --> Utf8 Class Initialized
INFO - 2020-10-26 13:17:47 --> URI Class Initialized
INFO - 2020-10-26 13:17:47 --> Router Class Initialized
INFO - 2020-10-26 13:17:47 --> URI Class Initialized
INFO - 2020-10-26 13:17:47 --> Router Class Initialized
INFO - 2020-10-26 13:17:47 --> Router Class Initialized
INFO - 2020-10-26 13:17:47 --> Output Class Initialized
INFO - 2020-10-26 13:17:47 --> Output Class Initialized
INFO - 2020-10-26 13:17:47 --> Output Class Initialized
INFO - 2020-10-26 13:17:47 --> Security Class Initialized
INFO - 2020-10-26 13:17:47 --> Security Class Initialized
DEBUG - 2020-10-26 13:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:17:47 --> Security Class Initialized
DEBUG - 2020-10-26 13:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:17:47 --> Input Class Initialized
INFO - 2020-10-26 13:17:47 --> Input Class Initialized
INFO - 2020-10-26 13:17:47 --> Input Class Initialized
INFO - 2020-10-26 13:17:47 --> Language Class Initialized
INFO - 2020-10-26 13:17:47 --> Language Class Initialized
INFO - 2020-10-26 13:17:47 --> Language Class Initialized
ERROR - 2020-10-26 13:17:47 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:17:47 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:17:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:19:50 --> Config Class Initialized
INFO - 2020-10-26 13:19:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:19:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
INFO - 2020-10-26 13:19:51 --> Loader Class Initialized
INFO - 2020-10-26 13:19:51 --> Helper loaded: url_helper
INFO - 2020-10-26 13:19:51 --> Helper loaded: form_helper
INFO - 2020-10-26 13:19:51 --> Helper loaded: html_helper
INFO - 2020-10-26 13:19:51 --> Helper loaded: date_helper
INFO - 2020-10-26 13:19:51 --> Database Driver Class Initialized
INFO - 2020-10-26 13:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:19:51 --> Table Class Initialized
INFO - 2020-10-26 13:19:51 --> Upload Class Initialized
INFO - 2020-10-26 13:19:51 --> Controller Class Initialized
INFO - 2020-10-26 13:19:51 --> Form Validation Class Initialized
INFO - 2020-10-26 13:19:51 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:19:51 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:19:51 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:19:51 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:19:51 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:19:51 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:19:51 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:19:51 --> Final output sent to browser
DEBUG - 2020-10-26 13:19:51 --> Total execution time: 0.1077
INFO - 2020-10-26 13:19:51 --> Config Class Initialized
INFO - 2020-10-26 13:19:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:19:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:19:51 --> Config Class Initialized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Hooks Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
DEBUG - 2020-10-26 13:19:51 --> UTF-8 Support Enabled
ERROR - 2020-10-26 13:19:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> Config Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Hooks Class Initialized
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
DEBUG - 2020-10-26 13:19:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
ERROR - 2020-10-26 13:19:51 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
ERROR - 2020-10-26 13:19:51 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:19:51 --> Config Class Initialized
INFO - 2020-10-26 13:19:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:19:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
INFO - 2020-10-26 13:19:51 --> Loader Class Initialized
INFO - 2020-10-26 13:19:51 --> Helper loaded: url_helper
INFO - 2020-10-26 13:19:51 --> Helper loaded: form_helper
INFO - 2020-10-26 13:19:51 --> Helper loaded: html_helper
INFO - 2020-10-26 13:19:51 --> Helper loaded: date_helper
INFO - 2020-10-26 13:19:51 --> Database Driver Class Initialized
INFO - 2020-10-26 13:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:19:51 --> Table Class Initialized
INFO - 2020-10-26 13:19:51 --> Upload Class Initialized
INFO - 2020-10-26 13:19:51 --> Controller Class Initialized
INFO - 2020-10-26 13:19:51 --> Form Validation Class Initialized
INFO - 2020-10-26 13:19:51 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:19:51 --> Final output sent to browser
DEBUG - 2020-10-26 13:19:51 --> Total execution time: 0.1027
INFO - 2020-10-26 13:19:51 --> Config Class Initialized
INFO - 2020-10-26 13:19:51 --> Config Class Initialized
INFO - 2020-10-26 13:19:51 --> Hooks Class Initialized
INFO - 2020-10-26 13:19:51 --> Config Class Initialized
INFO - 2020-10-26 13:19:51 --> Hooks Class Initialized
INFO - 2020-10-26 13:19:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:19:51 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:19:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:19:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
INFO - 2020-10-26 13:19:51 --> Utf8 Class Initialized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> URI Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Router Class Initialized
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
INFO - 2020-10-26 13:19:51 --> Output Class Initialized
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
INFO - 2020-10-26 13:19:51 --> Security Class Initialized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Input Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
INFO - 2020-10-26 13:19:51 --> Language Class Initialized
ERROR - 2020-10-26 13:19:51 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:19:51 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:19:51 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
INFO - 2020-10-26 13:22:07 --> Loader Class Initialized
INFO - 2020-10-26 13:22:07 --> Helper loaded: url_helper
INFO - 2020-10-26 13:22:07 --> Helper loaded: form_helper
INFO - 2020-10-26 13:22:07 --> Helper loaded: html_helper
INFO - 2020-10-26 13:22:07 --> Helper loaded: date_helper
INFO - 2020-10-26 13:22:07 --> Database Driver Class Initialized
INFO - 2020-10-26 13:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:22:07 --> Table Class Initialized
INFO - 2020-10-26 13:22:07 --> Upload Class Initialized
INFO - 2020-10-26 13:22:07 --> Controller Class Initialized
INFO - 2020-10-26 13:22:07 --> Form Validation Class Initialized
INFO - 2020-10-26 13:22:07 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:22:07 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:22:07 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:22:07 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:22:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:22:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:22:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:22:07 --> Final output sent to browser
DEBUG - 2020-10-26 13:22:07 --> Total execution time: 0.1268
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
ERROR - 2020-10-26 13:22:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
ERROR - 2020-10-26 13:22:07 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
ERROR - 2020-10-26 13:22:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
INFO - 2020-10-26 13:22:07 --> Loader Class Initialized
INFO - 2020-10-26 13:22:07 --> Helper loaded: url_helper
INFO - 2020-10-26 13:22:07 --> Helper loaded: form_helper
INFO - 2020-10-26 13:22:07 --> Helper loaded: html_helper
INFO - 2020-10-26 13:22:07 --> Helper loaded: date_helper
INFO - 2020-10-26 13:22:07 --> Database Driver Class Initialized
INFO - 2020-10-26 13:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:22:07 --> Table Class Initialized
INFO - 2020-10-26 13:22:07 --> Upload Class Initialized
INFO - 2020-10-26 13:22:07 --> Controller Class Initialized
INFO - 2020-10-26 13:22:07 --> Form Validation Class Initialized
INFO - 2020-10-26 13:22:07 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:22:07 --> Final output sent to browser
DEBUG - 2020-10-26 13:22:07 --> Total execution time: 0.1022
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
INFO - 2020-10-26 13:22:07 --> Config Class Initialized
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:22:07 --> Hooks Class Initialized
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:22:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
INFO - 2020-10-26 13:22:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> URI Class Initialized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Router Class Initialized
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
INFO - 2020-10-26 13:22:07 --> Output Class Initialized
INFO - 2020-10-26 13:22:07 --> Security Class Initialized
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Input Class Initialized
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
ERROR - 2020-10-26 13:22:07 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:22:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:22:07 --> Language Class Initialized
ERROR - 2020-10-26 13:22:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:24:07 --> Config Class Initialized
INFO - 2020-10-26 13:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:24:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:24:07 --> URI Class Initialized
INFO - 2020-10-26 13:24:07 --> Router Class Initialized
INFO - 2020-10-26 13:24:07 --> Output Class Initialized
INFO - 2020-10-26 13:24:07 --> Security Class Initialized
DEBUG - 2020-10-26 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:07 --> Input Class Initialized
INFO - 2020-10-26 13:24:07 --> Language Class Initialized
INFO - 2020-10-26 13:24:07 --> Loader Class Initialized
INFO - 2020-10-26 13:24:07 --> Helper loaded: url_helper
INFO - 2020-10-26 13:24:07 --> Helper loaded: form_helper
INFO - 2020-10-26 13:24:07 --> Helper loaded: html_helper
INFO - 2020-10-26 13:24:07 --> Helper loaded: date_helper
INFO - 2020-10-26 13:24:07 --> Database Driver Class Initialized
INFO - 2020-10-26 13:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:24:07 --> Table Class Initialized
INFO - 2020-10-26 13:24:07 --> Upload Class Initialized
INFO - 2020-10-26 13:24:07 --> Controller Class Initialized
INFO - 2020-10-26 13:24:07 --> Form Validation Class Initialized
INFO - 2020-10-26 13:24:07 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:24:07 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:24:07 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:24:07 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:24:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:24:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:24:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:24:07 --> Final output sent to browser
DEBUG - 2020-10-26 13:24:07 --> Total execution time: 0.1224
INFO - 2020-10-26 13:24:07 --> Config Class Initialized
INFO - 2020-10-26 13:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:24:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:24:07 --> URI Class Initialized
INFO - 2020-10-26 13:24:07 --> Config Class Initialized
INFO - 2020-10-26 13:24:07 --> Hooks Class Initialized
INFO - 2020-10-26 13:24:07 --> Router Class Initialized
DEBUG - 2020-10-26 13:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:24:07 --> Output Class Initialized
INFO - 2020-10-26 13:24:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:24:07 --> Security Class Initialized
INFO - 2020-10-26 13:24:07 --> URI Class Initialized
DEBUG - 2020-10-26 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:07 --> Router Class Initialized
INFO - 2020-10-26 13:24:07 --> Input Class Initialized
INFO - 2020-10-26 13:24:07 --> Output Class Initialized
INFO - 2020-10-26 13:24:07 --> Language Class Initialized
INFO - 2020-10-26 13:24:07 --> Security Class Initialized
ERROR - 2020-10-26 13:24:07 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:07 --> Input Class Initialized
INFO - 2020-10-26 13:24:07 --> Config Class Initialized
INFO - 2020-10-26 13:24:07 --> Language Class Initialized
ERROR - 2020-10-26 13:24:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:24:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:24:07 --> URI Class Initialized
INFO - 2020-10-26 13:24:07 --> Router Class Initialized
INFO - 2020-10-26 13:24:07 --> Output Class Initialized
INFO - 2020-10-26 13:24:07 --> Security Class Initialized
DEBUG - 2020-10-26 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:07 --> Input Class Initialized
INFO - 2020-10-26 13:24:07 --> Language Class Initialized
ERROR - 2020-10-26 13:24:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:24:07 --> Config Class Initialized
INFO - 2020-10-26 13:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:24:07 --> Utf8 Class Initialized
INFO - 2020-10-26 13:24:07 --> URI Class Initialized
INFO - 2020-10-26 13:24:07 --> Router Class Initialized
INFO - 2020-10-26 13:24:07 --> Output Class Initialized
INFO - 2020-10-26 13:24:07 --> Security Class Initialized
DEBUG - 2020-10-26 13:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:07 --> Input Class Initialized
INFO - 2020-10-26 13:24:07 --> Language Class Initialized
INFO - 2020-10-26 13:24:07 --> Loader Class Initialized
INFO - 2020-10-26 13:24:07 --> Helper loaded: url_helper
INFO - 2020-10-26 13:24:07 --> Helper loaded: form_helper
INFO - 2020-10-26 13:24:07 --> Helper loaded: html_helper
INFO - 2020-10-26 13:24:07 --> Helper loaded: date_helper
INFO - 2020-10-26 13:24:07 --> Database Driver Class Initialized
INFO - 2020-10-26 13:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:24:07 --> Table Class Initialized
INFO - 2020-10-26 13:24:07 --> Upload Class Initialized
INFO - 2020-10-26 13:24:07 --> Controller Class Initialized
INFO - 2020-10-26 13:24:07 --> Form Validation Class Initialized
INFO - 2020-10-26 13:24:08 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:24:08 --> Final output sent to browser
DEBUG - 2020-10-26 13:24:08 --> Total execution time: 0.1019
INFO - 2020-10-26 13:24:08 --> Config Class Initialized
INFO - 2020-10-26 13:24:08 --> Hooks Class Initialized
INFO - 2020-10-26 13:24:08 --> Config Class Initialized
INFO - 2020-10-26 13:24:08 --> Config Class Initialized
DEBUG - 2020-10-26 13:24:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:24:08 --> Hooks Class Initialized
INFO - 2020-10-26 13:24:08 --> Hooks Class Initialized
INFO - 2020-10-26 13:24:08 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:24:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:24:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:24:08 --> Utf8 Class Initialized
INFO - 2020-10-26 13:24:08 --> URI Class Initialized
INFO - 2020-10-26 13:24:08 --> URI Class Initialized
INFO - 2020-10-26 13:24:08 --> Utf8 Class Initialized
INFO - 2020-10-26 13:24:08 --> Router Class Initialized
INFO - 2020-10-26 13:24:08 --> Output Class Initialized
INFO - 2020-10-26 13:24:08 --> Router Class Initialized
INFO - 2020-10-26 13:24:08 --> URI Class Initialized
INFO - 2020-10-26 13:24:08 --> Security Class Initialized
INFO - 2020-10-26 13:24:08 --> Router Class Initialized
INFO - 2020-10-26 13:24:08 --> Output Class Initialized
DEBUG - 2020-10-26 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:08 --> Output Class Initialized
INFO - 2020-10-26 13:24:08 --> Security Class Initialized
INFO - 2020-10-26 13:24:08 --> Security Class Initialized
INFO - 2020-10-26 13:24:08 --> Input Class Initialized
DEBUG - 2020-10-26 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:08 --> Input Class Initialized
INFO - 2020-10-26 13:24:08 --> Language Class Initialized
DEBUG - 2020-10-26 13:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:24:08 --> Input Class Initialized
INFO - 2020-10-26 13:24:08 --> Language Class Initialized
ERROR - 2020-10-26 13:24:08 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:24:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:24:08 --> Language Class Initialized
ERROR - 2020-10-26 13:24:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
INFO - 2020-10-26 13:46:31 --> Loader Class Initialized
INFO - 2020-10-26 13:46:31 --> Helper loaded: url_helper
INFO - 2020-10-26 13:46:31 --> Helper loaded: form_helper
INFO - 2020-10-26 13:46:31 --> Helper loaded: html_helper
INFO - 2020-10-26 13:46:31 --> Helper loaded: date_helper
INFO - 2020-10-26 13:46:31 --> Database Driver Class Initialized
INFO - 2020-10-26 13:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:46:31 --> Table Class Initialized
INFO - 2020-10-26 13:46:31 --> Upload Class Initialized
INFO - 2020-10-26 13:46:31 --> Controller Class Initialized
INFO - 2020-10-26 13:46:31 --> Form Validation Class Initialized
INFO - 2020-10-26 13:46:31 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:46:31 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:46:31 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:46:31 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:46:31 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:46:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:46:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:46:31 --> Final output sent to browser
DEBUG - 2020-10-26 13:46:31 --> Total execution time: 0.1267
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
ERROR - 2020-10-26 13:46:31 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
ERROR - 2020-10-26 13:46:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
ERROR - 2020-10-26 13:46:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
INFO - 2020-10-26 13:46:31 --> Loader Class Initialized
INFO - 2020-10-26 13:46:31 --> Helper loaded: url_helper
INFO - 2020-10-26 13:46:31 --> Helper loaded: form_helper
INFO - 2020-10-26 13:46:31 --> Helper loaded: html_helper
INFO - 2020-10-26 13:46:31 --> Helper loaded: date_helper
INFO - 2020-10-26 13:46:31 --> Database Driver Class Initialized
INFO - 2020-10-26 13:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:46:31 --> Table Class Initialized
INFO - 2020-10-26 13:46:31 --> Upload Class Initialized
INFO - 2020-10-26 13:46:31 --> Controller Class Initialized
INFO - 2020-10-26 13:46:31 --> Form Validation Class Initialized
INFO - 2020-10-26 13:46:31 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:46:31 --> Final output sent to browser
DEBUG - 2020-10-26 13:46:31 --> Total execution time: 0.1112
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Config Class Initialized
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
INFO - 2020-10-26 13:46:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:46:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
INFO - 2020-10-26 13:46:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
INFO - 2020-10-26 13:46:31 --> URI Class Initialized
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> Router Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
INFO - 2020-10-26 13:46:31 --> Output Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
INFO - 2020-10-26 13:46:31 --> Security Class Initialized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
DEBUG - 2020-10-26 13:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
INFO - 2020-10-26 13:46:31 --> Input Class Initialized
ERROR - 2020-10-26 13:46:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
INFO - 2020-10-26 13:46:31 --> Language Class Initialized
ERROR - 2020-10-26 13:46:31 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:46:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
INFO - 2020-10-26 13:48:32 --> Loader Class Initialized
INFO - 2020-10-26 13:48:32 --> Helper loaded: url_helper
INFO - 2020-10-26 13:48:32 --> Helper loaded: form_helper
INFO - 2020-10-26 13:48:32 --> Helper loaded: html_helper
INFO - 2020-10-26 13:48:32 --> Helper loaded: date_helper
INFO - 2020-10-26 13:48:32 --> Database Driver Class Initialized
INFO - 2020-10-26 13:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:48:32 --> Table Class Initialized
INFO - 2020-10-26 13:48:32 --> Upload Class Initialized
INFO - 2020-10-26 13:48:32 --> Controller Class Initialized
INFO - 2020-10-26 13:48:32 --> Form Validation Class Initialized
INFO - 2020-10-26 13:48:32 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:48:32 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:48:32 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:48:32 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:48:32 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:48:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:48:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:48:32 --> Final output sent to browser
DEBUG - 2020-10-26 13:48:32 --> Total execution time: 0.1254
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
ERROR - 2020-10-26 13:48:32 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
ERROR - 2020-10-26 13:48:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
ERROR - 2020-10-26 13:48:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
INFO - 2020-10-26 13:48:32 --> Loader Class Initialized
INFO - 2020-10-26 13:48:32 --> Helper loaded: url_helper
INFO - 2020-10-26 13:48:32 --> Helper loaded: form_helper
INFO - 2020-10-26 13:48:32 --> Helper loaded: html_helper
INFO - 2020-10-26 13:48:32 --> Helper loaded: date_helper
INFO - 2020-10-26 13:48:32 --> Database Driver Class Initialized
INFO - 2020-10-26 13:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:48:32 --> Table Class Initialized
INFO - 2020-10-26 13:48:32 --> Upload Class Initialized
INFO - 2020-10-26 13:48:32 --> Controller Class Initialized
INFO - 2020-10-26 13:48:32 --> Form Validation Class Initialized
INFO - 2020-10-26 13:48:32 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:48:32 --> Final output sent to browser
DEBUG - 2020-10-26 13:48:32 --> Total execution time: 0.1145
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
INFO - 2020-10-26 13:48:32 --> Config Class Initialized
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:48:32 --> Hooks Class Initialized
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:48:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:48:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> URI Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Router Class Initialized
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
INFO - 2020-10-26 13:48:32 --> Output Class Initialized
INFO - 2020-10-26 13:48:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> Input Class Initialized
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
ERROR - 2020-10-26 13:48:32 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:48:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:48:32 --> Language Class Initialized
ERROR - 2020-10-26 13:48:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
INFO - 2020-10-26 13:49:00 --> Output Class Initialized
INFO - 2020-10-26 13:49:00 --> Security Class Initialized
DEBUG - 2020-10-26 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:49:00 --> Input Class Initialized
INFO - 2020-10-26 13:49:00 --> Language Class Initialized
INFO - 2020-10-26 13:49:00 --> Loader Class Initialized
INFO - 2020-10-26 13:49:00 --> Helper loaded: url_helper
INFO - 2020-10-26 13:49:00 --> Helper loaded: form_helper
INFO - 2020-10-26 13:49:00 --> Helper loaded: html_helper
INFO - 2020-10-26 13:49:00 --> Helper loaded: date_helper
INFO - 2020-10-26 13:49:00 --> Database Driver Class Initialized
INFO - 2020-10-26 13:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:49:00 --> Table Class Initialized
INFO - 2020-10-26 13:49:00 --> Upload Class Initialized
INFO - 2020-10-26 13:49:00 --> Controller Class Initialized
INFO - 2020-10-26 13:49:00 --> Form Validation Class Initialized
INFO - 2020-10-26 13:49:00 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:49:00 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:49:00 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:49:00 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:49:00 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:49:00 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:49:00 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:49:00 --> Final output sent to browser
DEBUG - 2020-10-26 13:49:00 --> Total execution time: 0.1293
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
INFO - 2020-10-26 13:49:00 --> Output Class Initialized
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Security Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:49:00 --> Input Class Initialized
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:49:00 --> Language Class Initialized
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
ERROR - 2020-10-26 13:49:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
INFO - 2020-10-26 13:49:00 --> Output Class Initialized
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Security Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:49:00 --> Input Class Initialized
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
INFO - 2020-10-26 13:49:00 --> Language Class Initialized
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
ERROR - 2020-10-26 13:49:00 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:49:00 --> Output Class Initialized
INFO - 2020-10-26 13:49:00 --> Security Class Initialized
DEBUG - 2020-10-26 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:49:00 --> Input Class Initialized
INFO - 2020-10-26 13:49:00 --> Language Class Initialized
ERROR - 2020-10-26 13:49:00 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
INFO - 2020-10-26 13:49:00 --> Output Class Initialized
INFO - 2020-10-26 13:49:00 --> Security Class Initialized
DEBUG - 2020-10-26 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:49:00 --> Input Class Initialized
INFO - 2020-10-26 13:49:00 --> Language Class Initialized
INFO - 2020-10-26 13:49:00 --> Loader Class Initialized
INFO - 2020-10-26 13:49:00 --> Helper loaded: url_helper
INFO - 2020-10-26 13:49:00 --> Helper loaded: form_helper
INFO - 2020-10-26 13:49:00 --> Helper loaded: html_helper
INFO - 2020-10-26 13:49:00 --> Helper loaded: date_helper
INFO - 2020-10-26 13:49:00 --> Database Driver Class Initialized
INFO - 2020-10-26 13:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:49:00 --> Table Class Initialized
INFO - 2020-10-26 13:49:00 --> Upload Class Initialized
INFO - 2020-10-26 13:49:00 --> Controller Class Initialized
INFO - 2020-10-26 13:49:00 --> Form Validation Class Initialized
INFO - 2020-10-26 13:49:00 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:49:00 --> Final output sent to browser
DEBUG - 2020-10-26 13:49:00 --> Total execution time: 0.1236
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Config Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
INFO - 2020-10-26 13:49:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:49:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> Utf8 Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
INFO - 2020-10-26 13:49:00 --> URI Class Initialized
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
INFO - 2020-10-26 13:49:00 --> Router Class Initialized
INFO - 2020-10-26 13:49:01 --> Output Class Initialized
INFO - 2020-10-26 13:49:01 --> Output Class Initialized
INFO - 2020-10-26 13:49:01 --> Output Class Initialized
INFO - 2020-10-26 13:49:01 --> Security Class Initialized
INFO - 2020-10-26 13:49:01 --> Security Class Initialized
INFO - 2020-10-26 13:49:01 --> Security Class Initialized
DEBUG - 2020-10-26 13:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:49:01 --> Input Class Initialized
INFO - 2020-10-26 13:49:01 --> Input Class Initialized
INFO - 2020-10-26 13:49:01 --> Input Class Initialized
INFO - 2020-10-26 13:49:01 --> Language Class Initialized
INFO - 2020-10-26 13:49:01 --> Language Class Initialized
INFO - 2020-10-26 13:49:01 --> Language Class Initialized
ERROR - 2020-10-26 13:49:01 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:49:01 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:49:01 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:50:53 --> Config Class Initialized
INFO - 2020-10-26 13:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:50:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:50:53 --> Utf8 Class Initialized
INFO - 2020-10-26 13:50:53 --> URI Class Initialized
INFO - 2020-10-26 13:50:53 --> Router Class Initialized
INFO - 2020-10-26 13:50:53 --> Output Class Initialized
INFO - 2020-10-26 13:50:53 --> Security Class Initialized
DEBUG - 2020-10-26 13:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:50:53 --> Input Class Initialized
INFO - 2020-10-26 13:50:53 --> Language Class Initialized
INFO - 2020-10-26 13:50:53 --> Loader Class Initialized
INFO - 2020-10-26 13:50:53 --> Helper loaded: url_helper
INFO - 2020-10-26 13:50:53 --> Helper loaded: form_helper
INFO - 2020-10-26 13:50:53 --> Helper loaded: html_helper
INFO - 2020-10-26 13:50:53 --> Helper loaded: date_helper
INFO - 2020-10-26 13:50:53 --> Database Driver Class Initialized
INFO - 2020-10-26 13:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:50:53 --> Table Class Initialized
INFO - 2020-10-26 13:50:53 --> Upload Class Initialized
INFO - 2020-10-26 13:50:53 --> Controller Class Initialized
INFO - 2020-10-26 13:50:53 --> Form Validation Class Initialized
INFO - 2020-10-26 13:50:53 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:50:53 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:50:53 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:50:53 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:50:53 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:50:53 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:50:53 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:50:53 --> Final output sent to browser
DEBUG - 2020-10-26 13:50:53 --> Total execution time: 0.1414
INFO - 2020-10-26 13:50:53 --> Config Class Initialized
INFO - 2020-10-26 13:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:50:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:50:53 --> Utf8 Class Initialized
INFO - 2020-10-26 13:50:53 --> URI Class Initialized
INFO - 2020-10-26 13:50:53 --> Router Class Initialized
INFO - 2020-10-26 13:50:53 --> Output Class Initialized
INFO - 2020-10-26 13:50:53 --> Config Class Initialized
INFO - 2020-10-26 13:50:53 --> Security Class Initialized
DEBUG - 2020-10-26 13:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:50:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:50:53 --> Input Class Initialized
INFO - 2020-10-26 13:50:53 --> Language Class Initialized
INFO - 2020-10-26 13:50:53 --> Utf8 Class Initialized
ERROR - 2020-10-26 13:50:53 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:50:53 --> URI Class Initialized
INFO - 2020-10-26 13:50:53 --> Router Class Initialized
INFO - 2020-10-26 13:50:53 --> Output Class Initialized
INFO - 2020-10-26 13:50:53 --> Config Class Initialized
INFO - 2020-10-26 13:50:53 --> Security Class Initialized
INFO - 2020-10-26 13:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:50:53 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:50:53 --> Input Class Initialized
INFO - 2020-10-26 13:50:53 --> Utf8 Class Initialized
INFO - 2020-10-26 13:50:53 --> URI Class Initialized
INFO - 2020-10-26 13:50:53 --> Language Class Initialized
ERROR - 2020-10-26 13:50:53 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:50:53 --> Router Class Initialized
INFO - 2020-10-26 13:50:54 --> Output Class Initialized
INFO - 2020-10-26 13:50:54 --> Security Class Initialized
DEBUG - 2020-10-26 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:50:54 --> Input Class Initialized
INFO - 2020-10-26 13:50:54 --> Language Class Initialized
ERROR - 2020-10-26 13:50:54 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:50:54 --> Config Class Initialized
INFO - 2020-10-26 13:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:50:54 --> Utf8 Class Initialized
INFO - 2020-10-26 13:50:54 --> URI Class Initialized
INFO - 2020-10-26 13:50:54 --> Router Class Initialized
INFO - 2020-10-26 13:50:54 --> Output Class Initialized
INFO - 2020-10-26 13:50:54 --> Security Class Initialized
DEBUG - 2020-10-26 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:50:54 --> Input Class Initialized
INFO - 2020-10-26 13:50:54 --> Language Class Initialized
INFO - 2020-10-26 13:50:54 --> Loader Class Initialized
INFO - 2020-10-26 13:50:54 --> Helper loaded: url_helper
INFO - 2020-10-26 13:50:54 --> Helper loaded: form_helper
INFO - 2020-10-26 13:50:54 --> Helper loaded: html_helper
INFO - 2020-10-26 13:50:54 --> Helper loaded: date_helper
INFO - 2020-10-26 13:50:54 --> Database Driver Class Initialized
INFO - 2020-10-26 13:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:50:54 --> Table Class Initialized
INFO - 2020-10-26 13:50:54 --> Upload Class Initialized
INFO - 2020-10-26 13:50:54 --> Controller Class Initialized
INFO - 2020-10-26 13:50:54 --> Form Validation Class Initialized
INFO - 2020-10-26 13:50:54 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:50:54 --> Final output sent to browser
DEBUG - 2020-10-26 13:50:54 --> Total execution time: 0.1392
INFO - 2020-10-26 13:50:54 --> Config Class Initialized
INFO - 2020-10-26 13:50:54 --> Config Class Initialized
INFO - 2020-10-26 13:50:54 --> Hooks Class Initialized
INFO - 2020-10-26 13:50:54 --> Config Class Initialized
INFO - 2020-10-26 13:50:54 --> Hooks Class Initialized
INFO - 2020-10-26 13:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:50:54 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:50:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:50:54 --> URI Class Initialized
INFO - 2020-10-26 13:50:54 --> Utf8 Class Initialized
INFO - 2020-10-26 13:50:54 --> Utf8 Class Initialized
INFO - 2020-10-26 13:50:54 --> URI Class Initialized
INFO - 2020-10-26 13:50:54 --> URI Class Initialized
INFO - 2020-10-26 13:50:54 --> Router Class Initialized
INFO - 2020-10-26 13:50:54 --> Output Class Initialized
INFO - 2020-10-26 13:50:54 --> Router Class Initialized
INFO - 2020-10-26 13:50:54 --> Router Class Initialized
INFO - 2020-10-26 13:50:54 --> Output Class Initialized
INFO - 2020-10-26 13:50:54 --> Security Class Initialized
INFO - 2020-10-26 13:50:54 --> Output Class Initialized
INFO - 2020-10-26 13:50:54 --> Security Class Initialized
DEBUG - 2020-10-26 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:50:54 --> Security Class Initialized
DEBUG - 2020-10-26 13:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:50:54 --> Input Class Initialized
INFO - 2020-10-26 13:50:54 --> Input Class Initialized
INFO - 2020-10-26 13:50:54 --> Input Class Initialized
INFO - 2020-10-26 13:50:54 --> Language Class Initialized
ERROR - 2020-10-26 13:50:54 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:50:54 --> Language Class Initialized
INFO - 2020-10-26 13:50:54 --> Language Class Initialized
ERROR - 2020-10-26 13:50:54 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:50:54 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:51:21 --> Config Class Initialized
INFO - 2020-10-26 13:51:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:51:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:51:21 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:21 --> URI Class Initialized
INFO - 2020-10-26 13:51:21 --> Router Class Initialized
INFO - 2020-10-26 13:51:21 --> Output Class Initialized
INFO - 2020-10-26 13:51:21 --> Security Class Initialized
DEBUG - 2020-10-26 13:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:51:21 --> Input Class Initialized
INFO - 2020-10-26 13:51:21 --> Language Class Initialized
INFO - 2020-10-26 13:51:21 --> Loader Class Initialized
INFO - 2020-10-26 13:51:21 --> Helper loaded: url_helper
INFO - 2020-10-26 13:51:21 --> Helper loaded: form_helper
INFO - 2020-10-26 13:51:21 --> Helper loaded: html_helper
INFO - 2020-10-26 13:51:21 --> Helper loaded: date_helper
INFO - 2020-10-26 13:51:21 --> Database Driver Class Initialized
INFO - 2020-10-26 13:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:51:22 --> Table Class Initialized
INFO - 2020-10-26 13:51:22 --> Upload Class Initialized
INFO - 2020-10-26 13:51:22 --> Controller Class Initialized
INFO - 2020-10-26 13:51:22 --> Form Validation Class Initialized
INFO - 2020-10-26 13:51:22 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:51:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:51:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:51:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:51:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:51:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:51:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:51:22 --> Final output sent to browser
DEBUG - 2020-10-26 13:51:22 --> Total execution time: 0.1372
INFO - 2020-10-26 13:51:22 --> Config Class Initialized
INFO - 2020-10-26 13:51:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:51:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:51:22 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:22 --> URI Class Initialized
INFO - 2020-10-26 13:51:22 --> Router Class Initialized
INFO - 2020-10-26 13:51:22 --> Output Class Initialized
INFO - 2020-10-26 13:51:22 --> Config Class Initialized
INFO - 2020-10-26 13:51:22 --> Security Class Initialized
INFO - 2020-10-26 13:51:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:51:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:51:22 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:22 --> Input Class Initialized
INFO - 2020-10-26 13:51:22 --> Language Class Initialized
INFO - 2020-10-26 13:51:22 --> URI Class Initialized
ERROR - 2020-10-26 13:51:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:51:22 --> Router Class Initialized
INFO - 2020-10-26 13:51:22 --> Output Class Initialized
INFO - 2020-10-26 13:51:22 --> Security Class Initialized
INFO - 2020-10-26 13:51:22 --> Config Class Initialized
DEBUG - 2020-10-26 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:51:22 --> Hooks Class Initialized
INFO - 2020-10-26 13:51:22 --> Input Class Initialized
DEBUG - 2020-10-26 13:51:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:51:22 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:22 --> Language Class Initialized
INFO - 2020-10-26 13:51:22 --> URI Class Initialized
ERROR - 2020-10-26 13:51:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:51:22 --> Router Class Initialized
INFO - 2020-10-26 13:51:22 --> Output Class Initialized
INFO - 2020-10-26 13:51:22 --> Security Class Initialized
DEBUG - 2020-10-26 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:51:22 --> Input Class Initialized
INFO - 2020-10-26 13:51:22 --> Language Class Initialized
ERROR - 2020-10-26 13:51:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:51:22 --> Config Class Initialized
INFO - 2020-10-26 13:51:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:51:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:51:22 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:22 --> URI Class Initialized
INFO - 2020-10-26 13:51:22 --> Router Class Initialized
INFO - 2020-10-26 13:51:22 --> Output Class Initialized
INFO - 2020-10-26 13:51:22 --> Security Class Initialized
DEBUG - 2020-10-26 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:51:22 --> Input Class Initialized
INFO - 2020-10-26 13:51:22 --> Language Class Initialized
INFO - 2020-10-26 13:51:22 --> Loader Class Initialized
INFO - 2020-10-26 13:51:22 --> Helper loaded: url_helper
INFO - 2020-10-26 13:51:22 --> Helper loaded: form_helper
INFO - 2020-10-26 13:51:22 --> Helper loaded: html_helper
INFO - 2020-10-26 13:51:22 --> Helper loaded: date_helper
INFO - 2020-10-26 13:51:22 --> Database Driver Class Initialized
INFO - 2020-10-26 13:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:51:22 --> Table Class Initialized
INFO - 2020-10-26 13:51:22 --> Upload Class Initialized
INFO - 2020-10-26 13:51:22 --> Controller Class Initialized
INFO - 2020-10-26 13:51:22 --> Form Validation Class Initialized
INFO - 2020-10-26 13:51:22 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:51:22 --> Final output sent to browser
DEBUG - 2020-10-26 13:51:22 --> Total execution time: 0.1380
INFO - 2020-10-26 13:51:22 --> Config Class Initialized
INFO - 2020-10-26 13:51:22 --> Hooks Class Initialized
INFO - 2020-10-26 13:51:22 --> Config Class Initialized
INFO - 2020-10-26 13:51:22 --> Config Class Initialized
INFO - 2020-10-26 13:51:22 --> Hooks Class Initialized
INFO - 2020-10-26 13:51:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:51:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:51:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:51:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:51:22 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:22 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:22 --> URI Class Initialized
INFO - 2020-10-26 13:51:22 --> Utf8 Class Initialized
INFO - 2020-10-26 13:51:22 --> URI Class Initialized
INFO - 2020-10-26 13:51:22 --> Router Class Initialized
INFO - 2020-10-26 13:51:22 --> URI Class Initialized
INFO - 2020-10-26 13:51:22 --> Router Class Initialized
INFO - 2020-10-26 13:51:22 --> Output Class Initialized
INFO - 2020-10-26 13:51:22 --> Router Class Initialized
INFO - 2020-10-26 13:51:22 --> Output Class Initialized
INFO - 2020-10-26 13:51:22 --> Output Class Initialized
INFO - 2020-10-26 13:51:22 --> Security Class Initialized
DEBUG - 2020-10-26 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:51:22 --> Security Class Initialized
INFO - 2020-10-26 13:51:22 --> Security Class Initialized
DEBUG - 2020-10-26 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:51:22 --> Input Class Initialized
DEBUG - 2020-10-26 13:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:51:22 --> Input Class Initialized
INFO - 2020-10-26 13:51:22 --> Language Class Initialized
INFO - 2020-10-26 13:51:22 --> Input Class Initialized
ERROR - 2020-10-26 13:51:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:51:22 --> Language Class Initialized
INFO - 2020-10-26 13:51:22 --> Language Class Initialized
ERROR - 2020-10-26 13:51:22 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:51:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
INFO - 2020-10-26 13:55:12 --> Loader Class Initialized
INFO - 2020-10-26 13:55:12 --> Helper loaded: url_helper
INFO - 2020-10-26 13:55:12 --> Helper loaded: form_helper
INFO - 2020-10-26 13:55:12 --> Helper loaded: html_helper
INFO - 2020-10-26 13:55:12 --> Helper loaded: date_helper
INFO - 2020-10-26 13:55:12 --> Database Driver Class Initialized
INFO - 2020-10-26 13:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:55:12 --> Table Class Initialized
INFO - 2020-10-26 13:55:12 --> Upload Class Initialized
INFO - 2020-10-26 13:55:12 --> Controller Class Initialized
INFO - 2020-10-26 13:55:12 --> Form Validation Class Initialized
INFO - 2020-10-26 13:55:12 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:55:12 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:55:12 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:55:12 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:55:12 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:55:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:55:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:55:12 --> Final output sent to browser
DEBUG - 2020-10-26 13:55:12 --> Total execution time: 0.1606
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
ERROR - 2020-10-26 13:55:12 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
ERROR - 2020-10-26 13:55:12 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
ERROR - 2020-10-26 13:55:12 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
INFO - 2020-10-26 13:55:12 --> Loader Class Initialized
INFO - 2020-10-26 13:55:12 --> Helper loaded: url_helper
INFO - 2020-10-26 13:55:12 --> Helper loaded: form_helper
INFO - 2020-10-26 13:55:12 --> Helper loaded: html_helper
INFO - 2020-10-26 13:55:12 --> Helper loaded: date_helper
INFO - 2020-10-26 13:55:12 --> Database Driver Class Initialized
INFO - 2020-10-26 13:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:55:12 --> Table Class Initialized
INFO - 2020-10-26 13:55:12 --> Upload Class Initialized
INFO - 2020-10-26 13:55:12 --> Controller Class Initialized
INFO - 2020-10-26 13:55:12 --> Form Validation Class Initialized
INFO - 2020-10-26 13:55:12 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:55:12 --> Final output sent to browser
DEBUG - 2020-10-26 13:55:12 --> Total execution time: 0.1365
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:12 --> Config Class Initialized
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:55:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:12 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> URI Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
INFO - 2020-10-26 13:55:12 --> Router Class Initialized
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Output Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
INFO - 2020-10-26 13:55:12 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Input Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
INFO - 2020-10-26 13:55:12 --> Language Class Initialized
ERROR - 2020-10-26 13:55:12 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:55:12 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:55:12 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
INFO - 2020-10-26 13:55:27 --> Loader Class Initialized
INFO - 2020-10-26 13:55:27 --> Helper loaded: url_helper
INFO - 2020-10-26 13:55:27 --> Helper loaded: form_helper
INFO - 2020-10-26 13:55:27 --> Helper loaded: html_helper
INFO - 2020-10-26 13:55:27 --> Helper loaded: date_helper
INFO - 2020-10-26 13:55:27 --> Database Driver Class Initialized
INFO - 2020-10-26 13:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:55:27 --> Table Class Initialized
INFO - 2020-10-26 13:55:27 --> Upload Class Initialized
INFO - 2020-10-26 13:55:27 --> Controller Class Initialized
INFO - 2020-10-26 13:55:27 --> Form Validation Class Initialized
INFO - 2020-10-26 13:55:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:55:27 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:55:27 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:55:27 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:55:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:55:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:55:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:55:27 --> Final output sent to browser
DEBUG - 2020-10-26 13:55:27 --> Total execution time: 0.1644
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
ERROR - 2020-10-26 13:55:27 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
ERROR - 2020-10-26 13:55:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
ERROR - 2020-10-26 13:55:27 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
INFO - 2020-10-26 13:55:27 --> Loader Class Initialized
INFO - 2020-10-26 13:55:27 --> Helper loaded: url_helper
INFO - 2020-10-26 13:55:27 --> Helper loaded: form_helper
INFO - 2020-10-26 13:55:27 --> Helper loaded: html_helper
INFO - 2020-10-26 13:55:27 --> Helper loaded: date_helper
INFO - 2020-10-26 13:55:27 --> Database Driver Class Initialized
INFO - 2020-10-26 13:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:55:27 --> Table Class Initialized
INFO - 2020-10-26 13:55:27 --> Upload Class Initialized
INFO - 2020-10-26 13:55:27 --> Controller Class Initialized
INFO - 2020-10-26 13:55:27 --> Form Validation Class Initialized
INFO - 2020-10-26 13:55:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:55:27 --> Final output sent to browser
DEBUG - 2020-10-26 13:55:27 --> Total execution time: 0.1339
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:27 --> Config Class Initialized
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:27 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
INFO - 2020-10-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> URI Class Initialized
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> Router Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
INFO - 2020-10-26 13:55:27 --> Output Class Initialized
INFO - 2020-10-26 13:55:27 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
INFO - 2020-10-26 13:55:27 --> Input Class Initialized
ERROR - 2020-10-26 13:55:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:27 --> Language Class Initialized
ERROR - 2020-10-26 13:55:27 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:55:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:47 --> Config Class Initialized
INFO - 2020-10-26 13:55:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:47 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:47 --> URI Class Initialized
INFO - 2020-10-26 13:55:47 --> Router Class Initialized
INFO - 2020-10-26 13:55:47 --> Output Class Initialized
INFO - 2020-10-26 13:55:47 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:47 --> Input Class Initialized
INFO - 2020-10-26 13:55:47 --> Language Class Initialized
INFO - 2020-10-26 13:55:47 --> Loader Class Initialized
INFO - 2020-10-26 13:55:47 --> Helper loaded: url_helper
INFO - 2020-10-26 13:55:47 --> Helper loaded: form_helper
INFO - 2020-10-26 13:55:47 --> Helper loaded: html_helper
INFO - 2020-10-26 13:55:47 --> Helper loaded: date_helper
INFO - 2020-10-26 13:55:47 --> Database Driver Class Initialized
INFO - 2020-10-26 13:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:55:47 --> Table Class Initialized
INFO - 2020-10-26 13:55:47 --> Upload Class Initialized
INFO - 2020-10-26 13:55:47 --> Controller Class Initialized
INFO - 2020-10-26 13:55:47 --> Form Validation Class Initialized
INFO - 2020-10-26 13:55:47 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:55:47 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:55:47 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:55:47 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:55:47 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:55:47 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:55:47 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:55:47 --> Final output sent to browser
DEBUG - 2020-10-26 13:55:48 --> Total execution time: 0.1609
INFO - 2020-10-26 13:55:48 --> Config Class Initialized
INFO - 2020-10-26 13:55:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:48 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:48 --> URI Class Initialized
INFO - 2020-10-26 13:55:48 --> Router Class Initialized
INFO - 2020-10-26 13:55:48 --> Config Class Initialized
INFO - 2020-10-26 13:55:48 --> Output Class Initialized
INFO - 2020-10-26 13:55:48 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:48 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:48 --> Input Class Initialized
INFO - 2020-10-26 13:55:48 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:48 --> Language Class Initialized
INFO - 2020-10-26 13:55:48 --> URI Class Initialized
INFO - 2020-10-26 13:55:48 --> Router Class Initialized
ERROR - 2020-10-26 13:55:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:55:48 --> Output Class Initialized
INFO - 2020-10-26 13:55:48 --> Config Class Initialized
INFO - 2020-10-26 13:55:48 --> Security Class Initialized
INFO - 2020-10-26 13:55:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:48 --> Input Class Initialized
DEBUG - 2020-10-26 13:55:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:48 --> Language Class Initialized
INFO - 2020-10-26 13:55:48 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:48 --> URI Class Initialized
ERROR - 2020-10-26 13:55:48 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:48 --> Router Class Initialized
INFO - 2020-10-26 13:55:48 --> Output Class Initialized
INFO - 2020-10-26 13:55:48 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:48 --> Input Class Initialized
INFO - 2020-10-26 13:55:48 --> Config Class Initialized
INFO - 2020-10-26 13:55:48 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:48 --> Language Class Initialized
ERROR - 2020-10-26 13:55:48 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 13:55:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:48 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:48 --> URI Class Initialized
INFO - 2020-10-26 13:55:48 --> Router Class Initialized
INFO - 2020-10-26 13:55:48 --> Output Class Initialized
INFO - 2020-10-26 13:55:48 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:48 --> Input Class Initialized
INFO - 2020-10-26 13:55:48 --> Language Class Initialized
INFO - 2020-10-26 13:55:48 --> Loader Class Initialized
INFO - 2020-10-26 13:55:48 --> Helper loaded: url_helper
INFO - 2020-10-26 13:55:48 --> Helper loaded: form_helper
INFO - 2020-10-26 13:55:48 --> Helper loaded: html_helper
INFO - 2020-10-26 13:55:48 --> Helper loaded: date_helper
INFO - 2020-10-26 13:55:48 --> Database Driver Class Initialized
INFO - 2020-10-26 13:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:55:48 --> Table Class Initialized
INFO - 2020-10-26 13:55:48 --> Upload Class Initialized
INFO - 2020-10-26 13:55:48 --> Controller Class Initialized
INFO - 2020-10-26 13:55:48 --> Form Validation Class Initialized
INFO - 2020-10-26 13:55:48 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:55:48 --> Final output sent to browser
DEBUG - 2020-10-26 13:55:48 --> Total execution time: 0.1481
INFO - 2020-10-26 13:55:48 --> Config Class Initialized
INFO - 2020-10-26 13:55:48 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:48 --> Config Class Initialized
INFO - 2020-10-26 13:55:48 --> Config Class Initialized
INFO - 2020-10-26 13:55:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:55:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:48 --> Hooks Class Initialized
INFO - 2020-10-26 13:55:48 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:55:48 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:55:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:55:48 --> URI Class Initialized
INFO - 2020-10-26 13:55:48 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:48 --> Utf8 Class Initialized
INFO - 2020-10-26 13:55:48 --> Router Class Initialized
INFO - 2020-10-26 13:55:48 --> URI Class Initialized
INFO - 2020-10-26 13:55:48 --> URI Class Initialized
INFO - 2020-10-26 13:55:48 --> Router Class Initialized
INFO - 2020-10-26 13:55:48 --> Output Class Initialized
INFO - 2020-10-26 13:55:48 --> Router Class Initialized
INFO - 2020-10-26 13:55:48 --> Output Class Initialized
INFO - 2020-10-26 13:55:48 --> Security Class Initialized
INFO - 2020-10-26 13:55:48 --> Output Class Initialized
INFO - 2020-10-26 13:55:48 --> Security Class Initialized
DEBUG - 2020-10-26 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:48 --> Security Class Initialized
INFO - 2020-10-26 13:55:48 --> Input Class Initialized
DEBUG - 2020-10-26 13:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:55:48 --> Input Class Initialized
INFO - 2020-10-26 13:55:48 --> Input Class Initialized
INFO - 2020-10-26 13:55:48 --> Language Class Initialized
ERROR - 2020-10-26 13:55:48 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:55:48 --> Language Class Initialized
INFO - 2020-10-26 13:55:48 --> Language Class Initialized
ERROR - 2020-10-26 13:55:48 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:55:48 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:57:31 --> Config Class Initialized
INFO - 2020-10-26 13:57:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:57:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:57:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:57:31 --> URI Class Initialized
INFO - 2020-10-26 13:57:31 --> Router Class Initialized
INFO - 2020-10-26 13:57:31 --> Output Class Initialized
INFO - 2020-10-26 13:57:31 --> Security Class Initialized
DEBUG - 2020-10-26 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:57:31 --> Input Class Initialized
INFO - 2020-10-26 13:57:31 --> Language Class Initialized
INFO - 2020-10-26 13:57:31 --> Loader Class Initialized
INFO - 2020-10-26 13:57:31 --> Helper loaded: url_helper
INFO - 2020-10-26 13:57:31 --> Helper loaded: form_helper
INFO - 2020-10-26 13:57:31 --> Helper loaded: html_helper
INFO - 2020-10-26 13:57:31 --> Helper loaded: date_helper
INFO - 2020-10-26 13:57:31 --> Database Driver Class Initialized
INFO - 2020-10-26 13:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:57:31 --> Table Class Initialized
INFO - 2020-10-26 13:57:31 --> Upload Class Initialized
INFO - 2020-10-26 13:57:31 --> Controller Class Initialized
INFO - 2020-10-26 13:57:31 --> Form Validation Class Initialized
INFO - 2020-10-26 13:57:31 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:57:31 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:57:31 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:57:31 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:57:31 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:57:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:57:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:57:31 --> Final output sent to browser
DEBUG - 2020-10-26 13:57:31 --> Total execution time: 0.1603
INFO - 2020-10-26 13:57:31 --> Config Class Initialized
INFO - 2020-10-26 13:57:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:57:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:57:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:57:31 --> URI Class Initialized
INFO - 2020-10-26 13:57:31 --> Router Class Initialized
INFO - 2020-10-26 13:57:31 --> Config Class Initialized
INFO - 2020-10-26 13:57:31 --> Output Class Initialized
INFO - 2020-10-26 13:57:31 --> Security Class Initialized
INFO - 2020-10-26 13:57:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:57:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:57:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:57:31 --> Input Class Initialized
INFO - 2020-10-26 13:57:31 --> URI Class Initialized
INFO - 2020-10-26 13:57:31 --> Language Class Initialized
INFO - 2020-10-26 13:57:31 --> Router Class Initialized
ERROR - 2020-10-26 13:57:31 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:57:31 --> Output Class Initialized
INFO - 2020-10-26 13:57:31 --> Security Class Initialized
INFO - 2020-10-26 13:57:31 --> Config Class Initialized
DEBUG - 2020-10-26 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:57:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:57:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:57:31 --> Input Class Initialized
INFO - 2020-10-26 13:57:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:57:31 --> Language Class Initialized
INFO - 2020-10-26 13:57:31 --> URI Class Initialized
ERROR - 2020-10-26 13:57:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:57:31 --> Router Class Initialized
INFO - 2020-10-26 13:57:31 --> Output Class Initialized
INFO - 2020-10-26 13:57:31 --> Security Class Initialized
DEBUG - 2020-10-26 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:57:31 --> Input Class Initialized
INFO - 2020-10-26 13:57:31 --> Language Class Initialized
INFO - 2020-10-26 13:57:31 --> Config Class Initialized
ERROR - 2020-10-26 13:57:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:57:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:57:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:57:31 --> Utf8 Class Initialized
INFO - 2020-10-26 13:57:31 --> URI Class Initialized
INFO - 2020-10-26 13:57:31 --> Router Class Initialized
INFO - 2020-10-26 13:57:32 --> Output Class Initialized
INFO - 2020-10-26 13:57:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:57:32 --> Input Class Initialized
INFO - 2020-10-26 13:57:32 --> Language Class Initialized
INFO - 2020-10-26 13:57:32 --> Loader Class Initialized
INFO - 2020-10-26 13:57:32 --> Helper loaded: url_helper
INFO - 2020-10-26 13:57:32 --> Helper loaded: form_helper
INFO - 2020-10-26 13:57:32 --> Helper loaded: html_helper
INFO - 2020-10-26 13:57:32 --> Helper loaded: date_helper
INFO - 2020-10-26 13:57:32 --> Database Driver Class Initialized
INFO - 2020-10-26 13:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:57:32 --> Table Class Initialized
INFO - 2020-10-26 13:57:32 --> Upload Class Initialized
INFO - 2020-10-26 13:57:32 --> Controller Class Initialized
INFO - 2020-10-26 13:57:32 --> Form Validation Class Initialized
INFO - 2020-10-26 13:57:32 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:57:32 --> Final output sent to browser
DEBUG - 2020-10-26 13:57:32 --> Total execution time: 0.1521
INFO - 2020-10-26 13:57:32 --> Config Class Initialized
INFO - 2020-10-26 13:57:32 --> Config Class Initialized
INFO - 2020-10-26 13:57:32 --> Hooks Class Initialized
INFO - 2020-10-26 13:57:32 --> Config Class Initialized
INFO - 2020-10-26 13:57:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:57:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:57:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:57:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:57:32 --> Utf8 Class Initialized
DEBUG - 2020-10-26 13:57:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:57:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:57:32 --> Utf8 Class Initialized
INFO - 2020-10-26 13:57:32 --> URI Class Initialized
INFO - 2020-10-26 13:57:32 --> Router Class Initialized
INFO - 2020-10-26 13:57:32 --> URI Class Initialized
INFO - 2020-10-26 13:57:32 --> URI Class Initialized
INFO - 2020-10-26 13:57:32 --> Output Class Initialized
INFO - 2020-10-26 13:57:32 --> Router Class Initialized
INFO - 2020-10-26 13:57:32 --> Router Class Initialized
INFO - 2020-10-26 13:57:32 --> Security Class Initialized
INFO - 2020-10-26 13:57:32 --> Output Class Initialized
INFO - 2020-10-26 13:57:32 --> Output Class Initialized
INFO - 2020-10-26 13:57:32 --> Security Class Initialized
INFO - 2020-10-26 13:57:32 --> Security Class Initialized
DEBUG - 2020-10-26 13:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 13:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:57:32 --> Input Class Initialized
DEBUG - 2020-10-26 13:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:57:32 --> Language Class Initialized
INFO - 2020-10-26 13:57:32 --> Input Class Initialized
INFO - 2020-10-26 13:57:32 --> Input Class Initialized
INFO - 2020-10-26 13:57:32 --> Language Class Initialized
ERROR - 2020-10-26 13:57:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:57:32 --> Language Class Initialized
ERROR - 2020-10-26 13:57:32 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 13:57:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:59:03 --> Config Class Initialized
INFO - 2020-10-26 13:59:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:03 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:03 --> URI Class Initialized
INFO - 2020-10-26 13:59:03 --> Router Class Initialized
INFO - 2020-10-26 13:59:03 --> Output Class Initialized
INFO - 2020-10-26 13:59:03 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:03 --> Input Class Initialized
INFO - 2020-10-26 13:59:03 --> Language Class Initialized
INFO - 2020-10-26 13:59:03 --> Loader Class Initialized
INFO - 2020-10-26 13:59:03 --> Helper loaded: url_helper
INFO - 2020-10-26 13:59:03 --> Helper loaded: form_helper
INFO - 2020-10-26 13:59:03 --> Helper loaded: html_helper
INFO - 2020-10-26 13:59:03 --> Helper loaded: date_helper
INFO - 2020-10-26 13:59:03 --> Database Driver Class Initialized
INFO - 2020-10-26 13:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:59:03 --> Table Class Initialized
INFO - 2020-10-26 13:59:03 --> Upload Class Initialized
INFO - 2020-10-26 13:59:03 --> Controller Class Initialized
INFO - 2020-10-26 13:59:03 --> Form Validation Class Initialized
INFO - 2020-10-26 13:59:03 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:59:03 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:59:03 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:59:03 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:59:03 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:59:03 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:59:03 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:59:03 --> Final output sent to browser
DEBUG - 2020-10-26 13:59:03 --> Total execution time: 0.1861
INFO - 2020-10-26 13:59:03 --> Config Class Initialized
INFO - 2020-10-26 13:59:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:03 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:03 --> URI Class Initialized
INFO - 2020-10-26 13:59:03 --> Config Class Initialized
INFO - 2020-10-26 13:59:03 --> Router Class Initialized
INFO - 2020-10-26 13:59:03 --> Hooks Class Initialized
INFO - 2020-10-26 13:59:03 --> Output Class Initialized
INFO - 2020-10-26 13:59:03 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 13:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:03 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:03 --> URI Class Initialized
INFO - 2020-10-26 13:59:03 --> Input Class Initialized
INFO - 2020-10-26 13:59:03 --> Router Class Initialized
INFO - 2020-10-26 13:59:03 --> Language Class Initialized
INFO - 2020-10-26 13:59:03 --> Output Class Initialized
ERROR - 2020-10-26 13:59:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:59:03 --> Security Class Initialized
INFO - 2020-10-26 13:59:03 --> Config Class Initialized
DEBUG - 2020-10-26 13:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:03 --> Hooks Class Initialized
INFO - 2020-10-26 13:59:03 --> Input Class Initialized
DEBUG - 2020-10-26 13:59:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:03 --> Language Class Initialized
INFO - 2020-10-26 13:59:03 --> Utf8 Class Initialized
ERROR - 2020-10-26 13:59:03 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:59:03 --> URI Class Initialized
INFO - 2020-10-26 13:59:03 --> Router Class Initialized
INFO - 2020-10-26 13:59:04 --> Output Class Initialized
INFO - 2020-10-26 13:59:04 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:04 --> Input Class Initialized
INFO - 2020-10-26 13:59:04 --> Config Class Initialized
INFO - 2020-10-26 13:59:04 --> Hooks Class Initialized
INFO - 2020-10-26 13:59:04 --> Language Class Initialized
ERROR - 2020-10-26 13:59:04 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 13:59:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:04 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:04 --> URI Class Initialized
INFO - 2020-10-26 13:59:04 --> Router Class Initialized
INFO - 2020-10-26 13:59:04 --> Output Class Initialized
INFO - 2020-10-26 13:59:04 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:04 --> Input Class Initialized
INFO - 2020-10-26 13:59:04 --> Language Class Initialized
INFO - 2020-10-26 13:59:04 --> Loader Class Initialized
INFO - 2020-10-26 13:59:04 --> Helper loaded: url_helper
INFO - 2020-10-26 13:59:04 --> Helper loaded: form_helper
INFO - 2020-10-26 13:59:04 --> Helper loaded: html_helper
INFO - 2020-10-26 13:59:04 --> Helper loaded: date_helper
INFO - 2020-10-26 13:59:04 --> Database Driver Class Initialized
INFO - 2020-10-26 13:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:59:04 --> Table Class Initialized
INFO - 2020-10-26 13:59:04 --> Upload Class Initialized
INFO - 2020-10-26 13:59:04 --> Controller Class Initialized
INFO - 2020-10-26 13:59:04 --> Form Validation Class Initialized
INFO - 2020-10-26 13:59:04 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:59:04 --> Final output sent to browser
DEBUG - 2020-10-26 13:59:04 --> Total execution time: 0.1509
INFO - 2020-10-26 13:59:04 --> Config Class Initialized
INFO - 2020-10-26 13:59:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:04 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:04 --> URI Class Initialized
INFO - 2020-10-26 13:59:04 --> Router Class Initialized
INFO - 2020-10-26 13:59:04 --> Output Class Initialized
INFO - 2020-10-26 13:59:04 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:04 --> Input Class Initialized
INFO - 2020-10-26 13:59:04 --> Language Class Initialized
ERROR - 2020-10-26 13:59:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:59:16 --> Config Class Initialized
INFO - 2020-10-26 13:59:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:16 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:16 --> URI Class Initialized
INFO - 2020-10-26 13:59:16 --> Router Class Initialized
INFO - 2020-10-26 13:59:16 --> Output Class Initialized
INFO - 2020-10-26 13:59:17 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:17 --> Input Class Initialized
INFO - 2020-10-26 13:59:17 --> Language Class Initialized
INFO - 2020-10-26 13:59:17 --> Loader Class Initialized
INFO - 2020-10-26 13:59:17 --> Helper loaded: url_helper
INFO - 2020-10-26 13:59:17 --> Helper loaded: form_helper
INFO - 2020-10-26 13:59:17 --> Helper loaded: html_helper
INFO - 2020-10-26 13:59:17 --> Helper loaded: date_helper
INFO - 2020-10-26 13:59:17 --> Database Driver Class Initialized
INFO - 2020-10-26 13:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:59:17 --> Table Class Initialized
INFO - 2020-10-26 13:59:17 --> Upload Class Initialized
INFO - 2020-10-26 13:59:17 --> Controller Class Initialized
INFO - 2020-10-26 13:59:17 --> Form Validation Class Initialized
INFO - 2020-10-26 13:59:17 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:59:17 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:59:17 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:59:17 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:59:17 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:59:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:59:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:59:17 --> Final output sent to browser
DEBUG - 2020-10-26 13:59:17 --> Total execution time: 0.1601
INFO - 2020-10-26 13:59:17 --> Config Class Initialized
INFO - 2020-10-26 13:59:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:17 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:17 --> URI Class Initialized
INFO - 2020-10-26 13:59:17 --> Router Class Initialized
INFO - 2020-10-26 13:59:17 --> Config Class Initialized
INFO - 2020-10-26 13:59:17 --> Output Class Initialized
INFO - 2020-10-26 13:59:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:17 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:17 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:17 --> URI Class Initialized
INFO - 2020-10-26 13:59:17 --> Input Class Initialized
INFO - 2020-10-26 13:59:17 --> Router Class Initialized
INFO - 2020-10-26 13:59:17 --> Language Class Initialized
INFO - 2020-10-26 13:59:17 --> Output Class Initialized
ERROR - 2020-10-26 13:59:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:59:17 --> Security Class Initialized
INFO - 2020-10-26 13:59:17 --> Config Class Initialized
DEBUG - 2020-10-26 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:17 --> Hooks Class Initialized
INFO - 2020-10-26 13:59:17 --> Input Class Initialized
DEBUG - 2020-10-26 13:59:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:17 --> Language Class Initialized
INFO - 2020-10-26 13:59:17 --> Utf8 Class Initialized
ERROR - 2020-10-26 13:59:17 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:59:17 --> URI Class Initialized
INFO - 2020-10-26 13:59:17 --> Router Class Initialized
INFO - 2020-10-26 13:59:17 --> Output Class Initialized
INFO - 2020-10-26 13:59:17 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:17 --> Input Class Initialized
INFO - 2020-10-26 13:59:17 --> Config Class Initialized
INFO - 2020-10-26 13:59:17 --> Hooks Class Initialized
INFO - 2020-10-26 13:59:17 --> Language Class Initialized
ERROR - 2020-10-26 13:59:17 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 13:59:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:17 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:17 --> URI Class Initialized
INFO - 2020-10-26 13:59:17 --> Router Class Initialized
INFO - 2020-10-26 13:59:17 --> Output Class Initialized
INFO - 2020-10-26 13:59:17 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:17 --> Input Class Initialized
INFO - 2020-10-26 13:59:17 --> Language Class Initialized
INFO - 2020-10-26 13:59:17 --> Loader Class Initialized
INFO - 2020-10-26 13:59:17 --> Helper loaded: url_helper
INFO - 2020-10-26 13:59:17 --> Helper loaded: form_helper
INFO - 2020-10-26 13:59:17 --> Helper loaded: html_helper
INFO - 2020-10-26 13:59:17 --> Helper loaded: date_helper
INFO - 2020-10-26 13:59:17 --> Database Driver Class Initialized
INFO - 2020-10-26 13:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:59:17 --> Table Class Initialized
INFO - 2020-10-26 13:59:17 --> Upload Class Initialized
INFO - 2020-10-26 13:59:17 --> Controller Class Initialized
INFO - 2020-10-26 13:59:17 --> Form Validation Class Initialized
INFO - 2020-10-26 13:59:17 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:59:17 --> Final output sent to browser
DEBUG - 2020-10-26 13:59:17 --> Total execution time: 0.1589
INFO - 2020-10-26 13:59:17 --> Config Class Initialized
INFO - 2020-10-26 13:59:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:17 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:17 --> URI Class Initialized
INFO - 2020-10-26 13:59:17 --> Router Class Initialized
INFO - 2020-10-26 13:59:17 --> Output Class Initialized
INFO - 2020-10-26 13:59:17 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:17 --> Input Class Initialized
INFO - 2020-10-26 13:59:17 --> Language Class Initialized
ERROR - 2020-10-26 13:59:17 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:59:52 --> Config Class Initialized
INFO - 2020-10-26 13:59:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:52 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:52 --> URI Class Initialized
INFO - 2020-10-26 13:59:52 --> Router Class Initialized
INFO - 2020-10-26 13:59:52 --> Output Class Initialized
INFO - 2020-10-26 13:59:52 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:52 --> Input Class Initialized
INFO - 2020-10-26 13:59:52 --> Language Class Initialized
INFO - 2020-10-26 13:59:52 --> Loader Class Initialized
INFO - 2020-10-26 13:59:52 --> Helper loaded: url_helper
INFO - 2020-10-26 13:59:52 --> Helper loaded: form_helper
INFO - 2020-10-26 13:59:52 --> Helper loaded: html_helper
INFO - 2020-10-26 13:59:52 --> Helper loaded: date_helper
INFO - 2020-10-26 13:59:52 --> Database Driver Class Initialized
INFO - 2020-10-26 13:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:59:52 --> Table Class Initialized
INFO - 2020-10-26 13:59:52 --> Upload Class Initialized
INFO - 2020-10-26 13:59:52 --> Controller Class Initialized
INFO - 2020-10-26 13:59:52 --> Form Validation Class Initialized
INFO - 2020-10-26 13:59:52 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:59:52 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 13:59:52 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 13:59:52 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 13:59:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 13:59:52 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 13:59:52 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 13:59:52 --> Final output sent to browser
DEBUG - 2020-10-26 13:59:52 --> Total execution time: 0.1841
INFO - 2020-10-26 13:59:52 --> Config Class Initialized
INFO - 2020-10-26 13:59:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:52 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:52 --> URI Class Initialized
INFO - 2020-10-26 13:59:52 --> Router Class Initialized
INFO - 2020-10-26 13:59:52 --> Config Class Initialized
INFO - 2020-10-26 13:59:52 --> Output Class Initialized
INFO - 2020-10-26 13:59:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:52 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:52 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:52 --> URI Class Initialized
INFO - 2020-10-26 13:59:52 --> Input Class Initialized
INFO - 2020-10-26 13:59:52 --> Language Class Initialized
INFO - 2020-10-26 13:59:52 --> Router Class Initialized
INFO - 2020-10-26 13:59:52 --> Output Class Initialized
ERROR - 2020-10-26 13:59:52 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 13:59:52 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:52 --> Config Class Initialized
INFO - 2020-10-26 13:59:52 --> Input Class Initialized
INFO - 2020-10-26 13:59:52 --> Hooks Class Initialized
INFO - 2020-10-26 13:59:52 --> Language Class Initialized
DEBUG - 2020-10-26 13:59:52 --> UTF-8 Support Enabled
ERROR - 2020-10-26 13:59:52 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:59:52 --> Utf8 Class Initialized
INFO - 2020-10-26 13:59:52 --> URI Class Initialized
INFO - 2020-10-26 13:59:52 --> Router Class Initialized
INFO - 2020-10-26 13:59:52 --> Output Class Initialized
INFO - 2020-10-26 13:59:52 --> Security Class Initialized
INFO - 2020-10-26 13:59:52 --> Config Class Initialized
DEBUG - 2020-10-26 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:52 --> Input Class Initialized
INFO - 2020-10-26 13:59:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 13:59:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 13:59:52 --> Language Class Initialized
INFO - 2020-10-26 13:59:52 --> Utf8 Class Initialized
ERROR - 2020-10-26 13:59:52 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 13:59:52 --> URI Class Initialized
INFO - 2020-10-26 13:59:52 --> Router Class Initialized
INFO - 2020-10-26 13:59:52 --> Output Class Initialized
INFO - 2020-10-26 13:59:52 --> Security Class Initialized
DEBUG - 2020-10-26 13:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 13:59:52 --> Input Class Initialized
INFO - 2020-10-26 13:59:52 --> Language Class Initialized
INFO - 2020-10-26 13:59:52 --> Loader Class Initialized
INFO - 2020-10-26 13:59:52 --> Helper loaded: url_helper
INFO - 2020-10-26 13:59:52 --> Helper loaded: form_helper
INFO - 2020-10-26 13:59:52 --> Helper loaded: html_helper
INFO - 2020-10-26 13:59:52 --> Helper loaded: date_helper
INFO - 2020-10-26 13:59:52 --> Database Driver Class Initialized
INFO - 2020-10-26 13:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 13:59:52 --> Table Class Initialized
INFO - 2020-10-26 13:59:52 --> Upload Class Initialized
INFO - 2020-10-26 13:59:52 --> Controller Class Initialized
INFO - 2020-10-26 13:59:52 --> Form Validation Class Initialized
INFO - 2020-10-26 13:59:52 --> Model "Crud_model" initialized
INFO - 2020-10-26 13:59:52 --> Final output sent to browser
DEBUG - 2020-10-26 13:59:52 --> Total execution time: 0.1641
INFO - 2020-10-26 14:04:17 --> Config Class Initialized
INFO - 2020-10-26 14:04:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:04:17 --> Utf8 Class Initialized
INFO - 2020-10-26 14:04:17 --> URI Class Initialized
INFO - 2020-10-26 14:04:17 --> Router Class Initialized
INFO - 2020-10-26 14:04:17 --> Output Class Initialized
INFO - 2020-10-26 14:04:17 --> Security Class Initialized
DEBUG - 2020-10-26 14:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:04:17 --> Input Class Initialized
INFO - 2020-10-26 14:04:17 --> Language Class Initialized
INFO - 2020-10-26 14:04:17 --> Loader Class Initialized
INFO - 2020-10-26 14:04:17 --> Helper loaded: url_helper
INFO - 2020-10-26 14:04:17 --> Helper loaded: form_helper
INFO - 2020-10-26 14:04:17 --> Helper loaded: html_helper
INFO - 2020-10-26 14:04:17 --> Helper loaded: date_helper
INFO - 2020-10-26 14:04:17 --> Database Driver Class Initialized
INFO - 2020-10-26 14:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:04:17 --> Table Class Initialized
INFO - 2020-10-26 14:04:17 --> Upload Class Initialized
INFO - 2020-10-26 14:04:17 --> Controller Class Initialized
INFO - 2020-10-26 14:04:17 --> Form Validation Class Initialized
INFO - 2020-10-26 14:04:17 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:04:17 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:04:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:04:17 --> Final output sent to browser
DEBUG - 2020-10-26 14:04:17 --> Total execution time: 0.1994
INFO - 2020-10-26 14:04:17 --> Config Class Initialized
INFO - 2020-10-26 14:04:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:04:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:04:17 --> Utf8 Class Initialized
INFO - 2020-10-26 14:04:17 --> URI Class Initialized
INFO - 2020-10-26 14:04:18 --> Router Class Initialized
INFO - 2020-10-26 14:04:18 --> Output Class Initialized
INFO - 2020-10-26 14:04:18 --> Config Class Initialized
INFO - 2020-10-26 14:04:18 --> Security Class Initialized
INFO - 2020-10-26 14:04:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:04:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:04:18 --> Input Class Initialized
INFO - 2020-10-26 14:04:18 --> Utf8 Class Initialized
INFO - 2020-10-26 14:04:18 --> URI Class Initialized
INFO - 2020-10-26 14:04:18 --> Language Class Initialized
INFO - 2020-10-26 14:04:18 --> Router Class Initialized
ERROR - 2020-10-26 14:04:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:04:18 --> Output Class Initialized
INFO - 2020-10-26 14:04:18 --> Config Class Initialized
INFO - 2020-10-26 14:04:18 --> Security Class Initialized
INFO - 2020-10-26 14:04:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:04:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:04:18 --> Input Class Initialized
INFO - 2020-10-26 14:04:18 --> Utf8 Class Initialized
INFO - 2020-10-26 14:04:18 --> Language Class Initialized
ERROR - 2020-10-26 14:04:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:04:18 --> URI Class Initialized
INFO - 2020-10-26 14:04:18 --> Router Class Initialized
INFO - 2020-10-26 14:04:18 --> Output Class Initialized
INFO - 2020-10-26 14:04:18 --> Security Class Initialized
DEBUG - 2020-10-26 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:04:18 --> Config Class Initialized
INFO - 2020-10-26 14:04:18 --> Hooks Class Initialized
INFO - 2020-10-26 14:04:18 --> Input Class Initialized
DEBUG - 2020-10-26 14:04:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:04:18 --> Language Class Initialized
ERROR - 2020-10-26 14:04:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:04:18 --> Utf8 Class Initialized
INFO - 2020-10-26 14:04:18 --> URI Class Initialized
INFO - 2020-10-26 14:04:18 --> Router Class Initialized
INFO - 2020-10-26 14:04:18 --> Output Class Initialized
INFO - 2020-10-26 14:04:18 --> Security Class Initialized
DEBUG - 2020-10-26 14:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:04:18 --> Input Class Initialized
INFO - 2020-10-26 14:04:18 --> Language Class Initialized
INFO - 2020-10-26 14:04:18 --> Loader Class Initialized
INFO - 2020-10-26 14:04:18 --> Helper loaded: url_helper
INFO - 2020-10-26 14:04:18 --> Helper loaded: form_helper
INFO - 2020-10-26 14:04:18 --> Helper loaded: html_helper
INFO - 2020-10-26 14:04:18 --> Helper loaded: date_helper
INFO - 2020-10-26 14:04:18 --> Database Driver Class Initialized
INFO - 2020-10-26 14:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:04:18 --> Table Class Initialized
INFO - 2020-10-26 14:04:18 --> Upload Class Initialized
INFO - 2020-10-26 14:04:18 --> Controller Class Initialized
INFO - 2020-10-26 14:04:18 --> Form Validation Class Initialized
INFO - 2020-10-26 14:04:18 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:04:18 --> Final output sent to browser
DEBUG - 2020-10-26 14:04:18 --> Total execution time: 0.1673
INFO - 2020-10-26 14:06:33 --> Config Class Initialized
INFO - 2020-10-26 14:06:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:06:33 --> Utf8 Class Initialized
INFO - 2020-10-26 14:06:33 --> URI Class Initialized
INFO - 2020-10-26 14:06:33 --> Router Class Initialized
INFO - 2020-10-26 14:06:33 --> Output Class Initialized
INFO - 2020-10-26 14:06:33 --> Security Class Initialized
DEBUG - 2020-10-26 14:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:06:33 --> Input Class Initialized
INFO - 2020-10-26 14:06:33 --> Language Class Initialized
INFO - 2020-10-26 14:06:33 --> Loader Class Initialized
INFO - 2020-10-26 14:06:33 --> Helper loaded: url_helper
INFO - 2020-10-26 14:06:33 --> Helper loaded: form_helper
INFO - 2020-10-26 14:06:33 --> Helper loaded: html_helper
INFO - 2020-10-26 14:06:33 --> Helper loaded: date_helper
INFO - 2020-10-26 14:06:33 --> Database Driver Class Initialized
INFO - 2020-10-26 14:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:06:33 --> Table Class Initialized
INFO - 2020-10-26 14:06:33 --> Upload Class Initialized
INFO - 2020-10-26 14:06:33 --> Controller Class Initialized
INFO - 2020-10-26 14:06:33 --> Form Validation Class Initialized
INFO - 2020-10-26 14:06:33 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:06:33 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:06:33 --> Final output sent to browser
DEBUG - 2020-10-26 14:06:33 --> Total execution time: 0.1626
INFO - 2020-10-26 14:06:33 --> Config Class Initialized
INFO - 2020-10-26 14:06:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:06:33 --> Utf8 Class Initialized
INFO - 2020-10-26 14:06:33 --> URI Class Initialized
INFO - 2020-10-26 14:06:33 --> Router Class Initialized
INFO - 2020-10-26 14:06:33 --> Output Class Initialized
INFO - 2020-10-26 14:06:33 --> Security Class Initialized
DEBUG - 2020-10-26 14:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:06:33 --> Input Class Initialized
INFO - 2020-10-26 14:06:33 --> Language Class Initialized
ERROR - 2020-10-26 14:06:33 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 14:07:17 --> Config Class Initialized
INFO - 2020-10-26 14:07:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:07:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:07:17 --> Utf8 Class Initialized
INFO - 2020-10-26 14:07:17 --> URI Class Initialized
INFO - 2020-10-26 14:07:17 --> Router Class Initialized
INFO - 2020-10-26 14:07:17 --> Output Class Initialized
INFO - 2020-10-26 14:07:17 --> Security Class Initialized
DEBUG - 2020-10-26 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:07:17 --> Input Class Initialized
INFO - 2020-10-26 14:07:17 --> Language Class Initialized
INFO - 2020-10-26 14:07:17 --> Loader Class Initialized
INFO - 2020-10-26 14:07:17 --> Helper loaded: url_helper
INFO - 2020-10-26 14:07:17 --> Helper loaded: form_helper
INFO - 2020-10-26 14:07:17 --> Helper loaded: html_helper
INFO - 2020-10-26 14:07:17 --> Helper loaded: date_helper
INFO - 2020-10-26 14:07:17 --> Database Driver Class Initialized
INFO - 2020-10-26 14:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:07:17 --> Table Class Initialized
INFO - 2020-10-26 14:07:17 --> Upload Class Initialized
INFO - 2020-10-26 14:07:17 --> Controller Class Initialized
INFO - 2020-10-26 14:07:17 --> Form Validation Class Initialized
INFO - 2020-10-26 14:07:17 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:07:17 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:07:17 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:07:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:07:17 --> Final output sent to browser
DEBUG - 2020-10-26 14:07:17 --> Total execution time: 0.1731
INFO - 2020-10-26 14:07:17 --> Config Class Initialized
INFO - 2020-10-26 14:07:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:07:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:07:17 --> Utf8 Class Initialized
INFO - 2020-10-26 14:07:17 --> URI Class Initialized
INFO - 2020-10-26 14:07:17 --> Router Class Initialized
INFO - 2020-10-26 14:07:17 --> Output Class Initialized
INFO - 2020-10-26 14:07:17 --> Security Class Initialized
DEBUG - 2020-10-26 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:07:17 --> Input Class Initialized
INFO - 2020-10-26 14:07:17 --> Language Class Initialized
ERROR - 2020-10-26 14:07:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:07:17 --> Config Class Initialized
INFO - 2020-10-26 14:07:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:07:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:07:17 --> Utf8 Class Initialized
INFO - 2020-10-26 14:07:17 --> URI Class Initialized
INFO - 2020-10-26 14:07:17 --> Router Class Initialized
INFO - 2020-10-26 14:07:17 --> Output Class Initialized
INFO - 2020-10-26 14:07:17 --> Security Class Initialized
DEBUG - 2020-10-26 14:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:07:17 --> Input Class Initialized
INFO - 2020-10-26 14:07:17 --> Language Class Initialized
INFO - 2020-10-26 14:07:17 --> Loader Class Initialized
INFO - 2020-10-26 14:07:17 --> Helper loaded: url_helper
INFO - 2020-10-26 14:07:17 --> Helper loaded: form_helper
INFO - 2020-10-26 14:07:18 --> Helper loaded: html_helper
INFO - 2020-10-26 14:07:18 --> Helper loaded: date_helper
INFO - 2020-10-26 14:07:18 --> Database Driver Class Initialized
INFO - 2020-10-26 14:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:07:18 --> Table Class Initialized
INFO - 2020-10-26 14:07:18 --> Upload Class Initialized
INFO - 2020-10-26 14:07:18 --> Controller Class Initialized
INFO - 2020-10-26 14:07:18 --> Form Validation Class Initialized
INFO - 2020-10-26 14:07:18 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:07:18 --> Final output sent to browser
DEBUG - 2020-10-26 14:07:18 --> Total execution time: 0.1792
INFO - 2020-10-26 14:07:31 --> Config Class Initialized
INFO - 2020-10-26 14:07:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:07:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:07:31 --> Utf8 Class Initialized
INFO - 2020-10-26 14:07:31 --> URI Class Initialized
INFO - 2020-10-26 14:07:31 --> Router Class Initialized
INFO - 2020-10-26 14:07:31 --> Output Class Initialized
INFO - 2020-10-26 14:07:31 --> Security Class Initialized
DEBUG - 2020-10-26 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:07:31 --> Input Class Initialized
INFO - 2020-10-26 14:07:31 --> Language Class Initialized
INFO - 2020-10-26 14:07:31 --> Loader Class Initialized
INFO - 2020-10-26 14:07:31 --> Helper loaded: url_helper
INFO - 2020-10-26 14:07:31 --> Helper loaded: form_helper
INFO - 2020-10-26 14:07:31 --> Helper loaded: html_helper
INFO - 2020-10-26 14:07:31 --> Helper loaded: date_helper
INFO - 2020-10-26 14:07:31 --> Database Driver Class Initialized
INFO - 2020-10-26 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:07:31 --> Table Class Initialized
INFO - 2020-10-26 14:07:31 --> Upload Class Initialized
INFO - 2020-10-26 14:07:31 --> Controller Class Initialized
INFO - 2020-10-26 14:07:31 --> Form Validation Class Initialized
INFO - 2020-10-26 14:07:31 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:07:31 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:07:31 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:07:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:07:31 --> Final output sent to browser
DEBUG - 2020-10-26 14:07:31 --> Total execution time: 0.1674
INFO - 2020-10-26 14:07:31 --> Config Class Initialized
INFO - 2020-10-26 14:07:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:07:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:07:31 --> Utf8 Class Initialized
INFO - 2020-10-26 14:07:31 --> URI Class Initialized
INFO - 2020-10-26 14:07:31 --> Router Class Initialized
INFO - 2020-10-26 14:07:31 --> Output Class Initialized
INFO - 2020-10-26 14:07:31 --> Security Class Initialized
DEBUG - 2020-10-26 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:07:31 --> Input Class Initialized
INFO - 2020-10-26 14:07:31 --> Language Class Initialized
ERROR - 2020-10-26 14:07:31 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:07:31 --> Config Class Initialized
INFO - 2020-10-26 14:07:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:07:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:07:31 --> Utf8 Class Initialized
INFO - 2020-10-26 14:07:31 --> URI Class Initialized
INFO - 2020-10-26 14:07:31 --> Router Class Initialized
INFO - 2020-10-26 14:07:31 --> Output Class Initialized
INFO - 2020-10-26 14:07:31 --> Security Class Initialized
DEBUG - 2020-10-26 14:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:07:31 --> Input Class Initialized
INFO - 2020-10-26 14:07:31 --> Language Class Initialized
INFO - 2020-10-26 14:07:31 --> Loader Class Initialized
INFO - 2020-10-26 14:07:31 --> Helper loaded: url_helper
INFO - 2020-10-26 14:07:31 --> Helper loaded: form_helper
INFO - 2020-10-26 14:07:31 --> Helper loaded: html_helper
INFO - 2020-10-26 14:07:31 --> Helper loaded: date_helper
INFO - 2020-10-26 14:07:31 --> Database Driver Class Initialized
INFO - 2020-10-26 14:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:07:31 --> Table Class Initialized
INFO - 2020-10-26 14:07:31 --> Upload Class Initialized
INFO - 2020-10-26 14:07:31 --> Controller Class Initialized
INFO - 2020-10-26 14:07:31 --> Form Validation Class Initialized
INFO - 2020-10-26 14:07:31 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:07:31 --> Final output sent to browser
DEBUG - 2020-10-26 14:07:31 --> Total execution time: 0.1682
INFO - 2020-10-26 14:09:06 --> Config Class Initialized
INFO - 2020-10-26 14:09:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:09:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:09:06 --> Utf8 Class Initialized
INFO - 2020-10-26 14:09:06 --> URI Class Initialized
INFO - 2020-10-26 14:09:06 --> Router Class Initialized
INFO - 2020-10-26 14:09:06 --> Output Class Initialized
INFO - 2020-10-26 14:09:06 --> Security Class Initialized
DEBUG - 2020-10-26 14:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:09:06 --> Input Class Initialized
INFO - 2020-10-26 14:09:06 --> Language Class Initialized
INFO - 2020-10-26 14:09:06 --> Loader Class Initialized
INFO - 2020-10-26 14:09:06 --> Helper loaded: url_helper
INFO - 2020-10-26 14:09:06 --> Helper loaded: form_helper
INFO - 2020-10-26 14:09:06 --> Helper loaded: html_helper
INFO - 2020-10-26 14:09:06 --> Helper loaded: date_helper
INFO - 2020-10-26 14:09:06 --> Database Driver Class Initialized
INFO - 2020-10-26 14:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:09:06 --> Table Class Initialized
INFO - 2020-10-26 14:09:06 --> Upload Class Initialized
INFO - 2020-10-26 14:09:06 --> Controller Class Initialized
INFO - 2020-10-26 14:09:06 --> Form Validation Class Initialized
INFO - 2020-10-26 14:09:06 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:09:06 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:09:06 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:09:06 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:09:06 --> Final output sent to browser
DEBUG - 2020-10-26 14:09:06 --> Total execution time: 0.1986
INFO - 2020-10-26 14:10:50 --> Config Class Initialized
INFO - 2020-10-26 14:10:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:10:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:10:50 --> Utf8 Class Initialized
INFO - 2020-10-26 14:10:50 --> URI Class Initialized
INFO - 2020-10-26 14:10:50 --> Router Class Initialized
INFO - 2020-10-26 14:10:50 --> Output Class Initialized
INFO - 2020-10-26 14:10:50 --> Security Class Initialized
DEBUG - 2020-10-26 14:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:10:50 --> Input Class Initialized
INFO - 2020-10-26 14:10:50 --> Language Class Initialized
INFO - 2020-10-26 14:10:50 --> Loader Class Initialized
INFO - 2020-10-26 14:10:50 --> Helper loaded: url_helper
INFO - 2020-10-26 14:10:50 --> Helper loaded: form_helper
INFO - 2020-10-26 14:10:50 --> Helper loaded: html_helper
INFO - 2020-10-26 14:10:50 --> Helper loaded: date_helper
INFO - 2020-10-26 14:10:50 --> Database Driver Class Initialized
INFO - 2020-10-26 14:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:10:50 --> Table Class Initialized
INFO - 2020-10-26 14:10:50 --> Upload Class Initialized
INFO - 2020-10-26 14:10:50 --> Controller Class Initialized
INFO - 2020-10-26 14:10:50 --> Form Validation Class Initialized
INFO - 2020-10-26 14:10:50 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:10:50 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:10:50 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:10:50 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:10:50 --> Final output sent to browser
DEBUG - 2020-10-26 14:10:50 --> Total execution time: 0.1680
INFO - 2020-10-26 14:10:50 --> Config Class Initialized
INFO - 2020-10-26 14:10:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:10:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:10:50 --> Utf8 Class Initialized
INFO - 2020-10-26 14:10:50 --> URI Class Initialized
INFO - 2020-10-26 14:10:50 --> Router Class Initialized
INFO - 2020-10-26 14:10:50 --> Output Class Initialized
INFO - 2020-10-26 14:10:50 --> Security Class Initialized
DEBUG - 2020-10-26 14:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:10:50 --> Input Class Initialized
INFO - 2020-10-26 14:10:50 --> Language Class Initialized
ERROR - 2020-10-26 14:10:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:10:50 --> Config Class Initialized
INFO - 2020-10-26 14:10:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:10:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:10:50 --> Utf8 Class Initialized
INFO - 2020-10-26 14:10:50 --> URI Class Initialized
INFO - 2020-10-26 14:10:50 --> Router Class Initialized
INFO - 2020-10-26 14:10:50 --> Output Class Initialized
INFO - 2020-10-26 14:10:50 --> Security Class Initialized
DEBUG - 2020-10-26 14:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:10:50 --> Input Class Initialized
INFO - 2020-10-26 14:10:50 --> Language Class Initialized
INFO - 2020-10-26 14:10:50 --> Loader Class Initialized
INFO - 2020-10-26 14:10:50 --> Helper loaded: url_helper
INFO - 2020-10-26 14:10:50 --> Helper loaded: form_helper
INFO - 2020-10-26 14:10:50 --> Helper loaded: html_helper
INFO - 2020-10-26 14:10:50 --> Helper loaded: date_helper
INFO - 2020-10-26 14:10:50 --> Database Driver Class Initialized
INFO - 2020-10-26 14:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:10:50 --> Table Class Initialized
INFO - 2020-10-26 14:10:50 --> Upload Class Initialized
INFO - 2020-10-26 14:10:51 --> Controller Class Initialized
INFO - 2020-10-26 14:10:51 --> Form Validation Class Initialized
INFO - 2020-10-26 14:10:51 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:10:51 --> Final output sent to browser
DEBUG - 2020-10-26 14:10:51 --> Total execution time: 0.1901
INFO - 2020-10-26 14:11:22 --> Config Class Initialized
INFO - 2020-10-26 14:11:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:11:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:11:22 --> Utf8 Class Initialized
INFO - 2020-10-26 14:11:22 --> URI Class Initialized
INFO - 2020-10-26 14:11:22 --> Router Class Initialized
INFO - 2020-10-26 14:11:22 --> Output Class Initialized
INFO - 2020-10-26 14:11:22 --> Security Class Initialized
DEBUG - 2020-10-26 14:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:11:22 --> Input Class Initialized
INFO - 2020-10-26 14:11:22 --> Language Class Initialized
ERROR - 2020-10-26 14:11:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:25:48 --> Config Class Initialized
INFO - 2020-10-26 14:25:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:25:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:25:48 --> Utf8 Class Initialized
INFO - 2020-10-26 14:25:48 --> URI Class Initialized
INFO - 2020-10-26 14:25:48 --> Router Class Initialized
INFO - 2020-10-26 14:25:48 --> Output Class Initialized
INFO - 2020-10-26 14:25:48 --> Security Class Initialized
DEBUG - 2020-10-26 14:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:25:48 --> Input Class Initialized
INFO - 2020-10-26 14:25:48 --> Language Class Initialized
INFO - 2020-10-26 14:25:48 --> Loader Class Initialized
INFO - 2020-10-26 14:25:48 --> Helper loaded: url_helper
INFO - 2020-10-26 14:25:48 --> Helper loaded: form_helper
INFO - 2020-10-26 14:25:48 --> Helper loaded: html_helper
INFO - 2020-10-26 14:25:48 --> Helper loaded: date_helper
INFO - 2020-10-26 14:25:48 --> Database Driver Class Initialized
INFO - 2020-10-26 14:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:25:48 --> Table Class Initialized
INFO - 2020-10-26 14:25:48 --> Upload Class Initialized
INFO - 2020-10-26 14:25:48 --> Controller Class Initialized
INFO - 2020-10-26 14:25:48 --> Form Validation Class Initialized
INFO - 2020-10-26 14:25:48 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:25:48 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:25:48 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:25:48 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:25:48 --> Final output sent to browser
DEBUG - 2020-10-26 14:25:48 --> Total execution time: 0.1796
INFO - 2020-10-26 14:25:48 --> Config Class Initialized
INFO - 2020-10-26 14:25:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:25:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:25:48 --> Utf8 Class Initialized
INFO - 2020-10-26 14:25:48 --> URI Class Initialized
INFO - 2020-10-26 14:25:48 --> Router Class Initialized
INFO - 2020-10-26 14:25:48 --> Output Class Initialized
INFO - 2020-10-26 14:25:48 --> Security Class Initialized
DEBUG - 2020-10-26 14:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:25:48 --> Input Class Initialized
INFO - 2020-10-26 14:25:48 --> Language Class Initialized
ERROR - 2020-10-26 14:25:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:25:48 --> Config Class Initialized
INFO - 2020-10-26 14:25:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:25:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:25:48 --> Utf8 Class Initialized
INFO - 2020-10-26 14:25:48 --> URI Class Initialized
INFO - 2020-10-26 14:25:48 --> Router Class Initialized
INFO - 2020-10-26 14:25:48 --> Output Class Initialized
INFO - 2020-10-26 14:25:48 --> Security Class Initialized
DEBUG - 2020-10-26 14:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:25:48 --> Input Class Initialized
INFO - 2020-10-26 14:25:48 --> Language Class Initialized
INFO - 2020-10-26 14:25:48 --> Loader Class Initialized
INFO - 2020-10-26 14:25:48 --> Helper loaded: url_helper
INFO - 2020-10-26 14:25:48 --> Helper loaded: form_helper
INFO - 2020-10-26 14:25:48 --> Helper loaded: html_helper
INFO - 2020-10-26 14:25:48 --> Helper loaded: date_helper
INFO - 2020-10-26 14:25:48 --> Database Driver Class Initialized
INFO - 2020-10-26 14:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:25:48 --> Table Class Initialized
INFO - 2020-10-26 14:25:48 --> Upload Class Initialized
INFO - 2020-10-26 14:25:48 --> Controller Class Initialized
INFO - 2020-10-26 14:25:48 --> Form Validation Class Initialized
INFO - 2020-10-26 14:25:48 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:25:48 --> Final output sent to browser
DEBUG - 2020-10-26 14:25:48 --> Total execution time: 0.1712
INFO - 2020-10-26 14:25:51 --> Config Class Initialized
INFO - 2020-10-26 14:25:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:25:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:25:51 --> Utf8 Class Initialized
INFO - 2020-10-26 14:25:51 --> URI Class Initialized
INFO - 2020-10-26 14:25:51 --> Router Class Initialized
INFO - 2020-10-26 14:25:51 --> Output Class Initialized
INFO - 2020-10-26 14:25:51 --> Security Class Initialized
DEBUG - 2020-10-26 14:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:25:51 --> Input Class Initialized
INFO - 2020-10-26 14:25:51 --> Language Class Initialized
INFO - 2020-10-26 14:25:51 --> Loader Class Initialized
INFO - 2020-10-26 14:25:51 --> Helper loaded: url_helper
INFO - 2020-10-26 14:25:51 --> Helper loaded: form_helper
INFO - 2020-10-26 14:25:51 --> Helper loaded: html_helper
INFO - 2020-10-26 14:25:51 --> Helper loaded: date_helper
INFO - 2020-10-26 14:25:51 --> Database Driver Class Initialized
INFO - 2020-10-26 14:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:25:51 --> Table Class Initialized
INFO - 2020-10-26 14:25:51 --> Upload Class Initialized
INFO - 2020-10-26 14:25:51 --> Controller Class Initialized
INFO - 2020-10-26 14:25:51 --> Form Validation Class Initialized
INFO - 2020-10-26 14:25:51 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:25:51 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:25:51 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:25:51 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:25:51 --> Final output sent to browser
DEBUG - 2020-10-26 14:25:51 --> Total execution time: 0.1660
INFO - 2020-10-26 14:25:51 --> Config Class Initialized
INFO - 2020-10-26 14:25:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:25:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:25:51 --> Utf8 Class Initialized
INFO - 2020-10-26 14:25:51 --> URI Class Initialized
INFO - 2020-10-26 14:25:51 --> Router Class Initialized
INFO - 2020-10-26 14:25:51 --> Output Class Initialized
INFO - 2020-10-26 14:25:51 --> Security Class Initialized
DEBUG - 2020-10-26 14:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:25:51 --> Input Class Initialized
INFO - 2020-10-26 14:25:51 --> Language Class Initialized
ERROR - 2020-10-26 14:25:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:25:52 --> Config Class Initialized
INFO - 2020-10-26 14:25:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:25:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:25:52 --> Utf8 Class Initialized
INFO - 2020-10-26 14:25:52 --> URI Class Initialized
INFO - 2020-10-26 14:25:52 --> Router Class Initialized
INFO - 2020-10-26 14:25:52 --> Output Class Initialized
INFO - 2020-10-26 14:25:52 --> Security Class Initialized
DEBUG - 2020-10-26 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:25:52 --> Input Class Initialized
INFO - 2020-10-26 14:25:52 --> Language Class Initialized
INFO - 2020-10-26 14:25:52 --> Loader Class Initialized
INFO - 2020-10-26 14:25:52 --> Helper loaded: url_helper
INFO - 2020-10-26 14:25:52 --> Helper loaded: form_helper
INFO - 2020-10-26 14:25:52 --> Helper loaded: html_helper
INFO - 2020-10-26 14:25:52 --> Helper loaded: date_helper
INFO - 2020-10-26 14:25:52 --> Database Driver Class Initialized
INFO - 2020-10-26 14:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:25:52 --> Table Class Initialized
INFO - 2020-10-26 14:25:52 --> Upload Class Initialized
INFO - 2020-10-26 14:25:52 --> Controller Class Initialized
INFO - 2020-10-26 14:25:52 --> Form Validation Class Initialized
INFO - 2020-10-26 14:25:52 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:25:52 --> Final output sent to browser
DEBUG - 2020-10-26 14:25:52 --> Total execution time: 0.1732
INFO - 2020-10-26 14:25:52 --> Config Class Initialized
INFO - 2020-10-26 14:25:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:25:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:25:52 --> Utf8 Class Initialized
INFO - 2020-10-26 14:25:52 --> URI Class Initialized
INFO - 2020-10-26 14:25:52 --> Router Class Initialized
INFO - 2020-10-26 14:25:52 --> Output Class Initialized
INFO - 2020-10-26 14:25:52 --> Security Class Initialized
DEBUG - 2020-10-26 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:25:52 --> Input Class Initialized
INFO - 2020-10-26 14:25:52 --> Language Class Initialized
ERROR - 2020-10-26 14:25:52 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:26:27 --> Config Class Initialized
INFO - 2020-10-26 14:26:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:26:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:26:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:26:27 --> URI Class Initialized
INFO - 2020-10-26 14:26:27 --> Router Class Initialized
INFO - 2020-10-26 14:26:27 --> Output Class Initialized
INFO - 2020-10-26 14:26:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:26:27 --> Input Class Initialized
INFO - 2020-10-26 14:26:27 --> Language Class Initialized
INFO - 2020-10-26 14:26:27 --> Loader Class Initialized
INFO - 2020-10-26 14:26:27 --> Helper loaded: url_helper
INFO - 2020-10-26 14:26:27 --> Helper loaded: form_helper
INFO - 2020-10-26 14:26:27 --> Helper loaded: html_helper
INFO - 2020-10-26 14:26:27 --> Helper loaded: date_helper
INFO - 2020-10-26 14:26:27 --> Database Driver Class Initialized
INFO - 2020-10-26 14:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:26:27 --> Table Class Initialized
INFO - 2020-10-26 14:26:27 --> Upload Class Initialized
INFO - 2020-10-26 14:26:27 --> Controller Class Initialized
INFO - 2020-10-26 14:26:27 --> Form Validation Class Initialized
INFO - 2020-10-26 14:26:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:26:27 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:26:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:26:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:26:27 --> Final output sent to browser
DEBUG - 2020-10-26 14:26:27 --> Total execution time: 0.1713
INFO - 2020-10-26 14:26:27 --> Config Class Initialized
INFO - 2020-10-26 14:26:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:26:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:26:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:26:27 --> URI Class Initialized
INFO - 2020-10-26 14:26:27 --> Router Class Initialized
INFO - 2020-10-26 14:26:27 --> Output Class Initialized
INFO - 2020-10-26 14:26:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:26:27 --> Input Class Initialized
INFO - 2020-10-26 14:26:27 --> Language Class Initialized
ERROR - 2020-10-26 14:26:27 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:26:27 --> Config Class Initialized
INFO - 2020-10-26 14:26:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:26:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:26:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:26:27 --> URI Class Initialized
INFO - 2020-10-26 14:26:27 --> Router Class Initialized
INFO - 2020-10-26 14:26:27 --> Output Class Initialized
INFO - 2020-10-26 14:26:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:26:27 --> Input Class Initialized
INFO - 2020-10-26 14:26:27 --> Language Class Initialized
INFO - 2020-10-26 14:26:27 --> Loader Class Initialized
INFO - 2020-10-26 14:26:27 --> Helper loaded: url_helper
INFO - 2020-10-26 14:26:27 --> Helper loaded: form_helper
INFO - 2020-10-26 14:26:27 --> Helper loaded: html_helper
INFO - 2020-10-26 14:26:27 --> Helper loaded: date_helper
INFO - 2020-10-26 14:26:27 --> Database Driver Class Initialized
INFO - 2020-10-26 14:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:26:28 --> Table Class Initialized
INFO - 2020-10-26 14:26:28 --> Upload Class Initialized
INFO - 2020-10-26 14:26:28 --> Controller Class Initialized
INFO - 2020-10-26 14:26:28 --> Form Validation Class Initialized
INFO - 2020-10-26 14:26:28 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:26:28 --> Final output sent to browser
DEBUG - 2020-10-26 14:26:28 --> Total execution time: 0.1830
INFO - 2020-10-26 14:27:26 --> Config Class Initialized
INFO - 2020-10-26 14:27:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:27:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:27:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:27:26 --> URI Class Initialized
INFO - 2020-10-26 14:27:26 --> Router Class Initialized
INFO - 2020-10-26 14:27:26 --> Output Class Initialized
INFO - 2020-10-26 14:27:26 --> Security Class Initialized
DEBUG - 2020-10-26 14:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:27:26 --> Input Class Initialized
INFO - 2020-10-26 14:27:27 --> Language Class Initialized
INFO - 2020-10-26 14:27:27 --> Loader Class Initialized
INFO - 2020-10-26 14:27:27 --> Helper loaded: url_helper
INFO - 2020-10-26 14:27:27 --> Helper loaded: form_helper
INFO - 2020-10-26 14:27:27 --> Helper loaded: html_helper
INFO - 2020-10-26 14:27:27 --> Helper loaded: date_helper
INFO - 2020-10-26 14:27:27 --> Database Driver Class Initialized
INFO - 2020-10-26 14:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:27:27 --> Table Class Initialized
INFO - 2020-10-26 14:27:27 --> Upload Class Initialized
INFO - 2020-10-26 14:27:27 --> Controller Class Initialized
INFO - 2020-10-26 14:27:27 --> Form Validation Class Initialized
INFO - 2020-10-26 14:27:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:27:27 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:27:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:27:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:27:27 --> Final output sent to browser
DEBUG - 2020-10-26 14:27:27 --> Total execution time: 0.1767
INFO - 2020-10-26 14:27:27 --> Config Class Initialized
INFO - 2020-10-26 14:27:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:27:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:27:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:27:27 --> URI Class Initialized
INFO - 2020-10-26 14:27:27 --> Router Class Initialized
INFO - 2020-10-26 14:27:27 --> Output Class Initialized
INFO - 2020-10-26 14:27:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:27:27 --> Input Class Initialized
INFO - 2020-10-26 14:27:27 --> Language Class Initialized
ERROR - 2020-10-26 14:27:27 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:27:27 --> Config Class Initialized
INFO - 2020-10-26 14:27:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:27:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:27:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:27:27 --> URI Class Initialized
INFO - 2020-10-26 14:27:27 --> Router Class Initialized
INFO - 2020-10-26 14:27:27 --> Output Class Initialized
INFO - 2020-10-26 14:27:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:27:27 --> Input Class Initialized
INFO - 2020-10-26 14:27:27 --> Language Class Initialized
INFO - 2020-10-26 14:27:27 --> Loader Class Initialized
INFO - 2020-10-26 14:27:27 --> Helper loaded: url_helper
INFO - 2020-10-26 14:27:27 --> Helper loaded: form_helper
INFO - 2020-10-26 14:27:27 --> Helper loaded: html_helper
INFO - 2020-10-26 14:27:27 --> Helper loaded: date_helper
INFO - 2020-10-26 14:27:27 --> Database Driver Class Initialized
INFO - 2020-10-26 14:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:27:27 --> Table Class Initialized
INFO - 2020-10-26 14:27:27 --> Upload Class Initialized
INFO - 2020-10-26 14:27:27 --> Controller Class Initialized
INFO - 2020-10-26 14:27:27 --> Form Validation Class Initialized
INFO - 2020-10-26 14:27:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:27:27 --> Final output sent to browser
DEBUG - 2020-10-26 14:27:27 --> Total execution time: 0.1812
INFO - 2020-10-26 14:27:28 --> Config Class Initialized
INFO - 2020-10-26 14:27:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:27:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:27:28 --> Utf8 Class Initialized
INFO - 2020-10-26 14:27:28 --> URI Class Initialized
INFO - 2020-10-26 14:27:28 --> Router Class Initialized
INFO - 2020-10-26 14:27:28 --> Output Class Initialized
INFO - 2020-10-26 14:27:29 --> Security Class Initialized
DEBUG - 2020-10-26 14:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:27:29 --> Input Class Initialized
INFO - 2020-10-26 14:27:29 --> Language Class Initialized
INFO - 2020-10-26 14:27:29 --> Loader Class Initialized
INFO - 2020-10-26 14:27:29 --> Helper loaded: url_helper
INFO - 2020-10-26 14:27:29 --> Helper loaded: form_helper
INFO - 2020-10-26 14:27:29 --> Helper loaded: html_helper
INFO - 2020-10-26 14:27:29 --> Helper loaded: date_helper
INFO - 2020-10-26 14:27:29 --> Database Driver Class Initialized
INFO - 2020-10-26 14:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:27:29 --> Table Class Initialized
INFO - 2020-10-26 14:27:29 --> Upload Class Initialized
INFO - 2020-10-26 14:27:29 --> Controller Class Initialized
INFO - 2020-10-26 14:27:29 --> Form Validation Class Initialized
INFO - 2020-10-26 14:27:29 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:27:29 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:27:29 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:27:29 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:27:29 --> Final output sent to browser
DEBUG - 2020-10-26 14:27:29 --> Total execution time: 0.2157
INFO - 2020-10-26 14:27:29 --> Config Class Initialized
INFO - 2020-10-26 14:27:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:27:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:27:29 --> Utf8 Class Initialized
INFO - 2020-10-26 14:27:29 --> URI Class Initialized
INFO - 2020-10-26 14:27:29 --> Router Class Initialized
INFO - 2020-10-26 14:27:29 --> Output Class Initialized
INFO - 2020-10-26 14:27:29 --> Security Class Initialized
DEBUG - 2020-10-26 14:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:27:29 --> Input Class Initialized
INFO - 2020-10-26 14:27:29 --> Language Class Initialized
ERROR - 2020-10-26 14:27:29 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 14:28:39 --> Config Class Initialized
INFO - 2020-10-26 14:28:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:28:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:28:39 --> Utf8 Class Initialized
INFO - 2020-10-26 14:28:39 --> URI Class Initialized
INFO - 2020-10-26 14:28:39 --> Router Class Initialized
INFO - 2020-10-26 14:28:39 --> Output Class Initialized
INFO - 2020-10-26 14:28:39 --> Security Class Initialized
DEBUG - 2020-10-26 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:28:39 --> Input Class Initialized
INFO - 2020-10-26 14:28:39 --> Language Class Initialized
INFO - 2020-10-26 14:28:39 --> Loader Class Initialized
INFO - 2020-10-26 14:28:39 --> Helper loaded: url_helper
INFO - 2020-10-26 14:28:39 --> Helper loaded: form_helper
INFO - 2020-10-26 14:28:39 --> Helper loaded: html_helper
INFO - 2020-10-26 14:28:39 --> Helper loaded: date_helper
INFO - 2020-10-26 14:28:39 --> Database Driver Class Initialized
INFO - 2020-10-26 14:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:28:39 --> Table Class Initialized
INFO - 2020-10-26 14:28:39 --> Upload Class Initialized
INFO - 2020-10-26 14:28:39 --> Controller Class Initialized
INFO - 2020-10-26 14:28:39 --> Form Validation Class Initialized
INFO - 2020-10-26 14:28:39 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:28:39 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:28:39 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:28:39 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:28:39 --> Final output sent to browser
DEBUG - 2020-10-26 14:28:39 --> Total execution time: 0.1734
INFO - 2020-10-26 14:28:39 --> Config Class Initialized
INFO - 2020-10-26 14:28:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:28:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:28:39 --> Utf8 Class Initialized
INFO - 2020-10-26 14:28:39 --> URI Class Initialized
INFO - 2020-10-26 14:28:39 --> Router Class Initialized
INFO - 2020-10-26 14:28:39 --> Output Class Initialized
INFO - 2020-10-26 14:28:39 --> Security Class Initialized
DEBUG - 2020-10-26 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:28:39 --> Input Class Initialized
INFO - 2020-10-26 14:28:39 --> Language Class Initialized
ERROR - 2020-10-26 14:28:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:28:39 --> Config Class Initialized
INFO - 2020-10-26 14:28:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:28:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:28:39 --> Utf8 Class Initialized
INFO - 2020-10-26 14:28:39 --> URI Class Initialized
INFO - 2020-10-26 14:28:39 --> Router Class Initialized
INFO - 2020-10-26 14:28:39 --> Output Class Initialized
INFO - 2020-10-26 14:28:39 --> Security Class Initialized
DEBUG - 2020-10-26 14:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:28:39 --> Input Class Initialized
INFO - 2020-10-26 14:28:39 --> Language Class Initialized
INFO - 2020-10-26 14:28:39 --> Loader Class Initialized
INFO - 2020-10-26 14:28:39 --> Helper loaded: url_helper
INFO - 2020-10-26 14:28:39 --> Helper loaded: form_helper
INFO - 2020-10-26 14:28:39 --> Helper loaded: html_helper
INFO - 2020-10-26 14:28:39 --> Helper loaded: date_helper
INFO - 2020-10-26 14:28:39 --> Database Driver Class Initialized
INFO - 2020-10-26 14:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:28:39 --> Table Class Initialized
INFO - 2020-10-26 14:28:39 --> Upload Class Initialized
INFO - 2020-10-26 14:28:39 --> Controller Class Initialized
INFO - 2020-10-26 14:28:39 --> Form Validation Class Initialized
INFO - 2020-10-26 14:28:39 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:28:39 --> Final output sent to browser
DEBUG - 2020-10-26 14:28:39 --> Total execution time: 0.1829
INFO - 2020-10-26 14:30:35 --> Config Class Initialized
INFO - 2020-10-26 14:30:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:35 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:35 --> URI Class Initialized
INFO - 2020-10-26 14:30:35 --> Router Class Initialized
INFO - 2020-10-26 14:30:35 --> Output Class Initialized
INFO - 2020-10-26 14:30:35 --> Security Class Initialized
DEBUG - 2020-10-26 14:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:35 --> Input Class Initialized
INFO - 2020-10-26 14:30:35 --> Language Class Initialized
INFO - 2020-10-26 14:30:35 --> Loader Class Initialized
INFO - 2020-10-26 14:30:35 --> Helper loaded: url_helper
INFO - 2020-10-26 14:30:35 --> Helper loaded: form_helper
INFO - 2020-10-26 14:30:35 --> Helper loaded: html_helper
INFO - 2020-10-26 14:30:35 --> Helper loaded: date_helper
INFO - 2020-10-26 14:30:35 --> Database Driver Class Initialized
INFO - 2020-10-26 14:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:30:35 --> Table Class Initialized
INFO - 2020-10-26 14:30:35 --> Upload Class Initialized
INFO - 2020-10-26 14:30:35 --> Controller Class Initialized
INFO - 2020-10-26 14:30:35 --> Form Validation Class Initialized
INFO - 2020-10-26 14:30:35 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:30:35 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:30:35 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:30:35 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:30:35 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:30:35 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:30:35 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:30:35 --> Final output sent to browser
DEBUG - 2020-10-26 14:30:35 --> Total execution time: 0.2009
INFO - 2020-10-26 14:30:35 --> Config Class Initialized
INFO - 2020-10-26 14:30:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:35 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:35 --> Config Class Initialized
INFO - 2020-10-26 14:30:35 --> Config Class Initialized
INFO - 2020-10-26 14:30:35 --> URI Class Initialized
INFO - 2020-10-26 14:30:35 --> Hooks Class Initialized
INFO - 2020-10-26 14:30:35 --> Hooks Class Initialized
INFO - 2020-10-26 14:30:35 --> Router Class Initialized
INFO - 2020-10-26 14:30:35 --> Output Class Initialized
DEBUG - 2020-10-26 14:30:35 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:30:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:35 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:35 --> Security Class Initialized
INFO - 2020-10-26 14:30:35 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:35 --> URI Class Initialized
INFO - 2020-10-26 14:30:35 --> URI Class Initialized
DEBUG - 2020-10-26 14:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:35 --> Router Class Initialized
INFO - 2020-10-26 14:30:35 --> Input Class Initialized
INFO - 2020-10-26 14:30:35 --> Router Class Initialized
INFO - 2020-10-26 14:30:35 --> Language Class Initialized
INFO - 2020-10-26 14:30:35 --> Output Class Initialized
INFO - 2020-10-26 14:30:35 --> Output Class Initialized
INFO - 2020-10-26 14:30:35 --> Security Class Initialized
INFO - 2020-10-26 14:30:35 --> Security Class Initialized
ERROR - 2020-10-26 14:30:35 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 14:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:35 --> Input Class Initialized
INFO - 2020-10-26 14:30:35 --> Input Class Initialized
INFO - 2020-10-26 14:30:35 --> Language Class Initialized
INFO - 2020-10-26 14:30:35 --> Language Class Initialized
ERROR - 2020-10-26 14:30:35 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-26 14:30:35 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:30:36 --> Config Class Initialized
INFO - 2020-10-26 14:30:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:36 --> URI Class Initialized
INFO - 2020-10-26 14:30:36 --> Router Class Initialized
INFO - 2020-10-26 14:30:36 --> Output Class Initialized
INFO - 2020-10-26 14:30:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:36 --> Input Class Initialized
INFO - 2020-10-26 14:30:36 --> Language Class Initialized
INFO - 2020-10-26 14:30:36 --> Loader Class Initialized
INFO - 2020-10-26 14:30:36 --> Helper loaded: url_helper
INFO - 2020-10-26 14:30:36 --> Helper loaded: form_helper
INFO - 2020-10-26 14:30:36 --> Helper loaded: html_helper
INFO - 2020-10-26 14:30:36 --> Helper loaded: date_helper
INFO - 2020-10-26 14:30:36 --> Database Driver Class Initialized
INFO - 2020-10-26 14:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:30:36 --> Table Class Initialized
INFO - 2020-10-26 14:30:36 --> Upload Class Initialized
INFO - 2020-10-26 14:30:36 --> Controller Class Initialized
INFO - 2020-10-26 14:30:36 --> Form Validation Class Initialized
INFO - 2020-10-26 14:30:36 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:30:36 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:30:36 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:30:36 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:30:36 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:30:36 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:30:36 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:30:36 --> Final output sent to browser
DEBUG - 2020-10-26 14:30:36 --> Total execution time: 0.1989
INFO - 2020-10-26 14:30:36 --> Config Class Initialized
INFO - 2020-10-26 14:30:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:36 --> URI Class Initialized
INFO - 2020-10-26 14:30:36 --> Router Class Initialized
INFO - 2020-10-26 14:30:36 --> Output Class Initialized
INFO - 2020-10-26 14:30:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:36 --> Input Class Initialized
INFO - 2020-10-26 14:30:36 --> Language Class Initialized
INFO - 2020-10-26 14:30:36 --> Loader Class Initialized
INFO - 2020-10-26 14:30:36 --> Helper loaded: url_helper
INFO - 2020-10-26 14:30:36 --> Helper loaded: form_helper
INFO - 2020-10-26 14:30:36 --> Helper loaded: html_helper
INFO - 2020-10-26 14:30:36 --> Helper loaded: date_helper
INFO - 2020-10-26 14:30:36 --> Database Driver Class Initialized
INFO - 2020-10-26 14:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:30:36 --> Table Class Initialized
INFO - 2020-10-26 14:30:36 --> Upload Class Initialized
INFO - 2020-10-26 14:30:36 --> Controller Class Initialized
INFO - 2020-10-26 14:30:36 --> Form Validation Class Initialized
INFO - 2020-10-26 14:30:36 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:30:36 --> Final output sent to browser
DEBUG - 2020-10-26 14:30:36 --> Total execution time: 0.1872
INFO - 2020-10-26 14:30:36 --> Config Class Initialized
INFO - 2020-10-26 14:30:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:36 --> URI Class Initialized
INFO - 2020-10-26 14:30:36 --> Router Class Initialized
INFO - 2020-10-26 14:30:36 --> Output Class Initialized
INFO - 2020-10-26 14:30:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:36 --> Input Class Initialized
INFO - 2020-10-26 14:30:36 --> Language Class Initialized
ERROR - 2020-10-26 14:30:36 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:30:53 --> Config Class Initialized
INFO - 2020-10-26 14:30:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:53 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:53 --> URI Class Initialized
INFO - 2020-10-26 14:30:53 --> Router Class Initialized
INFO - 2020-10-26 14:30:53 --> Output Class Initialized
INFO - 2020-10-26 14:30:53 --> Security Class Initialized
DEBUG - 2020-10-26 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:53 --> Input Class Initialized
INFO - 2020-10-26 14:30:53 --> Language Class Initialized
INFO - 2020-10-26 14:30:53 --> Loader Class Initialized
INFO - 2020-10-26 14:30:53 --> Helper loaded: url_helper
INFO - 2020-10-26 14:30:53 --> Helper loaded: form_helper
INFO - 2020-10-26 14:30:53 --> Helper loaded: html_helper
INFO - 2020-10-26 14:30:53 --> Helper loaded: date_helper
INFO - 2020-10-26 14:30:53 --> Database Driver Class Initialized
INFO - 2020-10-26 14:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:30:53 --> Table Class Initialized
INFO - 2020-10-26 14:30:53 --> Upload Class Initialized
INFO - 2020-10-26 14:30:53 --> Controller Class Initialized
INFO - 2020-10-26 14:30:53 --> Form Validation Class Initialized
INFO - 2020-10-26 14:30:53 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:30:53 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:30:53 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:30:53 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:30:53 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:30:53 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:30:53 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:30:53 --> Final output sent to browser
DEBUG - 2020-10-26 14:30:53 --> Total execution time: 0.2118
INFO - 2020-10-26 14:30:53 --> Config Class Initialized
INFO - 2020-10-26 14:30:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:53 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:53 --> Config Class Initialized
INFO - 2020-10-26 14:30:53 --> URI Class Initialized
INFO - 2020-10-26 14:30:53 --> Hooks Class Initialized
INFO - 2020-10-26 14:30:53 --> Router Class Initialized
DEBUG - 2020-10-26 14:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:53 --> Output Class Initialized
INFO - 2020-10-26 14:30:53 --> Security Class Initialized
INFO - 2020-10-26 14:30:53 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:53 --> URI Class Initialized
DEBUG - 2020-10-26 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:53 --> Input Class Initialized
INFO - 2020-10-26 14:30:53 --> Router Class Initialized
INFO - 2020-10-26 14:30:53 --> Language Class Initialized
INFO - 2020-10-26 14:30:53 --> Output Class Initialized
INFO - 2020-10-26 14:30:53 --> Security Class Initialized
ERROR - 2020-10-26 14:30:53 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:53 --> Input Class Initialized
INFO - 2020-10-26 14:30:53 --> Config Class Initialized
INFO - 2020-10-26 14:30:53 --> Hooks Class Initialized
INFO - 2020-10-26 14:30:53 --> Language Class Initialized
ERROR - 2020-10-26 14:30:53 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 14:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:53 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:53 --> URI Class Initialized
INFO - 2020-10-26 14:30:53 --> Router Class Initialized
INFO - 2020-10-26 14:30:53 --> Output Class Initialized
INFO - 2020-10-26 14:30:53 --> Security Class Initialized
INFO - 2020-10-26 14:30:53 --> Config Class Initialized
INFO - 2020-10-26 14:30:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:53 --> Input Class Initialized
DEBUG - 2020-10-26 14:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:30:53 --> Language Class Initialized
INFO - 2020-10-26 14:30:53 --> Utf8 Class Initialized
INFO - 2020-10-26 14:30:53 --> URI Class Initialized
ERROR - 2020-10-26 14:30:53 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:30:53 --> Router Class Initialized
INFO - 2020-10-26 14:30:53 --> Output Class Initialized
INFO - 2020-10-26 14:30:53 --> Security Class Initialized
DEBUG - 2020-10-26 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:30:53 --> Input Class Initialized
INFO - 2020-10-26 14:30:53 --> Language Class Initialized
INFO - 2020-10-26 14:30:53 --> Loader Class Initialized
INFO - 2020-10-26 14:30:53 --> Helper loaded: url_helper
INFO - 2020-10-26 14:30:53 --> Helper loaded: form_helper
INFO - 2020-10-26 14:30:53 --> Helper loaded: html_helper
INFO - 2020-10-26 14:30:53 --> Helper loaded: date_helper
INFO - 2020-10-26 14:30:53 --> Database Driver Class Initialized
INFO - 2020-10-26 14:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:30:53 --> Table Class Initialized
INFO - 2020-10-26 14:30:53 --> Upload Class Initialized
INFO - 2020-10-26 14:30:53 --> Controller Class Initialized
INFO - 2020-10-26 14:30:53 --> Form Validation Class Initialized
INFO - 2020-10-26 14:30:53 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:30:53 --> Final output sent to browser
DEBUG - 2020-10-26 14:30:53 --> Total execution time: 0.2017
INFO - 2020-10-26 14:31:21 --> Config Class Initialized
INFO - 2020-10-26 14:31:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:31:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:31:21 --> Utf8 Class Initialized
INFO - 2020-10-26 14:31:21 --> URI Class Initialized
INFO - 2020-10-26 14:31:21 --> Router Class Initialized
INFO - 2020-10-26 14:31:21 --> Output Class Initialized
INFO - 2020-10-26 14:31:21 --> Security Class Initialized
DEBUG - 2020-10-26 14:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:31:21 --> Input Class Initialized
INFO - 2020-10-26 14:31:21 --> Language Class Initialized
INFO - 2020-10-26 14:31:21 --> Loader Class Initialized
INFO - 2020-10-26 14:31:21 --> Helper loaded: url_helper
INFO - 2020-10-26 14:31:21 --> Helper loaded: form_helper
INFO - 2020-10-26 14:31:21 --> Helper loaded: html_helper
INFO - 2020-10-26 14:31:21 --> Helper loaded: date_helper
INFO - 2020-10-26 14:31:21 --> Database Driver Class Initialized
INFO - 2020-10-26 14:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:31:21 --> Table Class Initialized
INFO - 2020-10-26 14:31:21 --> Upload Class Initialized
INFO - 2020-10-26 14:31:21 --> Controller Class Initialized
INFO - 2020-10-26 14:31:21 --> Form Validation Class Initialized
INFO - 2020-10-26 14:31:21 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:31:21 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:31:21 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:31:21 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:31:21 --> Final output sent to browser
DEBUG - 2020-10-26 14:31:21 --> Total execution time: 0.1854
INFO - 2020-10-26 14:31:21 --> Config Class Initialized
INFO - 2020-10-26 14:31:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:31:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:31:21 --> Utf8 Class Initialized
INFO - 2020-10-26 14:31:21 --> URI Class Initialized
INFO - 2020-10-26 14:31:21 --> Router Class Initialized
INFO - 2020-10-26 14:31:21 --> Output Class Initialized
INFO - 2020-10-26 14:31:21 --> Security Class Initialized
DEBUG - 2020-10-26 14:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:31:21 --> Input Class Initialized
INFO - 2020-10-26 14:31:21 --> Language Class Initialized
ERROR - 2020-10-26 14:31:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:31:21 --> Config Class Initialized
INFO - 2020-10-26 14:31:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:31:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:31:21 --> Utf8 Class Initialized
INFO - 2020-10-26 14:31:21 --> URI Class Initialized
INFO - 2020-10-26 14:31:21 --> Router Class Initialized
INFO - 2020-10-26 14:31:21 --> Output Class Initialized
INFO - 2020-10-26 14:31:21 --> Security Class Initialized
DEBUG - 2020-10-26 14:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:31:21 --> Input Class Initialized
INFO - 2020-10-26 14:31:21 --> Language Class Initialized
INFO - 2020-10-26 14:31:21 --> Loader Class Initialized
INFO - 2020-10-26 14:31:21 --> Helper loaded: url_helper
INFO - 2020-10-26 14:31:21 --> Helper loaded: form_helper
INFO - 2020-10-26 14:31:21 --> Helper loaded: html_helper
INFO - 2020-10-26 14:31:21 --> Helper loaded: date_helper
INFO - 2020-10-26 14:31:21 --> Database Driver Class Initialized
INFO - 2020-10-26 14:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:31:21 --> Table Class Initialized
INFO - 2020-10-26 14:31:21 --> Upload Class Initialized
INFO - 2020-10-26 14:31:21 --> Controller Class Initialized
INFO - 2020-10-26 14:31:21 --> Form Validation Class Initialized
INFO - 2020-10-26 14:31:21 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:31:21 --> Final output sent to browser
DEBUG - 2020-10-26 14:31:21 --> Total execution time: 0.1919
INFO - 2020-10-26 14:32:11 --> Config Class Initialized
INFO - 2020-10-26 14:32:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:11 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:11 --> URI Class Initialized
INFO - 2020-10-26 14:32:11 --> Router Class Initialized
INFO - 2020-10-26 14:32:11 --> Output Class Initialized
INFO - 2020-10-26 14:32:11 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:11 --> Input Class Initialized
INFO - 2020-10-26 14:32:11 --> Language Class Initialized
INFO - 2020-10-26 14:32:11 --> Loader Class Initialized
INFO - 2020-10-26 14:32:11 --> Helper loaded: url_helper
INFO - 2020-10-26 14:32:11 --> Helper loaded: form_helper
INFO - 2020-10-26 14:32:11 --> Helper loaded: html_helper
INFO - 2020-10-26 14:32:11 --> Helper loaded: date_helper
INFO - 2020-10-26 14:32:11 --> Database Driver Class Initialized
INFO - 2020-10-26 14:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:32:11 --> Table Class Initialized
INFO - 2020-10-26 14:32:11 --> Upload Class Initialized
INFO - 2020-10-26 14:32:11 --> Controller Class Initialized
INFO - 2020-10-26 14:32:11 --> Form Validation Class Initialized
INFO - 2020-10-26 14:32:11 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:32:11 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:32:11 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:32:11 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:32:11 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:32:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:32:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:32:11 --> Final output sent to browser
DEBUG - 2020-10-26 14:32:11 --> Total execution time: 0.2071
INFO - 2020-10-26 14:32:11 --> Config Class Initialized
INFO - 2020-10-26 14:32:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:11 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:11 --> URI Class Initialized
INFO - 2020-10-26 14:32:11 --> Config Class Initialized
INFO - 2020-10-26 14:32:11 --> Hooks Class Initialized
INFO - 2020-10-26 14:32:11 --> Router Class Initialized
INFO - 2020-10-26 14:32:11 --> Output Class Initialized
DEBUG - 2020-10-26 14:32:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:11 --> Security Class Initialized
INFO - 2020-10-26 14:32:11 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:11 --> URI Class Initialized
DEBUG - 2020-10-26 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:11 --> Input Class Initialized
INFO - 2020-10-26 14:32:11 --> Router Class Initialized
INFO - 2020-10-26 14:32:11 --> Language Class Initialized
INFO - 2020-10-26 14:32:11 --> Output Class Initialized
INFO - 2020-10-26 14:32:11 --> Security Class Initialized
ERROR - 2020-10-26 14:32:11 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:11 --> Input Class Initialized
INFO - 2020-10-26 14:32:11 --> Config Class Initialized
INFO - 2020-10-26 14:32:11 --> Language Class Initialized
INFO - 2020-10-26 14:32:11 --> Hooks Class Initialized
ERROR - 2020-10-26 14:32:11 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 14:32:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:11 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:11 --> URI Class Initialized
INFO - 2020-10-26 14:32:11 --> Router Class Initialized
INFO - 2020-10-26 14:32:11 --> Config Class Initialized
INFO - 2020-10-26 14:32:11 --> Output Class Initialized
INFO - 2020-10-26 14:32:11 --> Security Class Initialized
INFO - 2020-10-26 14:32:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:11 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:11 --> Input Class Initialized
INFO - 2020-10-26 14:32:11 --> URI Class Initialized
INFO - 2020-10-26 14:32:11 --> Language Class Initialized
ERROR - 2020-10-26 14:32:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:32:11 --> Router Class Initialized
INFO - 2020-10-26 14:32:11 --> Output Class Initialized
INFO - 2020-10-26 14:32:11 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:11 --> Input Class Initialized
INFO - 2020-10-26 14:32:11 --> Language Class Initialized
INFO - 2020-10-26 14:32:11 --> Loader Class Initialized
INFO - 2020-10-26 14:32:11 --> Helper loaded: url_helper
INFO - 2020-10-26 14:32:11 --> Helper loaded: form_helper
INFO - 2020-10-26 14:32:11 --> Helper loaded: html_helper
INFO - 2020-10-26 14:32:12 --> Helper loaded: date_helper
INFO - 2020-10-26 14:32:12 --> Database Driver Class Initialized
INFO - 2020-10-26 14:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:32:12 --> Table Class Initialized
INFO - 2020-10-26 14:32:12 --> Upload Class Initialized
INFO - 2020-10-26 14:32:12 --> Controller Class Initialized
INFO - 2020-10-26 14:32:12 --> Form Validation Class Initialized
INFO - 2020-10-26 14:32:12 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:32:12 --> Final output sent to browser
DEBUG - 2020-10-26 14:32:12 --> Total execution time: 0.1927
INFO - 2020-10-26 14:32:26 --> Config Class Initialized
INFO - 2020-10-26 14:32:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:26 --> URI Class Initialized
INFO - 2020-10-26 14:32:26 --> Router Class Initialized
INFO - 2020-10-26 14:32:26 --> Output Class Initialized
INFO - 2020-10-26 14:32:26 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:26 --> Input Class Initialized
INFO - 2020-10-26 14:32:26 --> Language Class Initialized
INFO - 2020-10-26 14:32:26 --> Loader Class Initialized
INFO - 2020-10-26 14:32:26 --> Helper loaded: url_helper
INFO - 2020-10-26 14:32:26 --> Helper loaded: form_helper
INFO - 2020-10-26 14:32:26 --> Helper loaded: html_helper
INFO - 2020-10-26 14:32:26 --> Helper loaded: date_helper
INFO - 2020-10-26 14:32:26 --> Database Driver Class Initialized
INFO - 2020-10-26 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:32:26 --> Table Class Initialized
INFO - 2020-10-26 14:32:26 --> Upload Class Initialized
INFO - 2020-10-26 14:32:26 --> Controller Class Initialized
INFO - 2020-10-26 14:32:26 --> Form Validation Class Initialized
INFO - 2020-10-26 14:32:26 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:32:26 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:32:26 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:32:26 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:32:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:32:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:32:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:32:26 --> Final output sent to browser
DEBUG - 2020-10-26 14:32:26 --> Total execution time: 0.2239
INFO - 2020-10-26 14:32:26 --> Config Class Initialized
INFO - 2020-10-26 14:32:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:26 --> URI Class Initialized
INFO - 2020-10-26 14:32:26 --> Config Class Initialized
INFO - 2020-10-26 14:32:26 --> Hooks Class Initialized
INFO - 2020-10-26 14:32:26 --> Router Class Initialized
DEBUG - 2020-10-26 14:32:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:26 --> Output Class Initialized
INFO - 2020-10-26 14:32:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:26 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:26 --> URI Class Initialized
INFO - 2020-10-26 14:32:26 --> Router Class Initialized
INFO - 2020-10-26 14:32:26 --> Input Class Initialized
INFO - 2020-10-26 14:32:26 --> Language Class Initialized
INFO - 2020-10-26 14:32:26 --> Output Class Initialized
INFO - 2020-10-26 14:32:26 --> Security Class Initialized
ERROR - 2020-10-26 14:32:26 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:26 --> Config Class Initialized
INFO - 2020-10-26 14:32:26 --> Input Class Initialized
INFO - 2020-10-26 14:32:26 --> Language Class Initialized
INFO - 2020-10-26 14:32:26 --> Hooks Class Initialized
ERROR - 2020-10-26 14:32:26 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 14:32:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:26 --> URI Class Initialized
INFO - 2020-10-26 14:32:26 --> Router Class Initialized
INFO - 2020-10-26 14:32:26 --> Config Class Initialized
INFO - 2020-10-26 14:32:26 --> Output Class Initialized
INFO - 2020-10-26 14:32:26 --> Hooks Class Initialized
INFO - 2020-10-26 14:32:26 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:26 --> Input Class Initialized
INFO - 2020-10-26 14:32:26 --> URI Class Initialized
INFO - 2020-10-26 14:32:26 --> Language Class Initialized
ERROR - 2020-10-26 14:32:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:32:26 --> Router Class Initialized
INFO - 2020-10-26 14:32:26 --> Output Class Initialized
INFO - 2020-10-26 14:32:26 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:26 --> Input Class Initialized
INFO - 2020-10-26 14:32:26 --> Language Class Initialized
INFO - 2020-10-26 14:32:26 --> Loader Class Initialized
INFO - 2020-10-26 14:32:26 --> Helper loaded: url_helper
INFO - 2020-10-26 14:32:26 --> Helper loaded: form_helper
INFO - 2020-10-26 14:32:26 --> Helper loaded: html_helper
INFO - 2020-10-26 14:32:26 --> Helper loaded: date_helper
INFO - 2020-10-26 14:32:26 --> Database Driver Class Initialized
INFO - 2020-10-26 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:32:26 --> Table Class Initialized
INFO - 2020-10-26 14:32:26 --> Upload Class Initialized
INFO - 2020-10-26 14:32:26 --> Controller Class Initialized
INFO - 2020-10-26 14:32:26 --> Form Validation Class Initialized
INFO - 2020-10-26 14:32:26 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:32:26 --> Final output sent to browser
DEBUG - 2020-10-26 14:32:26 --> Total execution time: 0.1969
INFO - 2020-10-26 14:32:32 --> Config Class Initialized
INFO - 2020-10-26 14:32:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:32 --> URI Class Initialized
INFO - 2020-10-26 14:32:32 --> Router Class Initialized
INFO - 2020-10-26 14:32:32 --> Output Class Initialized
INFO - 2020-10-26 14:32:32 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:32 --> Input Class Initialized
INFO - 2020-10-26 14:32:32 --> Language Class Initialized
INFO - 2020-10-26 14:32:32 --> Loader Class Initialized
INFO - 2020-10-26 14:32:32 --> Helper loaded: url_helper
INFO - 2020-10-26 14:32:32 --> Helper loaded: form_helper
INFO - 2020-10-26 14:32:32 --> Helper loaded: html_helper
INFO - 2020-10-26 14:32:32 --> Helper loaded: date_helper
INFO - 2020-10-26 14:32:32 --> Database Driver Class Initialized
INFO - 2020-10-26 14:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:32:32 --> Table Class Initialized
INFO - 2020-10-26 14:32:32 --> Upload Class Initialized
INFO - 2020-10-26 14:32:32 --> Controller Class Initialized
INFO - 2020-10-26 14:32:32 --> Form Validation Class Initialized
INFO - 2020-10-26 14:32:32 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:32:32 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:32:32 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:32:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:32:32 --> Final output sent to browser
DEBUG - 2020-10-26 14:32:32 --> Total execution time: 0.1957
INFO - 2020-10-26 14:32:32 --> Config Class Initialized
INFO - 2020-10-26 14:32:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:32 --> URI Class Initialized
INFO - 2020-10-26 14:32:32 --> Router Class Initialized
INFO - 2020-10-26 14:32:32 --> Output Class Initialized
INFO - 2020-10-26 14:32:32 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:32 --> Input Class Initialized
INFO - 2020-10-26 14:32:32 --> Language Class Initialized
ERROR - 2020-10-26 14:32:32 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:32:32 --> Config Class Initialized
INFO - 2020-10-26 14:32:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:32:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:32:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:32:32 --> URI Class Initialized
INFO - 2020-10-26 14:32:32 --> Router Class Initialized
INFO - 2020-10-26 14:32:32 --> Output Class Initialized
INFO - 2020-10-26 14:32:32 --> Security Class Initialized
DEBUG - 2020-10-26 14:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:32:32 --> Input Class Initialized
INFO - 2020-10-26 14:32:32 --> Language Class Initialized
INFO - 2020-10-26 14:32:32 --> Loader Class Initialized
INFO - 2020-10-26 14:32:32 --> Helper loaded: url_helper
INFO - 2020-10-26 14:32:32 --> Helper loaded: form_helper
INFO - 2020-10-26 14:32:33 --> Helper loaded: html_helper
INFO - 2020-10-26 14:32:33 --> Helper loaded: date_helper
INFO - 2020-10-26 14:32:33 --> Database Driver Class Initialized
INFO - 2020-10-26 14:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:32:33 --> Table Class Initialized
INFO - 2020-10-26 14:32:33 --> Upload Class Initialized
INFO - 2020-10-26 14:32:33 --> Controller Class Initialized
INFO - 2020-10-26 14:32:33 --> Form Validation Class Initialized
INFO - 2020-10-26 14:32:33 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:32:33 --> Final output sent to browser
DEBUG - 2020-10-26 14:32:33 --> Total execution time: 0.2025
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:04 --> Output Class Initialized
INFO - 2020-10-26 14:33:04 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:04 --> Input Class Initialized
INFO - 2020-10-26 14:33:04 --> Language Class Initialized
INFO - 2020-10-26 14:33:04 --> Loader Class Initialized
INFO - 2020-10-26 14:33:04 --> Helper loaded: url_helper
INFO - 2020-10-26 14:33:04 --> Helper loaded: form_helper
INFO - 2020-10-26 14:33:04 --> Helper loaded: html_helper
INFO - 2020-10-26 14:33:04 --> Helper loaded: date_helper
INFO - 2020-10-26 14:33:04 --> Database Driver Class Initialized
INFO - 2020-10-26 14:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:33:04 --> Table Class Initialized
INFO - 2020-10-26 14:33:04 --> Upload Class Initialized
INFO - 2020-10-26 14:33:04 --> Controller Class Initialized
INFO - 2020-10-26 14:33:04 --> Form Validation Class Initialized
INFO - 2020-10-26 14:33:04 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:33:04 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:33:04 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:33:04 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:33:04 --> Final output sent to browser
DEBUG - 2020-10-26 14:33:04 --> Total execution time: 0.2003
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:04 --> Output Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:04 --> Security Class Initialized
INFO - 2020-10-26 14:33:04 --> Output Class Initialized
INFO - 2020-10-26 14:33:04 --> Output Class Initialized
INFO - 2020-10-26 14:33:04 --> Output Class Initialized
INFO - 2020-10-26 14:33:04 --> Output Class Initialized
INFO - 2020-10-26 14:33:04 --> Output Class Initialized
INFO - 2020-10-26 14:33:04 --> Security Class Initialized
INFO - 2020-10-26 14:33:04 --> Security Class Initialized
INFO - 2020-10-26 14:33:04 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:04 --> Security Class Initialized
INFO - 2020-10-26 14:33:04 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:04 --> Input Class Initialized
DEBUG - 2020-10-26 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:04 --> Input Class Initialized
INFO - 2020-10-26 14:33:04 --> Input Class Initialized
INFO - 2020-10-26 14:33:04 --> Input Class Initialized
INFO - 2020-10-26 14:33:04 --> Input Class Initialized
INFO - 2020-10-26 14:33:04 --> Input Class Initialized
INFO - 2020-10-26 14:33:04 --> Language Class Initialized
INFO - 2020-10-26 14:33:04 --> Language Class Initialized
INFO - 2020-10-26 14:33:04 --> Language Class Initialized
INFO - 2020-10-26 14:33:04 --> Language Class Initialized
INFO - 2020-10-26 14:33:04 --> Language Class Initialized
ERROR - 2020-10-26 14:33:04 --> 404 Page Not Found: Plugins/fontawesome-free
INFO - 2020-10-26 14:33:04 --> Language Class Initialized
ERROR - 2020-10-26 14:33:04 --> 404 Page Not Found: Plugins/bootstrap
ERROR - 2020-10-26 14:33:04 --> 404 Page Not Found: Dist/css
ERROR - 2020-10-26 14:33:04 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-26 14:33:04 --> 404 Page Not Found: Plugins/jquery
INFO - 2020-10-26 14:33:04 --> Config Class Initialized
ERROR - 2020-10-26 14:33:04 --> 404 Page Not Found: Plugins/icheck-bootstrap
INFO - 2020-10-26 14:33:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:04 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:04 --> URI Class Initialized
INFO - 2020-10-26 14:33:04 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Config Class Initialized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
DEBUG - 2020-10-26 14:33:05 --> UTF-8 Support Enabled
ERROR - 2020-10-26 14:33:05 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:33:05 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:05 --> URI Class Initialized
INFO - 2020-10-26 14:33:05 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
INFO - 2020-10-26 14:33:05 --> Loader Class Initialized
INFO - 2020-10-26 14:33:05 --> Helper loaded: url_helper
INFO - 2020-10-26 14:33:05 --> Helper loaded: form_helper
INFO - 2020-10-26 14:33:05 --> Helper loaded: html_helper
INFO - 2020-10-26 14:33:05 --> Helper loaded: date_helper
INFO - 2020-10-26 14:33:05 --> Database Driver Class Initialized
INFO - 2020-10-26 14:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:33:05 --> Table Class Initialized
INFO - 2020-10-26 14:33:05 --> Upload Class Initialized
INFO - 2020-10-26 14:33:05 --> Controller Class Initialized
INFO - 2020-10-26 14:33:05 --> Form Validation Class Initialized
INFO - 2020-10-26 14:33:05 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:33:05 --> Final output sent to browser
DEBUG - 2020-10-26 14:33:05 --> Total execution time: 0.2031
INFO - 2020-10-26 14:33:05 --> Config Class Initialized
INFO - 2020-10-26 14:33:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:05 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:05 --> URI Class Initialized
INFO - 2020-10-26 14:33:05 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
ERROR - 2020-10-26 14:33:05 --> 404 Page Not Found: Plugins/fontawesome-free
INFO - 2020-10-26 14:33:05 --> Config Class Initialized
INFO - 2020-10-26 14:33:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:05 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:05 --> URI Class Initialized
INFO - 2020-10-26 14:33:05 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
ERROR - 2020-10-26 14:33:05 --> 404 Page Not Found: Plugins/icheck-bootstrap
INFO - 2020-10-26 14:33:05 --> Config Class Initialized
INFO - 2020-10-26 14:33:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:05 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:05 --> URI Class Initialized
INFO - 2020-10-26 14:33:05 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
ERROR - 2020-10-26 14:33:05 --> 404 Page Not Found: Dist/css
INFO - 2020-10-26 14:33:05 --> Config Class Initialized
INFO - 2020-10-26 14:33:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:05 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:05 --> URI Class Initialized
INFO - 2020-10-26 14:33:05 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
ERROR - 2020-10-26 14:33:05 --> 404 Page Not Found: Plugins/jquery
INFO - 2020-10-26 14:33:05 --> Config Class Initialized
INFO - 2020-10-26 14:33:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:05 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:05 --> URI Class Initialized
INFO - 2020-10-26 14:33:05 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
ERROR - 2020-10-26 14:33:05 --> 404 Page Not Found: Plugins/bootstrap
INFO - 2020-10-26 14:33:05 --> Config Class Initialized
INFO - 2020-10-26 14:33:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:05 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:05 --> URI Class Initialized
INFO - 2020-10-26 14:33:05 --> Router Class Initialized
INFO - 2020-10-26 14:33:05 --> Output Class Initialized
INFO - 2020-10-26 14:33:05 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:05 --> Input Class Initialized
INFO - 2020-10-26 14:33:05 --> Language Class Initialized
ERROR - 2020-10-26 14:33:05 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
INFO - 2020-10-26 14:33:08 --> Loader Class Initialized
INFO - 2020-10-26 14:33:08 --> Helper loaded: url_helper
INFO - 2020-10-26 14:33:08 --> Helper loaded: form_helper
INFO - 2020-10-26 14:33:08 --> Helper loaded: html_helper
INFO - 2020-10-26 14:33:08 --> Helper loaded: date_helper
INFO - 2020-10-26 14:33:08 --> Database Driver Class Initialized
INFO - 2020-10-26 14:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:33:08 --> Table Class Initialized
INFO - 2020-10-26 14:33:08 --> Upload Class Initialized
INFO - 2020-10-26 14:33:08 --> Controller Class Initialized
INFO - 2020-10-26 14:33:08 --> Form Validation Class Initialized
INFO - 2020-10-26 14:33:08 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:33:08 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:33:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:33:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:33:08 --> Final output sent to browser
DEBUG - 2020-10-26 14:33:08 --> Total execution time: 0.1986
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
ERROR - 2020-10-26 14:33:08 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
ERROR - 2020-10-26 14:33:08 --> 404 Page Not Found: Plugins/icheck-bootstrap
ERROR - 2020-10-26 14:33:08 --> 404 Page Not Found: Plugins/bootstrap
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
ERROR - 2020-10-26 14:33:08 --> 404 Page Not Found: Plugins/jquery
ERROR - 2020-10-26 14:33:08 --> 404 Page Not Found: Plugins/fontawesome-free
ERROR - 2020-10-26 14:33:08 --> 404 Page Not Found: Dist/css
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
INFO - 2020-10-26 14:33:08 --> Config Class Initialized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:08 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
DEBUG - 2020-10-26 14:33:08 --> UTF-8 Support Enabled
ERROR - 2020-10-26 14:33:08 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:33:08 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:08 --> URI Class Initialized
INFO - 2020-10-26 14:33:08 --> Router Class Initialized
INFO - 2020-10-26 14:33:08 --> Output Class Initialized
INFO - 2020-10-26 14:33:08 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:08 --> Input Class Initialized
INFO - 2020-10-26 14:33:08 --> Language Class Initialized
INFO - 2020-10-26 14:33:08 --> Loader Class Initialized
INFO - 2020-10-26 14:33:08 --> Helper loaded: url_helper
INFO - 2020-10-26 14:33:08 --> Helper loaded: form_helper
INFO - 2020-10-26 14:33:08 --> Helper loaded: html_helper
INFO - 2020-10-26 14:33:08 --> Helper loaded: date_helper
INFO - 2020-10-26 14:33:08 --> Database Driver Class Initialized
INFO - 2020-10-26 14:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:33:09 --> Table Class Initialized
INFO - 2020-10-26 14:33:09 --> Upload Class Initialized
INFO - 2020-10-26 14:33:09 --> Controller Class Initialized
INFO - 2020-10-26 14:33:09 --> Form Validation Class Initialized
INFO - 2020-10-26 14:33:09 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:33:09 --> Final output sent to browser
DEBUG - 2020-10-26 14:33:09 --> Total execution time: 0.2117
INFO - 2020-10-26 14:33:09 --> Config Class Initialized
INFO - 2020-10-26 14:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:09 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:09 --> URI Class Initialized
INFO - 2020-10-26 14:33:09 --> Router Class Initialized
INFO - 2020-10-26 14:33:09 --> Output Class Initialized
INFO - 2020-10-26 14:33:09 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:09 --> Input Class Initialized
INFO - 2020-10-26 14:33:09 --> Language Class Initialized
ERROR - 2020-10-26 14:33:09 --> 404 Page Not Found: Plugins/icheck-bootstrap
INFO - 2020-10-26 14:33:09 --> Config Class Initialized
INFO - 2020-10-26 14:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:09 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:09 --> URI Class Initialized
INFO - 2020-10-26 14:33:09 --> Router Class Initialized
INFO - 2020-10-26 14:33:09 --> Output Class Initialized
INFO - 2020-10-26 14:33:09 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:09 --> Input Class Initialized
INFO - 2020-10-26 14:33:09 --> Language Class Initialized
ERROR - 2020-10-26 14:33:09 --> 404 Page Not Found: Dist/css
INFO - 2020-10-26 14:33:09 --> Config Class Initialized
INFO - 2020-10-26 14:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:09 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:09 --> URI Class Initialized
INFO - 2020-10-26 14:33:09 --> Router Class Initialized
INFO - 2020-10-26 14:33:09 --> Output Class Initialized
INFO - 2020-10-26 14:33:09 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:09 --> Input Class Initialized
INFO - 2020-10-26 14:33:09 --> Language Class Initialized
ERROR - 2020-10-26 14:33:09 --> 404 Page Not Found: Plugins/jquery
INFO - 2020-10-26 14:33:09 --> Config Class Initialized
INFO - 2020-10-26 14:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:09 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:09 --> URI Class Initialized
INFO - 2020-10-26 14:33:09 --> Router Class Initialized
INFO - 2020-10-26 14:33:09 --> Output Class Initialized
INFO - 2020-10-26 14:33:09 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:09 --> Input Class Initialized
INFO - 2020-10-26 14:33:09 --> Language Class Initialized
ERROR - 2020-10-26 14:33:09 --> 404 Page Not Found: Plugins/bootstrap
INFO - 2020-10-26 14:33:09 --> Config Class Initialized
INFO - 2020-10-26 14:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:09 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:09 --> URI Class Initialized
INFO - 2020-10-26 14:33:09 --> Router Class Initialized
INFO - 2020-10-26 14:33:09 --> Output Class Initialized
INFO - 2020-10-26 14:33:09 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:09 --> Input Class Initialized
INFO - 2020-10-26 14:33:09 --> Language Class Initialized
ERROR - 2020-10-26 14:33:09 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:33:09 --> Config Class Initialized
INFO - 2020-10-26 14:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:09 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:09 --> URI Class Initialized
INFO - 2020-10-26 14:33:09 --> Router Class Initialized
INFO - 2020-10-26 14:33:09 --> Output Class Initialized
INFO - 2020-10-26 14:33:09 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:09 --> Input Class Initialized
INFO - 2020-10-26 14:33:09 --> Language Class Initialized
ERROR - 2020-10-26 14:33:09 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:33:31 --> Config Class Initialized
INFO - 2020-10-26 14:33:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:31 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:31 --> URI Class Initialized
INFO - 2020-10-26 14:33:31 --> Router Class Initialized
INFO - 2020-10-26 14:33:31 --> Output Class Initialized
INFO - 2020-10-26 14:33:31 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:31 --> Input Class Initialized
INFO - 2020-10-26 14:33:31 --> Language Class Initialized
INFO - 2020-10-26 14:33:31 --> Loader Class Initialized
INFO - 2020-10-26 14:33:31 --> Helper loaded: url_helper
INFO - 2020-10-26 14:33:31 --> Helper loaded: form_helper
INFO - 2020-10-26 14:33:31 --> Helper loaded: html_helper
INFO - 2020-10-26 14:33:31 --> Helper loaded: date_helper
INFO - 2020-10-26 14:33:31 --> Database Driver Class Initialized
INFO - 2020-10-26 14:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:33:31 --> Table Class Initialized
INFO - 2020-10-26 14:33:31 --> Upload Class Initialized
INFO - 2020-10-26 14:33:31 --> Controller Class Initialized
INFO - 2020-10-26 14:33:31 --> Form Validation Class Initialized
INFO - 2020-10-26 14:33:31 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:33:31 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:33:31 --> Final output sent to browser
DEBUG - 2020-10-26 14:33:31 --> Total execution time: 0.2681
INFO - 2020-10-26 14:33:31 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:32 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:32 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Plugins/icheck-bootstrap
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Dist/css
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Dist/js
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Plugins/jquery
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Plugins/fontawesome-free
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Plugins/bootstrap
INFO - 2020-10-26 14:33:32 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:33:32 --> Config Class Initialized
INFO - 2020-10-26 14:33:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:32 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:32 --> URI Class Initialized
INFO - 2020-10-26 14:33:32 --> Router Class Initialized
INFO - 2020-10-26 14:33:32 --> Output Class Initialized
INFO - 2020-10-26 14:33:32 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:32 --> Input Class Initialized
INFO - 2020-10-26 14:33:32 --> Language Class Initialized
ERROR - 2020-10-26 14:33:32 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 14:33:33 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
INFO - 2020-10-26 14:33:34 --> Loader Class Initialized
INFO - 2020-10-26 14:33:34 --> Helper loaded: url_helper
INFO - 2020-10-26 14:33:34 --> Helper loaded: form_helper
INFO - 2020-10-26 14:33:34 --> Helper loaded: html_helper
INFO - 2020-10-26 14:33:34 --> Helper loaded: date_helper
INFO - 2020-10-26 14:33:34 --> Database Driver Class Initialized
INFO - 2020-10-26 14:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:33:34 --> Table Class Initialized
INFO - 2020-10-26 14:33:34 --> Upload Class Initialized
INFO - 2020-10-26 14:33:34 --> Controller Class Initialized
INFO - 2020-10-26 14:33:34 --> Form Validation Class Initialized
INFO - 2020-10-26 14:33:34 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:33:34 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:33:34 --> Final output sent to browser
DEBUG - 2020-10-26 14:33:34 --> Total execution time: 0.1919
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Dist/css
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Dist/js
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Plugins/bootstrap
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Plugins/icheck-bootstrap
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Plugins/jquery
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Plugins/fontawesome-free
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Plugins/bootstrap
INFO - 2020-10-26 14:33:34 --> Config Class Initialized
INFO - 2020-10-26 14:33:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:34 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:34 --> URI Class Initialized
INFO - 2020-10-26 14:33:34 --> Router Class Initialized
INFO - 2020-10-26 14:33:34 --> Output Class Initialized
INFO - 2020-10-26 14:33:34 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:34 --> Input Class Initialized
INFO - 2020-10-26 14:33:34 --> Language Class Initialized
ERROR - 2020-10-26 14:33:34 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:33:35 --> Config Class Initialized
INFO - 2020-10-26 14:33:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:35 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:35 --> URI Class Initialized
INFO - 2020-10-26 14:33:35 --> Router Class Initialized
INFO - 2020-10-26 14:33:35 --> Output Class Initialized
INFO - 2020-10-26 14:33:35 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
INFO - 2020-10-26 14:33:36 --> Loader Class Initialized
INFO - 2020-10-26 14:33:36 --> Helper loaded: url_helper
INFO - 2020-10-26 14:33:36 --> Helper loaded: form_helper
INFO - 2020-10-26 14:33:36 --> Helper loaded: html_helper
INFO - 2020-10-26 14:33:36 --> Helper loaded: date_helper
INFO - 2020-10-26 14:33:36 --> Database Driver Class Initialized
INFO - 2020-10-26 14:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:33:36 --> Table Class Initialized
INFO - 2020-10-26 14:33:36 --> Upload Class Initialized
INFO - 2020-10-26 14:33:36 --> Controller Class Initialized
INFO - 2020-10-26 14:33:36 --> Form Validation Class Initialized
INFO - 2020-10-26 14:33:36 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:33:36 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:33:36 --> Final output sent to browser
DEBUG - 2020-10-26 14:33:36 --> Total execution time: 0.1890
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Plugins/fontawesome-free
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Dist/css
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Plugins/bootstrap
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Dist/js
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Plugins/icheck-bootstrap
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Plugins/jquery
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Plugins/bootstrap
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:33:36 --> Config Class Initialized
INFO - 2020-10-26 14:33:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:33:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:33:36 --> Utf8 Class Initialized
INFO - 2020-10-26 14:33:36 --> URI Class Initialized
INFO - 2020-10-26 14:33:36 --> Router Class Initialized
INFO - 2020-10-26 14:33:36 --> Output Class Initialized
INFO - 2020-10-26 14:33:36 --> Security Class Initialized
DEBUG - 2020-10-26 14:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:33:36 --> Input Class Initialized
INFO - 2020-10-26 14:33:36 --> Language Class Initialized
ERROR - 2020-10-26 14:33:36 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 14:35:17 --> Config Class Initialized
INFO - 2020-10-26 14:35:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:35:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:35:17 --> Utf8 Class Initialized
INFO - 2020-10-26 14:35:17 --> URI Class Initialized
INFO - 2020-10-26 14:35:17 --> Router Class Initialized
INFO - 2020-10-26 14:35:17 --> Output Class Initialized
INFO - 2020-10-26 14:35:17 --> Security Class Initialized
DEBUG - 2020-10-26 14:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:35:17 --> Input Class Initialized
INFO - 2020-10-26 14:35:17 --> Language Class Initialized
INFO - 2020-10-26 14:35:17 --> Loader Class Initialized
INFO - 2020-10-26 14:35:17 --> Helper loaded: url_helper
INFO - 2020-10-26 14:35:17 --> Helper loaded: form_helper
INFO - 2020-10-26 14:35:17 --> Helper loaded: html_helper
INFO - 2020-10-26 14:35:18 --> Helper loaded: date_helper
INFO - 2020-10-26 14:35:18 --> Database Driver Class Initialized
INFO - 2020-10-26 14:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:35:18 --> Table Class Initialized
INFO - 2020-10-26 14:35:18 --> Upload Class Initialized
INFO - 2020-10-26 14:35:18 --> Controller Class Initialized
INFO - 2020-10-26 14:35:18 --> Form Validation Class Initialized
INFO - 2020-10-26 14:35:18 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:35:18 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:35:18 --> Final output sent to browser
DEBUG - 2020-10-26 14:35:18 --> Total execution time: 0.2188
INFO - 2020-10-26 14:35:18 --> Config Class Initialized
INFO - 2020-10-26 14:35:18 --> Config Class Initialized
INFO - 2020-10-26 14:35:18 --> Hooks Class Initialized
INFO - 2020-10-26 14:35:18 --> Config Class Initialized
DEBUG - 2020-10-26 14:35:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:35:18 --> Hooks Class Initialized
INFO - 2020-10-26 14:35:18 --> Hooks Class Initialized
INFO - 2020-10-26 14:35:18 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:35:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:35:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:35:18 --> Utf8 Class Initialized
INFO - 2020-10-26 14:35:18 --> Utf8 Class Initialized
INFO - 2020-10-26 14:35:18 --> URI Class Initialized
INFO - 2020-10-26 14:35:18 --> URI Class Initialized
INFO - 2020-10-26 14:35:18 --> URI Class Initialized
INFO - 2020-10-26 14:35:18 --> Router Class Initialized
INFO - 2020-10-26 14:35:18 --> Router Class Initialized
INFO - 2020-10-26 14:35:18 --> Output Class Initialized
INFO - 2020-10-26 14:35:18 --> Router Class Initialized
INFO - 2020-10-26 14:35:18 --> Security Class Initialized
INFO - 2020-10-26 14:35:18 --> Output Class Initialized
INFO - 2020-10-26 14:35:18 --> Output Class Initialized
DEBUG - 2020-10-26 14:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:35:18 --> Security Class Initialized
INFO - 2020-10-26 14:35:18 --> Security Class Initialized
DEBUG - 2020-10-26 14:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:35:18 --> Input Class Initialized
DEBUG - 2020-10-26 14:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:35:18 --> Input Class Initialized
INFO - 2020-10-26 14:35:18 --> Language Class Initialized
INFO - 2020-10-26 14:35:18 --> Input Class Initialized
INFO - 2020-10-26 14:35:18 --> Language Class Initialized
INFO - 2020-10-26 14:35:18 --> Language Class Initialized
ERROR - 2020-10-26 14:35:18 --> 404 Page Not Found: Plugins/jquery
ERROR - 2020-10-26 14:35:18 --> 404 Page Not Found: Plugins/bootstrap
ERROR - 2020-10-26 14:35:18 --> 404 Page Not Found: Dist/js
INFO - 2020-10-26 14:45:52 --> Config Class Initialized
INFO - 2020-10-26 14:45:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:45:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:45:52 --> Utf8 Class Initialized
INFO - 2020-10-26 14:45:52 --> URI Class Initialized
INFO - 2020-10-26 14:45:52 --> Router Class Initialized
INFO - 2020-10-26 14:45:52 --> Output Class Initialized
INFO - 2020-10-26 14:45:52 --> Security Class Initialized
DEBUG - 2020-10-26 14:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:45:52 --> Input Class Initialized
INFO - 2020-10-26 14:45:52 --> Language Class Initialized
INFO - 2020-10-26 14:45:52 --> Loader Class Initialized
INFO - 2020-10-26 14:45:53 --> Helper loaded: url_helper
INFO - 2020-10-26 14:45:53 --> Helper loaded: form_helper
INFO - 2020-10-26 14:45:53 --> Helper loaded: html_helper
INFO - 2020-10-26 14:45:53 --> Helper loaded: date_helper
INFO - 2020-10-26 14:45:53 --> Database Driver Class Initialized
INFO - 2020-10-26 14:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:45:53 --> Table Class Initialized
INFO - 2020-10-26 14:45:53 --> Upload Class Initialized
INFO - 2020-10-26 14:45:53 --> Controller Class Initialized
INFO - 2020-10-26 14:45:53 --> Form Validation Class Initialized
INFO - 2020-10-26 14:45:53 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:45:53 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:45:53 --> Final output sent to browser
DEBUG - 2020-10-26 14:45:53 --> Total execution time: 0.2367
INFO - 2020-10-26 14:46:12 --> Config Class Initialized
INFO - 2020-10-26 14:46:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:46:12 --> Utf8 Class Initialized
INFO - 2020-10-26 14:46:12 --> URI Class Initialized
INFO - 2020-10-26 14:46:12 --> Router Class Initialized
INFO - 2020-10-26 14:46:12 --> Output Class Initialized
INFO - 2020-10-26 14:46:12 --> Security Class Initialized
DEBUG - 2020-10-26 14:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:46:12 --> Input Class Initialized
INFO - 2020-10-26 14:46:12 --> Language Class Initialized
INFO - 2020-10-26 14:46:12 --> Loader Class Initialized
INFO - 2020-10-26 14:46:12 --> Helper loaded: url_helper
INFO - 2020-10-26 14:46:12 --> Helper loaded: form_helper
INFO - 2020-10-26 14:46:12 --> Helper loaded: html_helper
INFO - 2020-10-26 14:46:12 --> Helper loaded: date_helper
INFO - 2020-10-26 14:46:12 --> Database Driver Class Initialized
INFO - 2020-10-26 14:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:46:12 --> Table Class Initialized
INFO - 2020-10-26 14:46:12 --> Upload Class Initialized
INFO - 2020-10-26 14:46:12 --> Controller Class Initialized
INFO - 2020-10-26 14:46:12 --> Form Validation Class Initialized
INFO - 2020-10-26 14:46:12 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:46:12 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:46:12 --> Final output sent to browser
DEBUG - 2020-10-26 14:46:12 --> Total execution time: 0.2071
INFO - 2020-10-26 14:47:17 --> Config Class Initialized
INFO - 2020-10-26 14:47:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:47:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:47:17 --> Utf8 Class Initialized
INFO - 2020-10-26 14:47:17 --> URI Class Initialized
DEBUG - 2020-10-26 14:47:17 --> No URI present. Default controller set.
INFO - 2020-10-26 14:47:18 --> Router Class Initialized
INFO - 2020-10-26 14:47:18 --> Output Class Initialized
INFO - 2020-10-26 14:47:18 --> Security Class Initialized
DEBUG - 2020-10-26 14:47:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:47:18 --> Input Class Initialized
INFO - 2020-10-26 14:47:18 --> Language Class Initialized
ERROR - 2020-10-26 14:47:18 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 14:49:45 --> Config Class Initialized
INFO - 2020-10-26 14:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:49:45 --> Utf8 Class Initialized
INFO - 2020-10-26 14:49:46 --> URI Class Initialized
INFO - 2020-10-26 14:49:46 --> Router Class Initialized
INFO - 2020-10-26 14:49:46 --> Output Class Initialized
INFO - 2020-10-26 14:49:46 --> Security Class Initialized
DEBUG - 2020-10-26 14:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:49:46 --> Input Class Initialized
INFO - 2020-10-26 14:49:46 --> Language Class Initialized
INFO - 2020-10-26 14:49:46 --> Loader Class Initialized
INFO - 2020-10-26 14:49:46 --> Helper loaded: url_helper
INFO - 2020-10-26 14:49:46 --> Helper loaded: form_helper
INFO - 2020-10-26 14:49:46 --> Helper loaded: html_helper
INFO - 2020-10-26 14:49:46 --> Helper loaded: date_helper
INFO - 2020-10-26 14:49:46 --> Database Driver Class Initialized
INFO - 2020-10-26 14:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:49:46 --> Table Class Initialized
INFO - 2020-10-26 14:49:46 --> Upload Class Initialized
INFO - 2020-10-26 14:49:46 --> Controller Class Initialized
INFO - 2020-10-26 14:49:46 --> Form Validation Class Initialized
INFO - 2020-10-26 14:49:46 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:49:46 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:49:46 --> Final output sent to browser
DEBUG - 2020-10-26 14:49:46 --> Total execution time: 0.7168
INFO - 2020-10-26 14:50:02 --> Config Class Initialized
INFO - 2020-10-26 14:50:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:50:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:50:02 --> Utf8 Class Initialized
INFO - 2020-10-26 14:50:02 --> URI Class Initialized
INFO - 2020-10-26 14:50:03 --> Router Class Initialized
INFO - 2020-10-26 14:50:03 --> Output Class Initialized
INFO - 2020-10-26 14:50:03 --> Security Class Initialized
DEBUG - 2020-10-26 14:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:50:03 --> Input Class Initialized
INFO - 2020-10-26 14:50:03 --> Language Class Initialized
INFO - 2020-10-26 14:50:03 --> Loader Class Initialized
INFO - 2020-10-26 14:50:03 --> Helper loaded: url_helper
INFO - 2020-10-26 14:50:03 --> Helper loaded: form_helper
INFO - 2020-10-26 14:50:03 --> Helper loaded: html_helper
INFO - 2020-10-26 14:50:03 --> Helper loaded: date_helper
INFO - 2020-10-26 14:50:03 --> Database Driver Class Initialized
INFO - 2020-10-26 14:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:50:03 --> Table Class Initialized
INFO - 2020-10-26 14:50:03 --> Upload Class Initialized
INFO - 2020-10-26 14:50:03 --> Controller Class Initialized
INFO - 2020-10-26 14:50:03 --> Form Validation Class Initialized
INFO - 2020-10-26 14:50:03 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:50:03 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:50:03 --> Final output sent to browser
DEBUG - 2020-10-26 14:50:03 --> Total execution time: 0.4337
INFO - 2020-10-26 14:50:35 --> Config Class Initialized
INFO - 2020-10-26 14:50:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:50:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:50:35 --> Utf8 Class Initialized
INFO - 2020-10-26 14:50:35 --> URI Class Initialized
INFO - 2020-10-26 14:50:35 --> Router Class Initialized
INFO - 2020-10-26 14:50:35 --> Output Class Initialized
INFO - 2020-10-26 14:50:35 --> Security Class Initialized
DEBUG - 2020-10-26 14:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:50:35 --> Input Class Initialized
INFO - 2020-10-26 14:50:35 --> Language Class Initialized
INFO - 2020-10-26 14:50:35 --> Loader Class Initialized
INFO - 2020-10-26 14:50:36 --> Helper loaded: url_helper
INFO - 2020-10-26 14:50:36 --> Helper loaded: form_helper
INFO - 2020-10-26 14:50:36 --> Helper loaded: html_helper
INFO - 2020-10-26 14:50:36 --> Helper loaded: date_helper
INFO - 2020-10-26 14:50:36 --> Database Driver Class Initialized
INFO - 2020-10-26 14:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:50:36 --> Table Class Initialized
INFO - 2020-10-26 14:50:36 --> Upload Class Initialized
INFO - 2020-10-26 14:50:36 --> Controller Class Initialized
INFO - 2020-10-26 14:50:36 --> Form Validation Class Initialized
INFO - 2020-10-26 14:50:36 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:50:36 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:50:36 --> Final output sent to browser
DEBUG - 2020-10-26 14:50:36 --> Total execution time: 0.5226
INFO - 2020-10-26 14:50:39 --> Config Class Initialized
INFO - 2020-10-26 14:50:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:50:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:50:39 --> Utf8 Class Initialized
INFO - 2020-10-26 14:50:39 --> URI Class Initialized
INFO - 2020-10-26 14:50:39 --> Router Class Initialized
INFO - 2020-10-26 14:50:39 --> Output Class Initialized
INFO - 2020-10-26 14:50:39 --> Security Class Initialized
DEBUG - 2020-10-26 14:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:50:39 --> Input Class Initialized
INFO - 2020-10-26 14:50:39 --> Language Class Initialized
ERROR - 2020-10-26 14:50:39 --> 404 Page Not Found: Welcome/index3.html
INFO - 2020-10-26 14:50:41 --> Config Class Initialized
INFO - 2020-10-26 14:50:41 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:50:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:50:41 --> Utf8 Class Initialized
INFO - 2020-10-26 14:50:41 --> URI Class Initialized
INFO - 2020-10-26 14:50:41 --> Router Class Initialized
INFO - 2020-10-26 14:50:41 --> Output Class Initialized
INFO - 2020-10-26 14:50:41 --> Security Class Initialized
DEBUG - 2020-10-26 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:50:41 --> Input Class Initialized
INFO - 2020-10-26 14:50:41 --> Language Class Initialized
INFO - 2020-10-26 14:50:41 --> Loader Class Initialized
INFO - 2020-10-26 14:50:41 --> Helper loaded: url_helper
INFO - 2020-10-26 14:50:41 --> Helper loaded: form_helper
INFO - 2020-10-26 14:50:41 --> Helper loaded: html_helper
INFO - 2020-10-26 14:50:41 --> Helper loaded: date_helper
INFO - 2020-10-26 14:50:41 --> Database Driver Class Initialized
INFO - 2020-10-26 14:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:50:41 --> Table Class Initialized
INFO - 2020-10-26 14:50:41 --> Upload Class Initialized
INFO - 2020-10-26 14:50:41 --> Controller Class Initialized
INFO - 2020-10-26 14:50:41 --> Form Validation Class Initialized
INFO - 2020-10-26 14:50:41 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:50:41 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:50:41 --> Final output sent to browser
DEBUG - 2020-10-26 14:50:41 --> Total execution time: 0.5282
INFO - 2020-10-26 14:51:25 --> Config Class Initialized
INFO - 2020-10-26 14:51:25 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:51:25 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:51:25 --> Utf8 Class Initialized
INFO - 2020-10-26 14:51:25 --> URI Class Initialized
INFO - 2020-10-26 14:51:25 --> Router Class Initialized
INFO - 2020-10-26 14:51:25 --> Output Class Initialized
INFO - 2020-10-26 14:51:25 --> Security Class Initialized
DEBUG - 2020-10-26 14:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:51:26 --> Input Class Initialized
INFO - 2020-10-26 14:51:26 --> Language Class Initialized
INFO - 2020-10-26 14:51:26 --> Loader Class Initialized
INFO - 2020-10-26 14:51:26 --> Helper loaded: url_helper
INFO - 2020-10-26 14:51:26 --> Helper loaded: form_helper
INFO - 2020-10-26 14:51:26 --> Helper loaded: html_helper
INFO - 2020-10-26 14:51:26 --> Helper loaded: date_helper
INFO - 2020-10-26 14:51:26 --> Database Driver Class Initialized
INFO - 2020-10-26 14:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:51:26 --> Table Class Initialized
INFO - 2020-10-26 14:51:26 --> Upload Class Initialized
INFO - 2020-10-26 14:51:26 --> Controller Class Initialized
INFO - 2020-10-26 14:51:26 --> Form Validation Class Initialized
INFO - 2020-10-26 14:51:26 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:51:26 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:51:26 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:51:26 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:51:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:51:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:51:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:51:26 --> Final output sent to browser
DEBUG - 2020-10-26 14:51:26 --> Total execution time: 0.6324
INFO - 2020-10-26 14:51:26 --> Config Class Initialized
INFO - 2020-10-26 14:51:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:51:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:51:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:51:26 --> URI Class Initialized
INFO - 2020-10-26 14:51:26 --> Router Class Initialized
INFO - 2020-10-26 14:51:26 --> Output Class Initialized
INFO - 2020-10-26 14:51:26 --> Config Class Initialized
INFO - 2020-10-26 14:51:26 --> Security Class Initialized
INFO - 2020-10-26 14:51:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:51:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:51:26 --> Input Class Initialized
INFO - 2020-10-26 14:51:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:51:26 --> URI Class Initialized
INFO - 2020-10-26 14:51:26 --> Language Class Initialized
INFO - 2020-10-26 14:51:26 --> Router Class Initialized
ERROR - 2020-10-26 14:51:26 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:51:26 --> Config Class Initialized
INFO - 2020-10-26 14:51:26 --> Output Class Initialized
INFO - 2020-10-26 14:51:26 --> Security Class Initialized
INFO - 2020-10-26 14:51:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 14:51:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:51:27 --> Input Class Initialized
INFO - 2020-10-26 14:51:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:51:27 --> URI Class Initialized
INFO - 2020-10-26 14:51:27 --> Language Class Initialized
INFO - 2020-10-26 14:51:27 --> Router Class Initialized
ERROR - 2020-10-26 14:51:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:51:27 --> Output Class Initialized
INFO - 2020-10-26 14:51:27 --> Config Class Initialized
INFO - 2020-10-26 14:51:27 --> Hooks Class Initialized
INFO - 2020-10-26 14:51:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:51:27 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 14:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:51:27 --> Input Class Initialized
INFO - 2020-10-26 14:51:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:51:27 --> Language Class Initialized
INFO - 2020-10-26 14:51:27 --> URI Class Initialized
INFO - 2020-10-26 14:51:27 --> Router Class Initialized
ERROR - 2020-10-26 14:51:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:51:27 --> Output Class Initialized
INFO - 2020-10-26 14:51:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:51:27 --> Input Class Initialized
INFO - 2020-10-26 14:51:27 --> Language Class Initialized
INFO - 2020-10-26 14:51:27 --> Loader Class Initialized
INFO - 2020-10-26 14:51:27 --> Helper loaded: url_helper
INFO - 2020-10-26 14:51:27 --> Helper loaded: form_helper
INFO - 2020-10-26 14:51:27 --> Helper loaded: html_helper
INFO - 2020-10-26 14:51:27 --> Helper loaded: date_helper
INFO - 2020-10-26 14:51:27 --> Database Driver Class Initialized
INFO - 2020-10-26 14:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:51:27 --> Table Class Initialized
INFO - 2020-10-26 14:51:27 --> Upload Class Initialized
INFO - 2020-10-26 14:51:27 --> Controller Class Initialized
INFO - 2020-10-26 14:51:27 --> Form Validation Class Initialized
INFO - 2020-10-26 14:51:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:51:27 --> Final output sent to browser
DEBUG - 2020-10-26 14:51:27 --> Total execution time: 0.3364
INFO - 2020-10-26 14:51:27 --> Config Class Initialized
INFO - 2020-10-26 14:51:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:51:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:51:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:51:27 --> URI Class Initialized
INFO - 2020-10-26 14:51:27 --> Router Class Initialized
INFO - 2020-10-26 14:51:27 --> Output Class Initialized
INFO - 2020-10-26 14:51:27 --> Security Class Initialized
DEBUG - 2020-10-26 14:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:51:27 --> Input Class Initialized
INFO - 2020-10-26 14:51:27 --> Language Class Initialized
ERROR - 2020-10-26 14:51:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:51:27 --> Config Class Initialized
INFO - 2020-10-26 14:51:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:51:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:51:27 --> Utf8 Class Initialized
INFO - 2020-10-26 14:51:27 --> URI Class Initialized
INFO - 2020-10-26 14:51:27 --> Router Class Initialized
INFO - 2020-10-26 14:51:28 --> Output Class Initialized
INFO - 2020-10-26 14:51:28 --> Security Class Initialized
DEBUG - 2020-10-26 14:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:51:28 --> Input Class Initialized
INFO - 2020-10-26 14:51:28 --> Language Class Initialized
ERROR - 2020-10-26 14:51:28 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:52:06 --> Config Class Initialized
INFO - 2020-10-26 14:52:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:52:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:52:06 --> Utf8 Class Initialized
INFO - 2020-10-26 14:52:06 --> URI Class Initialized
INFO - 2020-10-26 14:52:06 --> Router Class Initialized
INFO - 2020-10-26 14:52:06 --> Output Class Initialized
INFO - 2020-10-26 14:52:06 --> Security Class Initialized
DEBUG - 2020-10-26 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:52:06 --> Input Class Initialized
INFO - 2020-10-26 14:52:06 --> Language Class Initialized
INFO - 2020-10-26 14:52:06 --> Loader Class Initialized
INFO - 2020-10-26 14:52:06 --> Helper loaded: url_helper
INFO - 2020-10-26 14:52:06 --> Helper loaded: form_helper
INFO - 2020-10-26 14:52:06 --> Helper loaded: html_helper
INFO - 2020-10-26 14:52:06 --> Helper loaded: date_helper
INFO - 2020-10-26 14:52:06 --> Database Driver Class Initialized
INFO - 2020-10-26 14:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:52:06 --> Table Class Initialized
INFO - 2020-10-26 14:52:06 --> Upload Class Initialized
INFO - 2020-10-26 14:52:06 --> Controller Class Initialized
INFO - 2020-10-26 14:52:06 --> Form Validation Class Initialized
INFO - 2020-10-26 14:52:06 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:52:06 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 14:52:06 --> Final output sent to browser
DEBUG - 2020-10-26 14:52:06 --> Total execution time: 0.6405
INFO - 2020-10-26 14:52:19 --> Config Class Initialized
INFO - 2020-10-26 14:52:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:52:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:52:19 --> Utf8 Class Initialized
INFO - 2020-10-26 14:52:19 --> URI Class Initialized
INFO - 2020-10-26 14:52:19 --> Router Class Initialized
INFO - 2020-10-26 14:52:19 --> Output Class Initialized
INFO - 2020-10-26 14:52:19 --> Security Class Initialized
DEBUG - 2020-10-26 14:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:52:19 --> Input Class Initialized
INFO - 2020-10-26 14:52:19 --> Language Class Initialized
INFO - 2020-10-26 14:52:19 --> Loader Class Initialized
INFO - 2020-10-26 14:52:19 --> Helper loaded: url_helper
INFO - 2020-10-26 14:52:20 --> Helper loaded: form_helper
INFO - 2020-10-26 14:52:20 --> Helper loaded: html_helper
INFO - 2020-10-26 14:52:20 --> Helper loaded: date_helper
INFO - 2020-10-26 14:52:20 --> Database Driver Class Initialized
INFO - 2020-10-26 14:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:52:20 --> Table Class Initialized
INFO - 2020-10-26 14:52:20 --> Upload Class Initialized
INFO - 2020-10-26 14:52:20 --> Controller Class Initialized
INFO - 2020-10-26 14:52:20 --> Form Validation Class Initialized
INFO - 2020-10-26 14:52:20 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:52:20 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 14:52:20 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 14:52:20 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 14:52:20 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 14:52:20 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 14:52:20 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 14:52:20 --> Final output sent to browser
DEBUG - 2020-10-26 14:52:20 --> Total execution time: 0.9147
INFO - 2020-10-26 14:52:20 --> Config Class Initialized
INFO - 2020-10-26 14:52:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:52:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:52:20 --> Utf8 Class Initialized
INFO - 2020-10-26 14:52:20 --> Config Class Initialized
INFO - 2020-10-26 14:52:20 --> URI Class Initialized
INFO - 2020-10-26 14:52:20 --> Hooks Class Initialized
INFO - 2020-10-26 14:52:20 --> Router Class Initialized
INFO - 2020-10-26 14:52:20 --> Output Class Initialized
DEBUG - 2020-10-26 14:52:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:52:20 --> Utf8 Class Initialized
INFO - 2020-10-26 14:52:20 --> Security Class Initialized
INFO - 2020-10-26 14:52:20 --> URI Class Initialized
DEBUG - 2020-10-26 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:52:20 --> Input Class Initialized
INFO - 2020-10-26 14:52:20 --> Router Class Initialized
INFO - 2020-10-26 14:52:20 --> Output Class Initialized
INFO - 2020-10-26 14:52:20 --> Language Class Initialized
ERROR - 2020-10-26 14:52:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 14:52:20 --> Security Class Initialized
DEBUG - 2020-10-26 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:52:20 --> Input Class Initialized
INFO - 2020-10-26 14:52:20 --> Config Class Initialized
INFO - 2020-10-26 14:52:20 --> Language Class Initialized
INFO - 2020-10-26 14:52:20 --> Hooks Class Initialized
ERROR - 2020-10-26 14:52:20 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 14:52:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:52:20 --> Utf8 Class Initialized
INFO - 2020-10-26 14:52:20 --> URI Class Initialized
INFO - 2020-10-26 14:52:20 --> Config Class Initialized
INFO - 2020-10-26 14:52:20 --> Router Class Initialized
INFO - 2020-10-26 14:52:20 --> Output Class Initialized
INFO - 2020-10-26 14:52:20 --> Hooks Class Initialized
INFO - 2020-10-26 14:52:20 --> Security Class Initialized
DEBUG - 2020-10-26 14:52:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:52:20 --> Utf8 Class Initialized
DEBUG - 2020-10-26 14:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:52:21 --> URI Class Initialized
INFO - 2020-10-26 14:52:21 --> Input Class Initialized
INFO - 2020-10-26 14:52:21 --> Language Class Initialized
INFO - 2020-10-26 14:52:21 --> Router Class Initialized
ERROR - 2020-10-26 14:52:21 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 14:52:21 --> Output Class Initialized
INFO - 2020-10-26 14:52:21 --> Security Class Initialized
DEBUG - 2020-10-26 14:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:52:21 --> Input Class Initialized
INFO - 2020-10-26 14:52:21 --> Language Class Initialized
INFO - 2020-10-26 14:52:21 --> Loader Class Initialized
INFO - 2020-10-26 14:52:21 --> Helper loaded: url_helper
INFO - 2020-10-26 14:52:21 --> Helper loaded: form_helper
INFO - 2020-10-26 14:52:21 --> Helper loaded: html_helper
INFO - 2020-10-26 14:52:21 --> Helper loaded: date_helper
INFO - 2020-10-26 14:52:21 --> Database Driver Class Initialized
INFO - 2020-10-26 14:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:52:21 --> Table Class Initialized
INFO - 2020-10-26 14:52:21 --> Upload Class Initialized
INFO - 2020-10-26 14:52:21 --> Controller Class Initialized
INFO - 2020-10-26 14:52:21 --> Form Validation Class Initialized
INFO - 2020-10-26 14:52:21 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:52:21 --> Final output sent to browser
DEBUG - 2020-10-26 14:52:21 --> Total execution time: 0.3488
INFO - 2020-10-26 14:52:26 --> Config Class Initialized
INFO - 2020-10-26 14:52:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:52:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:52:26 --> Utf8 Class Initialized
INFO - 2020-10-26 14:52:26 --> URI Class Initialized
INFO - 2020-10-26 14:52:26 --> Router Class Initialized
INFO - 2020-10-26 14:52:26 --> Output Class Initialized
INFO - 2020-10-26 14:52:26 --> Security Class Initialized
DEBUG - 2020-10-26 14:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:52:26 --> Input Class Initialized
INFO - 2020-10-26 14:52:26 --> Language Class Initialized
INFO - 2020-10-26 14:52:26 --> Loader Class Initialized
INFO - 2020-10-26 14:52:26 --> Helper loaded: url_helper
INFO - 2020-10-26 14:52:26 --> Helper loaded: form_helper
INFO - 2020-10-26 14:52:27 --> Helper loaded: html_helper
INFO - 2020-10-26 14:52:27 --> Helper loaded: date_helper
INFO - 2020-10-26 14:52:27 --> Database Driver Class Initialized
INFO - 2020-10-26 14:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 14:52:27 --> Table Class Initialized
INFO - 2020-10-26 14:52:27 --> Upload Class Initialized
INFO - 2020-10-26 14:52:27 --> Controller Class Initialized
INFO - 2020-10-26 14:52:27 --> Form Validation Class Initialized
INFO - 2020-10-26 14:52:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 14:52:27 --> Final output sent to browser
DEBUG - 2020-10-26 14:52:27 --> Total execution time: 0.5033
INFO - 2020-10-26 14:57:20 --> Config Class Initialized
INFO - 2020-10-26 14:57:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:57:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:57:21 --> Utf8 Class Initialized
INFO - 2020-10-26 14:57:21 --> URI Class Initialized
DEBUG - 2020-10-26 14:57:21 --> No URI present. Default controller set.
INFO - 2020-10-26 14:57:21 --> Router Class Initialized
INFO - 2020-10-26 14:57:21 --> Output Class Initialized
INFO - 2020-10-26 14:57:21 --> Security Class Initialized
DEBUG - 2020-10-26 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:57:21 --> Input Class Initialized
INFO - 2020-10-26 14:57:21 --> Language Class Initialized
ERROR - 2020-10-26 14:57:21 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 14:57:23 --> Config Class Initialized
INFO - 2020-10-26 14:57:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:57:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:57:23 --> Utf8 Class Initialized
INFO - 2020-10-26 14:57:23 --> URI Class Initialized
DEBUG - 2020-10-26 14:57:23 --> No URI present. Default controller set.
INFO - 2020-10-26 14:57:23 --> Router Class Initialized
INFO - 2020-10-26 14:57:23 --> Output Class Initialized
INFO - 2020-10-26 14:57:23 --> Security Class Initialized
DEBUG - 2020-10-26 14:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:57:23 --> Input Class Initialized
INFO - 2020-10-26 14:57:23 --> Language Class Initialized
ERROR - 2020-10-26 14:57:23 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 14:57:49 --> Config Class Initialized
INFO - 2020-10-26 14:57:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 14:57:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 14:57:49 --> Utf8 Class Initialized
INFO - 2020-10-26 14:57:49 --> URI Class Initialized
DEBUG - 2020-10-26 14:57:49 --> No URI present. Default controller set.
INFO - 2020-10-26 14:57:49 --> Router Class Initialized
INFO - 2020-10-26 14:57:49 --> Output Class Initialized
INFO - 2020-10-26 14:57:49 --> Security Class Initialized
DEBUG - 2020-10-26 14:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 14:57:49 --> Input Class Initialized
INFO - 2020-10-26 14:57:49 --> Language Class Initialized
ERROR - 2020-10-26 14:57:49 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:05:02 --> Config Class Initialized
INFO - 2020-10-26 15:05:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:02 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:02 --> URI Class Initialized
INFO - 2020-10-26 15:05:02 --> Router Class Initialized
INFO - 2020-10-26 15:05:02 --> Output Class Initialized
INFO - 2020-10-26 15:05:02 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:02 --> Input Class Initialized
INFO - 2020-10-26 15:05:02 --> Language Class Initialized
INFO - 2020-10-26 15:05:02 --> Loader Class Initialized
INFO - 2020-10-26 15:05:02 --> Helper loaded: url_helper
INFO - 2020-10-26 15:05:02 --> Helper loaded: form_helper
INFO - 2020-10-26 15:05:02 --> Helper loaded: html_helper
INFO - 2020-10-26 15:05:02 --> Helper loaded: date_helper
INFO - 2020-10-26 15:05:02 --> Database Driver Class Initialized
INFO - 2020-10-26 15:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:05:02 --> Table Class Initialized
INFO - 2020-10-26 15:05:02 --> Upload Class Initialized
INFO - 2020-10-26 15:05:02 --> Controller Class Initialized
INFO - 2020-10-26 15:05:02 --> Form Validation Class Initialized
INFO - 2020-10-26 15:05:02 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:05:02 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:05:02 --> Final output sent to browser
DEBUG - 2020-10-26 15:05:02 --> Total execution time: 0.3838
INFO - 2020-10-26 15:05:05 --> Config Class Initialized
INFO - 2020-10-26 15:05:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:06 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:06 --> URI Class Initialized
INFO - 2020-10-26 15:05:06 --> Router Class Initialized
INFO - 2020-10-26 15:05:06 --> Output Class Initialized
INFO - 2020-10-26 15:05:06 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:06 --> Input Class Initialized
INFO - 2020-10-26 15:05:06 --> Language Class Initialized
INFO - 2020-10-26 15:05:06 --> Loader Class Initialized
INFO - 2020-10-26 15:05:06 --> Helper loaded: url_helper
INFO - 2020-10-26 15:05:06 --> Helper loaded: form_helper
INFO - 2020-10-26 15:05:06 --> Helper loaded: html_helper
INFO - 2020-10-26 15:05:06 --> Helper loaded: date_helper
INFO - 2020-10-26 15:05:06 --> Database Driver Class Initialized
INFO - 2020-10-26 15:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:05:06 --> Table Class Initialized
INFO - 2020-10-26 15:05:06 --> Upload Class Initialized
INFO - 2020-10-26 15:05:06 --> Controller Class Initialized
INFO - 2020-10-26 15:05:06 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:05:06 --> Config Class Initialized
INFO - 2020-10-26 15:05:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:06 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:06 --> URI Class Initialized
DEBUG - 2020-10-26 15:05:06 --> No URI present. Default controller set.
INFO - 2020-10-26 15:05:06 --> Router Class Initialized
INFO - 2020-10-26 15:05:06 --> Output Class Initialized
INFO - 2020-10-26 15:05:06 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:06 --> Input Class Initialized
INFO - 2020-10-26 15:05:06 --> Language Class Initialized
ERROR - 2020-10-26 15:05:06 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:05:26 --> Config Class Initialized
INFO - 2020-10-26 15:05:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:26 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:26 --> URI Class Initialized
INFO - 2020-10-26 15:05:26 --> Router Class Initialized
INFO - 2020-10-26 15:05:26 --> Output Class Initialized
INFO - 2020-10-26 15:05:26 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:26 --> Input Class Initialized
INFO - 2020-10-26 15:05:26 --> Language Class Initialized
INFO - 2020-10-26 15:05:26 --> Loader Class Initialized
INFO - 2020-10-26 15:05:26 --> Helper loaded: url_helper
INFO - 2020-10-26 15:05:26 --> Helper loaded: form_helper
INFO - 2020-10-26 15:05:26 --> Helper loaded: html_helper
INFO - 2020-10-26 15:05:26 --> Helper loaded: date_helper
INFO - 2020-10-26 15:05:26 --> Database Driver Class Initialized
INFO - 2020-10-26 15:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:05:26 --> Table Class Initialized
INFO - 2020-10-26 15:05:26 --> Upload Class Initialized
INFO - 2020-10-26 15:05:26 --> Controller Class Initialized
INFO - 2020-10-26 15:05:26 --> Form Validation Class Initialized
INFO - 2020-10-26 15:05:26 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:05:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:05:26 --> Final output sent to browser
DEBUG - 2020-10-26 15:05:26 --> Total execution time: 0.5382
INFO - 2020-10-26 15:05:28 --> Config Class Initialized
INFO - 2020-10-26 15:05:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:28 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:28 --> URI Class Initialized
INFO - 2020-10-26 15:05:28 --> Router Class Initialized
INFO - 2020-10-26 15:05:28 --> Output Class Initialized
INFO - 2020-10-26 15:05:28 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:28 --> Input Class Initialized
INFO - 2020-10-26 15:05:28 --> Language Class Initialized
INFO - 2020-10-26 15:05:28 --> Loader Class Initialized
INFO - 2020-10-26 15:05:28 --> Helper loaded: url_helper
INFO - 2020-10-26 15:05:28 --> Helper loaded: form_helper
INFO - 2020-10-26 15:05:28 --> Helper loaded: html_helper
INFO - 2020-10-26 15:05:28 --> Helper loaded: date_helper
INFO - 2020-10-26 15:05:28 --> Database Driver Class Initialized
INFO - 2020-10-26 15:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:05:29 --> Table Class Initialized
INFO - 2020-10-26 15:05:29 --> Upload Class Initialized
INFO - 2020-10-26 15:05:29 --> Controller Class Initialized
INFO - 2020-10-26 15:05:29 --> Form Validation Class Initialized
INFO - 2020-10-26 15:05:29 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:05:29 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:05:29 --> Final output sent to browser
DEBUG - 2020-10-26 15:05:29 --> Total execution time: 0.8304
INFO - 2020-10-26 15:05:30 --> Config Class Initialized
INFO - 2020-10-26 15:05:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:30 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:30 --> URI Class Initialized
INFO - 2020-10-26 15:05:30 --> Router Class Initialized
INFO - 2020-10-26 15:05:30 --> Output Class Initialized
INFO - 2020-10-26 15:05:30 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:30 --> Input Class Initialized
INFO - 2020-10-26 15:05:30 --> Language Class Initialized
ERROR - 2020-10-26 15:05:30 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 15:05:32 --> Config Class Initialized
INFO - 2020-10-26 15:05:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:32 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:32 --> URI Class Initialized
INFO - 2020-10-26 15:05:32 --> Router Class Initialized
INFO - 2020-10-26 15:05:32 --> Output Class Initialized
INFO - 2020-10-26 15:05:32 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:32 --> Input Class Initialized
INFO - 2020-10-26 15:05:32 --> Language Class Initialized
INFO - 2020-10-26 15:05:32 --> Loader Class Initialized
INFO - 2020-10-26 15:05:32 --> Helper loaded: url_helper
INFO - 2020-10-26 15:05:32 --> Helper loaded: form_helper
INFO - 2020-10-26 15:05:32 --> Helper loaded: html_helper
INFO - 2020-10-26 15:05:32 --> Helper loaded: date_helper
INFO - 2020-10-26 15:05:32 --> Database Driver Class Initialized
INFO - 2020-10-26 15:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:05:32 --> Table Class Initialized
INFO - 2020-10-26 15:05:32 --> Upload Class Initialized
INFO - 2020-10-26 15:05:32 --> Controller Class Initialized
INFO - 2020-10-26 15:05:32 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:05:32 --> Config Class Initialized
INFO - 2020-10-26 15:05:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:32 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:32 --> URI Class Initialized
DEBUG - 2020-10-26 15:05:32 --> No URI present. Default controller set.
INFO - 2020-10-26 15:05:32 --> Router Class Initialized
INFO - 2020-10-26 15:05:32 --> Output Class Initialized
INFO - 2020-10-26 15:05:32 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:32 --> Input Class Initialized
INFO - 2020-10-26 15:05:32 --> Language Class Initialized
ERROR - 2020-10-26 15:05:32 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:05:37 --> Config Class Initialized
INFO - 2020-10-26 15:05:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:05:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:05:38 --> Utf8 Class Initialized
INFO - 2020-10-26 15:05:38 --> URI Class Initialized
INFO - 2020-10-26 15:05:38 --> Router Class Initialized
INFO - 2020-10-26 15:05:38 --> Output Class Initialized
INFO - 2020-10-26 15:05:38 --> Security Class Initialized
DEBUG - 2020-10-26 15:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:05:38 --> Input Class Initialized
INFO - 2020-10-26 15:05:38 --> Language Class Initialized
INFO - 2020-10-26 15:05:38 --> Loader Class Initialized
INFO - 2020-10-26 15:05:38 --> Helper loaded: url_helper
INFO - 2020-10-26 15:05:38 --> Helper loaded: form_helper
INFO - 2020-10-26 15:05:38 --> Helper loaded: html_helper
INFO - 2020-10-26 15:05:38 --> Helper loaded: date_helper
INFO - 2020-10-26 15:05:38 --> Database Driver Class Initialized
INFO - 2020-10-26 15:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:05:38 --> Table Class Initialized
INFO - 2020-10-26 15:05:38 --> Upload Class Initialized
INFO - 2020-10-26 15:05:38 --> Controller Class Initialized
INFO - 2020-10-26 15:05:38 --> Form Validation Class Initialized
INFO - 2020-10-26 15:05:38 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:05:38 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:05:38 --> Final output sent to browser
DEBUG - 2020-10-26 15:05:38 --> Total execution time: 0.5686
INFO - 2020-10-26 15:06:10 --> Config Class Initialized
INFO - 2020-10-26 15:06:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:06:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:06:10 --> Utf8 Class Initialized
INFO - 2020-10-26 15:06:10 --> URI Class Initialized
INFO - 2020-10-26 15:06:10 --> Router Class Initialized
INFO - 2020-10-26 15:06:10 --> Output Class Initialized
INFO - 2020-10-26 15:06:10 --> Security Class Initialized
DEBUG - 2020-10-26 15:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:06:10 --> Input Class Initialized
INFO - 2020-10-26 15:06:10 --> Language Class Initialized
INFO - 2020-10-26 15:06:10 --> Loader Class Initialized
INFO - 2020-10-26 15:06:10 --> Helper loaded: url_helper
INFO - 2020-10-26 15:06:10 --> Helper loaded: form_helper
INFO - 2020-10-26 15:06:10 --> Helper loaded: html_helper
INFO - 2020-10-26 15:06:10 --> Helper loaded: date_helper
INFO - 2020-10-26 15:06:11 --> Database Driver Class Initialized
INFO - 2020-10-26 15:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:06:11 --> Table Class Initialized
INFO - 2020-10-26 15:06:11 --> Upload Class Initialized
INFO - 2020-10-26 15:06:11 --> Controller Class Initialized
INFO - 2020-10-26 15:06:11 --> Form Validation Class Initialized
INFO - 2020-10-26 15:06:11 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:06:11 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:06:11 --> Final output sent to browser
DEBUG - 2020-10-26 15:06:11 --> Total execution time: 0.7650
INFO - 2020-10-26 15:06:13 --> Config Class Initialized
INFO - 2020-10-26 15:06:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:06:13 --> Utf8 Class Initialized
INFO - 2020-10-26 15:06:13 --> URI Class Initialized
INFO - 2020-10-26 15:06:13 --> Router Class Initialized
INFO - 2020-10-26 15:06:13 --> Output Class Initialized
INFO - 2020-10-26 15:06:13 --> Security Class Initialized
DEBUG - 2020-10-26 15:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:06:13 --> Input Class Initialized
INFO - 2020-10-26 15:06:13 --> Language Class Initialized
INFO - 2020-10-26 15:06:13 --> Loader Class Initialized
INFO - 2020-10-26 15:06:13 --> Helper loaded: url_helper
INFO - 2020-10-26 15:06:13 --> Helper loaded: form_helper
INFO - 2020-10-26 15:06:13 --> Helper loaded: html_helper
INFO - 2020-10-26 15:06:13 --> Helper loaded: date_helper
INFO - 2020-10-26 15:06:13 --> Database Driver Class Initialized
INFO - 2020-10-26 15:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:06:13 --> Table Class Initialized
INFO - 2020-10-26 15:06:13 --> Upload Class Initialized
INFO - 2020-10-26 15:06:13 --> Controller Class Initialized
INFO - 2020-10-26 15:06:13 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:06:13 --> Config Class Initialized
INFO - 2020-10-26 15:06:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:06:13 --> Utf8 Class Initialized
INFO - 2020-10-26 15:06:13 --> URI Class Initialized
DEBUG - 2020-10-26 15:06:13 --> No URI present. Default controller set.
INFO - 2020-10-26 15:06:13 --> Router Class Initialized
INFO - 2020-10-26 15:06:13 --> Output Class Initialized
INFO - 2020-10-26 15:06:13 --> Security Class Initialized
DEBUG - 2020-10-26 15:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:06:14 --> Input Class Initialized
INFO - 2020-10-26 15:06:14 --> Language Class Initialized
ERROR - 2020-10-26 15:06:14 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:06:16 --> Config Class Initialized
INFO - 2020-10-26 15:06:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:06:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:06:17 --> Utf8 Class Initialized
INFO - 2020-10-26 15:06:17 --> URI Class Initialized
INFO - 2020-10-26 15:06:17 --> Router Class Initialized
INFO - 2020-10-26 15:06:17 --> Output Class Initialized
INFO - 2020-10-26 15:06:17 --> Security Class Initialized
DEBUG - 2020-10-26 15:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:06:17 --> Input Class Initialized
INFO - 2020-10-26 15:06:17 --> Language Class Initialized
INFO - 2020-10-26 15:06:17 --> Loader Class Initialized
INFO - 2020-10-26 15:06:17 --> Helper loaded: url_helper
INFO - 2020-10-26 15:06:17 --> Helper loaded: form_helper
INFO - 2020-10-26 15:06:17 --> Helper loaded: html_helper
INFO - 2020-10-26 15:06:17 --> Helper loaded: date_helper
INFO - 2020-10-26 15:06:17 --> Database Driver Class Initialized
INFO - 2020-10-26 15:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:06:17 --> Table Class Initialized
INFO - 2020-10-26 15:06:17 --> Upload Class Initialized
INFO - 2020-10-26 15:06:17 --> Controller Class Initialized
INFO - 2020-10-26 15:06:17 --> Form Validation Class Initialized
INFO - 2020-10-26 15:06:17 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:06:17 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:06:17 --> Final output sent to browser
DEBUG - 2020-10-26 15:06:17 --> Total execution time: 0.5682
INFO - 2020-10-26 15:07:13 --> Config Class Initialized
INFO - 2020-10-26 15:07:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:13 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:13 --> URI Class Initialized
INFO - 2020-10-26 15:07:13 --> Router Class Initialized
INFO - 2020-10-26 15:07:14 --> Output Class Initialized
INFO - 2020-10-26 15:07:14 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:14 --> Input Class Initialized
INFO - 2020-10-26 15:07:14 --> Language Class Initialized
INFO - 2020-10-26 15:07:14 --> Loader Class Initialized
INFO - 2020-10-26 15:07:14 --> Helper loaded: url_helper
INFO - 2020-10-26 15:07:14 --> Helper loaded: form_helper
INFO - 2020-10-26 15:07:14 --> Helper loaded: html_helper
INFO - 2020-10-26 15:07:14 --> Helper loaded: date_helper
INFO - 2020-10-26 15:07:14 --> Database Driver Class Initialized
INFO - 2020-10-26 15:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:07:14 --> Table Class Initialized
INFO - 2020-10-26 15:07:14 --> Upload Class Initialized
INFO - 2020-10-26 15:07:14 --> Controller Class Initialized
INFO - 2020-10-26 15:07:14 --> Form Validation Class Initialized
INFO - 2020-10-26 15:07:14 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:07:14 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:07:14 --> Final output sent to browser
DEBUG - 2020-10-26 15:07:14 --> Total execution time: 0.6253
INFO - 2020-10-26 15:07:15 --> Config Class Initialized
INFO - 2020-10-26 15:07:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:15 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:15 --> URI Class Initialized
INFO - 2020-10-26 15:07:15 --> Router Class Initialized
INFO - 2020-10-26 15:07:15 --> Output Class Initialized
INFO - 2020-10-26 15:07:15 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:15 --> Input Class Initialized
INFO - 2020-10-26 15:07:15 --> Language Class Initialized
INFO - 2020-10-26 15:07:15 --> Loader Class Initialized
INFO - 2020-10-26 15:07:15 --> Helper loaded: url_helper
INFO - 2020-10-26 15:07:15 --> Helper loaded: form_helper
INFO - 2020-10-26 15:07:15 --> Helper loaded: html_helper
INFO - 2020-10-26 15:07:16 --> Helper loaded: date_helper
INFO - 2020-10-26 15:07:16 --> Database Driver Class Initialized
INFO - 2020-10-26 15:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:07:16 --> Table Class Initialized
INFO - 2020-10-26 15:07:16 --> Upload Class Initialized
INFO - 2020-10-26 15:07:16 --> Controller Class Initialized
INFO - 2020-10-26 15:07:16 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:07:16 --> Config Class Initialized
INFO - 2020-10-26 15:07:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:16 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:16 --> URI Class Initialized
DEBUG - 2020-10-26 15:07:16 --> No URI present. Default controller set.
INFO - 2020-10-26 15:07:16 --> Router Class Initialized
INFO - 2020-10-26 15:07:16 --> Output Class Initialized
INFO - 2020-10-26 15:07:16 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:16 --> Input Class Initialized
INFO - 2020-10-26 15:07:16 --> Language Class Initialized
ERROR - 2020-10-26 15:07:16 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:07:30 --> Config Class Initialized
INFO - 2020-10-26 15:07:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:30 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:30 --> URI Class Initialized
INFO - 2020-10-26 15:07:30 --> Router Class Initialized
INFO - 2020-10-26 15:07:30 --> Output Class Initialized
INFO - 2020-10-26 15:07:30 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:30 --> Input Class Initialized
INFO - 2020-10-26 15:07:30 --> Language Class Initialized
INFO - 2020-10-26 15:07:30 --> Loader Class Initialized
INFO - 2020-10-26 15:07:30 --> Helper loaded: url_helper
INFO - 2020-10-26 15:07:30 --> Helper loaded: form_helper
INFO - 2020-10-26 15:07:30 --> Helper loaded: html_helper
INFO - 2020-10-26 15:07:30 --> Helper loaded: date_helper
INFO - 2020-10-26 15:07:30 --> Database Driver Class Initialized
INFO - 2020-10-26 15:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:07:30 --> Table Class Initialized
INFO - 2020-10-26 15:07:30 --> Upload Class Initialized
INFO - 2020-10-26 15:07:30 --> Controller Class Initialized
INFO - 2020-10-26 15:07:30 --> Form Validation Class Initialized
INFO - 2020-10-26 15:07:30 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:07:30 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:07:30 --> Final output sent to browser
DEBUG - 2020-10-26 15:07:30 --> Total execution time: 0.5809
INFO - 2020-10-26 15:07:35 --> Config Class Initialized
INFO - 2020-10-26 15:07:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:35 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:35 --> URI Class Initialized
INFO - 2020-10-26 15:07:35 --> Router Class Initialized
INFO - 2020-10-26 15:07:35 --> Output Class Initialized
INFO - 2020-10-26 15:07:35 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:35 --> Input Class Initialized
INFO - 2020-10-26 15:07:36 --> Language Class Initialized
INFO - 2020-10-26 15:07:36 --> Loader Class Initialized
INFO - 2020-10-26 15:07:36 --> Helper loaded: url_helper
INFO - 2020-10-26 15:07:36 --> Helper loaded: form_helper
INFO - 2020-10-26 15:07:36 --> Helper loaded: html_helper
INFO - 2020-10-26 15:07:36 --> Helper loaded: date_helper
INFO - 2020-10-26 15:07:36 --> Database Driver Class Initialized
INFO - 2020-10-26 15:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:07:36 --> Table Class Initialized
INFO - 2020-10-26 15:07:36 --> Upload Class Initialized
INFO - 2020-10-26 15:07:36 --> Controller Class Initialized
INFO - 2020-10-26 15:07:36 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:07:36 --> Config Class Initialized
INFO - 2020-10-26 15:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:36 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:36 --> URI Class Initialized
DEBUG - 2020-10-26 15:07:36 --> No URI present. Default controller set.
INFO - 2020-10-26 15:07:36 --> Router Class Initialized
INFO - 2020-10-26 15:07:36 --> Output Class Initialized
INFO - 2020-10-26 15:07:36 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:36 --> Input Class Initialized
INFO - 2020-10-26 15:07:36 --> Language Class Initialized
ERROR - 2020-10-26 15:07:36 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:07:38 --> Config Class Initialized
INFO - 2020-10-26 15:07:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:38 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:38 --> URI Class Initialized
INFO - 2020-10-26 15:07:38 --> Router Class Initialized
INFO - 2020-10-26 15:07:38 --> Output Class Initialized
INFO - 2020-10-26 15:07:38 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:38 --> Input Class Initialized
INFO - 2020-10-26 15:07:38 --> Language Class Initialized
INFO - 2020-10-26 15:07:38 --> Loader Class Initialized
INFO - 2020-10-26 15:07:38 --> Helper loaded: url_helper
INFO - 2020-10-26 15:07:38 --> Helper loaded: form_helper
INFO - 2020-10-26 15:07:38 --> Helper loaded: html_helper
INFO - 2020-10-26 15:07:38 --> Helper loaded: date_helper
INFO - 2020-10-26 15:07:38 --> Database Driver Class Initialized
INFO - 2020-10-26 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:07:38 --> Table Class Initialized
INFO - 2020-10-26 15:07:38 --> Upload Class Initialized
INFO - 2020-10-26 15:07:38 --> Controller Class Initialized
INFO - 2020-10-26 15:07:38 --> Form Validation Class Initialized
INFO - 2020-10-26 15:07:38 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:07:38 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:07:38 --> Final output sent to browser
DEBUG - 2020-10-26 15:07:38 --> Total execution time: 0.5885
INFO - 2020-10-26 15:07:44 --> Config Class Initialized
INFO - 2020-10-26 15:07:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:44 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:44 --> URI Class Initialized
INFO - 2020-10-26 15:07:44 --> Router Class Initialized
INFO - 2020-10-26 15:07:44 --> Output Class Initialized
INFO - 2020-10-26 15:07:44 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:44 --> Input Class Initialized
INFO - 2020-10-26 15:07:44 --> Language Class Initialized
INFO - 2020-10-26 15:07:44 --> Loader Class Initialized
INFO - 2020-10-26 15:07:44 --> Helper loaded: url_helper
INFO - 2020-10-26 15:07:44 --> Helper loaded: form_helper
INFO - 2020-10-26 15:07:44 --> Helper loaded: html_helper
INFO - 2020-10-26 15:07:44 --> Helper loaded: date_helper
INFO - 2020-10-26 15:07:44 --> Database Driver Class Initialized
INFO - 2020-10-26 15:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:07:44 --> Table Class Initialized
INFO - 2020-10-26 15:07:44 --> Upload Class Initialized
INFO - 2020-10-26 15:07:44 --> Controller Class Initialized
INFO - 2020-10-26 15:07:44 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:07:44 --> Config Class Initialized
INFO - 2020-10-26 15:07:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:07:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:07:44 --> Utf8 Class Initialized
INFO - 2020-10-26 15:07:44 --> URI Class Initialized
INFO - 2020-10-26 15:07:44 --> Router Class Initialized
INFO - 2020-10-26 15:07:44 --> Output Class Initialized
INFO - 2020-10-26 15:07:44 --> Security Class Initialized
DEBUG - 2020-10-26 15:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:07:44 --> Input Class Initialized
INFO - 2020-10-26 15:07:44 --> Language Class Initialized
ERROR - 2020-10-26 15:07:44 --> 404 Page Not Found: Paginas/prueba
INFO - 2020-10-26 15:09:42 --> Config Class Initialized
INFO - 2020-10-26 15:09:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:09:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:09:42 --> Utf8 Class Initialized
INFO - 2020-10-26 15:09:42 --> URI Class Initialized
DEBUG - 2020-10-26 15:09:42 --> No URI present. Default controller set.
INFO - 2020-10-26 15:09:42 --> Router Class Initialized
INFO - 2020-10-26 15:09:42 --> Output Class Initialized
INFO - 2020-10-26 15:09:42 --> Security Class Initialized
DEBUG - 2020-10-26 15:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:09:42 --> Input Class Initialized
INFO - 2020-10-26 15:09:42 --> Language Class Initialized
ERROR - 2020-10-26 15:09:42 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:09:43 --> Config Class Initialized
INFO - 2020-10-26 15:09:43 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:09:43 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:09:43 --> Utf8 Class Initialized
INFO - 2020-10-26 15:09:43 --> URI Class Initialized
DEBUG - 2020-10-26 15:09:43 --> No URI present. Default controller set.
INFO - 2020-10-26 15:09:43 --> Router Class Initialized
INFO - 2020-10-26 15:09:43 --> Output Class Initialized
INFO - 2020-10-26 15:09:43 --> Security Class Initialized
DEBUG - 2020-10-26 15:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:09:43 --> Input Class Initialized
INFO - 2020-10-26 15:09:43 --> Language Class Initialized
ERROR - 2020-10-26 15:09:43 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:09:46 --> Config Class Initialized
INFO - 2020-10-26 15:09:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:09:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:09:46 --> Utf8 Class Initialized
INFO - 2020-10-26 15:09:46 --> URI Class Initialized
INFO - 2020-10-26 15:09:46 --> Router Class Initialized
INFO - 2020-10-26 15:09:46 --> Output Class Initialized
INFO - 2020-10-26 15:09:46 --> Security Class Initialized
DEBUG - 2020-10-26 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:09:46 --> Input Class Initialized
INFO - 2020-10-26 15:09:46 --> Language Class Initialized
ERROR - 2020-10-26 15:09:46 --> 404 Page Not Found: Welcome/HNAP1
INFO - 2020-10-26 15:10:10 --> Config Class Initialized
INFO - 2020-10-26 15:10:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:10 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:10 --> URI Class Initialized
INFO - 2020-10-26 15:10:10 --> Router Class Initialized
INFO - 2020-10-26 15:10:10 --> Output Class Initialized
INFO - 2020-10-26 15:10:10 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:10 --> Input Class Initialized
INFO - 2020-10-26 15:10:10 --> Language Class Initialized
ERROR - 2020-10-26 15:10:10 --> 404 Page Not Found: Paginas/prueba
INFO - 2020-10-26 15:10:11 --> Config Class Initialized
INFO - 2020-10-26 15:10:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:11 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:11 --> URI Class Initialized
INFO - 2020-10-26 15:10:11 --> Router Class Initialized
INFO - 2020-10-26 15:10:11 --> Output Class Initialized
INFO - 2020-10-26 15:10:11 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:11 --> Input Class Initialized
INFO - 2020-10-26 15:10:11 --> Language Class Initialized
ERROR - 2020-10-26 15:10:11 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 15:10:12 --> Config Class Initialized
INFO - 2020-10-26 15:10:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:12 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:12 --> URI Class Initialized
INFO - 2020-10-26 15:10:12 --> Router Class Initialized
INFO - 2020-10-26 15:10:12 --> Output Class Initialized
INFO - 2020-10-26 15:10:12 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:12 --> Input Class Initialized
INFO - 2020-10-26 15:10:12 --> Language Class Initialized
INFO - 2020-10-26 15:10:12 --> Loader Class Initialized
INFO - 2020-10-26 15:10:12 --> Helper loaded: url_helper
INFO - 2020-10-26 15:10:12 --> Helper loaded: form_helper
INFO - 2020-10-26 15:10:12 --> Helper loaded: html_helper
INFO - 2020-10-26 15:10:12 --> Helper loaded: date_helper
INFO - 2020-10-26 15:10:12 --> Database Driver Class Initialized
INFO - 2020-10-26 15:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:10:12 --> Table Class Initialized
INFO - 2020-10-26 15:10:12 --> Upload Class Initialized
INFO - 2020-10-26 15:10:12 --> Controller Class Initialized
INFO - 2020-10-26 15:10:12 --> Form Validation Class Initialized
INFO - 2020-10-26 15:10:12 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:10:12 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:10:12 --> Final output sent to browser
DEBUG - 2020-10-26 15:10:12 --> Total execution time: 0.5679
INFO - 2020-10-26 15:10:14 --> Config Class Initialized
INFO - 2020-10-26 15:10:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:14 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:14 --> URI Class Initialized
INFO - 2020-10-26 15:10:14 --> Router Class Initialized
INFO - 2020-10-26 15:10:14 --> Output Class Initialized
INFO - 2020-10-26 15:10:14 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:14 --> Input Class Initialized
INFO - 2020-10-26 15:10:14 --> Language Class Initialized
INFO - 2020-10-26 15:10:14 --> Loader Class Initialized
INFO - 2020-10-26 15:10:14 --> Helper loaded: url_helper
INFO - 2020-10-26 15:10:14 --> Helper loaded: form_helper
INFO - 2020-10-26 15:10:14 --> Helper loaded: html_helper
INFO - 2020-10-26 15:10:14 --> Helper loaded: date_helper
INFO - 2020-10-26 15:10:15 --> Database Driver Class Initialized
INFO - 2020-10-26 15:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:10:15 --> Table Class Initialized
INFO - 2020-10-26 15:10:15 --> Upload Class Initialized
INFO - 2020-10-26 15:10:15 --> Controller Class Initialized
INFO - 2020-10-26 15:10:15 --> Form Validation Class Initialized
INFO - 2020-10-26 15:10:15 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:10:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:10:15 --> Final output sent to browser
DEBUG - 2020-10-26 15:10:15 --> Total execution time: 0.7718
INFO - 2020-10-26 15:10:16 --> Config Class Initialized
INFO - 2020-10-26 15:10:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:16 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:16 --> URI Class Initialized
INFO - 2020-10-26 15:10:16 --> Router Class Initialized
INFO - 2020-10-26 15:10:16 --> Output Class Initialized
INFO - 2020-10-26 15:10:16 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:16 --> Input Class Initialized
INFO - 2020-10-26 15:10:16 --> Language Class Initialized
ERROR - 2020-10-26 15:10:16 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 15:10:17 --> Config Class Initialized
INFO - 2020-10-26 15:10:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:17 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:17 --> URI Class Initialized
INFO - 2020-10-26 15:10:17 --> Router Class Initialized
INFO - 2020-10-26 15:10:17 --> Output Class Initialized
INFO - 2020-10-26 15:10:17 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:17 --> Input Class Initialized
INFO - 2020-10-26 15:10:17 --> Language Class Initialized
INFO - 2020-10-26 15:10:17 --> Loader Class Initialized
INFO - 2020-10-26 15:10:17 --> Helper loaded: url_helper
INFO - 2020-10-26 15:10:17 --> Helper loaded: form_helper
INFO - 2020-10-26 15:10:17 --> Helper loaded: html_helper
INFO - 2020-10-26 15:10:17 --> Helper loaded: date_helper
INFO - 2020-10-26 15:10:17 --> Database Driver Class Initialized
INFO - 2020-10-26 15:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:10:17 --> Table Class Initialized
INFO - 2020-10-26 15:10:17 --> Upload Class Initialized
INFO - 2020-10-26 15:10:17 --> Controller Class Initialized
INFO - 2020-10-26 15:10:17 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:10:17 --> Config Class Initialized
INFO - 2020-10-26 15:10:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:17 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:17 --> URI Class Initialized
DEBUG - 2020-10-26 15:10:17 --> No URI present. Default controller set.
INFO - 2020-10-26 15:10:17 --> Router Class Initialized
INFO - 2020-10-26 15:10:17 --> Output Class Initialized
INFO - 2020-10-26 15:10:18 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:18 --> Input Class Initialized
INFO - 2020-10-26 15:10:18 --> Language Class Initialized
ERROR - 2020-10-26 15:10:18 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:10:27 --> Config Class Initialized
INFO - 2020-10-26 15:10:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:27 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:27 --> URI Class Initialized
INFO - 2020-10-26 15:10:27 --> Router Class Initialized
INFO - 2020-10-26 15:10:27 --> Output Class Initialized
INFO - 2020-10-26 15:10:27 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:27 --> Input Class Initialized
INFO - 2020-10-26 15:10:27 --> Language Class Initialized
INFO - 2020-10-26 15:10:27 --> Loader Class Initialized
INFO - 2020-10-26 15:10:27 --> Helper loaded: url_helper
INFO - 2020-10-26 15:10:27 --> Helper loaded: form_helper
INFO - 2020-10-26 15:10:27 --> Helper loaded: html_helper
INFO - 2020-10-26 15:10:27 --> Helper loaded: date_helper
INFO - 2020-10-26 15:10:27 --> Database Driver Class Initialized
INFO - 2020-10-26 15:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:10:27 --> Table Class Initialized
INFO - 2020-10-26 15:10:27 --> Upload Class Initialized
INFO - 2020-10-26 15:10:27 --> Controller Class Initialized
INFO - 2020-10-26 15:10:27 --> Form Validation Class Initialized
INFO - 2020-10-26 15:10:27 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:10:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:10:27 --> Final output sent to browser
DEBUG - 2020-10-26 15:10:27 --> Total execution time: 0.5844
INFO - 2020-10-26 15:10:34 --> Config Class Initialized
INFO - 2020-10-26 15:10:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:34 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:34 --> URI Class Initialized
INFO - 2020-10-26 15:10:34 --> Router Class Initialized
INFO - 2020-10-26 15:10:34 --> Output Class Initialized
INFO - 2020-10-26 15:10:34 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:34 --> Input Class Initialized
INFO - 2020-10-26 15:10:34 --> Language Class Initialized
INFO - 2020-10-26 15:10:34 --> Loader Class Initialized
INFO - 2020-10-26 15:10:34 --> Helper loaded: url_helper
INFO - 2020-10-26 15:10:34 --> Helper loaded: form_helper
INFO - 2020-10-26 15:10:34 --> Helper loaded: html_helper
INFO - 2020-10-26 15:10:34 --> Helper loaded: date_helper
INFO - 2020-10-26 15:10:34 --> Database Driver Class Initialized
INFO - 2020-10-26 15:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:10:34 --> Table Class Initialized
INFO - 2020-10-26 15:10:34 --> Upload Class Initialized
INFO - 2020-10-26 15:10:34 --> Controller Class Initialized
INFO - 2020-10-26 15:10:34 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:10:34 --> Config Class Initialized
INFO - 2020-10-26 15:10:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:10:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:10:34 --> Utf8 Class Initialized
INFO - 2020-10-26 15:10:34 --> URI Class Initialized
DEBUG - 2020-10-26 15:10:35 --> No URI present. Default controller set.
INFO - 2020-10-26 15:10:35 --> Router Class Initialized
INFO - 2020-10-26 15:10:35 --> Output Class Initialized
INFO - 2020-10-26 15:10:35 --> Security Class Initialized
DEBUG - 2020-10-26 15:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:10:35 --> Input Class Initialized
INFO - 2020-10-26 15:10:35 --> Language Class Initialized
ERROR - 2020-10-26 15:10:35 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:11:17 --> Config Class Initialized
INFO - 2020-10-26 15:11:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:11:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:11:17 --> Utf8 Class Initialized
INFO - 2020-10-26 15:11:17 --> URI Class Initialized
INFO - 2020-10-26 15:11:17 --> Router Class Initialized
INFO - 2020-10-26 15:11:17 --> Output Class Initialized
INFO - 2020-10-26 15:11:17 --> Security Class Initialized
DEBUG - 2020-10-26 15:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:11:17 --> Input Class Initialized
INFO - 2020-10-26 15:11:17 --> Language Class Initialized
INFO - 2020-10-26 15:11:17 --> Loader Class Initialized
INFO - 2020-10-26 15:11:17 --> Helper loaded: url_helper
INFO - 2020-10-26 15:11:18 --> Helper loaded: form_helper
INFO - 2020-10-26 15:11:18 --> Helper loaded: html_helper
INFO - 2020-10-26 15:11:18 --> Helper loaded: date_helper
INFO - 2020-10-26 15:11:18 --> Database Driver Class Initialized
INFO - 2020-10-26 15:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:11:18 --> Table Class Initialized
INFO - 2020-10-26 15:11:18 --> Upload Class Initialized
INFO - 2020-10-26 15:11:18 --> Controller Class Initialized
INFO - 2020-10-26 15:11:18 --> Form Validation Class Initialized
INFO - 2020-10-26 15:11:18 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:11:18 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:11:18 --> Final output sent to browser
DEBUG - 2020-10-26 15:11:18 --> Total execution time: 0.7002
INFO - 2020-10-26 15:11:20 --> Config Class Initialized
INFO - 2020-10-26 15:11:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:11:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:11:20 --> Utf8 Class Initialized
INFO - 2020-10-26 15:11:20 --> URI Class Initialized
INFO - 2020-10-26 15:11:20 --> Router Class Initialized
INFO - 2020-10-26 15:11:20 --> Output Class Initialized
INFO - 2020-10-26 15:11:20 --> Security Class Initialized
DEBUG - 2020-10-26 15:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:11:20 --> Input Class Initialized
INFO - 2020-10-26 15:11:20 --> Language Class Initialized
INFO - 2020-10-26 15:11:20 --> Loader Class Initialized
INFO - 2020-10-26 15:11:20 --> Helper loaded: url_helper
INFO - 2020-10-26 15:11:20 --> Helper loaded: form_helper
INFO - 2020-10-26 15:11:20 --> Helper loaded: html_helper
INFO - 2020-10-26 15:11:20 --> Helper loaded: date_helper
INFO - 2020-10-26 15:11:20 --> Database Driver Class Initialized
INFO - 2020-10-26 15:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:11:20 --> Table Class Initialized
INFO - 2020-10-26 15:11:20 --> Upload Class Initialized
INFO - 2020-10-26 15:11:20 --> Controller Class Initialized
INFO - 2020-10-26 15:11:20 --> Form Validation Class Initialized
INFO - 2020-10-26 15:11:20 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:11:21 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:11:21 --> Final output sent to browser
DEBUG - 2020-10-26 15:11:21 --> Total execution time: 0.9351
INFO - 2020-10-26 15:11:22 --> Config Class Initialized
INFO - 2020-10-26 15:11:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:11:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:11:22 --> Utf8 Class Initialized
INFO - 2020-10-26 15:11:22 --> URI Class Initialized
INFO - 2020-10-26 15:11:22 --> Router Class Initialized
INFO - 2020-10-26 15:11:22 --> Output Class Initialized
INFO - 2020-10-26 15:11:22 --> Security Class Initialized
DEBUG - 2020-10-26 15:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:11:22 --> Input Class Initialized
INFO - 2020-10-26 15:11:22 --> Language Class Initialized
ERROR - 2020-10-26 15:11:22 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 15:11:23 --> Config Class Initialized
INFO - 2020-10-26 15:11:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:11:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:11:23 --> Utf8 Class Initialized
INFO - 2020-10-26 15:11:23 --> URI Class Initialized
INFO - 2020-10-26 15:11:24 --> Router Class Initialized
INFO - 2020-10-26 15:11:24 --> Output Class Initialized
INFO - 2020-10-26 15:11:24 --> Security Class Initialized
DEBUG - 2020-10-26 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:11:24 --> Input Class Initialized
INFO - 2020-10-26 15:11:24 --> Language Class Initialized
INFO - 2020-10-26 15:11:24 --> Loader Class Initialized
INFO - 2020-10-26 15:11:24 --> Helper loaded: url_helper
INFO - 2020-10-26 15:11:24 --> Helper loaded: form_helper
INFO - 2020-10-26 15:11:24 --> Helper loaded: html_helper
INFO - 2020-10-26 15:11:24 --> Helper loaded: date_helper
INFO - 2020-10-26 15:11:24 --> Database Driver Class Initialized
INFO - 2020-10-26 15:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:11:24 --> Table Class Initialized
INFO - 2020-10-26 15:11:24 --> Upload Class Initialized
INFO - 2020-10-26 15:11:24 --> Controller Class Initialized
INFO - 2020-10-26 15:11:24 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:11:24 --> Config Class Initialized
INFO - 2020-10-26 15:11:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:11:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:11:24 --> Utf8 Class Initialized
INFO - 2020-10-26 15:11:24 --> URI Class Initialized
DEBUG - 2020-10-26 15:11:24 --> No URI present. Default controller set.
INFO - 2020-10-26 15:11:24 --> Router Class Initialized
INFO - 2020-10-26 15:11:24 --> Output Class Initialized
INFO - 2020-10-26 15:11:24 --> Security Class Initialized
DEBUG - 2020-10-26 15:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:11:24 --> Input Class Initialized
INFO - 2020-10-26 15:11:24 --> Language Class Initialized
ERROR - 2020-10-26 15:11:24 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-26 15:14:40 --> Config Class Initialized
INFO - 2020-10-26 15:14:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:14:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:14:40 --> Utf8 Class Initialized
INFO - 2020-10-26 15:14:40 --> URI Class Initialized
DEBUG - 2020-10-26 15:14:40 --> No URI present. Default controller set.
INFO - 2020-10-26 15:14:40 --> Router Class Initialized
INFO - 2020-10-26 15:14:40 --> Output Class Initialized
INFO - 2020-10-26 15:14:40 --> Security Class Initialized
DEBUG - 2020-10-26 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:14:40 --> Input Class Initialized
INFO - 2020-10-26 15:14:40 --> Language Class Initialized
INFO - 2020-10-26 15:14:40 --> Loader Class Initialized
INFO - 2020-10-26 15:14:40 --> Helper loaded: url_helper
INFO - 2020-10-26 15:14:40 --> Helper loaded: form_helper
INFO - 2020-10-26 15:14:40 --> Helper loaded: html_helper
INFO - 2020-10-26 15:14:40 --> Helper loaded: date_helper
INFO - 2020-10-26 15:14:40 --> Database Driver Class Initialized
INFO - 2020-10-26 15:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:14:40 --> Table Class Initialized
INFO - 2020-10-26 15:14:40 --> Upload Class Initialized
INFO - 2020-10-26 15:14:40 --> Controller Class Initialized
INFO - 2020-10-26 15:14:40 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:14:40 --> Config Class Initialized
INFO - 2020-10-26 15:14:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:14:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:14:40 --> Utf8 Class Initialized
INFO - 2020-10-26 15:14:40 --> URI Class Initialized
INFO - 2020-10-26 15:14:40 --> Router Class Initialized
INFO - 2020-10-26 15:14:40 --> Output Class Initialized
INFO - 2020-10-26 15:14:40 --> Security Class Initialized
DEBUG - 2020-10-26 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:14:40 --> Input Class Initialized
INFO - 2020-10-26 15:14:40 --> Language Class Initialized
ERROR - 2020-10-26 15:14:40 --> 404 Page Not Found: Welcome/dashboard
INFO - 2020-10-26 15:14:44 --> Config Class Initialized
INFO - 2020-10-26 15:14:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:14:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:14:44 --> Utf8 Class Initialized
INFO - 2020-10-26 15:14:44 --> URI Class Initialized
DEBUG - 2020-10-26 15:14:44 --> No URI present. Default controller set.
INFO - 2020-10-26 15:14:44 --> Router Class Initialized
INFO - 2020-10-26 15:14:44 --> Output Class Initialized
INFO - 2020-10-26 15:14:44 --> Security Class Initialized
DEBUG - 2020-10-26 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:14:44 --> Input Class Initialized
INFO - 2020-10-26 15:14:44 --> Language Class Initialized
INFO - 2020-10-26 15:14:44 --> Loader Class Initialized
INFO - 2020-10-26 15:14:44 --> Helper loaded: url_helper
INFO - 2020-10-26 15:14:45 --> Helper loaded: form_helper
INFO - 2020-10-26 15:14:45 --> Helper loaded: html_helper
INFO - 2020-10-26 15:14:45 --> Helper loaded: date_helper
INFO - 2020-10-26 15:14:45 --> Database Driver Class Initialized
INFO - 2020-10-26 15:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:14:45 --> Table Class Initialized
INFO - 2020-10-26 15:14:45 --> Upload Class Initialized
INFO - 2020-10-26 15:14:45 --> Controller Class Initialized
INFO - 2020-10-26 15:14:45 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:14:45 --> Config Class Initialized
INFO - 2020-10-26 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-26 15:14:45 --> URI Class Initialized
INFO - 2020-10-26 15:14:45 --> Router Class Initialized
INFO - 2020-10-26 15:14:45 --> Output Class Initialized
INFO - 2020-10-26 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-26 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:14:45 --> Input Class Initialized
INFO - 2020-10-26 15:14:45 --> Language Class Initialized
ERROR - 2020-10-26 15:14:45 --> 404 Page Not Found: Welcome/dashboard
INFO - 2020-10-26 15:14:52 --> Config Class Initialized
INFO - 2020-10-26 15:14:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:14:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:14:52 --> Utf8 Class Initialized
INFO - 2020-10-26 15:14:52 --> URI Class Initialized
INFO - 2020-10-26 15:14:52 --> Router Class Initialized
INFO - 2020-10-26 15:14:52 --> Output Class Initialized
INFO - 2020-10-26 15:14:52 --> Security Class Initialized
DEBUG - 2020-10-26 15:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:14:52 --> Input Class Initialized
INFO - 2020-10-26 15:14:52 --> Language Class Initialized
ERROR - 2020-10-26 15:14:52 --> 404 Page Not Found: Welcome/dashboard
INFO - 2020-10-26 15:14:53 --> Config Class Initialized
INFO - 2020-10-26 15:14:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:14:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:14:53 --> Utf8 Class Initialized
INFO - 2020-10-26 15:14:53 --> URI Class Initialized
INFO - 2020-10-26 15:14:53 --> Router Class Initialized
INFO - 2020-10-26 15:14:53 --> Output Class Initialized
INFO - 2020-10-26 15:14:53 --> Security Class Initialized
DEBUG - 2020-10-26 15:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:14:53 --> Input Class Initialized
INFO - 2020-10-26 15:14:53 --> Language Class Initialized
ERROR - 2020-10-26 15:14:53 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 15:15:19 --> Config Class Initialized
INFO - 2020-10-26 15:15:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:19 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:19 --> URI Class Initialized
INFO - 2020-10-26 15:15:19 --> Router Class Initialized
INFO - 2020-10-26 15:15:19 --> Output Class Initialized
INFO - 2020-10-26 15:15:19 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:19 --> Input Class Initialized
INFO - 2020-10-26 15:15:19 --> Language Class Initialized
ERROR - 2020-10-26 15:15:19 --> 404 Page Not Found: Welcome/dashboard
INFO - 2020-10-26 15:15:23 --> Config Class Initialized
INFO - 2020-10-26 15:15:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:23 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:23 --> URI Class Initialized
DEBUG - 2020-10-26 15:15:23 --> No URI present. Default controller set.
INFO - 2020-10-26 15:15:23 --> Router Class Initialized
INFO - 2020-10-26 15:15:23 --> Output Class Initialized
INFO - 2020-10-26 15:15:23 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:23 --> Input Class Initialized
INFO - 2020-10-26 15:15:23 --> Language Class Initialized
INFO - 2020-10-26 15:15:23 --> Loader Class Initialized
INFO - 2020-10-26 15:15:23 --> Helper loaded: url_helper
INFO - 2020-10-26 15:15:23 --> Helper loaded: form_helper
INFO - 2020-10-26 15:15:23 --> Helper loaded: html_helper
INFO - 2020-10-26 15:15:23 --> Helper loaded: date_helper
INFO - 2020-10-26 15:15:23 --> Database Driver Class Initialized
INFO - 2020-10-26 15:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:15:23 --> Table Class Initialized
INFO - 2020-10-26 15:15:23 --> Upload Class Initialized
INFO - 2020-10-26 15:15:23 --> Controller Class Initialized
INFO - 2020-10-26 15:15:24 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:15:24 --> Config Class Initialized
INFO - 2020-10-26 15:15:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:24 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:24 --> URI Class Initialized
INFO - 2020-10-26 15:15:24 --> Router Class Initialized
INFO - 2020-10-26 15:15:24 --> Output Class Initialized
INFO - 2020-10-26 15:15:24 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:24 --> Input Class Initialized
INFO - 2020-10-26 15:15:24 --> Language Class Initialized
ERROR - 2020-10-26 15:15:24 --> 404 Page Not Found: Welcome/dashboard
INFO - 2020-10-26 15:15:35 --> Config Class Initialized
INFO - 2020-10-26 15:15:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:35 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:35 --> URI Class Initialized
INFO - 2020-10-26 15:15:35 --> Router Class Initialized
INFO - 2020-10-26 15:15:35 --> Output Class Initialized
INFO - 2020-10-26 15:15:35 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:35 --> Input Class Initialized
INFO - 2020-10-26 15:15:35 --> Language Class Initialized
ERROR - 2020-10-26 15:15:35 --> 404 Page Not Found: Welcome/dashboard
INFO - 2020-10-26 15:15:39 --> Config Class Initialized
INFO - 2020-10-26 15:15:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:39 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:39 --> URI Class Initialized
DEBUG - 2020-10-26 15:15:39 --> No URI present. Default controller set.
INFO - 2020-10-26 15:15:39 --> Router Class Initialized
INFO - 2020-10-26 15:15:39 --> Output Class Initialized
INFO - 2020-10-26 15:15:39 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:39 --> Input Class Initialized
INFO - 2020-10-26 15:15:39 --> Language Class Initialized
INFO - 2020-10-26 15:15:39 --> Loader Class Initialized
INFO - 2020-10-26 15:15:39 --> Helper loaded: url_helper
INFO - 2020-10-26 15:15:39 --> Helper loaded: form_helper
INFO - 2020-10-26 15:15:39 --> Helper loaded: html_helper
INFO - 2020-10-26 15:15:39 --> Helper loaded: date_helper
INFO - 2020-10-26 15:15:39 --> Database Driver Class Initialized
INFO - 2020-10-26 15:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:15:39 --> Table Class Initialized
INFO - 2020-10-26 15:15:39 --> Upload Class Initialized
INFO - 2020-10-26 15:15:39 --> Controller Class Initialized
INFO - 2020-10-26 15:15:39 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:15:39 --> Config Class Initialized
INFO - 2020-10-26 15:15:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:39 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:39 --> URI Class Initialized
INFO - 2020-10-26 15:15:39 --> Router Class Initialized
INFO - 2020-10-26 15:15:40 --> Output Class Initialized
INFO - 2020-10-26 15:15:40 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:40 --> Input Class Initialized
INFO - 2020-10-26 15:15:40 --> Language Class Initialized
INFO - 2020-10-26 15:15:40 --> Loader Class Initialized
INFO - 2020-10-26 15:15:40 --> Helper loaded: url_helper
INFO - 2020-10-26 15:15:40 --> Helper loaded: form_helper
INFO - 2020-10-26 15:15:40 --> Helper loaded: html_helper
INFO - 2020-10-26 15:15:40 --> Helper loaded: date_helper
INFO - 2020-10-26 15:15:40 --> Database Driver Class Initialized
INFO - 2020-10-26 15:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:15:40 --> Table Class Initialized
INFO - 2020-10-26 15:15:40 --> Upload Class Initialized
INFO - 2020-10-26 15:15:40 --> Controller Class Initialized
INFO - 2020-10-26 15:15:40 --> Form Validation Class Initialized
INFO - 2020-10-26 15:15:40 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:15:40 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 15:15:40 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 15:15:40 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 15:15:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 15:15:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 15:15:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 15:15:40 --> Final output sent to browser
DEBUG - 2020-10-26 15:15:40 --> Total execution time: 0.7570
INFO - 2020-10-26 15:15:40 --> Config Class Initialized
INFO - 2020-10-26 15:15:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:40 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:40 --> URI Class Initialized
INFO - 2020-10-26 15:15:40 --> Config Class Initialized
INFO - 2020-10-26 15:15:40 --> Router Class Initialized
INFO - 2020-10-26 15:15:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:40 --> Output Class Initialized
INFO - 2020-10-26 15:15:40 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:40 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:40 --> URI Class Initialized
INFO - 2020-10-26 15:15:41 --> Router Class Initialized
INFO - 2020-10-26 15:15:41 --> Input Class Initialized
INFO - 2020-10-26 15:15:41 --> Output Class Initialized
INFO - 2020-10-26 15:15:41 --> Language Class Initialized
INFO - 2020-10-26 15:15:41 --> Security Class Initialized
ERROR - 2020-10-26 15:15:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 15:15:41 --> Config Class Initialized
DEBUG - 2020-10-26 15:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:41 --> Hooks Class Initialized
INFO - 2020-10-26 15:15:41 --> Input Class Initialized
INFO - 2020-10-26 15:15:41 --> Language Class Initialized
DEBUG - 2020-10-26 15:15:41 --> UTF-8 Support Enabled
ERROR - 2020-10-26 15:15:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:15:41 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:41 --> URI Class Initialized
INFO - 2020-10-26 15:15:41 --> Router Class Initialized
INFO - 2020-10-26 15:15:41 --> Output Class Initialized
INFO - 2020-10-26 15:15:41 --> Config Class Initialized
INFO - 2020-10-26 15:15:41 --> Hooks Class Initialized
INFO - 2020-10-26 15:15:41 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 15:15:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:41 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:41 --> Input Class Initialized
INFO - 2020-10-26 15:15:41 --> URI Class Initialized
INFO - 2020-10-26 15:15:41 --> Language Class Initialized
INFO - 2020-10-26 15:15:41 --> Router Class Initialized
ERROR - 2020-10-26 15:15:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:15:41 --> Output Class Initialized
INFO - 2020-10-26 15:15:41 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:41 --> Input Class Initialized
INFO - 2020-10-26 15:15:41 --> Language Class Initialized
INFO - 2020-10-26 15:15:41 --> Loader Class Initialized
INFO - 2020-10-26 15:15:41 --> Helper loaded: url_helper
INFO - 2020-10-26 15:15:41 --> Helper loaded: form_helper
INFO - 2020-10-26 15:15:41 --> Helper loaded: html_helper
INFO - 2020-10-26 15:15:41 --> Helper loaded: date_helper
INFO - 2020-10-26 15:15:41 --> Database Driver Class Initialized
INFO - 2020-10-26 15:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:15:41 --> Table Class Initialized
INFO - 2020-10-26 15:15:41 --> Upload Class Initialized
INFO - 2020-10-26 15:15:41 --> Controller Class Initialized
INFO - 2020-10-26 15:15:41 --> Form Validation Class Initialized
INFO - 2020-10-26 15:15:41 --> Model "Crud_model" initialized
ERROR - 2020-10-26 15:15:41 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 15:15:41 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 15:15:42 --> Config Class Initialized
INFO - 2020-10-26 15:15:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:42 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:42 --> URI Class Initialized
INFO - 2020-10-26 15:15:42 --> Router Class Initialized
INFO - 2020-10-26 15:15:42 --> Output Class Initialized
INFO - 2020-10-26 15:15:42 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:42 --> Input Class Initialized
INFO - 2020-10-26 15:15:42 --> Language Class Initialized
ERROR - 2020-10-26 15:15:42 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:15:42 --> Config Class Initialized
INFO - 2020-10-26 15:15:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:42 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:42 --> URI Class Initialized
INFO - 2020-10-26 15:15:42 --> Router Class Initialized
INFO - 2020-10-26 15:15:42 --> Output Class Initialized
INFO - 2020-10-26 15:15:42 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:42 --> Input Class Initialized
INFO - 2020-10-26 15:15:42 --> Language Class Initialized
ERROR - 2020-10-26 15:15:42 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 15:15:47 --> Config Class Initialized
INFO - 2020-10-26 15:15:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:48 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:48 --> URI Class Initialized
DEBUG - 2020-10-26 15:15:48 --> No URI present. Default controller set.
INFO - 2020-10-26 15:15:48 --> Router Class Initialized
INFO - 2020-10-26 15:15:48 --> Output Class Initialized
INFO - 2020-10-26 15:15:48 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:48 --> Input Class Initialized
INFO - 2020-10-26 15:15:48 --> Language Class Initialized
INFO - 2020-10-26 15:15:48 --> Loader Class Initialized
INFO - 2020-10-26 15:15:48 --> Helper loaded: url_helper
INFO - 2020-10-26 15:15:48 --> Helper loaded: form_helper
INFO - 2020-10-26 15:15:48 --> Helper loaded: html_helper
INFO - 2020-10-26 15:15:48 --> Helper loaded: date_helper
INFO - 2020-10-26 15:15:48 --> Database Driver Class Initialized
INFO - 2020-10-26 15:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:15:48 --> Table Class Initialized
INFO - 2020-10-26 15:15:48 --> Upload Class Initialized
INFO - 2020-10-26 15:15:48 --> Controller Class Initialized
INFO - 2020-10-26 15:15:48 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:15:48 --> Config Class Initialized
INFO - 2020-10-26 15:15:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:48 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:48 --> URI Class Initialized
INFO - 2020-10-26 15:15:48 --> Router Class Initialized
INFO - 2020-10-26 15:15:48 --> Output Class Initialized
INFO - 2020-10-26 15:15:48 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:48 --> Input Class Initialized
INFO - 2020-10-26 15:15:48 --> Language Class Initialized
INFO - 2020-10-26 15:15:48 --> Loader Class Initialized
INFO - 2020-10-26 15:15:48 --> Helper loaded: url_helper
INFO - 2020-10-26 15:15:48 --> Helper loaded: form_helper
INFO - 2020-10-26 15:15:49 --> Helper loaded: html_helper
INFO - 2020-10-26 15:15:49 --> Helper loaded: date_helper
INFO - 2020-10-26 15:15:49 --> Database Driver Class Initialized
INFO - 2020-10-26 15:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:15:49 --> Table Class Initialized
INFO - 2020-10-26 15:15:49 --> Upload Class Initialized
INFO - 2020-10-26 15:15:49 --> Controller Class Initialized
INFO - 2020-10-26 15:15:49 --> Form Validation Class Initialized
INFO - 2020-10-26 15:15:49 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:15:49 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 15:15:49 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 15:15:49 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 15:15:49 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 15:15:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 15:15:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 15:15:49 --> Final output sent to browser
DEBUG - 2020-10-26 15:15:49 --> Total execution time: 0.7783
INFO - 2020-10-26 15:15:49 --> Config Class Initialized
INFO - 2020-10-26 15:15:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:49 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:49 --> Config Class Initialized
INFO - 2020-10-26 15:15:49 --> URI Class Initialized
INFO - 2020-10-26 15:15:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:15:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:49 --> Router Class Initialized
INFO - 2020-10-26 15:15:49 --> Output Class Initialized
INFO - 2020-10-26 15:15:49 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:49 --> URI Class Initialized
INFO - 2020-10-26 15:15:49 --> Security Class Initialized
INFO - 2020-10-26 15:15:49 --> Router Class Initialized
DEBUG - 2020-10-26 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:49 --> Input Class Initialized
INFO - 2020-10-26 15:15:49 --> Output Class Initialized
INFO - 2020-10-26 15:15:49 --> Security Class Initialized
INFO - 2020-10-26 15:15:49 --> Language Class Initialized
ERROR - 2020-10-26 15:15:49 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:49 --> Config Class Initialized
INFO - 2020-10-26 15:15:49 --> Input Class Initialized
INFO - 2020-10-26 15:15:49 --> Language Class Initialized
INFO - 2020-10-26 15:15:49 --> Hooks Class Initialized
ERROR - 2020-10-26 15:15:49 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 15:15:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:15:49 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:49 --> URI Class Initialized
INFO - 2020-10-26 15:15:49 --> Config Class Initialized
INFO - 2020-10-26 15:15:49 --> Router Class Initialized
INFO - 2020-10-26 15:15:50 --> Hooks Class Initialized
INFO - 2020-10-26 15:15:50 --> Output Class Initialized
INFO - 2020-10-26 15:15:50 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:50 --> Utf8 Class Initialized
INFO - 2020-10-26 15:15:50 --> URI Class Initialized
INFO - 2020-10-26 15:15:50 --> Input Class Initialized
INFO - 2020-10-26 15:15:50 --> Language Class Initialized
INFO - 2020-10-26 15:15:50 --> Router Class Initialized
ERROR - 2020-10-26 15:15:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:15:50 --> Output Class Initialized
INFO - 2020-10-26 15:15:50 --> Security Class Initialized
DEBUG - 2020-10-26 15:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:15:50 --> Input Class Initialized
INFO - 2020-10-26 15:15:50 --> Language Class Initialized
INFO - 2020-10-26 15:15:50 --> Loader Class Initialized
INFO - 2020-10-26 15:15:50 --> Helper loaded: url_helper
INFO - 2020-10-26 15:15:50 --> Helper loaded: form_helper
INFO - 2020-10-26 15:15:50 --> Helper loaded: html_helper
INFO - 2020-10-26 15:15:50 --> Helper loaded: date_helper
INFO - 2020-10-26 15:15:50 --> Database Driver Class Initialized
INFO - 2020-10-26 15:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:15:50 --> Table Class Initialized
INFO - 2020-10-26 15:15:50 --> Upload Class Initialized
INFO - 2020-10-26 15:15:50 --> Controller Class Initialized
INFO - 2020-10-26 15:15:50 --> Form Validation Class Initialized
INFO - 2020-10-26 15:15:50 --> Model "Crud_model" initialized
ERROR - 2020-10-26 15:15:50 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 15:15:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 15:20:36 --> Config Class Initialized
INFO - 2020-10-26 15:20:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:20:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:20:36 --> Utf8 Class Initialized
INFO - 2020-10-26 15:20:36 --> URI Class Initialized
DEBUG - 2020-10-26 15:20:36 --> No URI present. Default controller set.
INFO - 2020-10-26 15:20:36 --> Router Class Initialized
INFO - 2020-10-26 15:20:36 --> Output Class Initialized
INFO - 2020-10-26 15:20:36 --> Security Class Initialized
DEBUG - 2020-10-26 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:20:36 --> Input Class Initialized
INFO - 2020-10-26 15:20:37 --> Language Class Initialized
INFO - 2020-10-26 15:20:37 --> Loader Class Initialized
INFO - 2020-10-26 15:20:37 --> Helper loaded: url_helper
INFO - 2020-10-26 15:20:37 --> Helper loaded: form_helper
INFO - 2020-10-26 15:20:37 --> Helper loaded: html_helper
INFO - 2020-10-26 15:20:37 --> Helper loaded: date_helper
INFO - 2020-10-26 15:20:37 --> Database Driver Class Initialized
INFO - 2020-10-26 15:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:20:37 --> Table Class Initialized
INFO - 2020-10-26 15:20:37 --> Upload Class Initialized
INFO - 2020-10-26 15:20:37 --> Controller Class Initialized
INFO - 2020-10-26 15:20:37 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:20:37 --> Config Class Initialized
INFO - 2020-10-26 15:20:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:20:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:20:37 --> Utf8 Class Initialized
INFO - 2020-10-26 15:20:37 --> URI Class Initialized
DEBUG - 2020-10-26 15:20:37 --> No URI present. Default controller set.
INFO - 2020-10-26 15:20:37 --> Router Class Initialized
INFO - 2020-10-26 15:20:37 --> Output Class Initialized
INFO - 2020-10-26 15:20:37 --> Security Class Initialized
DEBUG - 2020-10-26 15:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:20:37 --> Input Class Initialized
INFO - 2020-10-26 15:20:37 --> Language Class Initialized
INFO - 2020-10-26 15:20:38 --> Loader Class Initialized
INFO - 2020-10-26 15:20:38 --> Helper loaded: url_helper
INFO - 2020-10-26 15:20:38 --> Helper loaded: form_helper
INFO - 2020-10-26 15:20:38 --> Helper loaded: html_helper
INFO - 2020-10-26 15:20:38 --> Helper loaded: date_helper
INFO - 2020-10-26 15:20:38 --> Database Driver Class Initialized
INFO - 2020-10-26 15:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:20:38 --> Table Class Initialized
INFO - 2020-10-26 15:20:38 --> Upload Class Initialized
INFO - 2020-10-26 15:20:38 --> Controller Class Initialized
INFO - 2020-10-26 15:20:38 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:39:08 --> Config Class Initialized
INFO - 2020-10-26 15:39:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:39:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:08 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:08 --> URI Class Initialized
INFO - 2020-10-26 15:39:08 --> Router Class Initialized
INFO - 2020-10-26 15:39:08 --> Output Class Initialized
INFO - 2020-10-26 15:39:08 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:08 --> Input Class Initialized
INFO - 2020-10-26 15:39:08 --> Language Class Initialized
INFO - 2020-10-26 15:39:08 --> Loader Class Initialized
INFO - 2020-10-26 15:39:08 --> Helper loaded: url_helper
INFO - 2020-10-26 15:39:08 --> Helper loaded: form_helper
INFO - 2020-10-26 15:39:08 --> Helper loaded: html_helper
INFO - 2020-10-26 15:39:08 --> Helper loaded: date_helper
INFO - 2020-10-26 15:39:08 --> Database Driver Class Initialized
INFO - 2020-10-26 15:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:39:08 --> Table Class Initialized
INFO - 2020-10-26 15:39:08 --> Upload Class Initialized
INFO - 2020-10-26 15:39:08 --> Controller Class Initialized
INFO - 2020-10-26 15:39:08 --> Form Validation Class Initialized
INFO - 2020-10-26 15:39:08 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:39:08 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 15:39:08 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 15:39:08 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 15:39:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 15:39:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 15:39:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 15:39:08 --> Final output sent to browser
DEBUG - 2020-10-26 15:39:09 --> Total execution time: 0.8308
INFO - 2020-10-26 15:39:09 --> Config Class Initialized
INFO - 2020-10-26 15:39:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:39:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:09 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:09 --> Config Class Initialized
INFO - 2020-10-26 15:39:09 --> URI Class Initialized
INFO - 2020-10-26 15:39:09 --> Hooks Class Initialized
INFO - 2020-10-26 15:39:09 --> Router Class Initialized
DEBUG - 2020-10-26 15:39:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:09 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:09 --> Output Class Initialized
INFO - 2020-10-26 15:39:09 --> URI Class Initialized
INFO - 2020-10-26 15:39:09 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:09 --> Router Class Initialized
INFO - 2020-10-26 15:39:09 --> Input Class Initialized
INFO - 2020-10-26 15:39:09 --> Output Class Initialized
INFO - 2020-10-26 15:39:09 --> Security Class Initialized
INFO - 2020-10-26 15:39:09 --> Language Class Initialized
DEBUG - 2020-10-26 15:39:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-26 15:39:09 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 15:39:09 --> Config Class Initialized
INFO - 2020-10-26 15:39:09 --> Input Class Initialized
INFO - 2020-10-26 15:39:09 --> Language Class Initialized
INFO - 2020-10-26 15:39:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:39:09 --> UTF-8 Support Enabled
ERROR - 2020-10-26 15:39:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:39:09 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:09 --> URI Class Initialized
INFO - 2020-10-26 15:39:09 --> Router Class Initialized
INFO - 2020-10-26 15:39:09 --> Config Class Initialized
INFO - 2020-10-26 15:39:09 --> Hooks Class Initialized
INFO - 2020-10-26 15:39:09 --> Output Class Initialized
INFO - 2020-10-26 15:39:09 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:09 --> Utf8 Class Initialized
DEBUG - 2020-10-26 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:09 --> URI Class Initialized
INFO - 2020-10-26 15:39:09 --> Input Class Initialized
INFO - 2020-10-26 15:39:09 --> Router Class Initialized
INFO - 2020-10-26 15:39:09 --> Language Class Initialized
INFO - 2020-10-26 15:39:09 --> Output Class Initialized
ERROR - 2020-10-26 15:39:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:39:09 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:09 --> Input Class Initialized
INFO - 2020-10-26 15:39:09 --> Language Class Initialized
INFO - 2020-10-26 15:39:09 --> Loader Class Initialized
INFO - 2020-10-26 15:39:09 --> Helper loaded: url_helper
INFO - 2020-10-26 15:39:09 --> Helper loaded: form_helper
INFO - 2020-10-26 15:39:09 --> Helper loaded: html_helper
INFO - 2020-10-26 15:39:09 --> Helper loaded: date_helper
INFO - 2020-10-26 15:39:09 --> Database Driver Class Initialized
INFO - 2020-10-26 15:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:39:09 --> Table Class Initialized
INFO - 2020-10-26 15:39:09 --> Upload Class Initialized
INFO - 2020-10-26 15:39:09 --> Controller Class Initialized
INFO - 2020-10-26 15:39:09 --> Form Validation Class Initialized
INFO - 2020-10-26 15:39:09 --> Model "Crud_model" initialized
ERROR - 2020-10-26 15:39:10 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 15:39:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 15:39:29 --> Config Class Initialized
INFO - 2020-10-26 15:39:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:39:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:29 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:29 --> URI Class Initialized
INFO - 2020-10-26 15:39:29 --> Router Class Initialized
INFO - 2020-10-26 15:39:29 --> Output Class Initialized
INFO - 2020-10-26 15:39:29 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:29 --> Input Class Initialized
INFO - 2020-10-26 15:39:29 --> Language Class Initialized
INFO - 2020-10-26 15:39:29 --> Loader Class Initialized
INFO - 2020-10-26 15:39:29 --> Helper loaded: url_helper
INFO - 2020-10-26 15:39:29 --> Helper loaded: form_helper
INFO - 2020-10-26 15:39:29 --> Helper loaded: html_helper
INFO - 2020-10-26 15:39:29 --> Helper loaded: date_helper
INFO - 2020-10-26 15:39:29 --> Database Driver Class Initialized
INFO - 2020-10-26 15:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:39:29 --> Table Class Initialized
INFO - 2020-10-26 15:39:29 --> Upload Class Initialized
INFO - 2020-10-26 15:39:29 --> Controller Class Initialized
INFO - 2020-10-26 15:39:30 --> Form Validation Class Initialized
INFO - 2020-10-26 15:39:30 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:39:30 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 15:39:30 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 15:39:30 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 15:39:30 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 15:39:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 15:39:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 15:39:30 --> Final output sent to browser
DEBUG - 2020-10-26 15:39:30 --> Total execution time: 0.9448
INFO - 2020-10-26 15:39:30 --> Config Class Initialized
INFO - 2020-10-26 15:39:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:39:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:30 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:30 --> Config Class Initialized
INFO - 2020-10-26 15:39:30 --> Hooks Class Initialized
INFO - 2020-10-26 15:39:30 --> URI Class Initialized
INFO - 2020-10-26 15:39:30 --> Router Class Initialized
DEBUG - 2020-10-26 15:39:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:30 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:30 --> Output Class Initialized
INFO - 2020-10-26 15:39:30 --> URI Class Initialized
INFO - 2020-10-26 15:39:30 --> Security Class Initialized
INFO - 2020-10-26 15:39:30 --> Router Class Initialized
DEBUG - 2020-10-26 15:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:30 --> Output Class Initialized
INFO - 2020-10-26 15:39:30 --> Input Class Initialized
INFO - 2020-10-26 15:39:30 --> Language Class Initialized
INFO - 2020-10-26 15:39:30 --> Security Class Initialized
ERROR - 2020-10-26 15:39:30 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 15:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:30 --> Input Class Initialized
INFO - 2020-10-26 15:39:30 --> Config Class Initialized
INFO - 2020-10-26 15:39:30 --> Language Class Initialized
INFO - 2020-10-26 15:39:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:39:30 --> UTF-8 Support Enabled
ERROR - 2020-10-26 15:39:30 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:39:30 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:30 --> URI Class Initialized
INFO - 2020-10-26 15:39:30 --> Router Class Initialized
INFO - 2020-10-26 15:39:30 --> Config Class Initialized
INFO - 2020-10-26 15:39:30 --> Output Class Initialized
INFO - 2020-10-26 15:39:30 --> Hooks Class Initialized
INFO - 2020-10-26 15:39:30 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 15:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:30 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:30 --> URI Class Initialized
INFO - 2020-10-26 15:39:30 --> Input Class Initialized
INFO - 2020-10-26 15:39:30 --> Language Class Initialized
INFO - 2020-10-26 15:39:30 --> Router Class Initialized
ERROR - 2020-10-26 15:39:30 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:39:30 --> Output Class Initialized
INFO - 2020-10-26 15:39:31 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:31 --> Input Class Initialized
INFO - 2020-10-26 15:39:31 --> Language Class Initialized
INFO - 2020-10-26 15:39:31 --> Loader Class Initialized
INFO - 2020-10-26 15:39:31 --> Helper loaded: url_helper
INFO - 2020-10-26 15:39:31 --> Helper loaded: form_helper
INFO - 2020-10-26 15:39:31 --> Helper loaded: html_helper
INFO - 2020-10-26 15:39:31 --> Helper loaded: date_helper
INFO - 2020-10-26 15:39:31 --> Database Driver Class Initialized
INFO - 2020-10-26 15:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:39:31 --> Table Class Initialized
INFO - 2020-10-26 15:39:31 --> Config Class Initialized
INFO - 2020-10-26 15:39:31 --> Upload Class Initialized
INFO - 2020-10-26 15:39:31 --> Controller Class Initialized
INFO - 2020-10-26 15:39:31 --> Hooks Class Initialized
INFO - 2020-10-26 15:39:31 --> Form Validation Class Initialized
DEBUG - 2020-10-26 15:39:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:31 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:31 --> Model "Crud_model" initialized
ERROR - 2020-10-26 15:39:31 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 15:39:31 --> URI Class Initialized
INFO - 2020-10-26 15:39:31 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 15:39:31 --> Router Class Initialized
INFO - 2020-10-26 15:39:31 --> Output Class Initialized
INFO - 2020-10-26 15:39:31 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:31 --> Input Class Initialized
INFO - 2020-10-26 15:39:31 --> Language Class Initialized
ERROR - 2020-10-26 15:39:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:39:58 --> Config Class Initialized
INFO - 2020-10-26 15:39:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:39:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:39:58 --> Utf8 Class Initialized
INFO - 2020-10-26 15:39:58 --> URI Class Initialized
INFO - 2020-10-26 15:39:59 --> Router Class Initialized
INFO - 2020-10-26 15:39:59 --> Output Class Initialized
INFO - 2020-10-26 15:39:59 --> Security Class Initialized
DEBUG - 2020-10-26 15:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:39:59 --> Input Class Initialized
INFO - 2020-10-26 15:39:59 --> Language Class Initialized
INFO - 2020-10-26 15:39:59 --> Loader Class Initialized
INFO - 2020-10-26 15:39:59 --> Helper loaded: url_helper
INFO - 2020-10-26 15:39:59 --> Helper loaded: form_helper
INFO - 2020-10-26 15:39:59 --> Helper loaded: html_helper
INFO - 2020-10-26 15:39:59 --> Helper loaded: date_helper
INFO - 2020-10-26 15:39:59 --> Database Driver Class Initialized
INFO - 2020-10-26 15:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:39:59 --> Table Class Initialized
INFO - 2020-10-26 15:39:59 --> Upload Class Initialized
INFO - 2020-10-26 15:39:59 --> Controller Class Initialized
INFO - 2020-10-26 15:39:59 --> Form Validation Class Initialized
INFO - 2020-10-26 15:39:59 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:39:59 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 15:39:59 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 15:39:59 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 15:39:59 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 15:39:59 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 15:39:59 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 15:39:59 --> Final output sent to browser
DEBUG - 2020-10-26 15:39:59 --> Total execution time: 1.0370
INFO - 2020-10-26 15:39:59 --> Config Class Initialized
INFO - 2020-10-26 15:39:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:00 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:00 --> URI Class Initialized
INFO - 2020-10-26 15:40:00 --> Router Class Initialized
INFO - 2020-10-26 15:40:00 --> Output Class Initialized
INFO - 2020-10-26 15:40:00 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:00 --> Input Class Initialized
INFO - 2020-10-26 15:40:00 --> Language Class Initialized
ERROR - 2020-10-26 15:40:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 15:40:00 --> Config Class Initialized
INFO - 2020-10-26 15:40:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:00 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:00 --> URI Class Initialized
INFO - 2020-10-26 15:40:00 --> Router Class Initialized
INFO - 2020-10-26 15:40:00 --> Output Class Initialized
INFO - 2020-10-26 15:40:00 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:00 --> Input Class Initialized
INFO - 2020-10-26 15:40:01 --> Language Class Initialized
INFO - 2020-10-26 15:40:01 --> Loader Class Initialized
INFO - 2020-10-26 15:40:01 --> Helper loaded: url_helper
INFO - 2020-10-26 15:40:01 --> Helper loaded: form_helper
INFO - 2020-10-26 15:40:01 --> Helper loaded: html_helper
INFO - 2020-10-26 15:40:01 --> Config Class Initialized
INFO - 2020-10-26 15:40:01 --> Helper loaded: date_helper
INFO - 2020-10-26 15:40:01 --> Database Driver Class Initialized
INFO - 2020-10-26 15:40:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:40:01 --> Table Class Initialized
INFO - 2020-10-26 15:40:01 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:01 --> Upload Class Initialized
INFO - 2020-10-26 15:40:01 --> URI Class Initialized
INFO - 2020-10-26 15:40:01 --> Router Class Initialized
INFO - 2020-10-26 15:40:01 --> Controller Class Initialized
INFO - 2020-10-26 15:40:01 --> Output Class Initialized
INFO - 2020-10-26 15:40:01 --> Form Validation Class Initialized
INFO - 2020-10-26 15:40:01 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:40:01 --> Security Class Initialized
ERROR - 2020-10-26 15:40:01 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
DEBUG - 2020-10-26 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:01 --> Input Class Initialized
INFO - 2020-10-26 15:40:01 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 15:40:01 --> Language Class Initialized
ERROR - 2020-10-26 15:40:01 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:40:01 --> Config Class Initialized
INFO - 2020-10-26 15:40:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:01 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:01 --> URI Class Initialized
INFO - 2020-10-26 15:40:01 --> Router Class Initialized
INFO - 2020-10-26 15:40:01 --> Output Class Initialized
INFO - 2020-10-26 15:40:01 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:01 --> Input Class Initialized
INFO - 2020-10-26 15:40:01 --> Language Class Initialized
ERROR - 2020-10-26 15:40:01 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:40:01 --> Config Class Initialized
INFO - 2020-10-26 15:40:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:01 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:02 --> URI Class Initialized
INFO - 2020-10-26 15:40:02 --> Router Class Initialized
INFO - 2020-10-26 15:40:02 --> Output Class Initialized
INFO - 2020-10-26 15:40:02 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:02 --> Input Class Initialized
INFO - 2020-10-26 15:40:02 --> Language Class Initialized
ERROR - 2020-10-26 15:40:02 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 15:40:41 --> Config Class Initialized
INFO - 2020-10-26 15:40:41 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:41 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:41 --> URI Class Initialized
INFO - 2020-10-26 15:40:41 --> Router Class Initialized
INFO - 2020-10-26 15:40:41 --> Output Class Initialized
INFO - 2020-10-26 15:40:41 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:41 --> Input Class Initialized
INFO - 2020-10-26 15:40:41 --> Language Class Initialized
INFO - 2020-10-26 15:40:41 --> Loader Class Initialized
INFO - 2020-10-26 15:40:41 --> Helper loaded: url_helper
INFO - 2020-10-26 15:40:41 --> Helper loaded: form_helper
INFO - 2020-10-26 15:40:41 --> Helper loaded: html_helper
INFO - 2020-10-26 15:40:41 --> Helper loaded: date_helper
INFO - 2020-10-26 15:40:41 --> Database Driver Class Initialized
INFO - 2020-10-26 15:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:40:41 --> Table Class Initialized
INFO - 2020-10-26 15:40:41 --> Upload Class Initialized
INFO - 2020-10-26 15:40:41 --> Controller Class Initialized
INFO - 2020-10-26 15:40:41 --> Form Validation Class Initialized
INFO - 2020-10-26 15:40:42 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:40:42 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 15:40:42 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 15:40:42 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 15:40:42 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 15:40:42 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 15:40:42 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 15:40:42 --> Final output sent to browser
DEBUG - 2020-10-26 15:40:42 --> Total execution time: 1.0648
INFO - 2020-10-26 15:40:42 --> Config Class Initialized
INFO - 2020-10-26 15:40:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:42 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:42 --> URI Class Initialized
INFO - 2020-10-26 15:40:42 --> Router Class Initialized
INFO - 2020-10-26 15:40:42 --> Output Class Initialized
INFO - 2020-10-26 15:40:42 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:42 --> Input Class Initialized
INFO - 2020-10-26 15:40:42 --> Language Class Initialized
ERROR - 2020-10-26 15:40:42 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 15:40:44 --> Config Class Initialized
INFO - 2020-10-26 15:40:44 --> Config Class Initialized
INFO - 2020-10-26 15:40:44 --> Hooks Class Initialized
INFO - 2020-10-26 15:40:44 --> Config Class Initialized
INFO - 2020-10-26 15:40:44 --> Hooks Class Initialized
INFO - 2020-10-26 15:40:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-26 15:40:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:44 --> Utf8 Class Initialized
DEBUG - 2020-10-26 15:40:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:44 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:44 --> URI Class Initialized
INFO - 2020-10-26 15:40:44 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:44 --> Router Class Initialized
INFO - 2020-10-26 15:40:44 --> URI Class Initialized
INFO - 2020-10-26 15:40:44 --> URI Class Initialized
INFO - 2020-10-26 15:40:44 --> Output Class Initialized
INFO - 2020-10-26 15:40:44 --> Router Class Initialized
INFO - 2020-10-26 15:40:44 --> Router Class Initialized
INFO - 2020-10-26 15:40:44 --> Output Class Initialized
INFO - 2020-10-26 15:40:44 --> Security Class Initialized
INFO - 2020-10-26 15:40:44 --> Output Class Initialized
INFO - 2020-10-26 15:40:44 --> Security Class Initialized
INFO - 2020-10-26 15:40:44 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:44 --> Input Class Initialized
DEBUG - 2020-10-26 15:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 15:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:44 --> Input Class Initialized
INFO - 2020-10-26 15:40:44 --> Input Class Initialized
INFO - 2020-10-26 15:40:44 --> Language Class Initialized
INFO - 2020-10-26 15:40:44 --> Language Class Initialized
INFO - 2020-10-26 15:40:44 --> Language Class Initialized
INFO - 2020-10-26 15:40:44 --> Loader Class Initialized
ERROR - 2020-10-26 15:40:44 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:40:44 --> Helper loaded: url_helper
ERROR - 2020-10-26 15:40:44 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:40:44 --> Helper loaded: form_helper
INFO - 2020-10-26 15:40:44 --> Helper loaded: html_helper
INFO - 2020-10-26 15:40:44 --> Helper loaded: date_helper
INFO - 2020-10-26 15:40:44 --> Database Driver Class Initialized
INFO - 2020-10-26 15:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:40:44 --> Table Class Initialized
INFO - 2020-10-26 15:40:44 --> Upload Class Initialized
INFO - 2020-10-26 15:40:44 --> Controller Class Initialized
INFO - 2020-10-26 15:40:44 --> Form Validation Class Initialized
INFO - 2020-10-26 15:40:44 --> Model "Crud_model" initialized
ERROR - 2020-10-26 15:40:44 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 15:40:44 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 15:40:44 --> Config Class Initialized
INFO - 2020-10-26 15:40:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:44 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:44 --> URI Class Initialized
INFO - 2020-10-26 15:40:44 --> Router Class Initialized
INFO - 2020-10-26 15:40:44 --> Output Class Initialized
INFO - 2020-10-26 15:40:44 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:44 --> Input Class Initialized
INFO - 2020-10-26 15:40:44 --> Language Class Initialized
ERROR - 2020-10-26 15:40:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 15:40:46 --> Config Class Initialized
INFO - 2020-10-26 15:40:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:47 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:47 --> URI Class Initialized
INFO - 2020-10-26 15:40:47 --> Router Class Initialized
INFO - 2020-10-26 15:40:47 --> Output Class Initialized
INFO - 2020-10-26 15:40:47 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:47 --> Input Class Initialized
INFO - 2020-10-26 15:40:47 --> Language Class Initialized
INFO - 2020-10-26 15:40:47 --> Loader Class Initialized
INFO - 2020-10-26 15:40:47 --> Helper loaded: url_helper
INFO - 2020-10-26 15:40:47 --> Helper loaded: form_helper
INFO - 2020-10-26 15:40:47 --> Helper loaded: html_helper
INFO - 2020-10-26 15:40:47 --> Helper loaded: date_helper
INFO - 2020-10-26 15:40:47 --> Database Driver Class Initialized
INFO - 2020-10-26 15:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:40:47 --> Table Class Initialized
INFO - 2020-10-26 15:40:47 --> Upload Class Initialized
INFO - 2020-10-26 15:40:47 --> Controller Class Initialized
INFO - 2020-10-26 15:40:47 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:40:47 --> Config Class Initialized
INFO - 2020-10-26 15:40:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:47 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:47 --> URI Class Initialized
DEBUG - 2020-10-26 15:40:47 --> No URI present. Default controller set.
INFO - 2020-10-26 15:40:47 --> Router Class Initialized
INFO - 2020-10-26 15:40:47 --> Output Class Initialized
INFO - 2020-10-26 15:40:47 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:47 --> Input Class Initialized
INFO - 2020-10-26 15:40:47 --> Language Class Initialized
INFO - 2020-10-26 15:40:47 --> Loader Class Initialized
INFO - 2020-10-26 15:40:47 --> Helper loaded: url_helper
INFO - 2020-10-26 15:40:48 --> Helper loaded: form_helper
INFO - 2020-10-26 15:40:48 --> Helper loaded: html_helper
INFO - 2020-10-26 15:40:48 --> Helper loaded: date_helper
INFO - 2020-10-26 15:40:48 --> Database Driver Class Initialized
INFO - 2020-10-26 15:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:40:48 --> Table Class Initialized
INFO - 2020-10-26 15:40:48 --> Upload Class Initialized
INFO - 2020-10-26 15:40:48 --> Controller Class Initialized
INFO - 2020-10-26 15:40:48 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:40:48 --> Config Class Initialized
INFO - 2020-10-26 15:40:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:40:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:40:48 --> Utf8 Class Initialized
INFO - 2020-10-26 15:40:48 --> URI Class Initialized
INFO - 2020-10-26 15:40:48 --> Router Class Initialized
INFO - 2020-10-26 15:40:48 --> Output Class Initialized
INFO - 2020-10-26 15:40:48 --> Security Class Initialized
DEBUG - 2020-10-26 15:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:40:48 --> Input Class Initialized
INFO - 2020-10-26 15:40:48 --> Language Class Initialized
ERROR - 2020-10-26 15:40:48 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-26 15:41:19 --> Config Class Initialized
INFO - 2020-10-26 15:41:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:41:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:41:19 --> Utf8 Class Initialized
INFO - 2020-10-26 15:41:19 --> URI Class Initialized
DEBUG - 2020-10-26 15:41:19 --> No URI present. Default controller set.
INFO - 2020-10-26 15:41:19 --> Router Class Initialized
INFO - 2020-10-26 15:41:19 --> Output Class Initialized
INFO - 2020-10-26 15:41:19 --> Security Class Initialized
DEBUG - 2020-10-26 15:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:41:19 --> Input Class Initialized
INFO - 2020-10-26 15:41:19 --> Language Class Initialized
INFO - 2020-10-26 15:41:19 --> Loader Class Initialized
INFO - 2020-10-26 15:41:19 --> Helper loaded: url_helper
INFO - 2020-10-26 15:41:19 --> Helper loaded: form_helper
INFO - 2020-10-26 15:41:19 --> Helper loaded: html_helper
INFO - 2020-10-26 15:41:19 --> Helper loaded: date_helper
INFO - 2020-10-26 15:41:19 --> Database Driver Class Initialized
INFO - 2020-10-26 15:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:41:19 --> Table Class Initialized
INFO - 2020-10-26 15:41:19 --> Upload Class Initialized
INFO - 2020-10-26 15:41:19 --> Controller Class Initialized
INFO - 2020-10-26 15:41:19 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:41:21 --> Config Class Initialized
INFO - 2020-10-26 15:41:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:41:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:41:21 --> Utf8 Class Initialized
INFO - 2020-10-26 15:41:21 --> URI Class Initialized
DEBUG - 2020-10-26 15:41:21 --> No URI present. Default controller set.
INFO - 2020-10-26 15:41:21 --> Router Class Initialized
INFO - 2020-10-26 15:41:21 --> Output Class Initialized
INFO - 2020-10-26 15:41:21 --> Security Class Initialized
DEBUG - 2020-10-26 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:41:21 --> Input Class Initialized
INFO - 2020-10-26 15:41:21 --> Language Class Initialized
INFO - 2020-10-26 15:41:21 --> Loader Class Initialized
INFO - 2020-10-26 15:41:21 --> Helper loaded: url_helper
INFO - 2020-10-26 15:41:22 --> Helper loaded: form_helper
INFO - 2020-10-26 15:41:22 --> Helper loaded: html_helper
INFO - 2020-10-26 15:41:22 --> Helper loaded: date_helper
INFO - 2020-10-26 15:41:22 --> Database Driver Class Initialized
INFO - 2020-10-26 15:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:41:22 --> Table Class Initialized
INFO - 2020-10-26 15:41:22 --> Upload Class Initialized
INFO - 2020-10-26 15:41:22 --> Controller Class Initialized
INFO - 2020-10-26 15:41:22 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:41:23 --> Config Class Initialized
INFO - 2020-10-26 15:41:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:41:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:41:23 --> Utf8 Class Initialized
INFO - 2020-10-26 15:41:24 --> URI Class Initialized
DEBUG - 2020-10-26 15:41:24 --> No URI present. Default controller set.
INFO - 2020-10-26 15:41:24 --> Router Class Initialized
INFO - 2020-10-26 15:41:24 --> Output Class Initialized
INFO - 2020-10-26 15:41:24 --> Security Class Initialized
DEBUG - 2020-10-26 15:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:41:24 --> Input Class Initialized
INFO - 2020-10-26 15:41:24 --> Language Class Initialized
INFO - 2020-10-26 15:41:24 --> Loader Class Initialized
INFO - 2020-10-26 15:41:24 --> Helper loaded: url_helper
INFO - 2020-10-26 15:41:24 --> Helper loaded: form_helper
INFO - 2020-10-26 15:41:24 --> Helper loaded: html_helper
INFO - 2020-10-26 15:41:24 --> Helper loaded: date_helper
INFO - 2020-10-26 15:41:24 --> Database Driver Class Initialized
INFO - 2020-10-26 15:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:41:24 --> Table Class Initialized
INFO - 2020-10-26 15:41:24 --> Upload Class Initialized
INFO - 2020-10-26 15:41:24 --> Controller Class Initialized
INFO - 2020-10-26 15:41:24 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:41:26 --> Config Class Initialized
INFO - 2020-10-26 15:41:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:41:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:41:26 --> Utf8 Class Initialized
INFO - 2020-10-26 15:41:26 --> URI Class Initialized
DEBUG - 2020-10-26 15:41:26 --> No URI present. Default controller set.
INFO - 2020-10-26 15:41:26 --> Router Class Initialized
INFO - 2020-10-26 15:41:26 --> Output Class Initialized
INFO - 2020-10-26 15:41:26 --> Security Class Initialized
DEBUG - 2020-10-26 15:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:41:26 --> Input Class Initialized
INFO - 2020-10-26 15:41:26 --> Language Class Initialized
INFO - 2020-10-26 15:41:26 --> Loader Class Initialized
INFO - 2020-10-26 15:41:26 --> Helper loaded: url_helper
INFO - 2020-10-26 15:41:26 --> Helper loaded: form_helper
INFO - 2020-10-26 15:41:26 --> Helper loaded: html_helper
INFO - 2020-10-26 15:41:26 --> Helper loaded: date_helper
INFO - 2020-10-26 15:41:26 --> Database Driver Class Initialized
INFO - 2020-10-26 15:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:41:26 --> Table Class Initialized
INFO - 2020-10-26 15:41:26 --> Upload Class Initialized
INFO - 2020-10-26 15:41:27 --> Controller Class Initialized
INFO - 2020-10-26 15:41:27 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:41:51 --> Config Class Initialized
INFO - 2020-10-26 15:41:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:41:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:41:51 --> Utf8 Class Initialized
INFO - 2020-10-26 15:41:51 --> URI Class Initialized
DEBUG - 2020-10-26 15:41:51 --> No URI present. Default controller set.
INFO - 2020-10-26 15:41:51 --> Router Class Initialized
INFO - 2020-10-26 15:41:51 --> Output Class Initialized
INFO - 2020-10-26 15:41:51 --> Security Class Initialized
DEBUG - 2020-10-26 15:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:41:51 --> Input Class Initialized
INFO - 2020-10-26 15:41:51 --> Language Class Initialized
INFO - 2020-10-26 15:41:51 --> Loader Class Initialized
INFO - 2020-10-26 15:41:51 --> Helper loaded: url_helper
INFO - 2020-10-26 15:41:52 --> Helper loaded: form_helper
INFO - 2020-10-26 15:41:52 --> Helper loaded: html_helper
INFO - 2020-10-26 15:41:52 --> Helper loaded: date_helper
INFO - 2020-10-26 15:41:52 --> Database Driver Class Initialized
INFO - 2020-10-26 15:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:41:52 --> Table Class Initialized
INFO - 2020-10-26 15:41:52 --> Upload Class Initialized
INFO - 2020-10-26 15:41:52 --> Controller Class Initialized
INFO - 2020-10-26 15:41:52 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:41:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:41:52 --> Final output sent to browser
DEBUG - 2020-10-26 15:41:52 --> Total execution time: 0.7443
INFO - 2020-10-26 15:47:55 --> Config Class Initialized
INFO - 2020-10-26 15:47:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:47:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:47:55 --> Utf8 Class Initialized
INFO - 2020-10-26 15:47:55 --> URI Class Initialized
DEBUG - 2020-10-26 15:47:55 --> No URI present. Default controller set.
INFO - 2020-10-26 15:47:55 --> Router Class Initialized
INFO - 2020-10-26 15:47:55 --> Output Class Initialized
INFO - 2020-10-26 15:47:55 --> Security Class Initialized
DEBUG - 2020-10-26 15:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:47:55 --> Input Class Initialized
INFO - 2020-10-26 15:47:55 --> Language Class Initialized
INFO - 2020-10-26 15:47:55 --> Loader Class Initialized
INFO - 2020-10-26 15:47:55 --> Helper loaded: url_helper
INFO - 2020-10-26 15:47:55 --> Helper loaded: form_helper
INFO - 2020-10-26 15:47:55 --> Helper loaded: html_helper
INFO - 2020-10-26 15:47:55 --> Helper loaded: date_helper
INFO - 2020-10-26 15:47:55 --> Database Driver Class Initialized
INFO - 2020-10-26 15:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:47:55 --> Table Class Initialized
INFO - 2020-10-26 15:47:55 --> Upload Class Initialized
INFO - 2020-10-26 15:47:55 --> Controller Class Initialized
INFO - 2020-10-26 15:47:55 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:47:55 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:47:55 --> Final output sent to browser
DEBUG - 2020-10-26 15:47:56 --> Total execution time: 0.7272
INFO - 2020-10-26 15:48:22 --> Config Class Initialized
INFO - 2020-10-26 15:48:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:48:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:48:22 --> Utf8 Class Initialized
INFO - 2020-10-26 15:48:22 --> URI Class Initialized
INFO - 2020-10-26 15:48:22 --> Router Class Initialized
INFO - 2020-10-26 15:48:22 --> Output Class Initialized
INFO - 2020-10-26 15:48:22 --> Security Class Initialized
DEBUG - 2020-10-26 15:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:48:22 --> Input Class Initialized
INFO - 2020-10-26 15:48:22 --> Language Class Initialized
INFO - 2020-10-26 15:48:22 --> Loader Class Initialized
INFO - 2020-10-26 15:48:22 --> Helper loaded: url_helper
INFO - 2020-10-26 15:48:22 --> Helper loaded: form_helper
INFO - 2020-10-26 15:48:22 --> Helper loaded: html_helper
INFO - 2020-10-26 15:48:22 --> Helper loaded: date_helper
INFO - 2020-10-26 15:48:22 --> Database Driver Class Initialized
INFO - 2020-10-26 15:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:48:22 --> Table Class Initialized
INFO - 2020-10-26 15:48:22 --> Upload Class Initialized
INFO - 2020-10-26 15:48:22 --> Controller Class Initialized
INFO - 2020-10-26 15:48:22 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:48:23 --> Config Class Initialized
INFO - 2020-10-26 15:48:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:48:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:48:23 --> Utf8 Class Initialized
INFO - 2020-10-26 15:48:23 --> URI Class Initialized
DEBUG - 2020-10-26 15:48:23 --> No URI present. Default controller set.
INFO - 2020-10-26 15:48:23 --> Router Class Initialized
INFO - 2020-10-26 15:48:23 --> Output Class Initialized
INFO - 2020-10-26 15:48:23 --> Security Class Initialized
DEBUG - 2020-10-26 15:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:48:23 --> Input Class Initialized
INFO - 2020-10-26 15:48:23 --> Language Class Initialized
INFO - 2020-10-26 15:48:23 --> Loader Class Initialized
INFO - 2020-10-26 15:48:23 --> Helper loaded: url_helper
INFO - 2020-10-26 15:48:23 --> Helper loaded: form_helper
INFO - 2020-10-26 15:48:23 --> Helper loaded: html_helper
INFO - 2020-10-26 15:48:23 --> Helper loaded: date_helper
INFO - 2020-10-26 15:48:23 --> Database Driver Class Initialized
INFO - 2020-10-26 15:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:48:23 --> Table Class Initialized
INFO - 2020-10-26 15:48:23 --> Upload Class Initialized
INFO - 2020-10-26 15:48:23 --> Controller Class Initialized
INFO - 2020-10-26 15:48:23 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:48:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:48:23 --> Final output sent to browser
DEBUG - 2020-10-26 15:48:23 --> Total execution time: 0.6794
INFO - 2020-10-26 15:51:17 --> Config Class Initialized
INFO - 2020-10-26 15:51:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:51:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:51:17 --> Utf8 Class Initialized
INFO - 2020-10-26 15:51:17 --> URI Class Initialized
DEBUG - 2020-10-26 15:51:17 --> No URI present. Default controller set.
INFO - 2020-10-26 15:51:17 --> Router Class Initialized
INFO - 2020-10-26 15:51:17 --> Output Class Initialized
INFO - 2020-10-26 15:51:17 --> Security Class Initialized
DEBUG - 2020-10-26 15:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:51:17 --> Input Class Initialized
INFO - 2020-10-26 15:51:17 --> Language Class Initialized
INFO - 2020-10-26 15:51:17 --> Loader Class Initialized
INFO - 2020-10-26 15:51:17 --> Helper loaded: url_helper
INFO - 2020-10-26 15:51:17 --> Helper loaded: form_helper
INFO - 2020-10-26 15:51:17 --> Helper loaded: html_helper
INFO - 2020-10-26 15:51:17 --> Helper loaded: date_helper
INFO - 2020-10-26 15:51:17 --> Database Driver Class Initialized
INFO - 2020-10-26 15:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:51:17 --> Table Class Initialized
INFO - 2020-10-26 15:51:17 --> Upload Class Initialized
INFO - 2020-10-26 15:51:17 --> Controller Class Initialized
INFO - 2020-10-26 15:51:18 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:51:18 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:51:18 --> Final output sent to browser
DEBUG - 2020-10-26 15:51:18 --> Total execution time: 0.6547
INFO - 2020-10-26 15:51:18 --> Config Class Initialized
INFO - 2020-10-26 15:51:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:51:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:51:18 --> Utf8 Class Initialized
INFO - 2020-10-26 15:51:18 --> URI Class Initialized
DEBUG - 2020-10-26 15:51:18 --> No URI present. Default controller set.
INFO - 2020-10-26 15:51:18 --> Router Class Initialized
INFO - 2020-10-26 15:51:18 --> Output Class Initialized
INFO - 2020-10-26 15:51:18 --> Security Class Initialized
DEBUG - 2020-10-26 15:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:51:18 --> Input Class Initialized
INFO - 2020-10-26 15:51:18 --> Language Class Initialized
INFO - 2020-10-26 15:51:18 --> Loader Class Initialized
INFO - 2020-10-26 15:51:18 --> Helper loaded: url_helper
INFO - 2020-10-26 15:51:18 --> Helper loaded: form_helper
INFO - 2020-10-26 15:51:18 --> Helper loaded: html_helper
INFO - 2020-10-26 15:51:18 --> Helper loaded: date_helper
INFO - 2020-10-26 15:51:18 --> Database Driver Class Initialized
INFO - 2020-10-26 15:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:51:19 --> Table Class Initialized
INFO - 2020-10-26 15:51:19 --> Upload Class Initialized
INFO - 2020-10-26 15:51:19 --> Controller Class Initialized
INFO - 2020-10-26 15:51:19 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:51:19 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:51:19 --> Final output sent to browser
DEBUG - 2020-10-26 15:51:19 --> Total execution time: 0.7089
INFO - 2020-10-26 15:56:58 --> Config Class Initialized
INFO - 2020-10-26 15:56:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:56:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:56:58 --> Utf8 Class Initialized
INFO - 2020-10-26 15:56:58 --> URI Class Initialized
INFO - 2020-10-26 15:56:58 --> Router Class Initialized
INFO - 2020-10-26 15:56:58 --> Output Class Initialized
INFO - 2020-10-26 15:56:58 --> Security Class Initialized
DEBUG - 2020-10-26 15:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:56:58 --> Input Class Initialized
INFO - 2020-10-26 15:56:58 --> Language Class Initialized
INFO - 2020-10-26 15:56:58 --> Loader Class Initialized
INFO - 2020-10-26 15:56:59 --> Helper loaded: url_helper
INFO - 2020-10-26 15:56:59 --> Helper loaded: form_helper
INFO - 2020-10-26 15:56:59 --> Helper loaded: html_helper
INFO - 2020-10-26 15:56:59 --> Helper loaded: date_helper
INFO - 2020-10-26 15:56:59 --> Database Driver Class Initialized
INFO - 2020-10-26 15:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:56:59 --> Table Class Initialized
INFO - 2020-10-26 15:56:59 --> Upload Class Initialized
INFO - 2020-10-26 15:56:59 --> Controller Class Initialized
INFO - 2020-10-26 15:56:59 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:56:59 --> Config Class Initialized
INFO - 2020-10-26 15:56:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:56:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:56:59 --> Utf8 Class Initialized
INFO - 2020-10-26 15:56:59 --> URI Class Initialized
DEBUG - 2020-10-26 15:56:59 --> No URI present. Default controller set.
INFO - 2020-10-26 15:56:59 --> Router Class Initialized
INFO - 2020-10-26 15:56:59 --> Output Class Initialized
INFO - 2020-10-26 15:56:59 --> Security Class Initialized
DEBUG - 2020-10-26 15:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:56:59 --> Input Class Initialized
INFO - 2020-10-26 15:56:59 --> Language Class Initialized
INFO - 2020-10-26 15:56:59 --> Loader Class Initialized
INFO - 2020-10-26 15:56:59 --> Helper loaded: url_helper
INFO - 2020-10-26 15:56:59 --> Helper loaded: form_helper
INFO - 2020-10-26 15:56:59 --> Helper loaded: html_helper
INFO - 2020-10-26 15:56:59 --> Helper loaded: date_helper
INFO - 2020-10-26 15:56:59 --> Database Driver Class Initialized
INFO - 2020-10-26 15:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:56:59 --> Table Class Initialized
INFO - 2020-10-26 15:56:59 --> Upload Class Initialized
INFO - 2020-10-26 15:56:59 --> Controller Class Initialized
INFO - 2020-10-26 15:56:59 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:57:00 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:57:00 --> Final output sent to browser
DEBUG - 2020-10-26 15:57:00 --> Total execution time: 0.6991
INFO - 2020-10-26 15:57:05 --> Config Class Initialized
INFO - 2020-10-26 15:57:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:57:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:05 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:05 --> URI Class Initialized
INFO - 2020-10-26 15:57:05 --> Router Class Initialized
INFO - 2020-10-26 15:57:05 --> Output Class Initialized
INFO - 2020-10-26 15:57:05 --> Security Class Initialized
DEBUG - 2020-10-26 15:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:05 --> Input Class Initialized
INFO - 2020-10-26 15:57:05 --> Language Class Initialized
INFO - 2020-10-26 15:57:05 --> Loader Class Initialized
INFO - 2020-10-26 15:57:05 --> Helper loaded: url_helper
INFO - 2020-10-26 15:57:05 --> Helper loaded: form_helper
INFO - 2020-10-26 15:57:05 --> Helper loaded: html_helper
INFO - 2020-10-26 15:57:05 --> Helper loaded: date_helper
INFO - 2020-10-26 15:57:05 --> Database Driver Class Initialized
INFO - 2020-10-26 15:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:57:05 --> Table Class Initialized
INFO - 2020-10-26 15:57:05 --> Upload Class Initialized
INFO - 2020-10-26 15:57:05 --> Controller Class Initialized
INFO - 2020-10-26 15:57:05 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:57:05 --> Config Class Initialized
INFO - 2020-10-26 15:57:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:57:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:05 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:05 --> URI Class Initialized
INFO - 2020-10-26 15:57:05 --> Router Class Initialized
INFO - 2020-10-26 15:57:05 --> Output Class Initialized
INFO - 2020-10-26 15:57:05 --> Security Class Initialized
DEBUG - 2020-10-26 15:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:06 --> Input Class Initialized
INFO - 2020-10-26 15:57:06 --> Language Class Initialized
INFO - 2020-10-26 15:57:06 --> Loader Class Initialized
INFO - 2020-10-26 15:57:06 --> Helper loaded: url_helper
INFO - 2020-10-26 15:57:06 --> Helper loaded: form_helper
INFO - 2020-10-26 15:57:06 --> Helper loaded: html_helper
INFO - 2020-10-26 15:57:06 --> Helper loaded: date_helper
INFO - 2020-10-26 15:57:06 --> Database Driver Class Initialized
INFO - 2020-10-26 15:57:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:57:06 --> Table Class Initialized
INFO - 2020-10-26 15:57:06 --> Upload Class Initialized
INFO - 2020-10-26 15:57:06 --> Controller Class Initialized
INFO - 2020-10-26 15:57:06 --> Form Validation Class Initialized
INFO - 2020-10-26 15:57:06 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:57:06 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 15:57:06 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 15:57:06 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 15:57:06 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 15:57:06 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 15:57:06 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 15:57:06 --> Final output sent to browser
DEBUG - 2020-10-26 15:57:06 --> Total execution time: 0.8646
INFO - 2020-10-26 15:57:06 --> Config Class Initialized
INFO - 2020-10-26 15:57:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:57:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:06 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:06 --> Config Class Initialized
INFO - 2020-10-26 15:57:06 --> URI Class Initialized
INFO - 2020-10-26 15:57:06 --> Router Class Initialized
INFO - 2020-10-26 15:57:06 --> Hooks Class Initialized
INFO - 2020-10-26 15:57:06 --> Output Class Initialized
DEBUG - 2020-10-26 15:57:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:06 --> Security Class Initialized
INFO - 2020-10-26 15:57:06 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:07 --> URI Class Initialized
DEBUG - 2020-10-26 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:07 --> Input Class Initialized
INFO - 2020-10-26 15:57:07 --> Router Class Initialized
INFO - 2020-10-26 15:57:07 --> Output Class Initialized
INFO - 2020-10-26 15:57:07 --> Language Class Initialized
INFO - 2020-10-26 15:57:07 --> Security Class Initialized
ERROR - 2020-10-26 15:57:07 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:07 --> Config Class Initialized
INFO - 2020-10-26 15:57:07 --> Hooks Class Initialized
INFO - 2020-10-26 15:57:07 --> Input Class Initialized
INFO - 2020-10-26 15:57:07 --> Language Class Initialized
DEBUG - 2020-10-26 15:57:07 --> UTF-8 Support Enabled
ERROR - 2020-10-26 15:57:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:57:07 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:07 --> Config Class Initialized
INFO - 2020-10-26 15:57:07 --> URI Class Initialized
INFO - 2020-10-26 15:57:07 --> Hooks Class Initialized
INFO - 2020-10-26 15:57:07 --> Router Class Initialized
DEBUG - 2020-10-26 15:57:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:07 --> Output Class Initialized
INFO - 2020-10-26 15:57:07 --> Security Class Initialized
INFO - 2020-10-26 15:57:07 --> Utf8 Class Initialized
DEBUG - 2020-10-26 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:07 --> URI Class Initialized
INFO - 2020-10-26 15:57:07 --> Router Class Initialized
INFO - 2020-10-26 15:57:07 --> Input Class Initialized
INFO - 2020-10-26 15:57:07 --> Output Class Initialized
INFO - 2020-10-26 15:57:07 --> Language Class Initialized
INFO - 2020-10-26 15:57:07 --> Security Class Initialized
ERROR - 2020-10-26 15:57:07 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:07 --> Input Class Initialized
INFO - 2020-10-26 15:57:07 --> Language Class Initialized
INFO - 2020-10-26 15:57:07 --> Loader Class Initialized
INFO - 2020-10-26 15:57:07 --> Helper loaded: url_helper
INFO - 2020-10-26 15:57:07 --> Helper loaded: form_helper
INFO - 2020-10-26 15:57:07 --> Helper loaded: html_helper
INFO - 2020-10-26 15:57:07 --> Helper loaded: date_helper
INFO - 2020-10-26 15:57:07 --> Database Driver Class Initialized
INFO - 2020-10-26 15:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:57:07 --> Table Class Initialized
INFO - 2020-10-26 15:57:07 --> Upload Class Initialized
INFO - 2020-10-26 15:57:07 --> Controller Class Initialized
INFO - 2020-10-26 15:57:07 --> Form Validation Class Initialized
INFO - 2020-10-26 15:57:07 --> Config Class Initialized
INFO - 2020-10-26 15:57:07 --> Model "Crud_model" initialized
INFO - 2020-10-26 15:57:07 --> Hooks Class Initialized
ERROR - 2020-10-26 15:57:07 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 15:57:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2020-10-26 15:57:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:07 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:07 --> URI Class Initialized
INFO - 2020-10-26 15:57:07 --> Router Class Initialized
INFO - 2020-10-26 15:57:07 --> Output Class Initialized
INFO - 2020-10-26 15:57:07 --> Security Class Initialized
DEBUG - 2020-10-26 15:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:08 --> Input Class Initialized
INFO - 2020-10-26 15:57:08 --> Language Class Initialized
ERROR - 2020-10-26 15:57:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 15:57:27 --> Config Class Initialized
INFO - 2020-10-26 15:57:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:57:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:27 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:27 --> URI Class Initialized
INFO - 2020-10-26 15:57:28 --> Router Class Initialized
INFO - 2020-10-26 15:57:28 --> Output Class Initialized
INFO - 2020-10-26 15:57:28 --> Security Class Initialized
DEBUG - 2020-10-26 15:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:28 --> Input Class Initialized
INFO - 2020-10-26 15:57:28 --> Language Class Initialized
INFO - 2020-10-26 15:57:28 --> Loader Class Initialized
INFO - 2020-10-26 15:57:28 --> Helper loaded: url_helper
INFO - 2020-10-26 15:57:28 --> Helper loaded: form_helper
INFO - 2020-10-26 15:57:28 --> Helper loaded: html_helper
INFO - 2020-10-26 15:57:28 --> Helper loaded: date_helper
INFO - 2020-10-26 15:57:28 --> Database Driver Class Initialized
INFO - 2020-10-26 15:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:57:28 --> Table Class Initialized
INFO - 2020-10-26 15:57:28 --> Upload Class Initialized
INFO - 2020-10-26 15:57:28 --> Controller Class Initialized
INFO - 2020-10-26 15:57:28 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:57:28 --> Config Class Initialized
INFO - 2020-10-26 15:57:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 15:57:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 15:57:28 --> Utf8 Class Initialized
INFO - 2020-10-26 15:57:28 --> URI Class Initialized
DEBUG - 2020-10-26 15:57:28 --> No URI present. Default controller set.
INFO - 2020-10-26 15:57:28 --> Router Class Initialized
INFO - 2020-10-26 15:57:28 --> Output Class Initialized
INFO - 2020-10-26 15:57:28 --> Security Class Initialized
DEBUG - 2020-10-26 15:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 15:57:29 --> Input Class Initialized
INFO - 2020-10-26 15:57:29 --> Language Class Initialized
INFO - 2020-10-26 15:57:29 --> Loader Class Initialized
INFO - 2020-10-26 15:57:29 --> Helper loaded: url_helper
INFO - 2020-10-26 15:57:29 --> Helper loaded: form_helper
INFO - 2020-10-26 15:57:29 --> Helper loaded: html_helper
INFO - 2020-10-26 15:57:29 --> Helper loaded: date_helper
INFO - 2020-10-26 15:57:29 --> Database Driver Class Initialized
INFO - 2020-10-26 15:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 15:57:29 --> Table Class Initialized
INFO - 2020-10-26 15:57:29 --> Upload Class Initialized
INFO - 2020-10-26 15:57:29 --> Controller Class Initialized
INFO - 2020-10-26 15:57:29 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 15:57:29 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 15:57:29 --> Final output sent to browser
DEBUG - 2020-10-26 15:57:29 --> Total execution time: 0.8507
INFO - 2020-10-26 16:02:29 --> Config Class Initialized
INFO - 2020-10-26 16:02:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:02:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:02:29 --> Utf8 Class Initialized
INFO - 2020-10-26 16:02:29 --> URI Class Initialized
INFO - 2020-10-26 16:02:29 --> Router Class Initialized
INFO - 2020-10-26 16:02:29 --> Output Class Initialized
INFO - 2020-10-26 16:02:29 --> Security Class Initialized
DEBUG - 2020-10-26 16:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:02:29 --> Input Class Initialized
INFO - 2020-10-26 16:02:29 --> Language Class Initialized
INFO - 2020-10-26 16:02:29 --> Loader Class Initialized
INFO - 2020-10-26 16:02:29 --> Helper loaded: url_helper
INFO - 2020-10-26 16:02:29 --> Helper loaded: form_helper
INFO - 2020-10-26 16:02:29 --> Helper loaded: html_helper
INFO - 2020-10-26 16:02:29 --> Helper loaded: date_helper
INFO - 2020-10-26 16:02:29 --> Database Driver Class Initialized
INFO - 2020-10-26 16:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:02:29 --> Table Class Initialized
INFO - 2020-10-26 16:02:29 --> Upload Class Initialized
INFO - 2020-10-26 16:02:30 --> Controller Class Initialized
INFO - 2020-10-26 16:02:30 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 16:02:30 --> Config Class Initialized
INFO - 2020-10-26 16:02:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:02:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:02:30 --> Utf8 Class Initialized
INFO - 2020-10-26 16:02:30 --> URI Class Initialized
INFO - 2020-10-26 16:02:30 --> Router Class Initialized
INFO - 2020-10-26 16:02:30 --> Output Class Initialized
INFO - 2020-10-26 16:02:30 --> Security Class Initialized
DEBUG - 2020-10-26 16:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:02:30 --> Input Class Initialized
INFO - 2020-10-26 16:02:30 --> Language Class Initialized
INFO - 2020-10-26 16:02:30 --> Loader Class Initialized
INFO - 2020-10-26 16:02:30 --> Helper loaded: url_helper
INFO - 2020-10-26 16:02:30 --> Helper loaded: form_helper
INFO - 2020-10-26 16:02:30 --> Helper loaded: html_helper
INFO - 2020-10-26 16:02:30 --> Helper loaded: date_helper
INFO - 2020-10-26 16:02:30 --> Database Driver Class Initialized
INFO - 2020-10-26 16:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:02:30 --> Table Class Initialized
INFO - 2020-10-26 16:02:30 --> Upload Class Initialized
INFO - 2020-10-26 16:02:30 --> Controller Class Initialized
INFO - 2020-10-26 16:02:30 --> Form Validation Class Initialized
INFO - 2020-10-26 16:02:30 --> Model "Crud_model" initialized
INFO - 2020-10-26 16:02:30 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 16:02:30 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 16:02:30 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 16:02:30 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 16:02:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 16:02:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 16:02:30 --> Final output sent to browser
DEBUG - 2020-10-26 16:02:30 --> Total execution time: 0.8510
INFO - 2020-10-26 16:02:31 --> Config Class Initialized
INFO - 2020-10-26 16:02:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:02:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:02:31 --> Utf8 Class Initialized
INFO - 2020-10-26 16:02:31 --> URI Class Initialized
INFO - 2020-10-26 16:02:31 --> Config Class Initialized
INFO - 2020-10-26 16:02:31 --> Router Class Initialized
INFO - 2020-10-26 16:02:31 --> Hooks Class Initialized
INFO - 2020-10-26 16:02:31 --> Output Class Initialized
DEBUG - 2020-10-26 16:02:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:02:31 --> Security Class Initialized
DEBUG - 2020-10-26 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:02:31 --> Utf8 Class Initialized
INFO - 2020-10-26 16:02:31 --> Input Class Initialized
INFO - 2020-10-26 16:02:31 --> URI Class Initialized
INFO - 2020-10-26 16:02:31 --> Language Class Initialized
INFO - 2020-10-26 16:02:31 --> Router Class Initialized
INFO - 2020-10-26 16:02:31 --> Output Class Initialized
ERROR - 2020-10-26 16:02:31 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 16:02:31 --> Config Class Initialized
INFO - 2020-10-26 16:02:31 --> Security Class Initialized
INFO - 2020-10-26 16:02:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-26 16:02:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:02:31 --> Input Class Initialized
INFO - 2020-10-26 16:02:31 --> Language Class Initialized
INFO - 2020-10-26 16:02:31 --> Utf8 Class Initialized
INFO - 2020-10-26 16:02:31 --> Config Class Initialized
ERROR - 2020-10-26 16:02:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 16:02:31 --> URI Class Initialized
INFO - 2020-10-26 16:02:31 --> Router Class Initialized
INFO - 2020-10-26 16:02:31 --> Hooks Class Initialized
INFO - 2020-10-26 16:02:31 --> Output Class Initialized
DEBUG - 2020-10-26 16:02:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:02:31 --> Utf8 Class Initialized
INFO - 2020-10-26 16:02:31 --> Security Class Initialized
DEBUG - 2020-10-26 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:02:31 --> URI Class Initialized
INFO - 2020-10-26 16:02:31 --> Input Class Initialized
INFO - 2020-10-26 16:02:31 --> Router Class Initialized
INFO - 2020-10-26 16:02:31 --> Language Class Initialized
INFO - 2020-10-26 16:02:31 --> Output Class Initialized
ERROR - 2020-10-26 16:02:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 16:02:31 --> Security Class Initialized
DEBUG - 2020-10-26 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:02:31 --> Input Class Initialized
INFO - 2020-10-26 16:02:31 --> Language Class Initialized
INFO - 2020-10-26 16:02:31 --> Loader Class Initialized
INFO - 2020-10-26 16:02:31 --> Helper loaded: url_helper
INFO - 2020-10-26 16:02:31 --> Helper loaded: form_helper
INFO - 2020-10-26 16:02:31 --> Helper loaded: html_helper
INFO - 2020-10-26 16:02:31 --> Helper loaded: date_helper
INFO - 2020-10-26 16:02:31 --> Database Driver Class Initialized
INFO - 2020-10-26 16:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:02:31 --> Table Class Initialized
INFO - 2020-10-26 16:02:31 --> Upload Class Initialized
INFO - 2020-10-26 16:02:31 --> Controller Class Initialized
INFO - 2020-10-26 16:02:32 --> Form Validation Class Initialized
INFO - 2020-10-26 16:02:32 --> Model "Crud_model" initialized
ERROR - 2020-10-26 16:02:32 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 16:02:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 16:20:39 --> Config Class Initialized
INFO - 2020-10-26 16:20:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:20:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:20:40 --> Utf8 Class Initialized
INFO - 2020-10-26 16:20:40 --> URI Class Initialized
DEBUG - 2020-10-26 16:20:40 --> No URI present. Default controller set.
INFO - 2020-10-26 16:20:40 --> Router Class Initialized
INFO - 2020-10-26 16:20:40 --> Output Class Initialized
INFO - 2020-10-26 16:20:40 --> Security Class Initialized
DEBUG - 2020-10-26 16:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:20:40 --> Input Class Initialized
INFO - 2020-10-26 16:20:40 --> Language Class Initialized
INFO - 2020-10-26 16:20:40 --> Loader Class Initialized
INFO - 2020-10-26 16:20:40 --> Helper loaded: url_helper
INFO - 2020-10-26 16:20:40 --> Helper loaded: form_helper
INFO - 2020-10-26 16:20:40 --> Helper loaded: html_helper
INFO - 2020-10-26 16:20:40 --> Helper loaded: date_helper
INFO - 2020-10-26 16:20:40 --> Database Driver Class Initialized
INFO - 2020-10-26 16:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:20:40 --> Table Class Initialized
INFO - 2020-10-26 16:20:40 --> Upload Class Initialized
INFO - 2020-10-26 16:20:40 --> Controller Class Initialized
INFO - 2020-10-26 16:20:40 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 16:20:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 16:20:40 --> Final output sent to browser
DEBUG - 2020-10-26 16:20:40 --> Total execution time: 0.6894
INFO - 2020-10-26 16:20:40 --> Config Class Initialized
INFO - 2020-10-26 16:20:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:20:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:20:41 --> Utf8 Class Initialized
INFO - 2020-10-26 16:20:41 --> URI Class Initialized
DEBUG - 2020-10-26 16:20:41 --> No URI present. Default controller set.
INFO - 2020-10-26 16:20:41 --> Router Class Initialized
INFO - 2020-10-26 16:20:41 --> Output Class Initialized
INFO - 2020-10-26 16:20:41 --> Security Class Initialized
DEBUG - 2020-10-26 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:20:41 --> Input Class Initialized
INFO - 2020-10-26 16:20:41 --> Language Class Initialized
INFO - 2020-10-26 16:20:41 --> Loader Class Initialized
INFO - 2020-10-26 16:20:41 --> Helper loaded: url_helper
INFO - 2020-10-26 16:20:41 --> Helper loaded: form_helper
INFO - 2020-10-26 16:20:41 --> Helper loaded: html_helper
INFO - 2020-10-26 16:20:41 --> Helper loaded: date_helper
INFO - 2020-10-26 16:20:41 --> Database Driver Class Initialized
INFO - 2020-10-26 16:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:20:41 --> Table Class Initialized
INFO - 2020-10-26 16:20:41 --> Upload Class Initialized
INFO - 2020-10-26 16:20:41 --> Controller Class Initialized
INFO - 2020-10-26 16:20:41 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 16:20:41 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 16:20:41 --> Final output sent to browser
DEBUG - 2020-10-26 16:20:41 --> Total execution time: 0.7050
INFO - 2020-10-26 16:48:00 --> Config Class Initialized
INFO - 2020-10-26 16:48:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:48:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:48:00 --> Utf8 Class Initialized
INFO - 2020-10-26 16:48:00 --> URI Class Initialized
DEBUG - 2020-10-26 16:48:00 --> No URI present. Default controller set.
INFO - 2020-10-26 16:48:00 --> Router Class Initialized
INFO - 2020-10-26 16:48:00 --> Output Class Initialized
INFO - 2020-10-26 16:48:00 --> Security Class Initialized
DEBUG - 2020-10-26 16:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:48:00 --> Input Class Initialized
INFO - 2020-10-26 16:48:00 --> Language Class Initialized
INFO - 2020-10-26 16:48:00 --> Loader Class Initialized
INFO - 2020-10-26 16:48:00 --> Helper loaded: url_helper
INFO - 2020-10-26 16:48:00 --> Helper loaded: form_helper
INFO - 2020-10-26 16:48:00 --> Helper loaded: html_helper
INFO - 2020-10-26 16:48:00 --> Helper loaded: date_helper
INFO - 2020-10-26 16:48:00 --> Database Driver Class Initialized
INFO - 2020-10-26 16:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:48:00 --> Table Class Initialized
INFO - 2020-10-26 16:48:00 --> Upload Class Initialized
INFO - 2020-10-26 16:48:00 --> Controller Class Initialized
INFO - 2020-10-26 16:48:00 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 16:48:00 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 16:48:00 --> Final output sent to browser
DEBUG - 2020-10-26 16:48:00 --> Total execution time: 0.7050
INFO - 2020-10-26 16:53:57 --> Config Class Initialized
INFO - 2020-10-26 16:53:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:53:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:53:57 --> Utf8 Class Initialized
INFO - 2020-10-26 16:53:57 --> URI Class Initialized
INFO - 2020-10-26 16:53:57 --> Router Class Initialized
INFO - 2020-10-26 16:53:57 --> Output Class Initialized
INFO - 2020-10-26 16:53:57 --> Security Class Initialized
DEBUG - 2020-10-26 16:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:53:57 --> Input Class Initialized
INFO - 2020-10-26 16:53:57 --> Language Class Initialized
INFO - 2020-10-26 16:53:57 --> Loader Class Initialized
INFO - 2020-10-26 16:53:57 --> Helper loaded: url_helper
INFO - 2020-10-26 16:53:57 --> Helper loaded: form_helper
INFO - 2020-10-26 16:53:57 --> Helper loaded: html_helper
INFO - 2020-10-26 16:53:57 --> Helper loaded: date_helper
INFO - 2020-10-26 16:53:57 --> Database Driver Class Initialized
INFO - 2020-10-26 16:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:53:57 --> Table Class Initialized
INFO - 2020-10-26 16:53:57 --> Upload Class Initialized
INFO - 2020-10-26 16:53:57 --> Controller Class Initialized
INFO - 2020-10-26 16:53:58 --> Form Validation Class Initialized
INFO - 2020-10-26 16:53:58 --> Model "Crud_model" initialized
INFO - 2020-10-26 16:53:58 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 16:53:58 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 16:53:58 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 16:53:58 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 16:53:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 16:53:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 16:53:58 --> Final output sent to browser
DEBUG - 2020-10-26 16:53:58 --> Total execution time: 0.9218
INFO - 2020-10-26 16:53:58 --> Config Class Initialized
INFO - 2020-10-26 16:53:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:53:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:53:58 --> Utf8 Class Initialized
INFO - 2020-10-26 16:53:58 --> Config Class Initialized
INFO - 2020-10-26 16:53:58 --> URI Class Initialized
INFO - 2020-10-26 16:53:58 --> Hooks Class Initialized
INFO - 2020-10-26 16:53:58 --> Router Class Initialized
INFO - 2020-10-26 16:53:58 --> Output Class Initialized
DEBUG - 2020-10-26 16:53:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:53:58 --> Security Class Initialized
INFO - 2020-10-26 16:53:58 --> Utf8 Class Initialized
DEBUG - 2020-10-26 16:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:53:58 --> URI Class Initialized
INFO - 2020-10-26 16:53:58 --> Router Class Initialized
INFO - 2020-10-26 16:53:58 --> Input Class Initialized
INFO - 2020-10-26 16:53:58 --> Output Class Initialized
INFO - 2020-10-26 16:53:58 --> Language Class Initialized
ERROR - 2020-10-26 16:53:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 16:53:58 --> Security Class Initialized
DEBUG - 2020-10-26 16:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:53:58 --> Config Class Initialized
INFO - 2020-10-26 16:53:58 --> Hooks Class Initialized
INFO - 2020-10-26 16:53:58 --> Input Class Initialized
DEBUG - 2020-10-26 16:53:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:53:58 --> Language Class Initialized
INFO - 2020-10-26 16:53:58 --> Utf8 Class Initialized
ERROR - 2020-10-26 16:53:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 16:53:58 --> URI Class Initialized
INFO - 2020-10-26 16:53:58 --> Config Class Initialized
INFO - 2020-10-26 16:53:58 --> Hooks Class Initialized
INFO - 2020-10-26 16:53:58 --> Router Class Initialized
DEBUG - 2020-10-26 16:53:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:53:58 --> Output Class Initialized
INFO - 2020-10-26 16:53:58 --> Security Class Initialized
INFO - 2020-10-26 16:53:58 --> Utf8 Class Initialized
DEBUG - 2020-10-26 16:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:53:59 --> URI Class Initialized
INFO - 2020-10-26 16:53:59 --> Router Class Initialized
INFO - 2020-10-26 16:53:59 --> Input Class Initialized
INFO - 2020-10-26 16:53:59 --> Output Class Initialized
INFO - 2020-10-26 16:53:59 --> Language Class Initialized
INFO - 2020-10-26 16:53:59 --> Security Class Initialized
ERROR - 2020-10-26 16:53:59 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-26 16:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:53:59 --> Input Class Initialized
INFO - 2020-10-26 16:53:59 --> Language Class Initialized
INFO - 2020-10-26 16:53:59 --> Loader Class Initialized
INFO - 2020-10-26 16:53:59 --> Helper loaded: url_helper
INFO - 2020-10-26 16:53:59 --> Helper loaded: form_helper
INFO - 2020-10-26 16:53:59 --> Helper loaded: html_helper
INFO - 2020-10-26 16:53:59 --> Helper loaded: date_helper
INFO - 2020-10-26 16:53:59 --> Database Driver Class Initialized
INFO - 2020-10-26 16:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:53:59 --> Table Class Initialized
INFO - 2020-10-26 16:53:59 --> Upload Class Initialized
INFO - 2020-10-26 16:53:59 --> Controller Class Initialized
INFO - 2020-10-26 16:53:59 --> Form Validation Class Initialized
INFO - 2020-10-26 16:53:59 --> Model "Crud_model" initialized
ERROR - 2020-10-26 16:53:59 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 16:53:59 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 16:54:44 --> Config Class Initialized
INFO - 2020-10-26 16:54:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:54:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:54:44 --> Utf8 Class Initialized
INFO - 2020-10-26 16:54:44 --> URI Class Initialized
DEBUG - 2020-10-26 16:54:44 --> No URI present. Default controller set.
INFO - 2020-10-26 16:54:44 --> Router Class Initialized
INFO - 2020-10-26 16:54:44 --> Output Class Initialized
INFO - 2020-10-26 16:54:45 --> Security Class Initialized
DEBUG - 2020-10-26 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:54:45 --> Input Class Initialized
INFO - 2020-10-26 16:54:45 --> Language Class Initialized
INFO - 2020-10-26 16:54:45 --> Loader Class Initialized
INFO - 2020-10-26 16:54:45 --> Helper loaded: url_helper
INFO - 2020-10-26 16:54:45 --> Helper loaded: form_helper
INFO - 2020-10-26 16:54:45 --> Helper loaded: html_helper
INFO - 2020-10-26 16:54:45 --> Helper loaded: date_helper
INFO - 2020-10-26 16:54:45 --> Database Driver Class Initialized
INFO - 2020-10-26 16:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:54:45 --> Table Class Initialized
INFO - 2020-10-26 16:54:45 --> Upload Class Initialized
INFO - 2020-10-26 16:54:45 --> Controller Class Initialized
INFO - 2020-10-26 16:54:45 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 16:54:45 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 16:54:45 --> Final output sent to browser
DEBUG - 2020-10-26 16:54:45 --> Total execution time: 0.7295
INFO - 2020-10-26 16:54:45 --> Config Class Initialized
INFO - 2020-10-26 16:54:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:54:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:54:45 --> Utf8 Class Initialized
INFO - 2020-10-26 16:54:45 --> URI Class Initialized
DEBUG - 2020-10-26 16:54:45 --> No URI present. Default controller set.
INFO - 2020-10-26 16:54:45 --> Router Class Initialized
INFO - 2020-10-26 16:54:45 --> Output Class Initialized
INFO - 2020-10-26 16:54:45 --> Security Class Initialized
DEBUG - 2020-10-26 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:54:45 --> Input Class Initialized
INFO - 2020-10-26 16:54:45 --> Language Class Initialized
INFO - 2020-10-26 16:54:45 --> Loader Class Initialized
INFO - 2020-10-26 16:54:45 --> Helper loaded: url_helper
INFO - 2020-10-26 16:54:45 --> Helper loaded: form_helper
INFO - 2020-10-26 16:54:46 --> Helper loaded: html_helper
INFO - 2020-10-26 16:54:46 --> Helper loaded: date_helper
INFO - 2020-10-26 16:54:46 --> Database Driver Class Initialized
INFO - 2020-10-26 16:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:54:46 --> Table Class Initialized
INFO - 2020-10-26 16:54:46 --> Upload Class Initialized
INFO - 2020-10-26 16:54:46 --> Controller Class Initialized
INFO - 2020-10-26 16:54:46 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 16:54:46 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 16:54:46 --> Final output sent to browser
DEBUG - 2020-10-26 16:54:46 --> Total execution time: 0.7134
INFO - 2020-10-26 16:56:21 --> Config Class Initialized
INFO - 2020-10-26 16:56:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:56:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:56:21 --> Utf8 Class Initialized
INFO - 2020-10-26 16:56:21 --> URI Class Initialized
INFO - 2020-10-26 16:56:21 --> Router Class Initialized
INFO - 2020-10-26 16:56:22 --> Output Class Initialized
INFO - 2020-10-26 16:56:22 --> Security Class Initialized
DEBUG - 2020-10-26 16:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:56:22 --> Input Class Initialized
INFO - 2020-10-26 16:56:22 --> Language Class Initialized
INFO - 2020-10-26 16:56:22 --> Loader Class Initialized
INFO - 2020-10-26 16:56:22 --> Helper loaded: url_helper
INFO - 2020-10-26 16:56:22 --> Helper loaded: form_helper
INFO - 2020-10-26 16:56:22 --> Helper loaded: html_helper
INFO - 2020-10-26 16:56:22 --> Helper loaded: date_helper
INFO - 2020-10-26 16:56:22 --> Database Driver Class Initialized
INFO - 2020-10-26 16:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:56:22 --> Table Class Initialized
INFO - 2020-10-26 16:56:22 --> Upload Class Initialized
INFO - 2020-10-26 16:56:22 --> Controller Class Initialized
INFO - 2020-10-26 16:56:22 --> Form Validation Class Initialized
INFO - 2020-10-26 16:56:22 --> Model "Crud_model" initialized
INFO - 2020-10-26 16:56:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 16:56:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 16:56:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 16:56:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 16:56:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 16:56:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 16:56:22 --> Final output sent to browser
DEBUG - 2020-10-26 16:56:22 --> Total execution time: 1.0339
INFO - 2020-10-26 16:56:22 --> Config Class Initialized
INFO - 2020-10-26 16:56:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:56:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:56:22 --> Config Class Initialized
INFO - 2020-10-26 16:56:22 --> Utf8 Class Initialized
INFO - 2020-10-26 16:56:22 --> Hooks Class Initialized
INFO - 2020-10-26 16:56:22 --> URI Class Initialized
INFO - 2020-10-26 16:56:22 --> Router Class Initialized
DEBUG - 2020-10-26 16:56:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:56:23 --> Utf8 Class Initialized
INFO - 2020-10-26 16:56:23 --> Output Class Initialized
INFO - 2020-10-26 16:56:23 --> URI Class Initialized
INFO - 2020-10-26 16:56:23 --> Security Class Initialized
DEBUG - 2020-10-26 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:56:23 --> Router Class Initialized
INFO - 2020-10-26 16:56:23 --> Output Class Initialized
INFO - 2020-10-26 16:56:23 --> Input Class Initialized
INFO - 2020-10-26 16:56:23 --> Language Class Initialized
INFO - 2020-10-26 16:56:23 --> Security Class Initialized
ERROR - 2020-10-26 16:56:23 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-26 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:56:23 --> Input Class Initialized
INFO - 2020-10-26 16:56:23 --> Language Class Initialized
ERROR - 2020-10-26 16:56:23 --> 404 Page Not Found: Dist/img
INFO - 2020-10-26 16:56:23 --> Config Class Initialized
INFO - 2020-10-26 16:56:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 16:56:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 16:56:23 --> Utf8 Class Initialized
INFO - 2020-10-26 16:56:23 --> URI Class Initialized
INFO - 2020-10-26 16:56:23 --> Router Class Initialized
INFO - 2020-10-26 16:56:23 --> Output Class Initialized
INFO - 2020-10-26 16:56:23 --> Security Class Initialized
DEBUG - 2020-10-26 16:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 16:56:23 --> Input Class Initialized
INFO - 2020-10-26 16:56:23 --> Language Class Initialized
INFO - 2020-10-26 16:56:23 --> Loader Class Initialized
INFO - 2020-10-26 16:56:23 --> Helper loaded: url_helper
INFO - 2020-10-26 16:56:23 --> Helper loaded: form_helper
INFO - 2020-10-26 16:56:23 --> Helper loaded: html_helper
INFO - 2020-10-26 16:56:23 --> Helper loaded: date_helper
INFO - 2020-10-26 16:56:23 --> Database Driver Class Initialized
INFO - 2020-10-26 16:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 16:56:23 --> Table Class Initialized
INFO - 2020-10-26 16:56:23 --> Upload Class Initialized
INFO - 2020-10-26 16:56:23 --> Controller Class Initialized
INFO - 2020-10-26 16:56:23 --> Form Validation Class Initialized
INFO - 2020-10-26 16:56:23 --> Model "Crud_model" initialized
ERROR - 2020-10-26 16:56:23 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 16:56:24 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 17:01:11 --> Config Class Initialized
INFO - 2020-10-26 17:01:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:11 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:11 --> URI Class Initialized
INFO - 2020-10-26 17:01:11 --> Router Class Initialized
INFO - 2020-10-26 17:01:11 --> Output Class Initialized
INFO - 2020-10-26 17:01:11 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:11 --> Input Class Initialized
INFO - 2020-10-26 17:01:11 --> Language Class Initialized
INFO - 2020-10-26 17:01:11 --> Loader Class Initialized
INFO - 2020-10-26 17:01:11 --> Helper loaded: url_helper
INFO - 2020-10-26 17:01:11 --> Helper loaded: form_helper
INFO - 2020-10-26 17:01:11 --> Helper loaded: html_helper
INFO - 2020-10-26 17:01:11 --> Helper loaded: date_helper
INFO - 2020-10-26 17:01:11 --> Database Driver Class Initialized
INFO - 2020-10-26 17:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:01:11 --> Table Class Initialized
INFO - 2020-10-26 17:01:11 --> Upload Class Initialized
INFO - 2020-10-26 17:01:11 --> Controller Class Initialized
INFO - 2020-10-26 17:01:11 --> Form Validation Class Initialized
INFO - 2020-10-26 17:01:11 --> Model "Crud_model" initialized
INFO - 2020-10-26 17:01:11 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 17:01:11 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 17:01:11 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 17:01:11 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 17:01:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 17:01:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 17:01:12 --> Final output sent to browser
DEBUG - 2020-10-26 17:01:12 --> Total execution time: 0.9262
INFO - 2020-10-26 17:01:12 --> Config Class Initialized
INFO - 2020-10-26 17:01:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:12 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:12 --> URI Class Initialized
INFO - 2020-10-26 17:01:12 --> Router Class Initialized
INFO - 2020-10-26 17:01:12 --> Output Class Initialized
INFO - 2020-10-26 17:01:12 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:12 --> Input Class Initialized
INFO - 2020-10-26 17:01:12 --> Language Class Initialized
ERROR - 2020-10-26 17:01:12 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 17:01:12 --> Config Class Initialized
INFO - 2020-10-26 17:01:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:12 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:12 --> URI Class Initialized
INFO - 2020-10-26 17:01:12 --> Router Class Initialized
INFO - 2020-10-26 17:01:12 --> Output Class Initialized
INFO - 2020-10-26 17:01:12 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:12 --> Input Class Initialized
INFO - 2020-10-26 17:01:12 --> Language Class Initialized
INFO - 2020-10-26 17:01:12 --> Loader Class Initialized
INFO - 2020-10-26 17:01:12 --> Helper loaded: url_helper
INFO - 2020-10-26 17:01:12 --> Helper loaded: form_helper
INFO - 2020-10-26 17:01:12 --> Helper loaded: html_helper
INFO - 2020-10-26 17:01:13 --> Helper loaded: date_helper
INFO - 2020-10-26 17:01:13 --> Database Driver Class Initialized
INFO - 2020-10-26 17:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:01:13 --> Table Class Initialized
INFO - 2020-10-26 17:01:13 --> Upload Class Initialized
INFO - 2020-10-26 17:01:13 --> Controller Class Initialized
INFO - 2020-10-26 17:01:13 --> Form Validation Class Initialized
INFO - 2020-10-26 17:01:13 --> Model "Crud_model" initialized
ERROR - 2020-10-26 17:01:13 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 17:01:13 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 17:01:18 --> Config Class Initialized
INFO - 2020-10-26 17:01:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:18 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:18 --> URI Class Initialized
INFO - 2020-10-26 17:01:18 --> Router Class Initialized
INFO - 2020-10-26 17:01:18 --> Output Class Initialized
INFO - 2020-10-26 17:01:18 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:18 --> Input Class Initialized
INFO - 2020-10-26 17:01:18 --> Language Class Initialized
ERROR - 2020-10-26 17:01:18 --> 404 Page Not Found: Welcome/index3.html
INFO - 2020-10-26 17:01:20 --> Config Class Initialized
INFO - 2020-10-26 17:01:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:20 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:20 --> URI Class Initialized
INFO - 2020-10-26 17:01:20 --> Router Class Initialized
INFO - 2020-10-26 17:01:20 --> Output Class Initialized
INFO - 2020-10-26 17:01:20 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:20 --> Input Class Initialized
INFO - 2020-10-26 17:01:20 --> Language Class Initialized
INFO - 2020-10-26 17:01:20 --> Loader Class Initialized
INFO - 2020-10-26 17:01:20 --> Helper loaded: url_helper
INFO - 2020-10-26 17:01:20 --> Helper loaded: form_helper
INFO - 2020-10-26 17:01:20 --> Helper loaded: html_helper
INFO - 2020-10-26 17:01:20 --> Helper loaded: date_helper
INFO - 2020-10-26 17:01:20 --> Database Driver Class Initialized
INFO - 2020-10-26 17:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:01:20 --> Table Class Initialized
INFO - 2020-10-26 17:01:20 --> Upload Class Initialized
INFO - 2020-10-26 17:01:20 --> Controller Class Initialized
INFO - 2020-10-26 17:01:20 --> Form Validation Class Initialized
INFO - 2020-10-26 17:01:20 --> Model "Crud_model" initialized
INFO - 2020-10-26 17:01:20 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 17:01:20 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 17:01:20 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 17:01:20 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 17:01:20 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 17:01:20 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 17:01:20 --> Final output sent to browser
DEBUG - 2020-10-26 17:01:21 --> Total execution time: 0.9110
INFO - 2020-10-26 17:01:21 --> Config Class Initialized
INFO - 2020-10-26 17:01:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:21 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:21 --> URI Class Initialized
INFO - 2020-10-26 17:01:21 --> Router Class Initialized
INFO - 2020-10-26 17:01:21 --> Output Class Initialized
INFO - 2020-10-26 17:01:21 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:21 --> Input Class Initialized
INFO - 2020-10-26 17:01:21 --> Language Class Initialized
INFO - 2020-10-26 17:01:21 --> Loader Class Initialized
INFO - 2020-10-26 17:01:21 --> Helper loaded: url_helper
INFO - 2020-10-26 17:01:21 --> Helper loaded: form_helper
INFO - 2020-10-26 17:01:21 --> Helper loaded: html_helper
INFO - 2020-10-26 17:01:21 --> Helper loaded: date_helper
INFO - 2020-10-26 17:01:21 --> Database Driver Class Initialized
INFO - 2020-10-26 17:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:01:21 --> Table Class Initialized
INFO - 2020-10-26 17:01:21 --> Upload Class Initialized
INFO - 2020-10-26 17:01:21 --> Controller Class Initialized
INFO - 2020-10-26 17:01:21 --> Form Validation Class Initialized
INFO - 2020-10-26 17:01:21 --> Model "Crud_model" initialized
ERROR - 2020-10-26 17:01:21 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 17:01:22 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 17:01:30 --> Config Class Initialized
INFO - 2020-10-26 17:01:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:30 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:30 --> URI Class Initialized
INFO - 2020-10-26 17:01:30 --> Router Class Initialized
INFO - 2020-10-26 17:01:30 --> Output Class Initialized
INFO - 2020-10-26 17:01:30 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:30 --> Input Class Initialized
INFO - 2020-10-26 17:01:30 --> Language Class Initialized
INFO - 2020-10-26 17:01:30 --> Loader Class Initialized
INFO - 2020-10-26 17:01:30 --> Helper loaded: url_helper
INFO - 2020-10-26 17:01:30 --> Helper loaded: form_helper
INFO - 2020-10-26 17:01:30 --> Helper loaded: html_helper
INFO - 2020-10-26 17:01:30 --> Helper loaded: date_helper
INFO - 2020-10-26 17:01:30 --> Database Driver Class Initialized
INFO - 2020-10-26 17:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:01:30 --> Table Class Initialized
INFO - 2020-10-26 17:01:30 --> Upload Class Initialized
INFO - 2020-10-26 17:01:30 --> Controller Class Initialized
INFO - 2020-10-26 17:01:30 --> Form Validation Class Initialized
INFO - 2020-10-26 17:01:30 --> Model "Crud_model" initialized
INFO - 2020-10-26 17:01:30 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 17:01:30 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 17:01:30 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 17:01:30 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 17:01:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 17:01:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 17:01:31 --> Final output sent to browser
DEBUG - 2020-10-26 17:01:31 --> Total execution time: 0.9030
INFO - 2020-10-26 17:01:31 --> Config Class Initialized
INFO - 2020-10-26 17:01:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:31 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:31 --> URI Class Initialized
INFO - 2020-10-26 17:01:31 --> Router Class Initialized
INFO - 2020-10-26 17:01:31 --> Output Class Initialized
INFO - 2020-10-26 17:01:31 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:31 --> Input Class Initialized
INFO - 2020-10-26 17:01:31 --> Language Class Initialized
ERROR - 2020-10-26 17:01:31 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 17:01:31 --> Config Class Initialized
INFO - 2020-10-26 17:01:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:01:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:01:31 --> Utf8 Class Initialized
INFO - 2020-10-26 17:01:31 --> URI Class Initialized
INFO - 2020-10-26 17:01:31 --> Router Class Initialized
INFO - 2020-10-26 17:01:31 --> Output Class Initialized
INFO - 2020-10-26 17:01:31 --> Security Class Initialized
DEBUG - 2020-10-26 17:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:01:31 --> Input Class Initialized
INFO - 2020-10-26 17:01:31 --> Language Class Initialized
INFO - 2020-10-26 17:01:31 --> Loader Class Initialized
INFO - 2020-10-26 17:01:31 --> Helper loaded: url_helper
INFO - 2020-10-26 17:01:31 --> Helper loaded: form_helper
INFO - 2020-10-26 17:01:31 --> Helper loaded: html_helper
INFO - 2020-10-26 17:01:31 --> Helper loaded: date_helper
INFO - 2020-10-26 17:01:31 --> Database Driver Class Initialized
INFO - 2020-10-26 17:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:01:32 --> Table Class Initialized
INFO - 2020-10-26 17:01:32 --> Upload Class Initialized
INFO - 2020-10-26 17:01:32 --> Controller Class Initialized
INFO - 2020-10-26 17:01:32 --> Form Validation Class Initialized
INFO - 2020-10-26 17:01:32 --> Model "Crud_model" initialized
ERROR - 2020-10-26 17:01:32 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 17:01:32 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 17:03:08 --> Config Class Initialized
INFO - 2020-10-26 17:03:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:08 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:08 --> URI Class Initialized
INFO - 2020-10-26 17:03:08 --> Router Class Initialized
INFO - 2020-10-26 17:03:08 --> Output Class Initialized
INFO - 2020-10-26 17:03:08 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:08 --> Input Class Initialized
INFO - 2020-10-26 17:03:08 --> Language Class Initialized
INFO - 2020-10-26 17:03:08 --> Loader Class Initialized
INFO - 2020-10-26 17:03:08 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:08 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:09 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:09 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:09 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:09 --> Table Class Initialized
INFO - 2020-10-26 17:03:09 --> Upload Class Initialized
INFO - 2020-10-26 17:03:09 --> Controller Class Initialized
INFO - 2020-10-26 17:03:09 --> Form Validation Class Initialized
INFO - 2020-10-26 17:03:09 --> Model "Crud_model" initialized
INFO - 2020-10-26 17:03:09 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 17:03:09 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 17:03:09 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 17:03:09 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 17:03:09 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 17:03:09 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 17:03:09 --> Final output sent to browser
DEBUG - 2020-10-26 17:03:09 --> Total execution time: 0.9837
INFO - 2020-10-26 17:03:09 --> Config Class Initialized
INFO - 2020-10-26 17:03:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:09 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:09 --> URI Class Initialized
INFO - 2020-10-26 17:03:09 --> Router Class Initialized
INFO - 2020-10-26 17:03:09 --> Output Class Initialized
INFO - 2020-10-26 17:03:09 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:09 --> Input Class Initialized
INFO - 2020-10-26 17:03:09 --> Language Class Initialized
ERROR - 2020-10-26 17:03:09 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 17:03:10 --> Config Class Initialized
INFO - 2020-10-26 17:03:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:10 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:10 --> URI Class Initialized
INFO - 2020-10-26 17:03:10 --> Router Class Initialized
INFO - 2020-10-26 17:03:10 --> Output Class Initialized
INFO - 2020-10-26 17:03:10 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:10 --> Input Class Initialized
INFO - 2020-10-26 17:03:10 --> Language Class Initialized
INFO - 2020-10-26 17:03:10 --> Loader Class Initialized
INFO - 2020-10-26 17:03:10 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:10 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:10 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:10 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:10 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:10 --> Table Class Initialized
INFO - 2020-10-26 17:03:10 --> Upload Class Initialized
INFO - 2020-10-26 17:03:10 --> Controller Class Initialized
INFO - 2020-10-26 17:03:10 --> Form Validation Class Initialized
INFO - 2020-10-26 17:03:10 --> Model "Crud_model" initialized
ERROR - 2020-10-26 17:03:10 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 17:03:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 17:03:21 --> Config Class Initialized
INFO - 2020-10-26 17:03:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:21 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:21 --> URI Class Initialized
INFO - 2020-10-26 17:03:21 --> Router Class Initialized
INFO - 2020-10-26 17:03:21 --> Output Class Initialized
INFO - 2020-10-26 17:03:21 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:21 --> Input Class Initialized
INFO - 2020-10-26 17:03:21 --> Language Class Initialized
INFO - 2020-10-26 17:03:21 --> Loader Class Initialized
INFO - 2020-10-26 17:03:21 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:21 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:21 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:21 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:21 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:21 --> Table Class Initialized
INFO - 2020-10-26 17:03:22 --> Upload Class Initialized
INFO - 2020-10-26 17:03:22 --> Controller Class Initialized
INFO - 2020-10-26 17:03:22 --> Form Validation Class Initialized
INFO - 2020-10-26 17:03:22 --> Model "Crud_model" initialized
INFO - 2020-10-26 17:03:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-26 17:03:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-26 17:03:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-26 17:03:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-26 17:03:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-26 17:03:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-26 17:03:22 --> Final output sent to browser
DEBUG - 2020-10-26 17:03:22 --> Total execution time: 0.9089
INFO - 2020-10-26 17:03:22 --> Config Class Initialized
INFO - 2020-10-26 17:03:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:22 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:22 --> URI Class Initialized
INFO - 2020-10-26 17:03:22 --> Router Class Initialized
INFO - 2020-10-26 17:03:22 --> Output Class Initialized
INFO - 2020-10-26 17:03:22 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:22 --> Input Class Initialized
INFO - 2020-10-26 17:03:22 --> Language Class Initialized
ERROR - 2020-10-26 17:03:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-26 17:03:22 --> Config Class Initialized
INFO - 2020-10-26 17:03:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:23 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:23 --> URI Class Initialized
INFO - 2020-10-26 17:03:23 --> Router Class Initialized
INFO - 2020-10-26 17:03:23 --> Output Class Initialized
INFO - 2020-10-26 17:03:23 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:23 --> Input Class Initialized
INFO - 2020-10-26 17:03:23 --> Language Class Initialized
INFO - 2020-10-26 17:03:23 --> Loader Class Initialized
INFO - 2020-10-26 17:03:23 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:23 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:23 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:23 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:23 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:23 --> Table Class Initialized
INFO - 2020-10-26 17:03:23 --> Upload Class Initialized
INFO - 2020-10-26 17:03:23 --> Controller Class Initialized
INFO - 2020-10-26 17:03:23 --> Form Validation Class Initialized
INFO - 2020-10-26 17:03:23 --> Model "Crud_model" initialized
ERROR - 2020-10-26 17:03:23 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-26 17:03:23 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 17:03:24 --> Config Class Initialized
INFO - 2020-10-26 17:03:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:25 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:25 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:25 --> URI Class Initialized
INFO - 2020-10-26 17:03:25 --> Router Class Initialized
INFO - 2020-10-26 17:03:25 --> Output Class Initialized
INFO - 2020-10-26 17:03:25 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:25 --> Input Class Initialized
INFO - 2020-10-26 17:03:25 --> Language Class Initialized
INFO - 2020-10-26 17:03:25 --> Loader Class Initialized
INFO - 2020-10-26 17:03:25 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:25 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:25 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:25 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:25 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:25 --> Table Class Initialized
INFO - 2020-10-26 17:03:25 --> Upload Class Initialized
INFO - 2020-10-26 17:03:25 --> Controller Class Initialized
INFO - 2020-10-26 17:03:25 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 17:03:25 --> Config Class Initialized
INFO - 2020-10-26 17:03:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:26 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:26 --> URI Class Initialized
DEBUG - 2020-10-26 17:03:26 --> No URI present. Default controller set.
INFO - 2020-10-26 17:03:26 --> Router Class Initialized
INFO - 2020-10-26 17:03:26 --> Output Class Initialized
INFO - 2020-10-26 17:03:26 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:26 --> Input Class Initialized
INFO - 2020-10-26 17:03:26 --> Language Class Initialized
INFO - 2020-10-26 17:03:26 --> Loader Class Initialized
INFO - 2020-10-26 17:03:26 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:26 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:26 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:26 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:26 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:26 --> Table Class Initialized
INFO - 2020-10-26 17:03:26 --> Upload Class Initialized
INFO - 2020-10-26 17:03:26 --> Controller Class Initialized
INFO - 2020-10-26 17:03:26 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 17:03:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 17:03:26 --> Final output sent to browser
DEBUG - 2020-10-26 17:03:26 --> Total execution time: 0.7923
INFO - 2020-10-26 17:03:33 --> Config Class Initialized
INFO - 2020-10-26 17:03:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:33 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:33 --> URI Class Initialized
INFO - 2020-10-26 17:03:33 --> Router Class Initialized
INFO - 2020-10-26 17:03:33 --> Output Class Initialized
INFO - 2020-10-26 17:03:33 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:33 --> Input Class Initialized
INFO - 2020-10-26 17:03:33 --> Language Class Initialized
INFO - 2020-10-26 17:03:33 --> Loader Class Initialized
INFO - 2020-10-26 17:03:34 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:34 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:34 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:34 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:34 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:34 --> Table Class Initialized
INFO - 2020-10-26 17:03:34 --> Upload Class Initialized
INFO - 2020-10-26 17:03:34 --> Controller Class Initialized
INFO - 2020-10-26 17:03:34 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 17:03:34 --> Config Class Initialized
INFO - 2020-10-26 17:03:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:03:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:03:34 --> Utf8 Class Initialized
INFO - 2020-10-26 17:03:34 --> URI Class Initialized
DEBUG - 2020-10-26 17:03:34 --> No URI present. Default controller set.
INFO - 2020-10-26 17:03:34 --> Router Class Initialized
INFO - 2020-10-26 17:03:34 --> Output Class Initialized
INFO - 2020-10-26 17:03:34 --> Security Class Initialized
DEBUG - 2020-10-26 17:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:03:34 --> Input Class Initialized
INFO - 2020-10-26 17:03:35 --> Language Class Initialized
INFO - 2020-10-26 17:03:35 --> Loader Class Initialized
INFO - 2020-10-26 17:03:35 --> Helper loaded: url_helper
INFO - 2020-10-26 17:03:35 --> Helper loaded: form_helper
INFO - 2020-10-26 17:03:35 --> Helper loaded: html_helper
INFO - 2020-10-26 17:03:35 --> Helper loaded: date_helper
INFO - 2020-10-26 17:03:35 --> Database Driver Class Initialized
INFO - 2020-10-26 17:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:03:35 --> Table Class Initialized
INFO - 2020-10-26 17:03:35 --> Upload Class Initialized
INFO - 2020-10-26 17:03:35 --> Controller Class Initialized
INFO - 2020-10-26 17:03:35 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 17:03:35 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 17:03:35 --> Final output sent to browser
DEBUG - 2020-10-26 17:03:35 --> Total execution time: 1.1278
INFO - 2020-10-26 17:36:56 --> Config Class Initialized
INFO - 2020-10-26 17:36:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:36:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:36:56 --> Utf8 Class Initialized
INFO - 2020-10-26 17:36:56 --> URI Class Initialized
DEBUG - 2020-10-26 17:36:56 --> No URI present. Default controller set.
INFO - 2020-10-26 17:36:56 --> Router Class Initialized
INFO - 2020-10-26 17:36:56 --> Output Class Initialized
INFO - 2020-10-26 17:36:56 --> Security Class Initialized
DEBUG - 2020-10-26 17:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:36:56 --> Input Class Initialized
INFO - 2020-10-26 17:36:56 --> Language Class Initialized
INFO - 2020-10-26 17:36:56 --> Loader Class Initialized
INFO - 2020-10-26 17:36:56 --> Helper loaded: url_helper
INFO - 2020-10-26 17:36:56 --> Helper loaded: form_helper
INFO - 2020-10-26 17:36:56 --> Helper loaded: html_helper
INFO - 2020-10-26 17:36:56 --> Helper loaded: date_helper
INFO - 2020-10-26 17:36:56 --> Database Driver Class Initialized
INFO - 2020-10-26 17:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:36:56 --> Table Class Initialized
INFO - 2020-10-26 17:36:56 --> Upload Class Initialized
INFO - 2020-10-26 17:36:57 --> Controller Class Initialized
INFO - 2020-10-26 17:36:57 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 17:36:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 17:36:57 --> Final output sent to browser
DEBUG - 2020-10-26 17:36:57 --> Total execution time: 0.7387
INFO - 2020-10-26 17:36:57 --> Config Class Initialized
INFO - 2020-10-26 17:36:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:36:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:36:57 --> Utf8 Class Initialized
INFO - 2020-10-26 17:36:57 --> URI Class Initialized
DEBUG - 2020-10-26 17:36:57 --> No URI present. Default controller set.
INFO - 2020-10-26 17:36:57 --> Router Class Initialized
INFO - 2020-10-26 17:36:57 --> Output Class Initialized
INFO - 2020-10-26 17:36:57 --> Security Class Initialized
DEBUG - 2020-10-26 17:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:36:57 --> Input Class Initialized
INFO - 2020-10-26 17:36:57 --> Language Class Initialized
INFO - 2020-10-26 17:36:57 --> Loader Class Initialized
INFO - 2020-10-26 17:36:57 --> Helper loaded: url_helper
INFO - 2020-10-26 17:36:57 --> Helper loaded: form_helper
INFO - 2020-10-26 17:36:57 --> Helper loaded: html_helper
INFO - 2020-10-26 17:36:57 --> Helper loaded: date_helper
INFO - 2020-10-26 17:36:57 --> Database Driver Class Initialized
INFO - 2020-10-26 17:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:36:57 --> Table Class Initialized
INFO - 2020-10-26 17:36:57 --> Upload Class Initialized
INFO - 2020-10-26 17:36:57 --> Controller Class Initialized
INFO - 2020-10-26 17:36:57 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 17:36:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 17:36:57 --> Final output sent to browser
DEBUG - 2020-10-26 17:36:57 --> Total execution time: 0.7388
INFO - 2020-10-26 17:48:07 --> Config Class Initialized
INFO - 2020-10-26 17:48:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 17:48:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 17:48:07 --> Utf8 Class Initialized
INFO - 2020-10-26 17:48:07 --> URI Class Initialized
DEBUG - 2020-10-26 17:48:07 --> No URI present. Default controller set.
INFO - 2020-10-26 17:48:07 --> Router Class Initialized
INFO - 2020-10-26 17:48:07 --> Output Class Initialized
INFO - 2020-10-26 17:48:07 --> Security Class Initialized
DEBUG - 2020-10-26 17:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 17:48:07 --> Input Class Initialized
INFO - 2020-10-26 17:48:07 --> Language Class Initialized
INFO - 2020-10-26 17:48:07 --> Loader Class Initialized
INFO - 2020-10-26 17:48:07 --> Helper loaded: url_helper
INFO - 2020-10-26 17:48:07 --> Helper loaded: form_helper
INFO - 2020-10-26 17:48:07 --> Helper loaded: html_helper
INFO - 2020-10-26 17:48:07 --> Helper loaded: date_helper
INFO - 2020-10-26 17:48:07 --> Database Driver Class Initialized
INFO - 2020-10-26 17:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 17:48:07 --> Table Class Initialized
INFO - 2020-10-26 17:48:07 --> Upload Class Initialized
INFO - 2020-10-26 17:48:07 --> Controller Class Initialized
INFO - 2020-10-26 17:48:07 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 17:48:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 17:48:08 --> Final output sent to browser
DEBUG - 2020-10-26 17:48:08 --> Total execution time: 0.7439
INFO - 2020-10-26 18:33:58 --> Config Class Initialized
INFO - 2020-10-26 18:33:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 18:33:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 18:33:58 --> Utf8 Class Initialized
INFO - 2020-10-26 18:33:58 --> URI Class Initialized
DEBUG - 2020-10-26 18:33:58 --> No URI present. Default controller set.
INFO - 2020-10-26 18:33:58 --> Router Class Initialized
INFO - 2020-10-26 18:33:58 --> Output Class Initialized
INFO - 2020-10-26 18:33:58 --> Security Class Initialized
DEBUG - 2020-10-26 18:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 18:33:58 --> Input Class Initialized
INFO - 2020-10-26 18:33:58 --> Language Class Initialized
INFO - 2020-10-26 18:33:58 --> Loader Class Initialized
INFO - 2020-10-26 18:33:58 --> Helper loaded: url_helper
INFO - 2020-10-26 18:33:58 --> Helper loaded: form_helper
INFO - 2020-10-26 18:33:58 --> Helper loaded: html_helper
INFO - 2020-10-26 18:33:58 --> Helper loaded: date_helper
INFO - 2020-10-26 18:33:58 --> Database Driver Class Initialized
INFO - 2020-10-26 18:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 18:33:58 --> Table Class Initialized
INFO - 2020-10-26 18:33:58 --> Upload Class Initialized
INFO - 2020-10-26 18:33:58 --> Controller Class Initialized
INFO - 2020-10-26 18:33:58 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 18:33:59 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 18:33:59 --> Final output sent to browser
DEBUG - 2020-10-26 18:33:59 --> Total execution time: 0.7590
INFO - 2020-10-26 18:33:59 --> Config Class Initialized
INFO - 2020-10-26 18:33:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 18:33:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 18:33:59 --> Utf8 Class Initialized
INFO - 2020-10-26 18:33:59 --> URI Class Initialized
DEBUG - 2020-10-26 18:33:59 --> No URI present. Default controller set.
INFO - 2020-10-26 18:33:59 --> Router Class Initialized
INFO - 2020-10-26 18:33:59 --> Output Class Initialized
INFO - 2020-10-26 18:33:59 --> Security Class Initialized
DEBUG - 2020-10-26 18:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 18:33:59 --> Input Class Initialized
INFO - 2020-10-26 18:33:59 --> Language Class Initialized
INFO - 2020-10-26 18:33:59 --> Loader Class Initialized
INFO - 2020-10-26 18:33:59 --> Helper loaded: url_helper
INFO - 2020-10-26 18:33:59 --> Helper loaded: form_helper
INFO - 2020-10-26 18:33:59 --> Helper loaded: html_helper
INFO - 2020-10-26 18:33:59 --> Helper loaded: date_helper
INFO - 2020-10-26 18:33:59 --> Database Driver Class Initialized
INFO - 2020-10-26 18:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 18:34:00 --> Table Class Initialized
INFO - 2020-10-26 18:34:00 --> Upload Class Initialized
INFO - 2020-10-26 18:34:00 --> Controller Class Initialized
INFO - 2020-10-26 18:34:00 --> Model "Usuarios_model" initialized
INFO - 2020-10-26 18:34:00 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-26 18:34:00 --> Final output sent to browser
DEBUG - 2020-10-26 18:34:00 --> Total execution time: 0.9180

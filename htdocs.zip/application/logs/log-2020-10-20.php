<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-20 10:18:25 --> Config Class Initialized
INFO - 2020-10-20 10:18:25 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:25 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:25 --> URI Class Initialized
INFO - 2020-10-20 10:18:25 --> Router Class Initialized
INFO - 2020-10-20 10:18:25 --> Output Class Initialized
INFO - 2020-10-20 10:18:25 --> Security Class Initialized
DEBUG - 2020-10-20 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:25 --> Input Class Initialized
INFO - 2020-10-20 10:18:25 --> Language Class Initialized
INFO - 2020-10-20 10:18:25 --> Loader Class Initialized
INFO - 2020-10-20 10:18:25 --> Helper loaded: url_helper
INFO - 2020-10-20 10:18:25 --> Helper loaded: form_helper
INFO - 2020-10-20 10:18:25 --> Helper loaded: html_helper
INFO - 2020-10-20 10:18:25 --> Helper loaded: date_helper
INFO - 2020-10-20 10:18:25 --> Database Driver Class Initialized
INFO - 2020-10-20 10:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:18:25 --> Table Class Initialized
INFO - 2020-10-20 10:18:25 --> Upload Class Initialized
INFO - 2020-10-20 10:18:25 --> Controller Class Initialized
INFO - 2020-10-20 10:18:25 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:18:25 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:18:25 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:18:25 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:18:25 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:18:25 --> Final output sent to browser
DEBUG - 2020-10-20 10:18:25 --> Total execution time: 0.1070
INFO - 2020-10-20 10:18:25 --> Config Class Initialized
INFO - 2020-10-20 10:18:25 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:25 --> Config Class Initialized
INFO - 2020-10-20 10:18:25 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:25 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:25 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:25 --> URI Class Initialized
INFO - 2020-10-20 10:18:25 --> URI Class Initialized
INFO - 2020-10-20 10:18:25 --> Router Class Initialized
INFO - 2020-10-20 10:18:25 --> Router Class Initialized
INFO - 2020-10-20 10:18:25 --> Output Class Initialized
INFO - 2020-10-20 10:18:25 --> Output Class Initialized
INFO - 2020-10-20 10:18:25 --> Security Class Initialized
INFO - 2020-10-20 10:18:25 --> Security Class Initialized
INFO - 2020-10-20 10:18:25 --> Config Class Initialized
INFO - 2020-10-20 10:18:25 --> Config Class Initialized
INFO - 2020-10-20 10:18:25 --> Config Class Initialized
INFO - 2020-10-20 10:18:25 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:25 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:25 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:18:25 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:25 --> Input Class Initialized
DEBUG - 2020-10-20 10:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:25 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:25 --> Input Class Initialized
INFO - 2020-10-20 10:18:25 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:25 --> Language Class Initialized
DEBUG - 2020-10-20 10:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:25 --> Language Class Initialized
INFO - 2020-10-20 10:18:25 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:25 --> URI Class Initialized
INFO - 2020-10-20 10:18:25 --> URI Class Initialized
INFO - 2020-10-20 10:18:25 --> Router Class Initialized
ERROR - 2020-10-20 10:18:25 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:25 --> URI Class Initialized
ERROR - 2020-10-20 10:18:25 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:25 --> Output Class Initialized
INFO - 2020-10-20 10:18:25 --> Router Class Initialized
INFO - 2020-10-20 10:18:25 --> Router Class Initialized
INFO - 2020-10-20 10:18:25 --> Output Class Initialized
INFO - 2020-10-20 10:18:25 --> Output Class Initialized
INFO - 2020-10-20 10:18:25 --> Security Class Initialized
INFO - 2020-10-20 10:18:25 --> Security Class Initialized
INFO - 2020-10-20 10:18:25 --> Security Class Initialized
DEBUG - 2020-10-20 10:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:25 --> Input Class Initialized
INFO - 2020-10-20 10:18:25 --> Input Class Initialized
INFO - 2020-10-20 10:18:25 --> Input Class Initialized
INFO - 2020-10-20 10:18:25 --> Language Class Initialized
INFO - 2020-10-20 10:18:25 --> Language Class Initialized
INFO - 2020-10-20 10:18:25 --> Language Class Initialized
ERROR - 2020-10-20 10:18:25 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:18:25 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:18:25 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:25 --> Config Class Initialized
INFO - 2020-10-20 10:18:25 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:25 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:25 --> URI Class Initialized
INFO - 2020-10-20 10:18:25 --> Router Class Initialized
INFO - 2020-10-20 10:18:25 --> Output Class Initialized
INFO - 2020-10-20 10:18:25 --> Security Class Initialized
DEBUG - 2020-10-20 10:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:25 --> Input Class Initialized
INFO - 2020-10-20 10:18:25 --> Language Class Initialized
ERROR - 2020-10-20 10:18:25 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-20 10:18:26 --> Config Class Initialized
INFO - 2020-10-20 10:18:26 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:26 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:26 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:26 --> URI Class Initialized
INFO - 2020-10-20 10:18:26 --> Router Class Initialized
INFO - 2020-10-20 10:18:26 --> Output Class Initialized
INFO - 2020-10-20 10:18:26 --> Security Class Initialized
DEBUG - 2020-10-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:26 --> Input Class Initialized
INFO - 2020-10-20 10:18:26 --> Language Class Initialized
INFO - 2020-10-20 10:18:26 --> Loader Class Initialized
INFO - 2020-10-20 10:18:26 --> Helper loaded: url_helper
INFO - 2020-10-20 10:18:26 --> Helper loaded: form_helper
INFO - 2020-10-20 10:18:26 --> Helper loaded: html_helper
INFO - 2020-10-20 10:18:26 --> Helper loaded: date_helper
INFO - 2020-10-20 10:18:26 --> Database Driver Class Initialized
INFO - 2020-10-20 10:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:18:26 --> Table Class Initialized
INFO - 2020-10-20 10:18:26 --> Upload Class Initialized
INFO - 2020-10-20 10:18:26 --> Controller Class Initialized
INFO - 2020-10-20 10:18:26 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:18:26 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:18:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:18:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:18:26 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:18:26 --> Final output sent to browser
DEBUG - 2020-10-20 10:18:26 --> Total execution time: 0.0381
INFO - 2020-10-20 10:18:26 --> Config Class Initialized
INFO - 2020-10-20 10:18:26 --> Config Class Initialized
INFO - 2020-10-20 10:18:26 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:26 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:26 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:26 --> Config Class Initialized
INFO - 2020-10-20 10:18:26 --> Config Class Initialized
INFO - 2020-10-20 10:18:26 --> Config Class Initialized
INFO - 2020-10-20 10:18:26 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:26 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:26 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:26 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:26 --> URI Class Initialized
DEBUG - 2020-10-20 10:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:18:26 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:18:26 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:26 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:26 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:26 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:26 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:26 --> Router Class Initialized
INFO - 2020-10-20 10:18:26 --> URI Class Initialized
INFO - 2020-10-20 10:18:26 --> URI Class Initialized
INFO - 2020-10-20 10:18:26 --> URI Class Initialized
INFO - 2020-10-20 10:18:26 --> URI Class Initialized
INFO - 2020-10-20 10:18:26 --> Router Class Initialized
INFO - 2020-10-20 10:18:26 --> Router Class Initialized
INFO - 2020-10-20 10:18:26 --> Router Class Initialized
INFO - 2020-10-20 10:18:26 --> Output Class Initialized
INFO - 2020-10-20 10:18:26 --> Router Class Initialized
INFO - 2020-10-20 10:18:26 --> Output Class Initialized
INFO - 2020-10-20 10:18:26 --> Output Class Initialized
INFO - 2020-10-20 10:18:26 --> Output Class Initialized
INFO - 2020-10-20 10:18:26 --> Output Class Initialized
INFO - 2020-10-20 10:18:26 --> Security Class Initialized
INFO - 2020-10-20 10:18:26 --> Security Class Initialized
INFO - 2020-10-20 10:18:26 --> Security Class Initialized
INFO - 2020-10-20 10:18:26 --> Security Class Initialized
DEBUG - 2020-10-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:26 --> Input Class Initialized
DEBUG - 2020-10-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:26 --> Security Class Initialized
INFO - 2020-10-20 10:18:26 --> Input Class Initialized
INFO - 2020-10-20 10:18:26 --> Input Class Initialized
INFO - 2020-10-20 10:18:26 --> Input Class Initialized
INFO - 2020-10-20 10:18:26 --> Language Class Initialized
DEBUG - 2020-10-20 10:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:26 --> Language Class Initialized
INFO - 2020-10-20 10:18:26 --> Language Class Initialized
INFO - 2020-10-20 10:18:26 --> Language Class Initialized
ERROR - 2020-10-20 10:18:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:26 --> Input Class Initialized
ERROR - 2020-10-20 10:18:26 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:18:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:26 --> Language Class Initialized
ERROR - 2020-10-20 10:18:26 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:18:26 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:31 --> Config Class Initialized
INFO - 2020-10-20 10:18:31 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:31 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:31 --> URI Class Initialized
INFO - 2020-10-20 10:18:31 --> Router Class Initialized
INFO - 2020-10-20 10:18:31 --> Output Class Initialized
INFO - 2020-10-20 10:18:31 --> Security Class Initialized
DEBUG - 2020-10-20 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:31 --> Input Class Initialized
INFO - 2020-10-20 10:18:31 --> Language Class Initialized
INFO - 2020-10-20 10:18:31 --> Loader Class Initialized
INFO - 2020-10-20 10:18:31 --> Helper loaded: url_helper
INFO - 2020-10-20 10:18:31 --> Helper loaded: form_helper
INFO - 2020-10-20 10:18:31 --> Helper loaded: html_helper
INFO - 2020-10-20 10:18:31 --> Helper loaded: date_helper
INFO - 2020-10-20 10:18:31 --> Database Driver Class Initialized
INFO - 2020-10-20 10:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:18:31 --> Table Class Initialized
INFO - 2020-10-20 10:18:31 --> Upload Class Initialized
INFO - 2020-10-20 10:18:31 --> Controller Class Initialized
INFO - 2020-10-20 10:18:31 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:18:31 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:18:31 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:18:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:18:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:18:31 --> Final output sent to browser
DEBUG - 2020-10-20 10:18:31 --> Total execution time: 0.0436
INFO - 2020-10-20 10:18:31 --> Config Class Initialized
INFO - 2020-10-20 10:18:31 --> Config Class Initialized
INFO - 2020-10-20 10:18:31 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:31 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:31 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:18:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:31 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:31 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:31 --> URI Class Initialized
INFO - 2020-10-20 10:18:31 --> Config Class Initialized
INFO - 2020-10-20 10:18:31 --> URI Class Initialized
INFO - 2020-10-20 10:18:31 --> Config Class Initialized
INFO - 2020-10-20 10:18:31 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:31 --> Router Class Initialized
INFO - 2020-10-20 10:18:31 --> Router Class Initialized
INFO - 2020-10-20 10:18:31 --> Config Class Initialized
INFO - 2020-10-20 10:18:31 --> Hooks Class Initialized
INFO - 2020-10-20 10:18:31 --> Output Class Initialized
INFO - 2020-10-20 10:18:31 --> Output Class Initialized
INFO - 2020-10-20 10:18:31 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:18:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:31 --> Security Class Initialized
DEBUG - 2020-10-20 10:18:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:31 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:18:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:18:31 --> Security Class Initialized
INFO - 2020-10-20 10:18:31 --> Utf8 Class Initialized
INFO - 2020-10-20 10:18:31 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:31 --> URI Class Initialized
DEBUG - 2020-10-20 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:31 --> Input Class Initialized
INFO - 2020-10-20 10:18:31 --> Input Class Initialized
INFO - 2020-10-20 10:18:31 --> URI Class Initialized
INFO - 2020-10-20 10:18:31 --> URI Class Initialized
INFO - 2020-10-20 10:18:31 --> Router Class Initialized
INFO - 2020-10-20 10:18:31 --> Language Class Initialized
INFO - 2020-10-20 10:18:31 --> Language Class Initialized
INFO - 2020-10-20 10:18:31 --> Output Class Initialized
INFO - 2020-10-20 10:18:31 --> Router Class Initialized
ERROR - 2020-10-20 10:18:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:31 --> Router Class Initialized
ERROR - 2020-10-20 10:18:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:31 --> Security Class Initialized
INFO - 2020-10-20 10:18:31 --> Output Class Initialized
INFO - 2020-10-20 10:18:31 --> Output Class Initialized
DEBUG - 2020-10-20 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:31 --> Security Class Initialized
INFO - 2020-10-20 10:18:31 --> Security Class Initialized
INFO - 2020-10-20 10:18:31 --> Input Class Initialized
DEBUG - 2020-10-20 10:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:18:31 --> Language Class Initialized
INFO - 2020-10-20 10:18:31 --> Input Class Initialized
INFO - 2020-10-20 10:18:31 --> Input Class Initialized
INFO - 2020-10-20 10:18:31 --> Language Class Initialized
ERROR - 2020-10-20 10:18:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:18:31 --> Language Class Initialized
ERROR - 2020-10-20 10:18:31 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:18:31 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:55 --> Config Class Initialized
INFO - 2020-10-20 10:22:55 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:22:55 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:55 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:55 --> URI Class Initialized
INFO - 2020-10-20 10:22:55 --> Router Class Initialized
INFO - 2020-10-20 10:22:55 --> Output Class Initialized
INFO - 2020-10-20 10:22:55 --> Security Class Initialized
DEBUG - 2020-10-20 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:55 --> Input Class Initialized
INFO - 2020-10-20 10:22:55 --> Language Class Initialized
INFO - 2020-10-20 10:22:55 --> Loader Class Initialized
INFO - 2020-10-20 10:22:55 --> Helper loaded: url_helper
INFO - 2020-10-20 10:22:55 --> Helper loaded: form_helper
INFO - 2020-10-20 10:22:55 --> Helper loaded: html_helper
INFO - 2020-10-20 10:22:55 --> Helper loaded: date_helper
INFO - 2020-10-20 10:22:55 --> Database Driver Class Initialized
INFO - 2020-10-20 10:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:22:55 --> Table Class Initialized
INFO - 2020-10-20 10:22:55 --> Upload Class Initialized
INFO - 2020-10-20 10:22:55 --> Controller Class Initialized
INFO - 2020-10-20 10:22:55 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:22:55 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:22:55 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:22:55 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:22:55 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:22:55 --> Final output sent to browser
DEBUG - 2020-10-20 10:22:55 --> Total execution time: 0.0483
INFO - 2020-10-20 10:22:55 --> Config Class Initialized
INFO - 2020-10-20 10:22:55 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:55 --> Config Class Initialized
INFO - 2020-10-20 10:22:55 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:22:55 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:55 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:55 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:55 --> URI Class Initialized
INFO - 2020-10-20 10:22:55 --> Router Class Initialized
INFO - 2020-10-20 10:22:55 --> Config Class Initialized
INFO - 2020-10-20 10:22:55 --> Config Class Initialized
INFO - 2020-10-20 10:22:55 --> Config Class Initialized
INFO - 2020-10-20 10:22:55 --> URI Class Initialized
INFO - 2020-10-20 10:22:55 --> Output Class Initialized
INFO - 2020-10-20 10:22:55 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:55 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:55 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:55 --> Router Class Initialized
DEBUG - 2020-10-20 10:22:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:22:55 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:55 --> Output Class Initialized
DEBUG - 2020-10-20 10:22:55 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:55 --> Security Class Initialized
INFO - 2020-10-20 10:22:55 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:55 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:55 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:55 --> Security Class Initialized
INFO - 2020-10-20 10:22:55 --> URI Class Initialized
INFO - 2020-10-20 10:22:55 --> Input Class Initialized
INFO - 2020-10-20 10:22:55 --> URI Class Initialized
INFO - 2020-10-20 10:22:55 --> URI Class Initialized
INFO - 2020-10-20 10:22:55 --> Router Class Initialized
DEBUG - 2020-10-20 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:55 --> Router Class Initialized
INFO - 2020-10-20 10:22:55 --> Language Class Initialized
INFO - 2020-10-20 10:22:55 --> Router Class Initialized
ERROR - 2020-10-20 10:22:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:55 --> Output Class Initialized
INFO - 2020-10-20 10:22:55 --> Input Class Initialized
INFO - 2020-10-20 10:22:55 --> Output Class Initialized
INFO - 2020-10-20 10:22:55 --> Language Class Initialized
INFO - 2020-10-20 10:22:55 --> Output Class Initialized
INFO - 2020-10-20 10:22:55 --> Security Class Initialized
ERROR - 2020-10-20 10:22:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:55 --> Security Class Initialized
INFO - 2020-10-20 10:22:55 --> Security Class Initialized
DEBUG - 2020-10-20 10:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:55 --> Input Class Initialized
INFO - 2020-10-20 10:22:55 --> Input Class Initialized
DEBUG - 2020-10-20 10:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:55 --> Language Class Initialized
INFO - 2020-10-20 10:22:55 --> Input Class Initialized
INFO - 2020-10-20 10:22:55 --> Language Class Initialized
ERROR - 2020-10-20 10:22:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:55 --> Language Class Initialized
ERROR - 2020-10-20 10:22:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:22:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:22:56 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:56 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:56 --> URI Class Initialized
INFO - 2020-10-20 10:22:56 --> Router Class Initialized
INFO - 2020-10-20 10:22:56 --> Output Class Initialized
INFO - 2020-10-20 10:22:56 --> Security Class Initialized
DEBUG - 2020-10-20 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:56 --> Input Class Initialized
INFO - 2020-10-20 10:22:56 --> Language Class Initialized
INFO - 2020-10-20 10:22:56 --> Loader Class Initialized
INFO - 2020-10-20 10:22:56 --> Helper loaded: url_helper
INFO - 2020-10-20 10:22:56 --> Helper loaded: form_helper
INFO - 2020-10-20 10:22:56 --> Helper loaded: html_helper
INFO - 2020-10-20 10:22:56 --> Helper loaded: date_helper
INFO - 2020-10-20 10:22:56 --> Database Driver Class Initialized
INFO - 2020-10-20 10:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:22:56 --> Table Class Initialized
INFO - 2020-10-20 10:22:56 --> Upload Class Initialized
INFO - 2020-10-20 10:22:56 --> Controller Class Initialized
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:22:56 --> Final output sent to browser
DEBUG - 2020-10-20 10:22:56 --> Total execution time: 0.0507
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:22:56 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:56 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:56 --> URI Class Initialized
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> URI Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:56 --> Router Class Initialized
DEBUG - 2020-10-20 10:22:56 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:56 --> Router Class Initialized
INFO - 2020-10-20 10:22:56 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:56 --> Output Class Initialized
DEBUG - 2020-10-20 10:22:56 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:22:56 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:56 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:56 --> Output Class Initialized
INFO - 2020-10-20 10:22:56 --> URI Class Initialized
INFO - 2020-10-20 10:22:56 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:56 --> URI Class Initialized
INFO - 2020-10-20 10:22:56 --> Security Class Initialized
INFO - 2020-10-20 10:22:56 --> URI Class Initialized
INFO - 2020-10-20 10:22:56 --> Router Class Initialized
INFO - 2020-10-20 10:22:56 --> Security Class Initialized
DEBUG - 2020-10-20 10:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:56 --> Router Class Initialized
INFO - 2020-10-20 10:22:56 --> Input Class Initialized
INFO - 2020-10-20 10:22:56 --> Input Class Initialized
INFO - 2020-10-20 10:22:56 --> Output Class Initialized
INFO - 2020-10-20 10:22:56 --> Router Class Initialized
INFO - 2020-10-20 10:22:56 --> Output Class Initialized
INFO - 2020-10-20 10:22:56 --> Language Class Initialized
INFO - 2020-10-20 10:22:56 --> Language Class Initialized
INFO - 2020-10-20 10:22:56 --> Security Class Initialized
ERROR - 2020-10-20 10:22:56 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-20 10:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 10:22:56 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:56 --> Security Class Initialized
INFO - 2020-10-20 10:22:56 --> Output Class Initialized
INFO - 2020-10-20 10:22:56 --> Security Class Initialized
DEBUG - 2020-10-20 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:56 --> Input Class Initialized
INFO - 2020-10-20 10:22:56 --> Language Class Initialized
DEBUG - 2020-10-20 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:56 --> Input Class Initialized
ERROR - 2020-10-20 10:22:56 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:56 --> Language Class Initialized
INFO - 2020-10-20 10:22:56 --> Input Class Initialized
INFO - 2020-10-20 10:22:56 --> Language Class Initialized
ERROR - 2020-10-20 10:22:56 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:22:56 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:22:56 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:56 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:56 --> URI Class Initialized
INFO - 2020-10-20 10:22:56 --> Router Class Initialized
INFO - 2020-10-20 10:22:56 --> Output Class Initialized
INFO - 2020-10-20 10:22:56 --> Security Class Initialized
DEBUG - 2020-10-20 10:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:56 --> Input Class Initialized
INFO - 2020-10-20 10:22:56 --> Language Class Initialized
INFO - 2020-10-20 10:22:56 --> Loader Class Initialized
INFO - 2020-10-20 10:22:56 --> Helper loaded: url_helper
INFO - 2020-10-20 10:22:56 --> Helper loaded: form_helper
INFO - 2020-10-20 10:22:56 --> Helper loaded: html_helper
INFO - 2020-10-20 10:22:56 --> Helper loaded: date_helper
INFO - 2020-10-20 10:22:56 --> Database Driver Class Initialized
INFO - 2020-10-20 10:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:22:56 --> Table Class Initialized
INFO - 2020-10-20 10:22:56 --> Upload Class Initialized
INFO - 2020-10-20 10:22:56 --> Controller Class Initialized
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:22:56 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:22:56 --> Final output sent to browser
DEBUG - 2020-10-20 10:22:56 --> Total execution time: 0.0520
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:56 --> Config Class Initialized
INFO - 2020-10-20 10:22:56 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:22:57 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:57 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:57 --> Config Class Initialized
INFO - 2020-10-20 10:22:57 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:57 --> Config Class Initialized
INFO - 2020-10-20 10:22:57 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:57 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:57 --> URI Class Initialized
INFO - 2020-10-20 10:22:57 --> URI Class Initialized
INFO - 2020-10-20 10:22:57 --> Config Class Initialized
INFO - 2020-10-20 10:22:57 --> Router Class Initialized
INFO - 2020-10-20 10:22:57 --> Hooks Class Initialized
INFO - 2020-10-20 10:22:57 --> Router Class Initialized
DEBUG - 2020-10-20 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:22:57 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:57 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:57 --> Output Class Initialized
INFO - 2020-10-20 10:22:57 --> Output Class Initialized
INFO - 2020-10-20 10:22:57 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:22:57 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:22:57 --> Utf8 Class Initialized
INFO - 2020-10-20 10:22:57 --> URI Class Initialized
INFO - 2020-10-20 10:22:57 --> Security Class Initialized
INFO - 2020-10-20 10:22:57 --> URI Class Initialized
INFO - 2020-10-20 10:22:57 --> Security Class Initialized
INFO - 2020-10-20 10:22:57 --> Router Class Initialized
INFO - 2020-10-20 10:22:57 --> Router Class Initialized
DEBUG - 2020-10-20 10:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:57 --> URI Class Initialized
DEBUG - 2020-10-20 10:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:57 --> Router Class Initialized
INFO - 2020-10-20 10:22:57 --> Input Class Initialized
INFO - 2020-10-20 10:22:57 --> Output Class Initialized
INFO - 2020-10-20 10:22:57 --> Input Class Initialized
INFO - 2020-10-20 10:22:57 --> Output Class Initialized
INFO - 2020-10-20 10:22:57 --> Output Class Initialized
INFO - 2020-10-20 10:22:57 --> Security Class Initialized
INFO - 2020-10-20 10:22:57 --> Language Class Initialized
INFO - 2020-10-20 10:22:57 --> Security Class Initialized
INFO - 2020-10-20 10:22:57 --> Language Class Initialized
DEBUG - 2020-10-20 10:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 10:22:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:57 --> Input Class Initialized
INFO - 2020-10-20 10:22:57 --> Security Class Initialized
ERROR - 2020-10-20 10:22:57 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-20 10:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:57 --> Input Class Initialized
INFO - 2020-10-20 10:22:57 --> Language Class Initialized
DEBUG - 2020-10-20 10:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:22:57 --> Language Class Initialized
ERROR - 2020-10-20 10:22:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:57 --> Input Class Initialized
ERROR - 2020-10-20 10:22:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:22:57 --> Language Class Initialized
ERROR - 2020-10-20 10:22:57 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:23:08 --> Config Class Initialized
INFO - 2020-10-20 10:23:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:23:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:23:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:23:08 --> URI Class Initialized
INFO - 2020-10-20 10:23:08 --> Router Class Initialized
INFO - 2020-10-20 10:23:08 --> Output Class Initialized
INFO - 2020-10-20 10:23:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:23:08 --> Input Class Initialized
INFO - 2020-10-20 10:23:08 --> Language Class Initialized
INFO - 2020-10-20 10:23:08 --> Loader Class Initialized
INFO - 2020-10-20 10:23:08 --> Helper loaded: url_helper
INFO - 2020-10-20 10:23:08 --> Helper loaded: form_helper
INFO - 2020-10-20 10:23:08 --> Helper loaded: html_helper
INFO - 2020-10-20 10:23:08 --> Helper loaded: date_helper
INFO - 2020-10-20 10:23:08 --> Database Driver Class Initialized
INFO - 2020-10-20 10:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:23:08 --> Table Class Initialized
INFO - 2020-10-20 10:23:08 --> Upload Class Initialized
INFO - 2020-10-20 10:23:08 --> Controller Class Initialized
INFO - 2020-10-20 10:23:08 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:23:08 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:23:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:23:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:23:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:23:08 --> Final output sent to browser
DEBUG - 2020-10-20 10:23:08 --> Total execution time: 0.0710
INFO - 2020-10-20 10:23:09 --> Config Class Initialized
INFO - 2020-10-20 10:23:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:23:09 --> Config Class Initialized
DEBUG - 2020-10-20 10:23:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:23:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:23:09 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:23:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:23:09 --> Config Class Initialized
INFO - 2020-10-20 10:23:09 --> Config Class Initialized
INFO - 2020-10-20 10:23:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:23:09 --> URI Class Initialized
INFO - 2020-10-20 10:23:09 --> Config Class Initialized
INFO - 2020-10-20 10:23:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:23:09 --> URI Class Initialized
INFO - 2020-10-20 10:23:09 --> Router Class Initialized
INFO - 2020-10-20 10:23:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:23:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:23:09 --> Router Class Initialized
INFO - 2020-10-20 10:23:09 --> Output Class Initialized
DEBUG - 2020-10-20 10:23:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:23:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:23:09 --> Security Class Initialized
INFO - 2020-10-20 10:23:09 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:23:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:23:09 --> Output Class Initialized
INFO - 2020-10-20 10:23:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:23:09 --> URI Class Initialized
DEBUG - 2020-10-20 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:23:09 --> URI Class Initialized
INFO - 2020-10-20 10:23:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:23:09 --> Security Class Initialized
INFO - 2020-10-20 10:23:09 --> Router Class Initialized
DEBUG - 2020-10-20 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:23:09 --> Input Class Initialized
INFO - 2020-10-20 10:23:09 --> URI Class Initialized
INFO - 2020-10-20 10:23:09 --> Router Class Initialized
INFO - 2020-10-20 10:23:09 --> Input Class Initialized
INFO - 2020-10-20 10:23:09 --> Language Class Initialized
INFO - 2020-10-20 10:23:09 --> Router Class Initialized
INFO - 2020-10-20 10:23:09 --> Output Class Initialized
ERROR - 2020-10-20 10:23:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:23:09 --> Security Class Initialized
INFO - 2020-10-20 10:23:09 --> Language Class Initialized
INFO - 2020-10-20 10:23:09 --> Output Class Initialized
INFO - 2020-10-20 10:23:09 --> Output Class Initialized
DEBUG - 2020-10-20 10:23:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 10:23:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:23:09 --> Security Class Initialized
INFO - 2020-10-20 10:23:09 --> Security Class Initialized
DEBUG - 2020-10-20 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:23:09 --> Input Class Initialized
DEBUG - 2020-10-20 10:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:23:09 --> Input Class Initialized
INFO - 2020-10-20 10:23:09 --> Language Class Initialized
INFO - 2020-10-20 10:23:09 --> Language Class Initialized
ERROR - 2020-10-20 10:23:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:23:09 --> Input Class Initialized
INFO - 2020-10-20 10:23:09 --> Language Class Initialized
ERROR - 2020-10-20 10:23:09 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:23:09 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
INFO - 2020-10-20 10:24:49 --> Loader Class Initialized
INFO - 2020-10-20 10:24:49 --> Helper loaded: url_helper
INFO - 2020-10-20 10:24:49 --> Helper loaded: form_helper
INFO - 2020-10-20 10:24:49 --> Helper loaded: html_helper
INFO - 2020-10-20 10:24:49 --> Helper loaded: date_helper
INFO - 2020-10-20 10:24:49 --> Database Driver Class Initialized
INFO - 2020-10-20 10:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:24:49 --> Table Class Initialized
INFO - 2020-10-20 10:24:49 --> Upload Class Initialized
INFO - 2020-10-20 10:24:49 --> Controller Class Initialized
INFO - 2020-10-20 10:24:49 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:24:49 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:24:49 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:24:49 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:24:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:24:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:24:49 --> Final output sent to browser
DEBUG - 2020-10-20 10:24:49 --> Total execution time: 0.0611
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> Config Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
DEBUG - 2020-10-20 10:24:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:49 --> URI Class Initialized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
INFO - 2020-10-20 10:24:49 --> Router Class Initialized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
DEBUG - 2020-10-20 10:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
INFO - 2020-10-20 10:24:49 --> Input Class Initialized
INFO - 2020-10-20 10:24:49 --> Output Class Initialized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:49 --> Language Class Initialized
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:24:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:49 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:24:50 --> Config Class Initialized
INFO - 2020-10-20 10:24:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:24:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:24:50 --> Utf8 Class Initialized
INFO - 2020-10-20 10:24:50 --> URI Class Initialized
INFO - 2020-10-20 10:24:50 --> Router Class Initialized
INFO - 2020-10-20 10:24:50 --> Output Class Initialized
INFO - 2020-10-20 10:24:50 --> Security Class Initialized
DEBUG - 2020-10-20 10:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:24:50 --> Input Class Initialized
INFO - 2020-10-20 10:24:50 --> Language Class Initialized
ERROR - 2020-10-20 10:24:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Loader Class Initialized
INFO - 2020-10-20 10:28:08 --> Helper loaded: url_helper
INFO - 2020-10-20 10:28:08 --> Helper loaded: form_helper
INFO - 2020-10-20 10:28:08 --> Helper loaded: html_helper
INFO - 2020-10-20 10:28:08 --> Helper loaded: date_helper
INFO - 2020-10-20 10:28:08 --> Database Driver Class Initialized
INFO - 2020-10-20 10:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:28:08 --> Table Class Initialized
INFO - 2020-10-20 10:28:08 --> Upload Class Initialized
INFO - 2020-10-20 10:28:08 --> Controller Class Initialized
INFO - 2020-10-20 10:28:08 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:28:08 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:28:08 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:28:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:28:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:28:08 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:28:08 --> Final output sent to browser
DEBUG - 2020-10-20 10:28:08 --> Total execution time: 0.0742
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:08 --> Config Class Initialized
INFO - 2020-10-20 10:28:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:08 --> URI Class Initialized
INFO - 2020-10-20 10:28:08 --> Router Class Initialized
INFO - 2020-10-20 10:28:08 --> Output Class Initialized
INFO - 2020-10-20 10:28:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:08 --> Input Class Initialized
INFO - 2020-10-20 10:28:08 --> Language Class Initialized
ERROR - 2020-10-20 10:28:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Loader Class Initialized
INFO - 2020-10-20 10:28:43 --> Helper loaded: url_helper
INFO - 2020-10-20 10:28:43 --> Helper loaded: form_helper
INFO - 2020-10-20 10:28:43 --> Helper loaded: html_helper
INFO - 2020-10-20 10:28:43 --> Helper loaded: date_helper
INFO - 2020-10-20 10:28:43 --> Database Driver Class Initialized
INFO - 2020-10-20 10:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:28:43 --> Table Class Initialized
INFO - 2020-10-20 10:28:43 --> Upload Class Initialized
INFO - 2020-10-20 10:28:43 --> Controller Class Initialized
INFO - 2020-10-20 10:28:43 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:28:43 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:28:43 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:28:43 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:28:43 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:28:43 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:28:43 --> Final output sent to browser
DEBUG - 2020-10-20 10:28:43 --> Total execution time: 0.0986
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Output Class Initialized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Security Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:43 --> Input Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
INFO - 2020-10-20 10:28:43 --> Language Class Initialized
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:28:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Config Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:28:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:43 --> Router Class Initialized
INFO - 2020-10-20 10:28:43 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:28:44 --> Config Class Initialized
INFO - 2020-10-20 10:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:28:44 --> Utf8 Class Initialized
INFO - 2020-10-20 10:28:44 --> URI Class Initialized
INFO - 2020-10-20 10:28:44 --> Router Class Initialized
INFO - 2020-10-20 10:28:44 --> Output Class Initialized
INFO - 2020-10-20 10:28:44 --> Security Class Initialized
DEBUG - 2020-10-20 10:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:28:44 --> Input Class Initialized
INFO - 2020-10-20 10:28:44 --> Language Class Initialized
ERROR - 2020-10-20 10:28:44 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Loader Class Initialized
INFO - 2020-10-20 10:29:38 --> Helper loaded: url_helper
INFO - 2020-10-20 10:29:38 --> Helper loaded: form_helper
INFO - 2020-10-20 10:29:38 --> Helper loaded: html_helper
INFO - 2020-10-20 10:29:38 --> Helper loaded: date_helper
INFO - 2020-10-20 10:29:38 --> Database Driver Class Initialized
INFO - 2020-10-20 10:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:29:38 --> Table Class Initialized
INFO - 2020-10-20 10:29:38 --> Upload Class Initialized
INFO - 2020-10-20 10:29:38 --> Controller Class Initialized
INFO - 2020-10-20 10:29:38 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:29:38 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:29:38 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:29:38 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:29:38 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:29:38 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:29:38 --> Final output sent to browser
DEBUG - 2020-10-20 10:29:38 --> Total execution time: 0.0970
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Config Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:38 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:29:38 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> URI Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Router Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Output Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
INFO - 2020-10-20 10:29:38 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Input Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
INFO - 2020-10-20 10:29:38 --> Language Class Initialized
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:29:38 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:29:39 --> Config Class Initialized
INFO - 2020-10-20 10:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:29:39 --> Utf8 Class Initialized
INFO - 2020-10-20 10:29:39 --> URI Class Initialized
INFO - 2020-10-20 10:29:39 --> Router Class Initialized
INFO - 2020-10-20 10:29:39 --> Output Class Initialized
INFO - 2020-10-20 10:29:39 --> Security Class Initialized
DEBUG - 2020-10-20 10:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:29:39 --> Input Class Initialized
INFO - 2020-10-20 10:29:39 --> Language Class Initialized
ERROR - 2020-10-20 10:29:39 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Loader Class Initialized
INFO - 2020-10-20 10:38:30 --> Helper loaded: url_helper
INFO - 2020-10-20 10:38:30 --> Helper loaded: form_helper
INFO - 2020-10-20 10:38:30 --> Helper loaded: html_helper
INFO - 2020-10-20 10:38:30 --> Helper loaded: date_helper
INFO - 2020-10-20 10:38:30 --> Database Driver Class Initialized
INFO - 2020-10-20 10:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:38:30 --> Table Class Initialized
INFO - 2020-10-20 10:38:30 --> Upload Class Initialized
INFO - 2020-10-20 10:38:30 --> Controller Class Initialized
INFO - 2020-10-20 10:38:30 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:38:30 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:38:30 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:38:30 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:38:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:38:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:38:30 --> Final output sent to browser
DEBUG - 2020-10-20 10:38:30 --> Total execution time: 0.1055
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Config Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
DEBUG - 2020-10-20 10:38:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> URI Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Router Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Output Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Security Class Initialized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
DEBUG - 2020-10-20 10:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:30 --> Input Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:30 --> Language Class Initialized
ERROR - 2020-10-20 10:38:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:36 --> URI Class Initialized
INFO - 2020-10-20 10:38:36 --> Router Class Initialized
INFO - 2020-10-20 10:38:36 --> Output Class Initialized
INFO - 2020-10-20 10:38:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:36 --> Input Class Initialized
INFO - 2020-10-20 10:38:36 --> Language Class Initialized
ERROR - 2020-10-20 10:38:36 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:36 --> Config Class Initialized
INFO - 2020-10-20 10:38:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:37 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:37 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:37 --> URI Class Initialized
INFO - 2020-10-20 10:38:37 --> Router Class Initialized
INFO - 2020-10-20 10:38:37 --> Output Class Initialized
INFO - 2020-10-20 10:38:37 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:37 --> Input Class Initialized
INFO - 2020-10-20 10:38:37 --> Language Class Initialized
ERROR - 2020-10-20 10:38:37 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:38:37 --> Config Class Initialized
INFO - 2020-10-20 10:38:37 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:38:37 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:38:37 --> Utf8 Class Initialized
INFO - 2020-10-20 10:38:37 --> URI Class Initialized
INFO - 2020-10-20 10:38:37 --> Router Class Initialized
INFO - 2020-10-20 10:38:37 --> Output Class Initialized
INFO - 2020-10-20 10:38:37 --> Security Class Initialized
DEBUG - 2020-10-20 10:38:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:38:37 --> Input Class Initialized
INFO - 2020-10-20 10:38:37 --> Language Class Initialized
ERROR - 2020-10-20 10:38:37 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:42:10 --> Config Class Initialized
INFO - 2020-10-20 10:42:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:10 --> URI Class Initialized
INFO - 2020-10-20 10:42:10 --> Router Class Initialized
INFO - 2020-10-20 10:42:10 --> Output Class Initialized
INFO - 2020-10-20 10:42:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:10 --> Input Class Initialized
INFO - 2020-10-20 10:42:10 --> Language Class Initialized
INFO - 2020-10-20 10:42:10 --> Loader Class Initialized
INFO - 2020-10-20 10:42:10 --> Helper loaded: url_helper
INFO - 2020-10-20 10:42:10 --> Helper loaded: form_helper
INFO - 2020-10-20 10:42:10 --> Helper loaded: html_helper
INFO - 2020-10-20 10:42:11 --> Helper loaded: date_helper
INFO - 2020-10-20 10:42:11 --> Database Driver Class Initialized
INFO - 2020-10-20 10:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:42:11 --> Table Class Initialized
INFO - 2020-10-20 10:42:11 --> Upload Class Initialized
INFO - 2020-10-20 10:42:11 --> Controller Class Initialized
INFO - 2020-10-20 10:42:11 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:42:11 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:42:11 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:42:11 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:42:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:42:11 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:42:11 --> Final output sent to browser
DEBUG - 2020-10-20 10:42:11 --> Total execution time: 0.1331
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:11 --> Config Class Initialized
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> URI Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Router Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Output Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
INFO - 2020-10-20 10:42:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Input Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
INFO - 2020-10-20 10:42:11 --> Language Class Initialized
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:42:18 --> Config Class Initialized
INFO - 2020-10-20 10:42:18 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:18 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:18 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:18 --> URI Class Initialized
INFO - 2020-10-20 10:42:18 --> Router Class Initialized
INFO - 2020-10-20 10:42:18 --> Output Class Initialized
INFO - 2020-10-20 10:42:18 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:18 --> Input Class Initialized
INFO - 2020-10-20 10:42:18 --> Language Class Initialized
INFO - 2020-10-20 10:42:18 --> Loader Class Initialized
INFO - 2020-10-20 10:42:18 --> Helper loaded: url_helper
INFO - 2020-10-20 10:42:18 --> Helper loaded: form_helper
INFO - 2020-10-20 10:42:18 --> Helper loaded: html_helper
INFO - 2020-10-20 10:42:18 --> Helper loaded: date_helper
INFO - 2020-10-20 10:42:18 --> Database Driver Class Initialized
INFO - 2020-10-20 10:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:42:18 --> Table Class Initialized
INFO - 2020-10-20 10:42:18 --> Upload Class Initialized
INFO - 2020-10-20 10:42:18 --> Controller Class Initialized
INFO - 2020-10-20 10:42:18 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:42:18 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:42:18 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:42:18 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:42:18 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:42:18 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:42:18 --> Final output sent to browser
DEBUG - 2020-10-20 10:42:18 --> Total execution time: 0.1343
INFO - 2020-10-20 10:42:18 --> Config Class Initialized
INFO - 2020-10-20 10:42:18 --> Config Class Initialized
INFO - 2020-10-20 10:42:18 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:18 --> Config Class Initialized
INFO - 2020-10-20 10:42:18 --> Config Class Initialized
INFO - 2020-10-20 10:42:18 --> Config Class Initialized
INFO - 2020-10-20 10:42:18 --> Config Class Initialized
INFO - 2020-10-20 10:42:18 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:18 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:18 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:18 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:18 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:18 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:18 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:18 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:18 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:18 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:18 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:18 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:18 --> URI Class Initialized
INFO - 2020-10-20 10:42:18 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:18 --> URI Class Initialized
INFO - 2020-10-20 10:42:18 --> URI Class Initialized
INFO - 2020-10-20 10:42:18 --> URI Class Initialized
INFO - 2020-10-20 10:42:18 --> URI Class Initialized
INFO - 2020-10-20 10:42:18 --> URI Class Initialized
INFO - 2020-10-20 10:42:18 --> Router Class Initialized
INFO - 2020-10-20 10:42:18 --> Router Class Initialized
INFO - 2020-10-20 10:42:18 --> Router Class Initialized
INFO - 2020-10-20 10:42:18 --> Router Class Initialized
INFO - 2020-10-20 10:42:18 --> Router Class Initialized
INFO - 2020-10-20 10:42:18 --> Router Class Initialized
INFO - 2020-10-20 10:42:18 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:19 --> Router Class Initialized
INFO - 2020-10-20 10:42:19 --> Output Class Initialized
INFO - 2020-10-20 10:42:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:19 --> Input Class Initialized
INFO - 2020-10-20 10:42:19 --> Language Class Initialized
ERROR - 2020-10-20 10:42:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:19 --> Config Class Initialized
INFO - 2020-10-20 10:42:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:19 --> URI Class Initialized
INFO - 2020-10-20 10:42:20 --> Router Class Initialized
INFO - 2020-10-20 10:42:20 --> Output Class Initialized
INFO - 2020-10-20 10:42:20 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:20 --> Input Class Initialized
INFO - 2020-10-20 10:42:20 --> Language Class Initialized
ERROR - 2020-10-20 10:42:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:20 --> Config Class Initialized
INFO - 2020-10-20 10:42:20 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:20 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:20 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:20 --> URI Class Initialized
INFO - 2020-10-20 10:42:20 --> Router Class Initialized
INFO - 2020-10-20 10:42:20 --> Output Class Initialized
INFO - 2020-10-20 10:42:20 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:20 --> Input Class Initialized
INFO - 2020-10-20 10:42:20 --> Language Class Initialized
ERROR - 2020-10-20 10:42:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:42:20 --> Config Class Initialized
INFO - 2020-10-20 10:42:20 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:42:20 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:42:20 --> Utf8 Class Initialized
INFO - 2020-10-20 10:42:20 --> URI Class Initialized
INFO - 2020-10-20 10:42:20 --> Router Class Initialized
INFO - 2020-10-20 10:42:20 --> Output Class Initialized
INFO - 2020-10-20 10:42:20 --> Security Class Initialized
DEBUG - 2020-10-20 10:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:42:20 --> Input Class Initialized
INFO - 2020-10-20 10:42:20 --> Language Class Initialized
ERROR - 2020-10-20 10:42:20 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:44:43 --> Config Class Initialized
INFO - 2020-10-20 10:44:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:44:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:44:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:44:43 --> URI Class Initialized
DEBUG - 2020-10-20 10:44:43 --> No URI present. Default controller set.
INFO - 2020-10-20 10:44:43 --> Router Class Initialized
INFO - 2020-10-20 10:44:43 --> Output Class Initialized
INFO - 2020-10-20 10:44:43 --> Security Class Initialized
DEBUG - 2020-10-20 10:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:44:43 --> Input Class Initialized
INFO - 2020-10-20 10:44:43 --> Language Class Initialized
INFO - 2020-10-20 10:44:43 --> Loader Class Initialized
INFO - 2020-10-20 10:44:43 --> Helper loaded: url_helper
INFO - 2020-10-20 10:44:43 --> Helper loaded: form_helper
INFO - 2020-10-20 10:44:43 --> Helper loaded: html_helper
INFO - 2020-10-20 10:44:43 --> Helper loaded: date_helper
INFO - 2020-10-20 10:44:43 --> Database Driver Class Initialized
INFO - 2020-10-20 10:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:44:43 --> Table Class Initialized
INFO - 2020-10-20 10:44:43 --> Upload Class Initialized
INFO - 2020-10-20 10:44:43 --> Controller Class Initialized
INFO - 2020-10-20 10:44:43 --> Form Validation Class Initialized
ERROR - 2020-10-20 10:44:43 --> Severity: error --> Exception: Unable to locate the model you have specified: Crud_model C:\xampp\htdocs\system\core\Loader.php 348
INFO - 2020-10-20 10:45:08 --> Config Class Initialized
INFO - 2020-10-20 10:45:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:45:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:45:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:45:09 --> URI Class Initialized
INFO - 2020-10-20 10:45:09 --> Router Class Initialized
INFO - 2020-10-20 10:45:09 --> Output Class Initialized
INFO - 2020-10-20 10:45:09 --> Security Class Initialized
DEBUG - 2020-10-20 10:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:45:09 --> Input Class Initialized
INFO - 2020-10-20 10:45:09 --> Language Class Initialized
ERROR - 2020-10-20 10:45:09 --> 404 Page Not Found: Welcome/panel
INFO - 2020-10-20 10:45:14 --> Config Class Initialized
INFO - 2020-10-20 10:45:14 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:45:14 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:45:14 --> Utf8 Class Initialized
INFO - 2020-10-20 10:45:14 --> URI Class Initialized
INFO - 2020-10-20 10:45:14 --> Router Class Initialized
INFO - 2020-10-20 10:45:14 --> Output Class Initialized
INFO - 2020-10-20 10:45:14 --> Security Class Initialized
DEBUG - 2020-10-20 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:45:14 --> Input Class Initialized
INFO - 2020-10-20 10:45:14 --> Language Class Initialized
ERROR - 2020-10-20 10:45:14 --> 404 Page Not Found: Welcome/panel
INFO - 2020-10-20 10:46:07 --> Config Class Initialized
INFO - 2020-10-20 10:46:07 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:46:07 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:46:07 --> Utf8 Class Initialized
INFO - 2020-10-20 10:46:07 --> URI Class Initialized
INFO - 2020-10-20 10:46:07 --> Router Class Initialized
INFO - 2020-10-20 10:46:07 --> Output Class Initialized
INFO - 2020-10-20 10:46:07 --> Security Class Initialized
DEBUG - 2020-10-20 10:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:46:07 --> Input Class Initialized
INFO - 2020-10-20 10:46:07 --> Language Class Initialized
ERROR - 2020-10-20 10:46:07 --> 404 Page Not Found: Welcome/panel
INFO - 2020-10-20 10:46:10 --> Config Class Initialized
INFO - 2020-10-20 10:46:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:46:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:46:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:46:10 --> URI Class Initialized
INFO - 2020-10-20 10:46:10 --> Router Class Initialized
INFO - 2020-10-20 10:46:10 --> Output Class Initialized
INFO - 2020-10-20 10:46:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:46:10 --> Input Class Initialized
INFO - 2020-10-20 10:46:10 --> Language Class Initialized
ERROR - 2020-10-20 10:46:10 --> 404 Page Not Found: Welcome/panel
INFO - 2020-10-20 10:46:19 --> Config Class Initialized
INFO - 2020-10-20 10:46:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:46:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:46:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:46:19 --> URI Class Initialized
INFO - 2020-10-20 10:46:19 --> Router Class Initialized
INFO - 2020-10-20 10:46:19 --> Output Class Initialized
INFO - 2020-10-20 10:46:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:46:19 --> Input Class Initialized
INFO - 2020-10-20 10:46:19 --> Language Class Initialized
INFO - 2020-10-20 10:46:19 --> Loader Class Initialized
INFO - 2020-10-20 10:46:19 --> Helper loaded: url_helper
INFO - 2020-10-20 10:46:19 --> Helper loaded: form_helper
INFO - 2020-10-20 10:46:19 --> Helper loaded: html_helper
INFO - 2020-10-20 10:46:19 --> Helper loaded: date_helper
INFO - 2020-10-20 10:46:19 --> Database Driver Class Initialized
INFO - 2020-10-20 10:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:46:19 --> Table Class Initialized
INFO - 2020-10-20 10:46:19 --> Upload Class Initialized
INFO - 2020-10-20 10:46:19 --> Controller Class Initialized
INFO - 2020-10-20 10:46:19 --> Form Validation Class Initialized
ERROR - 2020-10-20 10:46:19 --> Severity: error --> Exception: Unable to locate the model you have specified: Crud_model C:\xampp\htdocs\system\core\Loader.php 348
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> Router Class Initialized
INFO - 2020-10-20 10:48:40 --> Output Class Initialized
INFO - 2020-10-20 10:48:40 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:40 --> Input Class Initialized
INFO - 2020-10-20 10:48:40 --> Language Class Initialized
INFO - 2020-10-20 10:48:40 --> Loader Class Initialized
INFO - 2020-10-20 10:48:40 --> Helper loaded: url_helper
INFO - 2020-10-20 10:48:40 --> Helper loaded: form_helper
INFO - 2020-10-20 10:48:40 --> Helper loaded: html_helper
INFO - 2020-10-20 10:48:40 --> Helper loaded: date_helper
INFO - 2020-10-20 10:48:40 --> Database Driver Class Initialized
INFO - 2020-10-20 10:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:48:40 --> Table Class Initialized
INFO - 2020-10-20 10:48:40 --> Upload Class Initialized
INFO - 2020-10-20 10:48:40 --> Controller Class Initialized
INFO - 2020-10-20 10:48:40 --> Form Validation Class Initialized
INFO - 2020-10-20 10:48:40 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:48:40 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:48:40 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:48:40 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:48:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:48:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:48:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:48:40 --> Final output sent to browser
DEBUG - 2020-10-20 10:48:40 --> Total execution time: 0.1508
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> Router Class Initialized
INFO - 2020-10-20 10:48:40 --> Router Class Initialized
INFO - 2020-10-20 10:48:40 --> Router Class Initialized
INFO - 2020-10-20 10:48:40 --> Router Class Initialized
INFO - 2020-10-20 10:48:40 --> Router Class Initialized
INFO - 2020-10-20 10:48:40 --> Router Class Initialized
INFO - 2020-10-20 10:48:40 --> Output Class Initialized
INFO - 2020-10-20 10:48:40 --> Security Class Initialized
INFO - 2020-10-20 10:48:40 --> Output Class Initialized
INFO - 2020-10-20 10:48:40 --> Output Class Initialized
INFO - 2020-10-20 10:48:40 --> Output Class Initialized
INFO - 2020-10-20 10:48:40 --> Output Class Initialized
INFO - 2020-10-20 10:48:40 --> Output Class Initialized
DEBUG - 2020-10-20 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:40 --> Security Class Initialized
INFO - 2020-10-20 10:48:40 --> Security Class Initialized
INFO - 2020-10-20 10:48:40 --> Security Class Initialized
INFO - 2020-10-20 10:48:40 --> Security Class Initialized
INFO - 2020-10-20 10:48:40 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:40 --> Input Class Initialized
DEBUG - 2020-10-20 10:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:40 --> Input Class Initialized
INFO - 2020-10-20 10:48:40 --> Input Class Initialized
INFO - 2020-10-20 10:48:40 --> Input Class Initialized
INFO - 2020-10-20 10:48:40 --> Input Class Initialized
INFO - 2020-10-20 10:48:40 --> Input Class Initialized
INFO - 2020-10-20 10:48:40 --> Language Class Initialized
INFO - 2020-10-20 10:48:40 --> Language Class Initialized
INFO - 2020-10-20 10:48:40 --> Language Class Initialized
INFO - 2020-10-20 10:48:40 --> Language Class Initialized
INFO - 2020-10-20 10:48:40 --> Language Class Initialized
INFO - 2020-10-20 10:48:40 --> Language Class Initialized
ERROR - 2020-10-20 10:48:40 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:48:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:40 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
INFO - 2020-10-20 10:48:40 --> Config Class Initialized
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:40 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:40 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:41 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:41 --> URI Class Initialized
INFO - 2020-10-20 10:48:41 --> Router Class Initialized
INFO - 2020-10-20 10:48:41 --> Output Class Initialized
INFO - 2020-10-20 10:48:41 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:41 --> Input Class Initialized
INFO - 2020-10-20 10:48:41 --> Language Class Initialized
ERROR - 2020-10-20 10:48:41 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:41 --> Config Class Initialized
INFO - 2020-10-20 10:48:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:42 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:42 --> URI Class Initialized
INFO - 2020-10-20 10:48:42 --> Router Class Initialized
INFO - 2020-10-20 10:48:42 --> Output Class Initialized
INFO - 2020-10-20 10:48:42 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:42 --> Input Class Initialized
INFO - 2020-10-20 10:48:42 --> Language Class Initialized
ERROR - 2020-10-20 10:48:42 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:48:42 --> Config Class Initialized
INFO - 2020-10-20 10:48:42 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:48:42 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:48:42 --> Utf8 Class Initialized
INFO - 2020-10-20 10:48:42 --> URI Class Initialized
INFO - 2020-10-20 10:48:42 --> Router Class Initialized
INFO - 2020-10-20 10:48:42 --> Output Class Initialized
INFO - 2020-10-20 10:48:42 --> Security Class Initialized
DEBUG - 2020-10-20 10:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:48:42 --> Input Class Initialized
INFO - 2020-10-20 10:48:42 --> Language Class Initialized
ERROR - 2020-10-20 10:48:42 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:51:11 --> Config Class Initialized
INFO - 2020-10-20 10:51:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:11 --> URI Class Initialized
INFO - 2020-10-20 10:51:11 --> Router Class Initialized
INFO - 2020-10-20 10:51:11 --> Output Class Initialized
INFO - 2020-10-20 10:51:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:11 --> Input Class Initialized
INFO - 2020-10-20 10:51:11 --> Language Class Initialized
INFO - 2020-10-20 10:51:11 --> Loader Class Initialized
INFO - 2020-10-20 10:51:11 --> Helper loaded: url_helper
INFO - 2020-10-20 10:51:11 --> Helper loaded: form_helper
INFO - 2020-10-20 10:51:11 --> Helper loaded: html_helper
INFO - 2020-10-20 10:51:11 --> Helper loaded: date_helper
INFO - 2020-10-20 10:51:11 --> Database Driver Class Initialized
INFO - 2020-10-20 10:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:51:11 --> Table Class Initialized
INFO - 2020-10-20 10:51:12 --> Upload Class Initialized
INFO - 2020-10-20 10:51:12 --> Controller Class Initialized
INFO - 2020-10-20 10:51:12 --> Form Validation Class Initialized
INFO - 2020-10-20 10:51:12 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:51:12 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:51:12 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:51:12 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:51:12 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:51:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:51:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:51:12 --> Final output sent to browser
DEBUG - 2020-10-20 10:51:12 --> Total execution time: 0.1731
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/js
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/js
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:12 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:12 --> URI Class Initialized
INFO - 2020-10-20 10:51:12 --> Router Class Initialized
INFO - 2020-10-20 10:51:12 --> Output Class Initialized
INFO - 2020-10-20 10:51:12 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:12 --> Input Class Initialized
INFO - 2020-10-20 10:51:12 --> Language Class Initialized
ERROR - 2020-10-20 10:51:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:51:12 --> Config Class Initialized
INFO - 2020-10-20 10:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:13 --> Config Class Initialized
INFO - 2020-10-20 10:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:13 --> URI Class Initialized
INFO - 2020-10-20 10:51:13 --> Router Class Initialized
INFO - 2020-10-20 10:51:13 --> Output Class Initialized
INFO - 2020-10-20 10:51:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:13 --> Input Class Initialized
INFO - 2020-10-20 10:51:13 --> Language Class Initialized
ERROR - 2020-10-20 10:51:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:51:19 --> Config Class Initialized
INFO - 2020-10-20 10:51:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:19 --> URI Class Initialized
INFO - 2020-10-20 10:51:19 --> Router Class Initialized
INFO - 2020-10-20 10:51:19 --> Output Class Initialized
INFO - 2020-10-20 10:51:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:19 --> Input Class Initialized
INFO - 2020-10-20 10:51:19 --> Language Class Initialized
ERROR - 2020-10-20 10:51:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:51:59 --> Config Class Initialized
INFO - 2020-10-20 10:51:59 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:51:59 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:51:59 --> Utf8 Class Initialized
INFO - 2020-10-20 10:51:59 --> URI Class Initialized
INFO - 2020-10-20 10:51:59 --> Router Class Initialized
INFO - 2020-10-20 10:51:59 --> Output Class Initialized
INFO - 2020-10-20 10:51:59 --> Security Class Initialized
DEBUG - 2020-10-20 10:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:51:59 --> Input Class Initialized
INFO - 2020-10-20 10:51:59 --> Language Class Initialized
ERROR - 2020-10-20 10:51:59 --> 404 Page Not Found: Assets/js
INFO - 2020-10-20 10:52:26 --> Config Class Initialized
INFO - 2020-10-20 10:52:26 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:52:26 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:52:26 --> Utf8 Class Initialized
INFO - 2020-10-20 10:52:26 --> URI Class Initialized
INFO - 2020-10-20 10:52:26 --> Router Class Initialized
INFO - 2020-10-20 10:52:26 --> Output Class Initialized
INFO - 2020-10-20 10:52:26 --> Security Class Initialized
DEBUG - 2020-10-20 10:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:52:26 --> Input Class Initialized
INFO - 2020-10-20 10:52:26 --> Language Class Initialized
ERROR - 2020-10-20 10:52:26 --> 404 Page Not Found: Assets/js
INFO - 2020-10-20 10:52:35 --> Config Class Initialized
INFO - 2020-10-20 10:52:35 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:52:35 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:52:35 --> Utf8 Class Initialized
INFO - 2020-10-20 10:52:35 --> URI Class Initialized
INFO - 2020-10-20 10:52:35 --> Router Class Initialized
INFO - 2020-10-20 10:52:35 --> Output Class Initialized
INFO - 2020-10-20 10:52:35 --> Security Class Initialized
DEBUG - 2020-10-20 10:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:52:35 --> Input Class Initialized
INFO - 2020-10-20 10:52:35 --> Language Class Initialized
INFO - 2020-10-20 10:52:35 --> Loader Class Initialized
INFO - 2020-10-20 10:52:35 --> Helper loaded: url_helper
INFO - 2020-10-20 10:52:35 --> Helper loaded: form_helper
INFO - 2020-10-20 10:52:35 --> Helper loaded: html_helper
INFO - 2020-10-20 10:52:35 --> Helper loaded: date_helper
INFO - 2020-10-20 10:52:35 --> Database Driver Class Initialized
INFO - 2020-10-20 10:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:52:35 --> Table Class Initialized
INFO - 2020-10-20 10:52:35 --> Upload Class Initialized
INFO - 2020-10-20 10:52:35 --> Controller Class Initialized
INFO - 2020-10-20 10:52:35 --> Form Validation Class Initialized
INFO - 2020-10-20 10:52:35 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:52:35 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:52:35 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:52:35 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:52:35 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:52:35 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:52:35 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:52:35 --> Final output sent to browser
DEBUG - 2020-10-20 10:52:35 --> Total execution time: 0.2103
INFO - 2020-10-20 10:52:43 --> Config Class Initialized
INFO - 2020-10-20 10:52:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:52:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:52:43 --> Utf8 Class Initialized
INFO - 2020-10-20 10:52:43 --> URI Class Initialized
INFO - 2020-10-20 10:52:43 --> Router Class Initialized
INFO - 2020-10-20 10:52:43 --> Output Class Initialized
INFO - 2020-10-20 10:52:43 --> Security Class Initialized
DEBUG - 2020-10-20 10:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:52:43 --> Input Class Initialized
INFO - 2020-10-20 10:52:43 --> Language Class Initialized
ERROR - 2020-10-20 10:52:43 --> 404 Page Not Found: Assets/js
INFO - 2020-10-20 10:52:58 --> Config Class Initialized
INFO - 2020-10-20 10:52:58 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:52:58 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:52:58 --> Utf8 Class Initialized
INFO - 2020-10-20 10:52:58 --> URI Class Initialized
INFO - 2020-10-20 10:52:58 --> Router Class Initialized
INFO - 2020-10-20 10:52:58 --> Output Class Initialized
INFO - 2020-10-20 10:52:58 --> Security Class Initialized
DEBUG - 2020-10-20 10:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:52:58 --> Input Class Initialized
INFO - 2020-10-20 10:52:58 --> Language Class Initialized
INFO - 2020-10-20 10:52:58 --> Loader Class Initialized
INFO - 2020-10-20 10:52:58 --> Helper loaded: url_helper
INFO - 2020-10-20 10:52:58 --> Helper loaded: form_helper
INFO - 2020-10-20 10:52:58 --> Helper loaded: html_helper
INFO - 2020-10-20 10:52:58 --> Helper loaded: date_helper
INFO - 2020-10-20 10:52:58 --> Database Driver Class Initialized
INFO - 2020-10-20 10:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:52:58 --> Table Class Initialized
INFO - 2020-10-20 10:52:58 --> Upload Class Initialized
INFO - 2020-10-20 10:52:58 --> Controller Class Initialized
INFO - 2020-10-20 10:52:58 --> Form Validation Class Initialized
INFO - 2020-10-20 10:52:58 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:52:58 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:52:58 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:52:58 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:52:58 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:52:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:52:58 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:52:58 --> Final output sent to browser
DEBUG - 2020-10-20 10:52:58 --> Total execution time: 0.1908
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Loader Class Initialized
INFO - 2020-10-20 10:53:09 --> Helper loaded: url_helper
INFO - 2020-10-20 10:53:09 --> Helper loaded: form_helper
INFO - 2020-10-20 10:53:09 --> Helper loaded: html_helper
INFO - 2020-10-20 10:53:09 --> Helper loaded: date_helper
INFO - 2020-10-20 10:53:09 --> Database Driver Class Initialized
INFO - 2020-10-20 10:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:53:09 --> Table Class Initialized
INFO - 2020-10-20 10:53:09 --> Upload Class Initialized
INFO - 2020-10-20 10:53:09 --> Controller Class Initialized
INFO - 2020-10-20 10:53:09 --> Form Validation Class Initialized
INFO - 2020-10-20 10:53:09 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:53:09 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:53:09 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:53:09 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:53:09 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:53:09 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:53:09 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:53:09 --> Final output sent to browser
DEBUG - 2020-10-20 10:53:09 --> Total execution time: 0.1966
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
INFO - 2020-10-20 10:53:09 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Input Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
INFO - 2020-10-20 10:53:09 --> Language Class Initialized
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-20 10:53:09 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:09 --> Config Class Initialized
INFO - 2020-10-20 10:53:09 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> URI Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Router Class Initialized
INFO - 2020-10-20 10:53:09 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:10 --> Config Class Initialized
INFO - 2020-10-20 10:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:10 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:10 --> URI Class Initialized
INFO - 2020-10-20 10:53:10 --> Router Class Initialized
INFO - 2020-10-20 10:53:10 --> Output Class Initialized
INFO - 2020-10-20 10:53:10 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:10 --> Input Class Initialized
INFO - 2020-10-20 10:53:10 --> Language Class Initialized
ERROR - 2020-10-20 10:53:10 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:11 --> Config Class Initialized
INFO - 2020-10-20 10:53:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:11 --> URI Class Initialized
INFO - 2020-10-20 10:53:11 --> Router Class Initialized
INFO - 2020-10-20 10:53:11 --> Output Class Initialized
INFO - 2020-10-20 10:53:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:11 --> Input Class Initialized
INFO - 2020-10-20 10:53:11 --> Language Class Initialized
ERROR - 2020-10-20 10:53:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:11 --> Config Class Initialized
INFO - 2020-10-20 10:53:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:11 --> URI Class Initialized
INFO - 2020-10-20 10:53:11 --> Router Class Initialized
INFO - 2020-10-20 10:53:11 --> Output Class Initialized
INFO - 2020-10-20 10:53:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:11 --> Input Class Initialized
INFO - 2020-10-20 10:53:11 --> Language Class Initialized
ERROR - 2020-10-20 10:53:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:11 --> Config Class Initialized
INFO - 2020-10-20 10:53:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:11 --> URI Class Initialized
INFO - 2020-10-20 10:53:11 --> Router Class Initialized
INFO - 2020-10-20 10:53:11 --> Output Class Initialized
INFO - 2020-10-20 10:53:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:11 --> Input Class Initialized
INFO - 2020-10-20 10:53:11 --> Language Class Initialized
ERROR - 2020-10-20 10:53:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:53:11 --> Config Class Initialized
INFO - 2020-10-20 10:53:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:11 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:11 --> URI Class Initialized
INFO - 2020-10-20 10:53:11 --> Router Class Initialized
INFO - 2020-10-20 10:53:11 --> Output Class Initialized
INFO - 2020-10-20 10:53:11 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:11 --> Input Class Initialized
INFO - 2020-10-20 10:53:11 --> Language Class Initialized
ERROR - 2020-10-20 10:53:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:13 --> Config Class Initialized
INFO - 2020-10-20 10:53:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:13 --> URI Class Initialized
INFO - 2020-10-20 10:53:13 --> Router Class Initialized
INFO - 2020-10-20 10:53:13 --> Output Class Initialized
INFO - 2020-10-20 10:53:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:13 --> Input Class Initialized
INFO - 2020-10-20 10:53:13 --> Language Class Initialized
ERROR - 2020-10-20 10:53:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:53:29 --> Config Class Initialized
INFO - 2020-10-20 10:53:29 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:29 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:29 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:29 --> URI Class Initialized
INFO - 2020-10-20 10:53:29 --> Router Class Initialized
INFO - 2020-10-20 10:53:29 --> Output Class Initialized
INFO - 2020-10-20 10:53:29 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:29 --> Input Class Initialized
INFO - 2020-10-20 10:53:29 --> Language Class Initialized
ERROR - 2020-10-20 10:53:29 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:53:29 --> Config Class Initialized
INFO - 2020-10-20 10:53:29 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:29 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:29 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:29 --> URI Class Initialized
INFO - 2020-10-20 10:53:29 --> Router Class Initialized
INFO - 2020-10-20 10:53:29 --> Output Class Initialized
INFO - 2020-10-20 10:53:29 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:29 --> Input Class Initialized
INFO - 2020-10-20 10:53:29 --> Language Class Initialized
ERROR - 2020-10-20 10:53:29 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-20 10:53:36 --> Config Class Initialized
INFO - 2020-10-20 10:53:36 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:53:36 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:53:36 --> Utf8 Class Initialized
INFO - 2020-10-20 10:53:36 --> URI Class Initialized
INFO - 2020-10-20 10:53:36 --> Router Class Initialized
INFO - 2020-10-20 10:53:36 --> Output Class Initialized
INFO - 2020-10-20 10:53:36 --> Security Class Initialized
DEBUG - 2020-10-20 10:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:53:36 --> Input Class Initialized
INFO - 2020-10-20 10:53:36 --> Language Class Initialized
ERROR - 2020-10-20 10:53:36 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:56:05 --> Config Class Initialized
INFO - 2020-10-20 10:56:05 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:56:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:05 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:05 --> URI Class Initialized
INFO - 2020-10-20 10:56:05 --> Router Class Initialized
INFO - 2020-10-20 10:56:05 --> Output Class Initialized
INFO - 2020-10-20 10:56:05 --> Security Class Initialized
DEBUG - 2020-10-20 10:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:05 --> Input Class Initialized
INFO - 2020-10-20 10:56:05 --> Language Class Initialized
INFO - 2020-10-20 10:56:05 --> Loader Class Initialized
INFO - 2020-10-20 10:56:05 --> Helper loaded: url_helper
INFO - 2020-10-20 10:56:05 --> Helper loaded: form_helper
INFO - 2020-10-20 10:56:05 --> Helper loaded: html_helper
INFO - 2020-10-20 10:56:05 --> Helper loaded: date_helper
INFO - 2020-10-20 10:56:05 --> Database Driver Class Initialized
INFO - 2020-10-20 10:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:56:05 --> Table Class Initialized
INFO - 2020-10-20 10:56:05 --> Upload Class Initialized
INFO - 2020-10-20 10:56:05 --> Controller Class Initialized
INFO - 2020-10-20 10:56:05 --> Form Validation Class Initialized
INFO - 2020-10-20 10:56:05 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:56:05 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:56:05 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:56:05 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:56:05 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:56:05 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:56:05 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:56:05 --> Final output sent to browser
DEBUG - 2020-10-20 10:56:05 --> Total execution time: 0.2246
INFO - 2020-10-20 10:56:05 --> Config Class Initialized
INFO - 2020-10-20 10:56:05 --> Config Class Initialized
INFO - 2020-10-20 10:56:05 --> Hooks Class Initialized
INFO - 2020-10-20 10:56:05 --> Config Class Initialized
INFO - 2020-10-20 10:56:05 --> Hooks Class Initialized
INFO - 2020-10-20 10:56:05 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:56:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 10:56:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:05 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:56:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:05 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:05 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:05 --> URI Class Initialized
INFO - 2020-10-20 10:56:05 --> URI Class Initialized
INFO - 2020-10-20 10:56:05 --> URI Class Initialized
INFO - 2020-10-20 10:56:05 --> Router Class Initialized
INFO - 2020-10-20 10:56:05 --> Router Class Initialized
INFO - 2020-10-20 10:56:05 --> Output Class Initialized
INFO - 2020-10-20 10:56:05 --> Router Class Initialized
INFO - 2020-10-20 10:56:05 --> Output Class Initialized
INFO - 2020-10-20 10:56:05 --> Security Class Initialized
INFO - 2020-10-20 10:56:05 --> Output Class Initialized
INFO - 2020-10-20 10:56:05 --> Security Class Initialized
DEBUG - 2020-10-20 10:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:05 --> Security Class Initialized
INFO - 2020-10-20 10:56:05 --> Input Class Initialized
DEBUG - 2020-10-20 10:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:05 --> Input Class Initialized
INFO - 2020-10-20 10:56:05 --> Language Class Initialized
INFO - 2020-10-20 10:56:05 --> Input Class Initialized
INFO - 2020-10-20 10:56:05 --> Language Class Initialized
ERROR - 2020-10-20 10:56:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:56:05 --> Language Class Initialized
ERROR - 2020-10-20 10:56:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-20 10:56:05 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:56:08 --> Config Class Initialized
INFO - 2020-10-20 10:56:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:56:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:08 --> URI Class Initialized
INFO - 2020-10-20 10:56:08 --> Router Class Initialized
INFO - 2020-10-20 10:56:08 --> Output Class Initialized
INFO - 2020-10-20 10:56:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:08 --> Input Class Initialized
INFO - 2020-10-20 10:56:08 --> Config Class Initialized
INFO - 2020-10-20 10:56:08 --> Language Class Initialized
INFO - 2020-10-20 10:56:08 --> Hooks Class Initialized
ERROR - 2020-10-20 10:56:08 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-20 10:56:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:08 --> URI Class Initialized
INFO - 2020-10-20 10:56:08 --> Router Class Initialized
INFO - 2020-10-20 10:56:08 --> Output Class Initialized
INFO - 2020-10-20 10:56:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:08 --> Input Class Initialized
INFO - 2020-10-20 10:56:08 --> Language Class Initialized
ERROR - 2020-10-20 10:56:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:56:08 --> Config Class Initialized
INFO - 2020-10-20 10:56:08 --> Config Class Initialized
INFO - 2020-10-20 10:56:08 --> Config Class Initialized
INFO - 2020-10-20 10:56:08 --> Hooks Class Initialized
INFO - 2020-10-20 10:56:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:56:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:08 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:56:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:08 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:56:08 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:08 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:08 --> URI Class Initialized
INFO - 2020-10-20 10:56:08 --> Router Class Initialized
INFO - 2020-10-20 10:56:08 --> URI Class Initialized
INFO - 2020-10-20 10:56:08 --> URI Class Initialized
INFO - 2020-10-20 10:56:08 --> Output Class Initialized
INFO - 2020-10-20 10:56:08 --> Router Class Initialized
INFO - 2020-10-20 10:56:08 --> Router Class Initialized
INFO - 2020-10-20 10:56:08 --> Security Class Initialized
INFO - 2020-10-20 10:56:08 --> Output Class Initialized
INFO - 2020-10-20 10:56:08 --> Output Class Initialized
INFO - 2020-10-20 10:56:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:08 --> Security Class Initialized
DEBUG - 2020-10-20 10:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:08 --> Input Class Initialized
DEBUG - 2020-10-20 10:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:08 --> Input Class Initialized
INFO - 2020-10-20 10:56:08 --> Input Class Initialized
INFO - 2020-10-20 10:56:08 --> Language Class Initialized
INFO - 2020-10-20 10:56:08 --> Language Class Initialized
ERROR - 2020-10-20 10:56:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:56:08 --> Language Class Initialized
ERROR - 2020-10-20 10:56:08 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:56:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:56:13 --> Config Class Initialized
INFO - 2020-10-20 10:56:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:56:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:56:13 --> Utf8 Class Initialized
INFO - 2020-10-20 10:56:13 --> URI Class Initialized
INFO - 2020-10-20 10:56:13 --> Router Class Initialized
INFO - 2020-10-20 10:56:13 --> Output Class Initialized
INFO - 2020-10-20 10:56:13 --> Security Class Initialized
DEBUG - 2020-10-20 10:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:56:13 --> Input Class Initialized
INFO - 2020-10-20 10:56:14 --> Language Class Initialized
ERROR - 2020-10-20 10:56:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:57:30 --> Config Class Initialized
INFO - 2020-10-20 10:57:30 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:57:30 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:57:30 --> Utf8 Class Initialized
INFO - 2020-10-20 10:57:30 --> URI Class Initialized
INFO - 2020-10-20 10:57:30 --> Router Class Initialized
INFO - 2020-10-20 10:57:30 --> Output Class Initialized
INFO - 2020-10-20 10:57:30 --> Security Class Initialized
DEBUG - 2020-10-20 10:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:57:30 --> Input Class Initialized
INFO - 2020-10-20 10:57:30 --> Language Class Initialized
INFO - 2020-10-20 10:57:30 --> Loader Class Initialized
INFO - 2020-10-20 10:57:30 --> Helper loaded: url_helper
INFO - 2020-10-20 10:57:30 --> Helper loaded: form_helper
INFO - 2020-10-20 10:57:30 --> Helper loaded: html_helper
INFO - 2020-10-20 10:57:30 --> Helper loaded: date_helper
INFO - 2020-10-20 10:57:30 --> Database Driver Class Initialized
INFO - 2020-10-20 10:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:57:30 --> Table Class Initialized
INFO - 2020-10-20 10:57:30 --> Upload Class Initialized
INFO - 2020-10-20 10:57:30 --> Controller Class Initialized
INFO - 2020-10-20 10:57:30 --> Form Validation Class Initialized
INFO - 2020-10-20 10:57:30 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:57:30 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:57:30 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:57:30 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:57:30 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:57:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:57:30 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:57:30 --> Final output sent to browser
DEBUG - 2020-10-20 10:57:30 --> Total execution time: 0.2087
INFO - 2020-10-20 10:57:45 --> Config Class Initialized
INFO - 2020-10-20 10:57:45 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:57:45 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:57:45 --> Utf8 Class Initialized
INFO - 2020-10-20 10:57:45 --> URI Class Initialized
INFO - 2020-10-20 10:57:45 --> Router Class Initialized
INFO - 2020-10-20 10:57:45 --> Output Class Initialized
INFO - 2020-10-20 10:57:45 --> Security Class Initialized
DEBUG - 2020-10-20 10:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:57:45 --> Input Class Initialized
INFO - 2020-10-20 10:57:45 --> Language Class Initialized
ERROR - 2020-10-20 10:57:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-20 10:59:19 --> Config Class Initialized
INFO - 2020-10-20 10:59:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:59:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:19 --> URI Class Initialized
INFO - 2020-10-20 10:59:19 --> Router Class Initialized
INFO - 2020-10-20 10:59:19 --> Output Class Initialized
INFO - 2020-10-20 10:59:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:19 --> Input Class Initialized
INFO - 2020-10-20 10:59:19 --> Language Class Initialized
INFO - 2020-10-20 10:59:19 --> Loader Class Initialized
INFO - 2020-10-20 10:59:19 --> Helper loaded: url_helper
INFO - 2020-10-20 10:59:19 --> Helper loaded: form_helper
INFO - 2020-10-20 10:59:19 --> Helper loaded: html_helper
INFO - 2020-10-20 10:59:19 --> Helper loaded: date_helper
INFO - 2020-10-20 10:59:19 --> Database Driver Class Initialized
INFO - 2020-10-20 10:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:59:19 --> Table Class Initialized
INFO - 2020-10-20 10:59:19 --> Upload Class Initialized
INFO - 2020-10-20 10:59:19 --> Controller Class Initialized
INFO - 2020-10-20 10:59:19 --> Form Validation Class Initialized
INFO - 2020-10-20 10:59:19 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:59:19 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:59:19 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:59:19 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:59:19 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:59:19 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:59:19 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:59:19 --> Final output sent to browser
DEBUG - 2020-10-20 10:59:19 --> Total execution time: 0.2565
INFO - 2020-10-20 10:59:19 --> Config Class Initialized
INFO - 2020-10-20 10:59:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:59:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:19 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:19 --> URI Class Initialized
INFO - 2020-10-20 10:59:19 --> Router Class Initialized
INFO - 2020-10-20 10:59:19 --> Output Class Initialized
INFO - 2020-10-20 10:59:19 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:19 --> Input Class Initialized
INFO - 2020-10-20 10:59:19 --> Language Class Initialized
ERROR - 2020-10-20 10:59:19 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:32 --> URI Class Initialized
INFO - 2020-10-20 10:59:32 --> Router Class Initialized
INFO - 2020-10-20 10:59:32 --> Output Class Initialized
INFO - 2020-10-20 10:59:32 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:32 --> Input Class Initialized
INFO - 2020-10-20 10:59:32 --> Language Class Initialized
INFO - 2020-10-20 10:59:32 --> Loader Class Initialized
INFO - 2020-10-20 10:59:32 --> Helper loaded: url_helper
INFO - 2020-10-20 10:59:32 --> Helper loaded: form_helper
INFO - 2020-10-20 10:59:32 --> Helper loaded: html_helper
INFO - 2020-10-20 10:59:32 --> Helper loaded: date_helper
INFO - 2020-10-20 10:59:32 --> Database Driver Class Initialized
INFO - 2020-10-20 10:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 10:59:32 --> Table Class Initialized
INFO - 2020-10-20 10:59:32 --> Upload Class Initialized
INFO - 2020-10-20 10:59:32 --> Controller Class Initialized
INFO - 2020-10-20 10:59:32 --> Form Validation Class Initialized
INFO - 2020-10-20 10:59:32 --> Model "Crud_model" initialized
INFO - 2020-10-20 10:59:32 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 10:59:32 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 10:59:32 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 10:59:32 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 10:59:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 10:59:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 10:59:32 --> Final output sent to browser
DEBUG - 2020-10-20 10:59:32 --> Total execution time: 0.2255
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:32 --> URI Class Initialized
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
INFO - 2020-10-20 10:59:32 --> Router Class Initialized
INFO - 2020-10-20 10:59:32 --> Output Class Initialized
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
INFO - 2020-10-20 10:59:32 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:32 --> Input Class Initialized
INFO - 2020-10-20 10:59:32 --> URI Class Initialized
INFO - 2020-10-20 10:59:32 --> Router Class Initialized
INFO - 2020-10-20 10:59:32 --> Language Class Initialized
ERROR - 2020-10-20 10:59:32 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:59:32 --> Output Class Initialized
INFO - 2020-10-20 10:59:32 --> Security Class Initialized
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
DEBUG - 2020-10-20 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:32 --> Input Class Initialized
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
INFO - 2020-10-20 10:59:32 --> Language Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
ERROR - 2020-10-20 10:59:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:32 --> URI Class Initialized
INFO - 2020-10-20 10:59:32 --> Router Class Initialized
INFO - 2020-10-20 10:59:32 --> Output Class Initialized
INFO - 2020-10-20 10:59:32 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:32 --> Input Class Initialized
INFO - 2020-10-20 10:59:32 --> Language Class Initialized
ERROR - 2020-10-20 10:59:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:32 --> URI Class Initialized
INFO - 2020-10-20 10:59:32 --> Router Class Initialized
INFO - 2020-10-20 10:59:32 --> URI Class Initialized
INFO - 2020-10-20 10:59:32 --> URI Class Initialized
INFO - 2020-10-20 10:59:32 --> Router Class Initialized
INFO - 2020-10-20 10:59:32 --> Output Class Initialized
INFO - 2020-10-20 10:59:32 --> Router Class Initialized
INFO - 2020-10-20 10:59:32 --> Output Class Initialized
INFO - 2020-10-20 10:59:32 --> Security Class Initialized
INFO - 2020-10-20 10:59:32 --> Output Class Initialized
INFO - 2020-10-20 10:59:32 --> Security Class Initialized
INFO - 2020-10-20 10:59:32 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:32 --> Input Class Initialized
DEBUG - 2020-10-20 10:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:32 --> Input Class Initialized
INFO - 2020-10-20 10:59:32 --> Language Class Initialized
INFO - 2020-10-20 10:59:32 --> Input Class Initialized
INFO - 2020-10-20 10:59:32 --> Language Class Initialized
ERROR - 2020-10-20 10:59:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:59:32 --> Language Class Initialized
ERROR - 2020-10-20 10:59:32 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 10:59:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 10:59:32 --> Config Class Initialized
INFO - 2020-10-20 10:59:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:59:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:32 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:33 --> URI Class Initialized
INFO - 2020-10-20 10:59:33 --> Router Class Initialized
INFO - 2020-10-20 10:59:33 --> Output Class Initialized
INFO - 2020-10-20 10:59:33 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:33 --> Input Class Initialized
INFO - 2020-10-20 10:59:33 --> Language Class Initialized
ERROR - 2020-10-20 10:59:33 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 10:59:34 --> Config Class Initialized
INFO - 2020-10-20 10:59:34 --> Hooks Class Initialized
DEBUG - 2020-10-20 10:59:34 --> UTF-8 Support Enabled
INFO - 2020-10-20 10:59:34 --> Utf8 Class Initialized
INFO - 2020-10-20 10:59:34 --> URI Class Initialized
INFO - 2020-10-20 10:59:34 --> Router Class Initialized
INFO - 2020-10-20 10:59:34 --> Output Class Initialized
INFO - 2020-10-20 10:59:34 --> Security Class Initialized
DEBUG - 2020-10-20 10:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 10:59:34 --> Input Class Initialized
INFO - 2020-10-20 10:59:34 --> Language Class Initialized
ERROR - 2020-10-20 10:59:34 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 11:01:40 --> Config Class Initialized
INFO - 2020-10-20 11:01:40 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:01:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:01:40 --> Utf8 Class Initialized
INFO - 2020-10-20 11:01:40 --> URI Class Initialized
INFO - 2020-10-20 11:01:40 --> Router Class Initialized
INFO - 2020-10-20 11:01:40 --> Output Class Initialized
INFO - 2020-10-20 11:01:40 --> Security Class Initialized
DEBUG - 2020-10-20 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:01:40 --> Input Class Initialized
INFO - 2020-10-20 11:01:40 --> Language Class Initialized
INFO - 2020-10-20 11:01:40 --> Loader Class Initialized
INFO - 2020-10-20 11:01:40 --> Helper loaded: url_helper
INFO - 2020-10-20 11:01:40 --> Helper loaded: form_helper
INFO - 2020-10-20 11:01:40 --> Helper loaded: html_helper
INFO - 2020-10-20 11:01:40 --> Helper loaded: date_helper
INFO - 2020-10-20 11:01:40 --> Database Driver Class Initialized
INFO - 2020-10-20 11:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:01:40 --> Table Class Initialized
INFO - 2020-10-20 11:01:40 --> Upload Class Initialized
INFO - 2020-10-20 11:01:40 --> Controller Class Initialized
INFO - 2020-10-20 11:01:40 --> Form Validation Class Initialized
INFO - 2020-10-20 11:01:40 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:01:40 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 11:01:40 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 11:01:40 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 11:01:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 11:01:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 11:01:40 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 11:01:40 --> Final output sent to browser
DEBUG - 2020-10-20 11:01:40 --> Total execution time: 0.2349
INFO - 2020-10-20 11:01:40 --> Config Class Initialized
INFO - 2020-10-20 11:01:40 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:01:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:01:40 --> Utf8 Class Initialized
INFO - 2020-10-20 11:01:40 --> URI Class Initialized
INFO - 2020-10-20 11:01:40 --> Router Class Initialized
INFO - 2020-10-20 11:01:40 --> Output Class Initialized
INFO - 2020-10-20 11:01:40 --> Config Class Initialized
INFO - 2020-10-20 11:01:40 --> Hooks Class Initialized
INFO - 2020-10-20 11:01:40 --> Security Class Initialized
DEBUG - 2020-10-20 11:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 11:01:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:01:40 --> Input Class Initialized
INFO - 2020-10-20 11:01:40 --> Utf8 Class Initialized
INFO - 2020-10-20 11:01:40 --> Language Class Initialized
INFO - 2020-10-20 11:01:40 --> URI Class Initialized
ERROR - 2020-10-20 11:01:40 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 11:01:40 --> Router Class Initialized
INFO - 2020-10-20 11:01:40 --> Output Class Initialized
INFO - 2020-10-20 11:01:40 --> Security Class Initialized
INFO - 2020-10-20 11:01:40 --> Config Class Initialized
DEBUG - 2020-10-20 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:01:40 --> Hooks Class Initialized
INFO - 2020-10-20 11:01:40 --> Input Class Initialized
DEBUG - 2020-10-20 11:01:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:01:40 --> Utf8 Class Initialized
INFO - 2020-10-20 11:01:40 --> Language Class Initialized
ERROR - 2020-10-20 11:01:40 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:01:40 --> URI Class Initialized
INFO - 2020-10-20 11:01:40 --> Router Class Initialized
INFO - 2020-10-20 11:01:40 --> Output Class Initialized
INFO - 2020-10-20 11:01:40 --> Security Class Initialized
DEBUG - 2020-10-20 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:01:40 --> Input Class Initialized
INFO - 2020-10-20 11:01:40 --> Language Class Initialized
ERROR - 2020-10-20 11:01:40 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:01:40 --> Config Class Initialized
INFO - 2020-10-20 11:01:40 --> Config Class Initialized
INFO - 2020-10-20 11:01:40 --> Hooks Class Initialized
INFO - 2020-10-20 11:01:40 --> Config Class Initialized
INFO - 2020-10-20 11:01:40 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:01:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:01:40 --> Hooks Class Initialized
INFO - 2020-10-20 11:01:40 --> Utf8 Class Initialized
DEBUG - 2020-10-20 11:01:40 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 11:01:40 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:01:40 --> Utf8 Class Initialized
INFO - 2020-10-20 11:01:40 --> URI Class Initialized
INFO - 2020-10-20 11:01:40 --> Utf8 Class Initialized
INFO - 2020-10-20 11:01:40 --> URI Class Initialized
INFO - 2020-10-20 11:01:40 --> URI Class Initialized
INFO - 2020-10-20 11:01:40 --> Router Class Initialized
INFO - 2020-10-20 11:01:40 --> Router Class Initialized
INFO - 2020-10-20 11:01:40 --> Output Class Initialized
INFO - 2020-10-20 11:01:40 --> Router Class Initialized
INFO - 2020-10-20 11:01:40 --> Output Class Initialized
INFO - 2020-10-20 11:01:40 --> Security Class Initialized
INFO - 2020-10-20 11:01:40 --> Output Class Initialized
DEBUG - 2020-10-20 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:01:40 --> Security Class Initialized
INFO - 2020-10-20 11:01:40 --> Security Class Initialized
INFO - 2020-10-20 11:01:40 --> Input Class Initialized
DEBUG - 2020-10-20 11:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 11:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:01:41 --> Input Class Initialized
INFO - 2020-10-20 11:01:41 --> Input Class Initialized
INFO - 2020-10-20 11:01:41 --> Language Class Initialized
INFO - 2020-10-20 11:01:41 --> Language Class Initialized
INFO - 2020-10-20 11:01:41 --> Language Class Initialized
ERROR - 2020-10-20 11:01:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 11:01:41 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 11:01:41 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:02:03 --> Config Class Initialized
INFO - 2020-10-20 11:02:03 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:02:03 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:02:03 --> Utf8 Class Initialized
INFO - 2020-10-20 11:02:03 --> URI Class Initialized
INFO - 2020-10-20 11:02:03 --> Router Class Initialized
INFO - 2020-10-20 11:02:03 --> Output Class Initialized
INFO - 2020-10-20 11:02:03 --> Security Class Initialized
DEBUG - 2020-10-20 11:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:02:03 --> Input Class Initialized
INFO - 2020-10-20 11:02:03 --> Language Class Initialized
ERROR - 2020-10-20 11:02:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
INFO - 2020-10-20 11:05:27 --> Loader Class Initialized
INFO - 2020-10-20 11:05:27 --> Helper loaded: url_helper
INFO - 2020-10-20 11:05:27 --> Helper loaded: form_helper
INFO - 2020-10-20 11:05:27 --> Helper loaded: html_helper
INFO - 2020-10-20 11:05:27 --> Helper loaded: date_helper
INFO - 2020-10-20 11:05:27 --> Database Driver Class Initialized
INFO - 2020-10-20 11:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:05:27 --> Table Class Initialized
INFO - 2020-10-20 11:05:27 --> Upload Class Initialized
INFO - 2020-10-20 11:05:27 --> Controller Class Initialized
INFO - 2020-10-20 11:05:27 --> Form Validation Class Initialized
INFO - 2020-10-20 11:05:27 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:05:27 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 11:05:27 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 11:05:27 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 11:05:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 11:05:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 11:05:27 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 11:05:27 --> Final output sent to browser
DEBUG - 2020-10-20 11:05:27 --> Total execution time: 0.2439
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
ERROR - 2020-10-20 11:05:27 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
ERROR - 2020-10-20 11:05:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
ERROR - 2020-10-20 11:05:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
INFO - 2020-10-20 11:05:27 --> Loader Class Initialized
INFO - 2020-10-20 11:05:27 --> Helper loaded: url_helper
INFO - 2020-10-20 11:05:27 --> Helper loaded: form_helper
INFO - 2020-10-20 11:05:27 --> Helper loaded: html_helper
INFO - 2020-10-20 11:05:27 --> Helper loaded: date_helper
INFO - 2020-10-20 11:05:27 --> Database Driver Class Initialized
INFO - 2020-10-20 11:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:05:27 --> Table Class Initialized
INFO - 2020-10-20 11:05:27 --> Upload Class Initialized
INFO - 2020-10-20 11:05:27 --> Controller Class Initialized
INFO - 2020-10-20 11:05:27 --> Form Validation Class Initialized
INFO - 2020-10-20 11:05:27 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:05:27 --> Final output sent to browser
DEBUG - 2020-10-20 11:05:27 --> Total execution time: 0.2412
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
INFO - 2020-10-20 11:05:27 --> Config Class Initialized
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:05:27 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
DEBUG - 2020-10-20 11:05:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
INFO - 2020-10-20 11:05:27 --> Utf8 Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
INFO - 2020-10-20 11:05:27 --> URI Class Initialized
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
INFO - 2020-10-20 11:05:27 --> Router Class Initialized
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Output Class Initialized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
INFO - 2020-10-20 11:05:27 --> Security Class Initialized
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 11:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
INFO - 2020-10-20 11:05:27 --> Input Class Initialized
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
ERROR - 2020-10-20 11:05:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:05:27 --> Language Class Initialized
ERROR - 2020-10-20 11:05:27 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 11:05:27 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:06:13 --> Config Class Initialized
INFO - 2020-10-20 11:06:13 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:06:13 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:06:13 --> Utf8 Class Initialized
INFO - 2020-10-20 11:06:13 --> URI Class Initialized
DEBUG - 2020-10-20 11:06:13 --> No URI present. Default controller set.
INFO - 2020-10-20 11:06:13 --> Router Class Initialized
INFO - 2020-10-20 11:06:13 --> Output Class Initialized
INFO - 2020-10-20 11:06:13 --> Security Class Initialized
DEBUG - 2020-10-20 11:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:06:13 --> Input Class Initialized
INFO - 2020-10-20 11:06:13 --> Language Class Initialized
ERROR - 2020-10-20 11:06:13 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 11:07:49 --> Config Class Initialized
INFO - 2020-10-20 11:07:49 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:07:49 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:07:49 --> Utf8 Class Initialized
INFO - 2020-10-20 11:07:49 --> URI Class Initialized
INFO - 2020-10-20 11:07:49 --> Router Class Initialized
INFO - 2020-10-20 11:07:49 --> Output Class Initialized
INFO - 2020-10-20 11:07:49 --> Security Class Initialized
DEBUG - 2020-10-20 11:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:07:49 --> Input Class Initialized
INFO - 2020-10-20 11:07:49 --> Language Class Initialized
INFO - 2020-10-20 11:07:49 --> Loader Class Initialized
INFO - 2020-10-20 11:07:49 --> Helper loaded: url_helper
INFO - 2020-10-20 11:07:49 --> Helper loaded: form_helper
INFO - 2020-10-20 11:07:49 --> Helper loaded: html_helper
INFO - 2020-10-20 11:07:49 --> Helper loaded: date_helper
INFO - 2020-10-20 11:07:49 --> Database Driver Class Initialized
INFO - 2020-10-20 11:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:07:49 --> Table Class Initialized
INFO - 2020-10-20 11:07:49 --> Upload Class Initialized
INFO - 2020-10-20 11:07:49 --> Controller Class Initialized
INFO - 2020-10-20 11:07:49 --> Form Validation Class Initialized
INFO - 2020-10-20 11:07:49 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:07:49 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 11:07:49 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 11:07:49 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 11:07:49 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 11:07:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 11:07:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 11:07:49 --> Final output sent to browser
DEBUG - 2020-10-20 11:07:50 --> Total execution time: 0.2209
INFO - 2020-10-20 11:07:50 --> Config Class Initialized
INFO - 2020-10-20 11:07:50 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:07:50 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:07:50 --> Utf8 Class Initialized
INFO - 2020-10-20 11:07:50 --> URI Class Initialized
INFO - 2020-10-20 11:07:50 --> Router Class Initialized
INFO - 2020-10-20 11:07:50 --> Output Class Initialized
INFO - 2020-10-20 11:07:50 --> Security Class Initialized
DEBUG - 2020-10-20 11:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:07:50 --> Input Class Initialized
INFO - 2020-10-20 11:07:50 --> Language Class Initialized
INFO - 2020-10-20 11:07:50 --> Loader Class Initialized
INFO - 2020-10-20 11:07:50 --> Helper loaded: url_helper
INFO - 2020-10-20 11:07:50 --> Helper loaded: form_helper
INFO - 2020-10-20 11:07:50 --> Helper loaded: html_helper
INFO - 2020-10-20 11:07:50 --> Helper loaded: date_helper
INFO - 2020-10-20 11:07:50 --> Database Driver Class Initialized
INFO - 2020-10-20 11:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:07:50 --> Table Class Initialized
INFO - 2020-10-20 11:07:50 --> Upload Class Initialized
INFO - 2020-10-20 11:07:50 --> Controller Class Initialized
INFO - 2020-10-20 11:07:50 --> Form Validation Class Initialized
INFO - 2020-10-20 11:07:50 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:07:50 --> Final output sent to browser
DEBUG - 2020-10-20 11:07:50 --> Total execution time: 0.2213
INFO - 2020-10-20 11:07:57 --> Config Class Initialized
INFO - 2020-10-20 11:07:57 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:07:57 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:07:57 --> Utf8 Class Initialized
INFO - 2020-10-20 11:07:57 --> URI Class Initialized
INFO - 2020-10-20 11:07:57 --> Router Class Initialized
INFO - 2020-10-20 11:07:57 --> Output Class Initialized
INFO - 2020-10-20 11:07:57 --> Security Class Initialized
DEBUG - 2020-10-20 11:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:07:57 --> Input Class Initialized
INFO - 2020-10-20 11:07:57 --> Language Class Initialized
INFO - 2020-10-20 11:07:57 --> Loader Class Initialized
INFO - 2020-10-20 11:07:57 --> Helper loaded: url_helper
INFO - 2020-10-20 11:07:57 --> Helper loaded: form_helper
INFO - 2020-10-20 11:07:57 --> Helper loaded: html_helper
INFO - 2020-10-20 11:07:57 --> Helper loaded: date_helper
INFO - 2020-10-20 11:07:57 --> Database Driver Class Initialized
INFO - 2020-10-20 11:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:07:57 --> Table Class Initialized
INFO - 2020-10-20 11:07:57 --> Upload Class Initialized
INFO - 2020-10-20 11:07:57 --> Controller Class Initialized
INFO - 2020-10-20 11:07:57 --> Form Validation Class Initialized
INFO - 2020-10-20 11:07:57 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:07:57 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 11:07:57 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 11:07:57 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 11:07:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 11:07:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 11:07:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 11:07:57 --> Final output sent to browser
DEBUG - 2020-10-20 11:07:57 --> Total execution time: 0.2180
INFO - 2020-10-20 11:07:57 --> Config Class Initialized
INFO - 2020-10-20 11:07:57 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:07:57 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:07:57 --> Utf8 Class Initialized
INFO - 2020-10-20 11:07:57 --> URI Class Initialized
INFO - 2020-10-20 11:07:57 --> Router Class Initialized
INFO - 2020-10-20 11:07:57 --> Output Class Initialized
INFO - 2020-10-20 11:07:57 --> Security Class Initialized
DEBUG - 2020-10-20 11:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:07:57 --> Input Class Initialized
INFO - 2020-10-20 11:07:57 --> Language Class Initialized
INFO - 2020-10-20 11:07:57 --> Loader Class Initialized
INFO - 2020-10-20 11:07:57 --> Helper loaded: url_helper
INFO - 2020-10-20 11:07:57 --> Helper loaded: form_helper
INFO - 2020-10-20 11:07:57 --> Helper loaded: html_helper
INFO - 2020-10-20 11:07:57 --> Helper loaded: date_helper
INFO - 2020-10-20 11:07:57 --> Database Driver Class Initialized
INFO - 2020-10-20 11:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:07:57 --> Table Class Initialized
INFO - 2020-10-20 11:07:57 --> Upload Class Initialized
INFO - 2020-10-20 11:07:57 --> Controller Class Initialized
INFO - 2020-10-20 11:07:57 --> Form Validation Class Initialized
INFO - 2020-10-20 11:07:57 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:07:57 --> Final output sent to browser
DEBUG - 2020-10-20 11:07:57 --> Total execution time: 0.2116
INFO - 2020-10-20 11:08:31 --> Config Class Initialized
INFO - 2020-10-20 11:08:31 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:08:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:31 --> Utf8 Class Initialized
INFO - 2020-10-20 11:08:31 --> URI Class Initialized
INFO - 2020-10-20 11:08:31 --> Router Class Initialized
INFO - 2020-10-20 11:08:31 --> Output Class Initialized
INFO - 2020-10-20 11:08:31 --> Security Class Initialized
DEBUG - 2020-10-20 11:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:08:31 --> Input Class Initialized
INFO - 2020-10-20 11:08:31 --> Language Class Initialized
INFO - 2020-10-20 11:08:31 --> Loader Class Initialized
INFO - 2020-10-20 11:08:31 --> Helper loaded: url_helper
INFO - 2020-10-20 11:08:31 --> Helper loaded: form_helper
INFO - 2020-10-20 11:08:31 --> Helper loaded: html_helper
INFO - 2020-10-20 11:08:31 --> Helper loaded: date_helper
INFO - 2020-10-20 11:08:31 --> Database Driver Class Initialized
INFO - 2020-10-20 11:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:08:31 --> Table Class Initialized
INFO - 2020-10-20 11:08:31 --> Upload Class Initialized
INFO - 2020-10-20 11:08:31 --> Controller Class Initialized
INFO - 2020-10-20 11:08:31 --> Form Validation Class Initialized
INFO - 2020-10-20 11:08:31 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:08:31 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 11:08:31 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 11:08:31 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 11:08:31 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 11:08:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 11:08:31 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 11:08:31 --> Final output sent to browser
DEBUG - 2020-10-20 11:08:31 --> Total execution time: 0.2416
INFO - 2020-10-20 11:08:31 --> Config Class Initialized
INFO - 2020-10-20 11:08:31 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:08:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:32 --> Config Class Initialized
INFO - 2020-10-20 11:08:32 --> Utf8 Class Initialized
INFO - 2020-10-20 11:08:32 --> Hooks Class Initialized
INFO - 2020-10-20 11:08:32 --> URI Class Initialized
INFO - 2020-10-20 11:08:32 --> Router Class Initialized
DEBUG - 2020-10-20 11:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:32 --> Utf8 Class Initialized
INFO - 2020-10-20 11:08:32 --> Output Class Initialized
INFO - 2020-10-20 11:08:32 --> Security Class Initialized
INFO - 2020-10-20 11:08:32 --> URI Class Initialized
DEBUG - 2020-10-20 11:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:08:32 --> Router Class Initialized
INFO - 2020-10-20 11:08:32 --> Input Class Initialized
INFO - 2020-10-20 11:08:32 --> Output Class Initialized
INFO - 2020-10-20 11:08:32 --> Language Class Initialized
INFO - 2020-10-20 11:08:32 --> Security Class Initialized
ERROR - 2020-10-20 11:08:32 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-20 11:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:08:32 --> Input Class Initialized
INFO - 2020-10-20 11:08:32 --> Config Class Initialized
INFO - 2020-10-20 11:08:32 --> Language Class Initialized
ERROR - 2020-10-20 11:08:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:08:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:32 --> Utf8 Class Initialized
INFO - 2020-10-20 11:08:32 --> URI Class Initialized
INFO - 2020-10-20 11:08:32 --> Config Class Initialized
INFO - 2020-10-20 11:08:32 --> Router Class Initialized
INFO - 2020-10-20 11:08:32 --> Hooks Class Initialized
INFO - 2020-10-20 11:08:32 --> Output Class Initialized
DEBUG - 2020-10-20 11:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:32 --> Security Class Initialized
INFO - 2020-10-20 11:08:32 --> Utf8 Class Initialized
DEBUG - 2020-10-20 11:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:08:32 --> URI Class Initialized
INFO - 2020-10-20 11:08:32 --> Input Class Initialized
INFO - 2020-10-20 11:08:32 --> Language Class Initialized
INFO - 2020-10-20 11:08:32 --> Router Class Initialized
INFO - 2020-10-20 11:08:32 --> Output Class Initialized
ERROR - 2020-10-20 11:08:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:08:32 --> Security Class Initialized
DEBUG - 2020-10-20 11:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:08:32 --> Input Class Initialized
INFO - 2020-10-20 11:08:32 --> Language Class Initialized
INFO - 2020-10-20 11:08:32 --> Loader Class Initialized
INFO - 2020-10-20 11:08:32 --> Helper loaded: url_helper
INFO - 2020-10-20 11:08:32 --> Helper loaded: form_helper
INFO - 2020-10-20 11:08:32 --> Helper loaded: html_helper
INFO - 2020-10-20 11:08:32 --> Helper loaded: date_helper
INFO - 2020-10-20 11:08:32 --> Database Driver Class Initialized
INFO - 2020-10-20 11:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:08:32 --> Table Class Initialized
INFO - 2020-10-20 11:08:32 --> Upload Class Initialized
INFO - 2020-10-20 11:08:32 --> Controller Class Initialized
INFO - 2020-10-20 11:08:32 --> Form Validation Class Initialized
INFO - 2020-10-20 11:08:32 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:08:32 --> Final output sent to browser
DEBUG - 2020-10-20 11:08:32 --> Total execution time: 0.2236
INFO - 2020-10-20 11:08:32 --> Config Class Initialized
INFO - 2020-10-20 11:08:32 --> Config Class Initialized
INFO - 2020-10-20 11:08:32 --> Config Class Initialized
INFO - 2020-10-20 11:08:32 --> Hooks Class Initialized
INFO - 2020-10-20 11:08:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:32 --> Utf8 Class Initialized
INFO - 2020-10-20 11:08:32 --> Utf8 Class Initialized
DEBUG - 2020-10-20 11:08:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:08:32 --> Utf8 Class Initialized
INFO - 2020-10-20 11:08:32 --> URI Class Initialized
INFO - 2020-10-20 11:08:32 --> URI Class Initialized
INFO - 2020-10-20 11:08:32 --> URI Class Initialized
INFO - 2020-10-20 11:08:32 --> Router Class Initialized
INFO - 2020-10-20 11:08:32 --> Router Class Initialized
INFO - 2020-10-20 11:08:32 --> Output Class Initialized
INFO - 2020-10-20 11:08:32 --> Output Class Initialized
INFO - 2020-10-20 11:08:32 --> Router Class Initialized
INFO - 2020-10-20 11:08:32 --> Security Class Initialized
INFO - 2020-10-20 11:08:32 --> Output Class Initialized
INFO - 2020-10-20 11:08:32 --> Security Class Initialized
DEBUG - 2020-10-20 11:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 11:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:08:32 --> Security Class Initialized
INFO - 2020-10-20 11:08:32 --> Input Class Initialized
INFO - 2020-10-20 11:08:32 --> Input Class Initialized
DEBUG - 2020-10-20 11:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:08:32 --> Language Class Initialized
INFO - 2020-10-20 11:08:32 --> Language Class Initialized
INFO - 2020-10-20 11:08:32 --> Input Class Initialized
INFO - 2020-10-20 11:08:32 --> Language Class Initialized
ERROR - 2020-10-20 11:08:32 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 11:08:32 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 11:08:32 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:11:10 --> Config Class Initialized
INFO - 2020-10-20 11:11:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:11:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:10 --> Utf8 Class Initialized
INFO - 2020-10-20 11:11:10 --> URI Class Initialized
INFO - 2020-10-20 11:11:10 --> Router Class Initialized
INFO - 2020-10-20 11:11:10 --> Output Class Initialized
INFO - 2020-10-20 11:11:10 --> Security Class Initialized
DEBUG - 2020-10-20 11:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:11:10 --> Input Class Initialized
INFO - 2020-10-20 11:11:10 --> Language Class Initialized
INFO - 2020-10-20 11:11:10 --> Loader Class Initialized
INFO - 2020-10-20 11:11:10 --> Helper loaded: url_helper
INFO - 2020-10-20 11:11:10 --> Helper loaded: form_helper
INFO - 2020-10-20 11:11:10 --> Helper loaded: html_helper
INFO - 2020-10-20 11:11:10 --> Helper loaded: date_helper
INFO - 2020-10-20 11:11:10 --> Database Driver Class Initialized
INFO - 2020-10-20 11:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:11:10 --> Table Class Initialized
INFO - 2020-10-20 11:11:10 --> Upload Class Initialized
INFO - 2020-10-20 11:11:10 --> Controller Class Initialized
INFO - 2020-10-20 11:11:10 --> Form Validation Class Initialized
INFO - 2020-10-20 11:11:10 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:11:10 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 11:11:10 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 11:11:10 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 11:11:10 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 11:11:10 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 11:11:10 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 11:11:10 --> Final output sent to browser
DEBUG - 2020-10-20 11:11:10 --> Total execution time: 0.2465
INFO - 2020-10-20 11:11:10 --> Config Class Initialized
INFO - 2020-10-20 11:11:10 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:11:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:10 --> Utf8 Class Initialized
INFO - 2020-10-20 11:11:10 --> Config Class Initialized
INFO - 2020-10-20 11:11:10 --> URI Class Initialized
INFO - 2020-10-20 11:11:10 --> Hooks Class Initialized
INFO - 2020-10-20 11:11:10 --> Router Class Initialized
INFO - 2020-10-20 11:11:10 --> Output Class Initialized
DEBUG - 2020-10-20 11:11:10 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:10 --> Security Class Initialized
INFO - 2020-10-20 11:11:10 --> Utf8 Class Initialized
DEBUG - 2020-10-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:11:11 --> URI Class Initialized
INFO - 2020-10-20 11:11:11 --> Input Class Initialized
INFO - 2020-10-20 11:11:11 --> Router Class Initialized
INFO - 2020-10-20 11:11:11 --> Language Class Initialized
INFO - 2020-10-20 11:11:11 --> Output Class Initialized
ERROR - 2020-10-20 11:11:11 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 11:11:11 --> Security Class Initialized
DEBUG - 2020-10-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:11:11 --> Config Class Initialized
INFO - 2020-10-20 11:11:11 --> Input Class Initialized
INFO - 2020-10-20 11:11:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:11:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:11 --> Language Class Initialized
INFO - 2020-10-20 11:11:11 --> Utf8 Class Initialized
ERROR - 2020-10-20 11:11:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:11:11 --> URI Class Initialized
INFO - 2020-10-20 11:11:11 --> Router Class Initialized
INFO - 2020-10-20 11:11:11 --> Output Class Initialized
INFO - 2020-10-20 11:11:11 --> Config Class Initialized
INFO - 2020-10-20 11:11:11 --> Hooks Class Initialized
INFO - 2020-10-20 11:11:11 --> Security Class Initialized
DEBUG - 2020-10-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 11:11:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:11 --> Utf8 Class Initialized
INFO - 2020-10-20 11:11:11 --> Input Class Initialized
INFO - 2020-10-20 11:11:11 --> URI Class Initialized
INFO - 2020-10-20 11:11:11 --> Language Class Initialized
INFO - 2020-10-20 11:11:11 --> Router Class Initialized
ERROR - 2020-10-20 11:11:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:11:11 --> Output Class Initialized
INFO - 2020-10-20 11:11:11 --> Security Class Initialized
DEBUG - 2020-10-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:11:11 --> Input Class Initialized
INFO - 2020-10-20 11:11:11 --> Language Class Initialized
INFO - 2020-10-20 11:11:11 --> Loader Class Initialized
INFO - 2020-10-20 11:11:11 --> Helper loaded: url_helper
INFO - 2020-10-20 11:11:11 --> Helper loaded: form_helper
INFO - 2020-10-20 11:11:11 --> Helper loaded: html_helper
INFO - 2020-10-20 11:11:11 --> Helper loaded: date_helper
INFO - 2020-10-20 11:11:11 --> Database Driver Class Initialized
INFO - 2020-10-20 11:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 11:11:11 --> Table Class Initialized
INFO - 2020-10-20 11:11:11 --> Upload Class Initialized
INFO - 2020-10-20 11:11:11 --> Controller Class Initialized
INFO - 2020-10-20 11:11:11 --> Form Validation Class Initialized
INFO - 2020-10-20 11:11:11 --> Model "Crud_model" initialized
INFO - 2020-10-20 11:11:11 --> Final output sent to browser
DEBUG - 2020-10-20 11:11:11 --> Total execution time: 0.2230
INFO - 2020-10-20 11:11:11 --> Config Class Initialized
INFO - 2020-10-20 11:11:11 --> Hooks Class Initialized
INFO - 2020-10-20 11:11:11 --> Config Class Initialized
INFO - 2020-10-20 11:11:11 --> Config Class Initialized
INFO - 2020-10-20 11:11:11 --> Hooks Class Initialized
INFO - 2020-10-20 11:11:11 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:11:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:11 --> Utf8 Class Initialized
DEBUG - 2020-10-20 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 11:11:11 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:11 --> Utf8 Class Initialized
INFO - 2020-10-20 11:11:11 --> Utf8 Class Initialized
INFO - 2020-10-20 11:11:11 --> URI Class Initialized
INFO - 2020-10-20 11:11:11 --> URI Class Initialized
INFO - 2020-10-20 11:11:11 --> URI Class Initialized
INFO - 2020-10-20 11:11:11 --> Router Class Initialized
INFO - 2020-10-20 11:11:11 --> Router Class Initialized
INFO - 2020-10-20 11:11:11 --> Router Class Initialized
INFO - 2020-10-20 11:11:11 --> Output Class Initialized
INFO - 2020-10-20 11:11:11 --> Output Class Initialized
INFO - 2020-10-20 11:11:11 --> Security Class Initialized
INFO - 2020-10-20 11:11:11 --> Output Class Initialized
DEBUG - 2020-10-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:11:11 --> Security Class Initialized
INFO - 2020-10-20 11:11:11 --> Security Class Initialized
INFO - 2020-10-20 11:11:11 --> Input Class Initialized
DEBUG - 2020-10-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 11:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:11:11 --> Input Class Initialized
INFO - 2020-10-20 11:11:11 --> Input Class Initialized
INFO - 2020-10-20 11:11:11 --> Language Class Initialized
INFO - 2020-10-20 11:11:11 --> Language Class Initialized
ERROR - 2020-10-20 11:11:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:11:11 --> Language Class Initialized
ERROR - 2020-10-20 11:11:11 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 11:11:11 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 11:11:46 --> Config Class Initialized
INFO - 2020-10-20 11:11:46 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:11:46 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:11:46 --> Utf8 Class Initialized
INFO - 2020-10-20 11:11:46 --> URI Class Initialized
INFO - 2020-10-20 11:11:46 --> Router Class Initialized
INFO - 2020-10-20 11:11:46 --> Output Class Initialized
INFO - 2020-10-20 11:11:46 --> Security Class Initialized
DEBUG - 2020-10-20 11:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:11:46 --> Input Class Initialized
INFO - 2020-10-20 11:11:46 --> Language Class Initialized
ERROR - 2020-10-20 11:11:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 11:49:31 --> Config Class Initialized
INFO - 2020-10-20 11:49:31 --> Hooks Class Initialized
DEBUG - 2020-10-20 11:49:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 11:49:31 --> Utf8 Class Initialized
INFO - 2020-10-20 11:49:31 --> URI Class Initialized
DEBUG - 2020-10-20 11:49:31 --> No URI present. Default controller set.
INFO - 2020-10-20 11:49:31 --> Router Class Initialized
INFO - 2020-10-20 11:49:31 --> Output Class Initialized
INFO - 2020-10-20 11:49:31 --> Security Class Initialized
DEBUG - 2020-10-20 11:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 11:49:31 --> Input Class Initialized
INFO - 2020-10-20 11:49:31 --> Language Class Initialized
ERROR - 2020-10-20 11:49:31 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 12:37:22 --> Config Class Initialized
INFO - 2020-10-20 12:37:22 --> Hooks Class Initialized
DEBUG - 2020-10-20 12:37:22 --> UTF-8 Support Enabled
INFO - 2020-10-20 12:37:22 --> Utf8 Class Initialized
INFO - 2020-10-20 12:37:23 --> URI Class Initialized
DEBUG - 2020-10-20 12:37:23 --> No URI present. Default controller set.
INFO - 2020-10-20 12:37:23 --> Router Class Initialized
INFO - 2020-10-20 12:37:23 --> Output Class Initialized
INFO - 2020-10-20 12:37:23 --> Security Class Initialized
DEBUG - 2020-10-20 12:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 12:37:23 --> Input Class Initialized
INFO - 2020-10-20 12:37:23 --> Language Class Initialized
ERROR - 2020-10-20 12:37:23 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 12:37:25 --> Config Class Initialized
INFO - 2020-10-20 12:37:25 --> Hooks Class Initialized
DEBUG - 2020-10-20 12:37:25 --> UTF-8 Support Enabled
INFO - 2020-10-20 12:37:25 --> Utf8 Class Initialized
INFO - 2020-10-20 12:37:25 --> URI Class Initialized
DEBUG - 2020-10-20 12:37:25 --> No URI present. Default controller set.
INFO - 2020-10-20 12:37:25 --> Router Class Initialized
INFO - 2020-10-20 12:37:25 --> Output Class Initialized
INFO - 2020-10-20 12:37:25 --> Security Class Initialized
DEBUG - 2020-10-20 12:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 12:37:25 --> Input Class Initialized
INFO - 2020-10-20 12:37:25 --> Language Class Initialized
ERROR - 2020-10-20 12:37:25 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 12:37:27 --> Config Class Initialized
INFO - 2020-10-20 12:37:27 --> Hooks Class Initialized
DEBUG - 2020-10-20 12:37:27 --> UTF-8 Support Enabled
INFO - 2020-10-20 12:37:27 --> Utf8 Class Initialized
INFO - 2020-10-20 12:37:27 --> URI Class Initialized
DEBUG - 2020-10-20 12:37:27 --> No URI present. Default controller set.
INFO - 2020-10-20 12:37:27 --> Router Class Initialized
INFO - 2020-10-20 12:37:27 --> Output Class Initialized
INFO - 2020-10-20 12:37:27 --> Security Class Initialized
DEBUG - 2020-10-20 12:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 12:37:27 --> Input Class Initialized
INFO - 2020-10-20 12:37:27 --> Language Class Initialized
ERROR - 2020-10-20 12:37:27 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 12:49:57 --> Config Class Initialized
INFO - 2020-10-20 12:49:58 --> Hooks Class Initialized
DEBUG - 2020-10-20 12:49:58 --> UTF-8 Support Enabled
INFO - 2020-10-20 12:49:58 --> Utf8 Class Initialized
INFO - 2020-10-20 12:49:58 --> URI Class Initialized
DEBUG - 2020-10-20 12:49:58 --> No URI present. Default controller set.
INFO - 2020-10-20 12:49:58 --> Router Class Initialized
INFO - 2020-10-20 12:49:58 --> Output Class Initialized
INFO - 2020-10-20 12:49:58 --> Security Class Initialized
DEBUG - 2020-10-20 12:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 12:49:58 --> Input Class Initialized
INFO - 2020-10-20 12:49:58 --> Language Class Initialized
ERROR - 2020-10-20 12:49:58 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 12:59:05 --> Config Class Initialized
INFO - 2020-10-20 12:59:05 --> Hooks Class Initialized
DEBUG - 2020-10-20 12:59:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 12:59:05 --> Utf8 Class Initialized
INFO - 2020-10-20 12:59:05 --> URI Class Initialized
DEBUG - 2020-10-20 12:59:05 --> No URI present. Default controller set.
INFO - 2020-10-20 12:59:05 --> Router Class Initialized
INFO - 2020-10-20 12:59:05 --> Output Class Initialized
INFO - 2020-10-20 12:59:05 --> Security Class Initialized
DEBUG - 2020-10-20 12:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 12:59:05 --> Input Class Initialized
INFO - 2020-10-20 12:59:05 --> Language Class Initialized
ERROR - 2020-10-20 12:59:05 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 13:08:46 --> Config Class Initialized
INFO - 2020-10-20 13:08:46 --> Hooks Class Initialized
DEBUG - 2020-10-20 13:08:46 --> UTF-8 Support Enabled
INFO - 2020-10-20 13:08:46 --> Utf8 Class Initialized
INFO - 2020-10-20 13:08:46 --> URI Class Initialized
DEBUG - 2020-10-20 13:08:46 --> No URI present. Default controller set.
INFO - 2020-10-20 13:08:46 --> Router Class Initialized
INFO - 2020-10-20 13:08:46 --> Output Class Initialized
INFO - 2020-10-20 13:08:46 --> Security Class Initialized
DEBUG - 2020-10-20 13:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 13:08:46 --> Input Class Initialized
INFO - 2020-10-20 13:08:46 --> Language Class Initialized
ERROR - 2020-10-20 13:08:46 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 13:08:48 --> Config Class Initialized
INFO - 2020-10-20 13:08:48 --> Hooks Class Initialized
DEBUG - 2020-10-20 13:08:48 --> UTF-8 Support Enabled
INFO - 2020-10-20 13:08:48 --> Utf8 Class Initialized
INFO - 2020-10-20 13:08:48 --> URI Class Initialized
DEBUG - 2020-10-20 13:08:48 --> No URI present. Default controller set.
INFO - 2020-10-20 13:08:48 --> Router Class Initialized
INFO - 2020-10-20 13:08:48 --> Output Class Initialized
INFO - 2020-10-20 13:08:48 --> Security Class Initialized
DEBUG - 2020-10-20 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 13:08:48 --> Input Class Initialized
INFO - 2020-10-20 13:08:48 --> Language Class Initialized
ERROR - 2020-10-20 13:08:48 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 13:56:47 --> Config Class Initialized
INFO - 2020-10-20 13:56:47 --> Hooks Class Initialized
DEBUG - 2020-10-20 13:56:47 --> UTF-8 Support Enabled
INFO - 2020-10-20 13:56:47 --> Utf8 Class Initialized
INFO - 2020-10-20 13:56:47 --> URI Class Initialized
DEBUG - 2020-10-20 13:56:47 --> No URI present. Default controller set.
INFO - 2020-10-20 13:56:47 --> Router Class Initialized
INFO - 2020-10-20 13:56:47 --> Output Class Initialized
INFO - 2020-10-20 13:56:47 --> Security Class Initialized
DEBUG - 2020-10-20 13:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 13:56:47 --> Input Class Initialized
INFO - 2020-10-20 13:56:47 --> Language Class Initialized
ERROR - 2020-10-20 13:56:47 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 13:57:52 --> Config Class Initialized
INFO - 2020-10-20 13:57:52 --> Hooks Class Initialized
DEBUG - 2020-10-20 13:57:52 --> UTF-8 Support Enabled
INFO - 2020-10-20 13:57:52 --> Utf8 Class Initialized
INFO - 2020-10-20 13:57:52 --> URI Class Initialized
DEBUG - 2020-10-20 13:57:52 --> No URI present. Default controller set.
INFO - 2020-10-20 13:57:52 --> Router Class Initialized
INFO - 2020-10-20 13:57:52 --> Output Class Initialized
INFO - 2020-10-20 13:57:52 --> Security Class Initialized
DEBUG - 2020-10-20 13:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 13:57:52 --> Input Class Initialized
INFO - 2020-10-20 13:57:52 --> Language Class Initialized
ERROR - 2020-10-20 13:57:52 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 16:32:31 --> Config Class Initialized
INFO - 2020-10-20 16:32:31 --> Hooks Class Initialized
DEBUG - 2020-10-20 16:32:31 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:32:31 --> Utf8 Class Initialized
INFO - 2020-10-20 16:32:31 --> URI Class Initialized
DEBUG - 2020-10-20 16:32:31 --> No URI present. Default controller set.
INFO - 2020-10-20 16:32:31 --> Router Class Initialized
INFO - 2020-10-20 16:32:31 --> Output Class Initialized
INFO - 2020-10-20 16:32:31 --> Security Class Initialized
DEBUG - 2020-10-20 16:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:32:31 --> Input Class Initialized
INFO - 2020-10-20 16:32:31 --> Language Class Initialized
ERROR - 2020-10-20 16:32:31 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 16:33:09 --> Config Class Initialized
INFO - 2020-10-20 16:33:09 --> Hooks Class Initialized
DEBUG - 2020-10-20 16:33:09 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:33:09 --> Utf8 Class Initialized
INFO - 2020-10-20 16:33:09 --> URI Class Initialized
DEBUG - 2020-10-20 16:33:09 --> No URI present. Default controller set.
INFO - 2020-10-20 16:33:09 --> Router Class Initialized
INFO - 2020-10-20 16:33:09 --> Output Class Initialized
INFO - 2020-10-20 16:33:09 --> Security Class Initialized
DEBUG - 2020-10-20 16:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:33:09 --> Input Class Initialized
INFO - 2020-10-20 16:33:09 --> Language Class Initialized
ERROR - 2020-10-20 16:33:09 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 16:33:19 --> Config Class Initialized
INFO - 2020-10-20 16:33:19 --> Hooks Class Initialized
DEBUG - 2020-10-20 16:33:19 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:33:19 --> Utf8 Class Initialized
INFO - 2020-10-20 16:33:19 --> URI Class Initialized
DEBUG - 2020-10-20 16:33:19 --> No URI present. Default controller set.
INFO - 2020-10-20 16:33:19 --> Router Class Initialized
INFO - 2020-10-20 16:33:19 --> Output Class Initialized
INFO - 2020-10-20 16:33:19 --> Security Class Initialized
DEBUG - 2020-10-20 16:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:33:19 --> Input Class Initialized
INFO - 2020-10-20 16:33:19 --> Language Class Initialized
ERROR - 2020-10-20 16:33:19 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 16:40:14 --> Config Class Initialized
INFO - 2020-10-20 16:40:14 --> Hooks Class Initialized
DEBUG - 2020-10-20 16:40:14 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:40:14 --> Utf8 Class Initialized
INFO - 2020-10-20 16:40:14 --> URI Class Initialized
INFO - 2020-10-20 16:40:14 --> Router Class Initialized
INFO - 2020-10-20 16:40:14 --> Output Class Initialized
INFO - 2020-10-20 16:40:14 --> Security Class Initialized
DEBUG - 2020-10-20 16:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:40:14 --> Input Class Initialized
INFO - 2020-10-20 16:40:14 --> Language Class Initialized
INFO - 2020-10-20 16:40:14 --> Loader Class Initialized
INFO - 2020-10-20 16:40:14 --> Helper loaded: url_helper
INFO - 2020-10-20 16:40:14 --> Helper loaded: form_helper
INFO - 2020-10-20 16:40:14 --> Helper loaded: html_helper
INFO - 2020-10-20 16:40:14 --> Helper loaded: date_helper
INFO - 2020-10-20 16:40:14 --> Database Driver Class Initialized
INFO - 2020-10-20 16:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 16:40:14 --> Table Class Initialized
INFO - 2020-10-20 16:40:14 --> Upload Class Initialized
INFO - 2020-10-20 16:40:14 --> Controller Class Initialized
INFO - 2020-10-20 16:40:14 --> Form Validation Class Initialized
INFO - 2020-10-20 16:40:14 --> Model "Crud_model" initialized
INFO - 2020-10-20 16:40:14 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 16:40:14 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 16:40:14 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 16:40:14 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 16:40:14 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 16:40:14 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 16:40:14 --> Final output sent to browser
DEBUG - 2020-10-20 16:40:14 --> Total execution time: 0.2488
INFO - 2020-10-20 16:40:14 --> Config Class Initialized
INFO - 2020-10-20 16:40:14 --> Hooks Class Initialized
DEBUG - 2020-10-20 16:40:14 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:40:14 --> Utf8 Class Initialized
INFO - 2020-10-20 16:40:14 --> URI Class Initialized
INFO - 2020-10-20 16:40:15 --> Router Class Initialized
INFO - 2020-10-20 16:40:15 --> Output Class Initialized
INFO - 2020-10-20 16:40:15 --> Security Class Initialized
DEBUG - 2020-10-20 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:40:15 --> Input Class Initialized
INFO - 2020-10-20 16:40:15 --> Config Class Initialized
INFO - 2020-10-20 16:40:15 --> Hooks Class Initialized
INFO - 2020-10-20 16:40:15 --> Language Class Initialized
ERROR - 2020-10-20 16:40:15 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-20 16:40:15 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:40:15 --> Config Class Initialized
INFO - 2020-10-20 16:40:15 --> Utf8 Class Initialized
INFO - 2020-10-20 16:40:15 --> Hooks Class Initialized
INFO - 2020-10-20 16:40:15 --> URI Class Initialized
DEBUG - 2020-10-20 16:40:15 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:40:15 --> Router Class Initialized
INFO - 2020-10-20 16:40:15 --> Utf8 Class Initialized
INFO - 2020-10-20 16:40:15 --> Output Class Initialized
INFO - 2020-10-20 16:40:15 --> Security Class Initialized
INFO - 2020-10-20 16:40:15 --> URI Class Initialized
DEBUG - 2020-10-20 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:40:15 --> Router Class Initialized
INFO - 2020-10-20 16:40:15 --> Input Class Initialized
INFO - 2020-10-20 16:40:15 --> Output Class Initialized
INFO - 2020-10-20 16:40:15 --> Config Class Initialized
INFO - 2020-10-20 16:40:15 --> Language Class Initialized
INFO - 2020-10-20 16:40:15 --> Hooks Class Initialized
INFO - 2020-10-20 16:40:15 --> Security Class Initialized
DEBUG - 2020-10-20 16:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-20 16:40:15 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-20 16:40:15 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:40:15 --> Utf8 Class Initialized
INFO - 2020-10-20 16:40:15 --> Input Class Initialized
INFO - 2020-10-20 16:40:15 --> URI Class Initialized
INFO - 2020-10-20 16:40:15 --> Language Class Initialized
ERROR - 2020-10-20 16:40:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 16:40:15 --> Router Class Initialized
INFO - 2020-10-20 16:40:15 --> Output Class Initialized
INFO - 2020-10-20 16:40:15 --> Security Class Initialized
DEBUG - 2020-10-20 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:40:15 --> Input Class Initialized
INFO - 2020-10-20 16:40:15 --> Language Class Initialized
INFO - 2020-10-20 16:40:15 --> Loader Class Initialized
INFO - 2020-10-20 16:40:15 --> Helper loaded: url_helper
INFO - 2020-10-20 16:40:15 --> Helper loaded: form_helper
INFO - 2020-10-20 16:40:15 --> Helper loaded: html_helper
INFO - 2020-10-20 16:40:15 --> Helper loaded: date_helper
INFO - 2020-10-20 16:40:15 --> Database Driver Class Initialized
INFO - 2020-10-20 16:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 16:40:15 --> Table Class Initialized
INFO - 2020-10-20 16:40:15 --> Upload Class Initialized
INFO - 2020-10-20 16:40:15 --> Controller Class Initialized
INFO - 2020-10-20 16:40:15 --> Form Validation Class Initialized
INFO - 2020-10-20 16:40:15 --> Model "Crud_model" initialized
INFO - 2020-10-20 16:40:15 --> Final output sent to browser
DEBUG - 2020-10-20 16:40:15 --> Total execution time: 0.2316
INFO - 2020-10-20 16:40:15 --> Config Class Initialized
INFO - 2020-10-20 16:40:15 --> Config Class Initialized
INFO - 2020-10-20 16:40:15 --> Config Class Initialized
INFO - 2020-10-20 16:40:15 --> Hooks Class Initialized
INFO - 2020-10-20 16:40:15 --> Hooks Class Initialized
DEBUG - 2020-10-20 16:40:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 16:40:15 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:40:15 --> Hooks Class Initialized
INFO - 2020-10-20 16:40:15 --> Utf8 Class Initialized
INFO - 2020-10-20 16:40:15 --> Utf8 Class Initialized
DEBUG - 2020-10-20 16:40:15 --> UTF-8 Support Enabled
INFO - 2020-10-20 16:40:15 --> Utf8 Class Initialized
INFO - 2020-10-20 16:40:15 --> URI Class Initialized
INFO - 2020-10-20 16:40:15 --> URI Class Initialized
INFO - 2020-10-20 16:40:15 --> Router Class Initialized
INFO - 2020-10-20 16:40:15 --> Router Class Initialized
INFO - 2020-10-20 16:40:15 --> URI Class Initialized
INFO - 2020-10-20 16:40:15 --> Output Class Initialized
INFO - 2020-10-20 16:40:15 --> Output Class Initialized
INFO - 2020-10-20 16:40:15 --> Router Class Initialized
INFO - 2020-10-20 16:40:15 --> Security Class Initialized
INFO - 2020-10-20 16:40:15 --> Security Class Initialized
INFO - 2020-10-20 16:40:15 --> Output Class Initialized
DEBUG - 2020-10-20 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:40:15 --> Security Class Initialized
DEBUG - 2020-10-20 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:40:15 --> Input Class Initialized
INFO - 2020-10-20 16:40:15 --> Input Class Initialized
DEBUG - 2020-10-20 16:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 16:40:15 --> Language Class Initialized
INFO - 2020-10-20 16:40:15 --> Input Class Initialized
INFO - 2020-10-20 16:40:15 --> Language Class Initialized
ERROR - 2020-10-20 16:40:15 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 16:40:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 16:40:15 --> Language Class Initialized
ERROR - 2020-10-20 16:40:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 17:32:41 --> Config Class Initialized
INFO - 2020-10-20 17:32:41 --> Hooks Class Initialized
DEBUG - 2020-10-20 17:32:41 --> UTF-8 Support Enabled
INFO - 2020-10-20 17:32:41 --> Utf8 Class Initialized
INFO - 2020-10-20 17:32:41 --> URI Class Initialized
DEBUG - 2020-10-20 17:32:41 --> No URI present. Default controller set.
INFO - 2020-10-20 17:32:41 --> Router Class Initialized
INFO - 2020-10-20 17:32:41 --> Output Class Initialized
INFO - 2020-10-20 17:32:41 --> Security Class Initialized
DEBUG - 2020-10-20 17:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 17:32:41 --> Input Class Initialized
INFO - 2020-10-20 17:32:41 --> Language Class Initialized
ERROR - 2020-10-20 17:32:41 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 17:32:46 --> Config Class Initialized
INFO - 2020-10-20 17:32:46 --> Hooks Class Initialized
DEBUG - 2020-10-20 17:32:46 --> UTF-8 Support Enabled
INFO - 2020-10-20 17:32:46 --> Utf8 Class Initialized
INFO - 2020-10-20 17:32:46 --> URI Class Initialized
DEBUG - 2020-10-20 17:32:46 --> No URI present. Default controller set.
INFO - 2020-10-20 17:32:46 --> Router Class Initialized
INFO - 2020-10-20 17:32:46 --> Output Class Initialized
INFO - 2020-10-20 17:32:46 --> Security Class Initialized
DEBUG - 2020-10-20 17:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 17:32:46 --> Input Class Initialized
INFO - 2020-10-20 17:32:46 --> Language Class Initialized
ERROR - 2020-10-20 17:32:46 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 17:32:48 --> Config Class Initialized
INFO - 2020-10-20 17:32:48 --> Hooks Class Initialized
DEBUG - 2020-10-20 17:32:48 --> UTF-8 Support Enabled
INFO - 2020-10-20 17:32:48 --> Utf8 Class Initialized
INFO - 2020-10-20 17:32:48 --> URI Class Initialized
DEBUG - 2020-10-20 17:32:48 --> No URI present. Default controller set.
INFO - 2020-10-20 17:32:48 --> Router Class Initialized
INFO - 2020-10-20 17:32:48 --> Output Class Initialized
INFO - 2020-10-20 17:32:48 --> Security Class Initialized
DEBUG - 2020-10-20 17:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 17:32:48 --> Input Class Initialized
INFO - 2020-10-20 17:32:48 --> Language Class Initialized
ERROR - 2020-10-20 17:32:48 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 18:18:29 --> Config Class Initialized
INFO - 2020-10-20 18:18:29 --> Hooks Class Initialized
DEBUG - 2020-10-20 18:18:29 --> UTF-8 Support Enabled
INFO - 2020-10-20 18:18:29 --> Utf8 Class Initialized
INFO - 2020-10-20 18:18:29 --> URI Class Initialized
DEBUG - 2020-10-20 18:18:29 --> No URI present. Default controller set.
INFO - 2020-10-20 18:18:29 --> Router Class Initialized
INFO - 2020-10-20 18:18:29 --> Output Class Initialized
INFO - 2020-10-20 18:18:29 --> Security Class Initialized
DEBUG - 2020-10-20 18:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 18:18:29 --> Input Class Initialized
INFO - 2020-10-20 18:18:29 --> Language Class Initialized
ERROR - 2020-10-20 18:18:29 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 18:18:32 --> Config Class Initialized
INFO - 2020-10-20 18:18:32 --> Hooks Class Initialized
DEBUG - 2020-10-20 18:18:32 --> UTF-8 Support Enabled
INFO - 2020-10-20 18:18:32 --> Utf8 Class Initialized
INFO - 2020-10-20 18:18:32 --> URI Class Initialized
DEBUG - 2020-10-20 18:18:32 --> No URI present. Default controller set.
INFO - 2020-10-20 18:18:32 --> Router Class Initialized
INFO - 2020-10-20 18:18:32 --> Output Class Initialized
INFO - 2020-10-20 18:18:32 --> Security Class Initialized
DEBUG - 2020-10-20 18:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 18:18:32 --> Input Class Initialized
INFO - 2020-10-20 18:18:32 --> Language Class Initialized
ERROR - 2020-10-20 18:18:32 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 18:33:04 --> Config Class Initialized
INFO - 2020-10-20 18:33:04 --> Hooks Class Initialized
DEBUG - 2020-10-20 18:33:04 --> UTF-8 Support Enabled
INFO - 2020-10-20 18:33:04 --> Utf8 Class Initialized
INFO - 2020-10-20 18:33:04 --> URI Class Initialized
DEBUG - 2020-10-20 18:33:04 --> No URI present. Default controller set.
INFO - 2020-10-20 18:33:04 --> Router Class Initialized
INFO - 2020-10-20 18:33:04 --> Output Class Initialized
INFO - 2020-10-20 18:33:04 --> Security Class Initialized
DEBUG - 2020-10-20 18:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 18:33:04 --> Input Class Initialized
INFO - 2020-10-20 18:33:04 --> Language Class Initialized
ERROR - 2020-10-20 18:33:04 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 18:33:43 --> Config Class Initialized
INFO - 2020-10-20 18:33:43 --> Hooks Class Initialized
DEBUG - 2020-10-20 18:33:43 --> UTF-8 Support Enabled
INFO - 2020-10-20 18:33:43 --> Utf8 Class Initialized
INFO - 2020-10-20 18:33:43 --> URI Class Initialized
DEBUG - 2020-10-20 18:33:43 --> No URI present. Default controller set.
INFO - 2020-10-20 18:33:43 --> Router Class Initialized
INFO - 2020-10-20 18:33:43 --> Output Class Initialized
INFO - 2020-10-20 18:33:43 --> Security Class Initialized
DEBUG - 2020-10-20 18:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 18:33:43 --> Input Class Initialized
INFO - 2020-10-20 18:33:43 --> Language Class Initialized
ERROR - 2020-10-20 18:33:43 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 21:20:01 --> Config Class Initialized
INFO - 2020-10-20 21:20:01 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:01 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:01 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:01 --> URI Class Initialized
DEBUG - 2020-10-20 21:20:01 --> No URI present. Default controller set.
INFO - 2020-10-20 21:20:01 --> Router Class Initialized
INFO - 2020-10-20 21:20:01 --> Output Class Initialized
INFO - 2020-10-20 21:20:01 --> Security Class Initialized
DEBUG - 2020-10-20 21:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:01 --> Input Class Initialized
INFO - 2020-10-20 21:20:01 --> Language Class Initialized
ERROR - 2020-10-20 21:20:01 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-20 21:20:01 --> Config Class Initialized
INFO - 2020-10-20 21:20:01 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:01 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:01 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:01 --> URI Class Initialized
INFO - 2020-10-20 21:20:01 --> Router Class Initialized
INFO - 2020-10-20 21:20:01 --> Output Class Initialized
INFO - 2020-10-20 21:20:01 --> Security Class Initialized
DEBUG - 2020-10-20 21:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:01 --> Input Class Initialized
INFO - 2020-10-20 21:20:01 --> Language Class Initialized
ERROR - 2020-10-20 21:20:01 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-20 21:20:05 --> Config Class Initialized
INFO - 2020-10-20 21:20:05 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:05 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:05 --> URI Class Initialized
INFO - 2020-10-20 21:20:05 --> Router Class Initialized
INFO - 2020-10-20 21:20:05 --> Output Class Initialized
INFO - 2020-10-20 21:20:05 --> Security Class Initialized
DEBUG - 2020-10-20 21:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:05 --> Input Class Initialized
INFO - 2020-10-20 21:20:05 --> Language Class Initialized
INFO - 2020-10-20 21:20:05 --> Loader Class Initialized
INFO - 2020-10-20 21:20:05 --> Helper loaded: url_helper
INFO - 2020-10-20 21:20:05 --> Helper loaded: form_helper
INFO - 2020-10-20 21:20:05 --> Helper loaded: html_helper
INFO - 2020-10-20 21:20:05 --> Helper loaded: date_helper
INFO - 2020-10-20 21:20:05 --> Database Driver Class Initialized
INFO - 2020-10-20 21:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 21:20:05 --> Table Class Initialized
INFO - 2020-10-20 21:20:05 --> Upload Class Initialized
INFO - 2020-10-20 21:20:05 --> Controller Class Initialized
INFO - 2020-10-20 21:20:05 --> Form Validation Class Initialized
INFO - 2020-10-20 21:20:05 --> Model "Crud_model" initialized
INFO - 2020-10-20 21:20:05 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 21:20:05 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 21:20:05 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 21:20:05 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 21:20:05 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 21:20:05 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 21:20:05 --> Final output sent to browser
DEBUG - 2020-10-20 21:20:05 --> Total execution time: 0.2739
INFO - 2020-10-20 21:20:05 --> Config Class Initialized
INFO - 2020-10-20 21:20:05 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:05 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:05 --> URI Class Initialized
INFO - 2020-10-20 21:20:05 --> Router Class Initialized
INFO - 2020-10-20 21:20:05 --> Config Class Initialized
INFO - 2020-10-20 21:20:05 --> Config Class Initialized
INFO - 2020-10-20 21:20:05 --> Hooks Class Initialized
INFO - 2020-10-20 21:20:05 --> Config Class Initialized
INFO - 2020-10-20 21:20:05 --> Config Class Initialized
INFO - 2020-10-20 21:20:05 --> Output Class Initialized
INFO - 2020-10-20 21:20:05 --> Config Class Initialized
INFO - 2020-10-20 21:20:05 --> Hooks Class Initialized
INFO - 2020-10-20 21:20:05 --> Security Class Initialized
INFO - 2020-10-20 21:20:05 --> Hooks Class Initialized
INFO - 2020-10-20 21:20:05 --> Hooks Class Initialized
INFO - 2020-10-20 21:20:05 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 21:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 21:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:05 --> Utf8 Class Initialized
DEBUG - 2020-10-20 21:20:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:05 --> Utf8 Class Initialized
DEBUG - 2020-10-20 21:20:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-20 21:20:05 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:05 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:05 --> URI Class Initialized
INFO - 2020-10-20 21:20:05 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:05 --> Input Class Initialized
INFO - 2020-10-20 21:20:05 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:05 --> URI Class Initialized
INFO - 2020-10-20 21:20:05 --> Language Class Initialized
INFO - 2020-10-20 21:20:05 --> Router Class Initialized
INFO - 2020-10-20 21:20:05 --> URI Class Initialized
INFO - 2020-10-20 21:20:05 --> Router Class Initialized
INFO - 2020-10-20 21:20:05 --> URI Class Initialized
INFO - 2020-10-20 21:20:05 --> URI Class Initialized
ERROR - 2020-10-20 21:20:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-20 21:20:05 --> Output Class Initialized
INFO - 2020-10-20 21:20:05 --> Router Class Initialized
INFO - 2020-10-20 21:20:05 --> Output Class Initialized
INFO - 2020-10-20 21:20:05 --> Router Class Initialized
INFO - 2020-10-20 21:20:05 --> Router Class Initialized
INFO - 2020-10-20 21:20:05 --> Security Class Initialized
INFO - 2020-10-20 21:20:05 --> Output Class Initialized
INFO - 2020-10-20 21:20:05 --> Security Class Initialized
INFO - 2020-10-20 21:20:05 --> Output Class Initialized
INFO - 2020-10-20 21:20:05 --> Output Class Initialized
DEBUG - 2020-10-20 21:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 21:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:05 --> Security Class Initialized
INFO - 2020-10-20 21:20:05 --> Security Class Initialized
INFO - 2020-10-20 21:20:05 --> Security Class Initialized
INFO - 2020-10-20 21:20:05 --> Input Class Initialized
INFO - 2020-10-20 21:20:05 --> Input Class Initialized
DEBUG - 2020-10-20 21:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 21:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-20 21:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:05 --> Input Class Initialized
INFO - 2020-10-20 21:20:05 --> Input Class Initialized
INFO - 2020-10-20 21:20:05 --> Input Class Initialized
INFO - 2020-10-20 21:20:05 --> Language Class Initialized
INFO - 2020-10-20 21:20:05 --> Language Class Initialized
INFO - 2020-10-20 21:20:05 --> Language Class Initialized
INFO - 2020-10-20 21:20:05 --> Language Class Initialized
ERROR - 2020-10-20 21:20:05 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 21:20:05 --> Language Class Initialized
ERROR - 2020-10-20 21:20:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 21:20:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 21:20:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-20 21:20:05 --> 404 Page Not Found: Dist/img
INFO - 2020-10-20 21:20:06 --> Config Class Initialized
INFO - 2020-10-20 21:20:06 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:06 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:06 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:06 --> URI Class Initialized
INFO - 2020-10-20 21:20:06 --> Router Class Initialized
INFO - 2020-10-20 21:20:06 --> Output Class Initialized
INFO - 2020-10-20 21:20:06 --> Security Class Initialized
DEBUG - 2020-10-20 21:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:06 --> Input Class Initialized
INFO - 2020-10-20 21:20:06 --> Language Class Initialized
INFO - 2020-10-20 21:20:07 --> Loader Class Initialized
INFO - 2020-10-20 21:20:07 --> Helper loaded: url_helper
INFO - 2020-10-20 21:20:07 --> Helper loaded: form_helper
INFO - 2020-10-20 21:20:07 --> Helper loaded: html_helper
INFO - 2020-10-20 21:20:07 --> Helper loaded: date_helper
INFO - 2020-10-20 21:20:07 --> Database Driver Class Initialized
INFO - 2020-10-20 21:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 21:20:07 --> Table Class Initialized
INFO - 2020-10-20 21:20:07 --> Upload Class Initialized
INFO - 2020-10-20 21:20:07 --> Controller Class Initialized
INFO - 2020-10-20 21:20:07 --> Form Validation Class Initialized
INFO - 2020-10-20 21:20:07 --> Model "Crud_model" initialized
INFO - 2020-10-20 21:20:07 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-20 21:20:07 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-20 21:20:07 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-20 21:20:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-20 21:20:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-20 21:20:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-20 21:20:07 --> Final output sent to browser
DEBUG - 2020-10-20 21:20:07 --> Total execution time: 0.2640
INFO - 2020-10-20 21:20:07 --> Config Class Initialized
INFO - 2020-10-20 21:20:07 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:07 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:07 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:07 --> URI Class Initialized
INFO - 2020-10-20 21:20:07 --> Router Class Initialized
INFO - 2020-10-20 21:20:07 --> Output Class Initialized
INFO - 2020-10-20 21:20:07 --> Security Class Initialized
DEBUG - 2020-10-20 21:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:07 --> Input Class Initialized
INFO - 2020-10-20 21:20:07 --> Language Class Initialized
INFO - 2020-10-20 21:20:07 --> Loader Class Initialized
INFO - 2020-10-20 21:20:07 --> Helper loaded: url_helper
INFO - 2020-10-20 21:20:07 --> Helper loaded: form_helper
INFO - 2020-10-20 21:20:07 --> Helper loaded: html_helper
INFO - 2020-10-20 21:20:07 --> Helper loaded: date_helper
INFO - 2020-10-20 21:20:07 --> Database Driver Class Initialized
INFO - 2020-10-20 21:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-20 21:20:07 --> Table Class Initialized
INFO - 2020-10-20 21:20:07 --> Upload Class Initialized
INFO - 2020-10-20 21:20:07 --> Controller Class Initialized
INFO - 2020-10-20 21:20:07 --> Form Validation Class Initialized
INFO - 2020-10-20 21:20:07 --> Model "Crud_model" initialized
INFO - 2020-10-20 21:20:07 --> Final output sent to browser
DEBUG - 2020-10-20 21:20:07 --> Total execution time: 0.2524
INFO - 2020-10-20 21:20:07 --> Config Class Initialized
INFO - 2020-10-20 21:20:07 --> Hooks Class Initialized
DEBUG - 2020-10-20 21:20:07 --> UTF-8 Support Enabled
INFO - 2020-10-20 21:20:07 --> Utf8 Class Initialized
INFO - 2020-10-20 21:20:07 --> URI Class Initialized
INFO - 2020-10-20 21:20:08 --> Router Class Initialized
INFO - 2020-10-20 21:20:08 --> Output Class Initialized
INFO - 2020-10-20 21:20:08 --> Security Class Initialized
DEBUG - 2020-10-20 21:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-20 21:20:08 --> Input Class Initialized
INFO - 2020-10-20 21:20:08 --> Language Class Initialized
ERROR - 2020-10-20 21:20:08 --> 404 Page Not Found: Assets/dist

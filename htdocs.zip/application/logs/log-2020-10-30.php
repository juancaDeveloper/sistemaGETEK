<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-30 10:13:06 --> Config Class Initialized
INFO - 2020-10-30 10:13:06 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:13:06 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:13:06 --> Utf8 Class Initialized
INFO - 2020-10-30 10:13:06 --> URI Class Initialized
INFO - 2020-10-30 10:13:06 --> Router Class Initialized
INFO - 2020-10-30 10:13:06 --> Output Class Initialized
INFO - 2020-10-30 10:13:06 --> Security Class Initialized
DEBUG - 2020-10-30 10:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:13:06 --> Input Class Initialized
INFO - 2020-10-30 10:13:06 --> Language Class Initialized
INFO - 2020-10-30 10:13:06 --> Loader Class Initialized
INFO - 2020-10-30 10:13:06 --> Helper loaded: url_helper
INFO - 2020-10-30 10:13:06 --> Helper loaded: form_helper
INFO - 2020-10-30 10:13:06 --> Helper loaded: html_helper
INFO - 2020-10-30 10:13:06 --> Helper loaded: date_helper
INFO - 2020-10-30 10:13:06 --> Database Driver Class Initialized
INFO - 2020-10-30 10:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 10:13:06 --> Table Class Initialized
INFO - 2020-10-30 10:13:06 --> Upload Class Initialized
INFO - 2020-10-30 10:13:06 --> Controller Class Initialized
INFO - 2020-10-30 10:13:06 --> Form Validation Class Initialized
INFO - 2020-10-30 10:13:06 --> Model "Crud_model" initialized
INFO - 2020-10-30 10:13:06 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-30 10:13:06 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-30 10:13:06 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-30 10:13:06 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-30 10:13:06 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-30 10:13:06 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-30 10:13:06 --> Final output sent to browser
DEBUG - 2020-10-30 10:13:06 --> Total execution time: 0.2551
INFO - 2020-10-30 10:13:06 --> Config Class Initialized
INFO - 2020-10-30 10:13:06 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:13:06 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:13:06 --> Utf8 Class Initialized
INFO - 2020-10-30 10:13:06 --> URI Class Initialized
INFO - 2020-10-30 10:13:06 --> Router Class Initialized
INFO - 2020-10-30 10:13:06 --> Output Class Initialized
INFO - 2020-10-30 10:13:06 --> Security Class Initialized
DEBUG - 2020-10-30 10:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:13:06 --> Input Class Initialized
INFO - 2020-10-30 10:13:06 --> Language Class Initialized
ERROR - 2020-10-30 10:13:06 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-30 10:13:07 --> Config Class Initialized
INFO - 2020-10-30 10:13:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:13:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:13:07 --> Utf8 Class Initialized
INFO - 2020-10-30 10:13:07 --> URI Class Initialized
INFO - 2020-10-30 10:13:07 --> Router Class Initialized
INFO - 2020-10-30 10:13:07 --> Output Class Initialized
INFO - 2020-10-30 10:13:07 --> Security Class Initialized
DEBUG - 2020-10-30 10:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:13:07 --> Input Class Initialized
INFO - 2020-10-30 10:13:07 --> Language Class Initialized
INFO - 2020-10-30 10:13:07 --> Loader Class Initialized
INFO - 2020-10-30 10:13:07 --> Helper loaded: url_helper
INFO - 2020-10-30 10:13:07 --> Helper loaded: form_helper
INFO - 2020-10-30 10:13:07 --> Helper loaded: html_helper
INFO - 2020-10-30 10:13:07 --> Helper loaded: date_helper
INFO - 2020-10-30 10:13:07 --> Database Driver Class Initialized
INFO - 2020-10-30 10:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 10:13:07 --> Table Class Initialized
INFO - 2020-10-30 10:13:07 --> Upload Class Initialized
INFO - 2020-10-30 10:13:07 --> Controller Class Initialized
INFO - 2020-10-30 10:13:07 --> Form Validation Class Initialized
INFO - 2020-10-30 10:13:07 --> Model "Crud_model" initialized
ERROR - 2020-10-30 10:13:07 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-10-30 10:13:07 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-30 10:13:08 --> Config Class Initialized
INFO - 2020-10-30 10:13:08 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:13:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:13:08 --> Utf8 Class Initialized
INFO - 2020-10-30 10:13:08 --> URI Class Initialized
INFO - 2020-10-30 10:13:08 --> Router Class Initialized
INFO - 2020-10-30 10:13:08 --> Output Class Initialized
INFO - 2020-10-30 10:13:08 --> Security Class Initialized
DEBUG - 2020-10-30 10:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:13:08 --> Input Class Initialized
INFO - 2020-10-30 10:13:08 --> Language Class Initialized
ERROR - 2020-10-30 10:13:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-30 10:23:52 --> Config Class Initialized
INFO - 2020-10-30 10:23:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:23:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:23:52 --> Utf8 Class Initialized
INFO - 2020-10-30 10:23:52 --> URI Class Initialized
DEBUG - 2020-10-30 10:23:52 --> No URI present. Default controller set.
INFO - 2020-10-30 10:23:52 --> Router Class Initialized
INFO - 2020-10-30 10:23:52 --> Output Class Initialized
INFO - 2020-10-30 10:23:52 --> Security Class Initialized
DEBUG - 2020-10-30 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:23:52 --> Input Class Initialized
INFO - 2020-10-30 10:23:52 --> Language Class Initialized
INFO - 2020-10-30 10:23:52 --> Loader Class Initialized
INFO - 2020-10-30 10:23:52 --> Helper loaded: url_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: form_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: html_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: date_helper
INFO - 2020-10-30 10:23:52 --> Database Driver Class Initialized
INFO - 2020-10-30 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 10:23:52 --> Table Class Initialized
INFO - 2020-10-30 10:23:52 --> Upload Class Initialized
INFO - 2020-10-30 10:23:52 --> Controller Class Initialized
INFO - 2020-10-30 10:23:52 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 10:23:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 10:23:52 --> Final output sent to browser
DEBUG - 2020-10-30 10:23:52 --> Total execution time: 0.1512
INFO - 2020-10-30 10:23:52 --> Config Class Initialized
INFO - 2020-10-30 10:23:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:23:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:23:52 --> Utf8 Class Initialized
INFO - 2020-10-30 10:23:52 --> URI Class Initialized
DEBUG - 2020-10-30 10:23:52 --> No URI present. Default controller set.
INFO - 2020-10-30 10:23:52 --> Router Class Initialized
INFO - 2020-10-30 10:23:52 --> Output Class Initialized
INFO - 2020-10-30 10:23:52 --> Security Class Initialized
DEBUG - 2020-10-30 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:23:52 --> Input Class Initialized
INFO - 2020-10-30 10:23:52 --> Language Class Initialized
INFO - 2020-10-30 10:23:52 --> Loader Class Initialized
INFO - 2020-10-30 10:23:52 --> Helper loaded: url_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: form_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: html_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: date_helper
INFO - 2020-10-30 10:23:52 --> Database Driver Class Initialized
INFO - 2020-10-30 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 10:23:52 --> Table Class Initialized
INFO - 2020-10-30 10:23:52 --> Upload Class Initialized
INFO - 2020-10-30 10:23:52 --> Controller Class Initialized
INFO - 2020-10-30 10:23:52 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 10:23:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 10:23:52 --> Final output sent to browser
DEBUG - 2020-10-30 10:23:52 --> Total execution time: 0.0886
INFO - 2020-10-30 10:23:52 --> Config Class Initialized
INFO - 2020-10-30 10:23:52 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:23:52 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:23:52 --> Utf8 Class Initialized
INFO - 2020-10-30 10:23:52 --> URI Class Initialized
DEBUG - 2020-10-30 10:23:52 --> No URI present. Default controller set.
INFO - 2020-10-30 10:23:52 --> Router Class Initialized
INFO - 2020-10-30 10:23:52 --> Output Class Initialized
INFO - 2020-10-30 10:23:52 --> Security Class Initialized
DEBUG - 2020-10-30 10:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:23:52 --> Input Class Initialized
INFO - 2020-10-30 10:23:52 --> Language Class Initialized
INFO - 2020-10-30 10:23:52 --> Loader Class Initialized
INFO - 2020-10-30 10:23:52 --> Helper loaded: url_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: form_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: html_helper
INFO - 2020-10-30 10:23:52 --> Helper loaded: date_helper
INFO - 2020-10-30 10:23:52 --> Database Driver Class Initialized
INFO - 2020-10-30 10:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 10:23:52 --> Table Class Initialized
INFO - 2020-10-30 10:23:52 --> Upload Class Initialized
INFO - 2020-10-30 10:23:52 --> Controller Class Initialized
INFO - 2020-10-30 10:23:52 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 10:23:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 10:23:52 --> Final output sent to browser
DEBUG - 2020-10-30 10:23:52 --> Total execution time: 0.1104
INFO - 2020-10-30 10:50:38 --> Config Class Initialized
INFO - 2020-10-30 10:50:38 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:50:38 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:50:38 --> Utf8 Class Initialized
INFO - 2020-10-30 10:50:38 --> URI Class Initialized
DEBUG - 2020-10-30 10:50:38 --> No URI present. Default controller set.
INFO - 2020-10-30 10:50:38 --> Router Class Initialized
INFO - 2020-10-30 10:50:38 --> Output Class Initialized
INFO - 2020-10-30 10:50:38 --> Security Class Initialized
DEBUG - 2020-10-30 10:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:50:38 --> Input Class Initialized
INFO - 2020-10-30 10:50:38 --> Language Class Initialized
INFO - 2020-10-30 10:50:38 --> Loader Class Initialized
INFO - 2020-10-30 10:50:38 --> Helper loaded: url_helper
INFO - 2020-10-30 10:50:38 --> Helper loaded: form_helper
INFO - 2020-10-30 10:50:38 --> Helper loaded: html_helper
INFO - 2020-10-30 10:50:38 --> Helper loaded: date_helper
INFO - 2020-10-30 10:50:38 --> Database Driver Class Initialized
INFO - 2020-10-30 10:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 10:50:38 --> Table Class Initialized
INFO - 2020-10-30 10:50:38 --> Upload Class Initialized
INFO - 2020-10-30 10:50:38 --> Controller Class Initialized
INFO - 2020-10-30 10:50:38 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 10:50:38 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 10:50:38 --> Final output sent to browser
DEBUG - 2020-10-30 10:50:38 --> Total execution time: 0.0943
INFO - 2020-10-30 10:50:38 --> Config Class Initialized
INFO - 2020-10-30 10:50:38 --> Hooks Class Initialized
DEBUG - 2020-10-30 10:50:38 --> UTF-8 Support Enabled
INFO - 2020-10-30 10:50:38 --> Utf8 Class Initialized
INFO - 2020-10-30 10:50:38 --> URI Class Initialized
DEBUG - 2020-10-30 10:50:38 --> No URI present. Default controller set.
INFO - 2020-10-30 10:50:38 --> Router Class Initialized
INFO - 2020-10-30 10:50:38 --> Output Class Initialized
INFO - 2020-10-30 10:50:38 --> Security Class Initialized
DEBUG - 2020-10-30 10:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 10:50:38 --> Input Class Initialized
INFO - 2020-10-30 10:50:38 --> Language Class Initialized
INFO - 2020-10-30 10:50:38 --> Loader Class Initialized
INFO - 2020-10-30 10:50:38 --> Helper loaded: url_helper
INFO - 2020-10-30 10:50:38 --> Helper loaded: form_helper
INFO - 2020-10-30 10:50:39 --> Helper loaded: html_helper
INFO - 2020-10-30 10:50:39 --> Helper loaded: date_helper
INFO - 2020-10-30 10:50:39 --> Database Driver Class Initialized
INFO - 2020-10-30 10:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 10:50:39 --> Table Class Initialized
INFO - 2020-10-30 10:50:39 --> Upload Class Initialized
INFO - 2020-10-30 10:50:39 --> Controller Class Initialized
INFO - 2020-10-30 10:50:39 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 10:50:39 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 10:50:39 --> Final output sent to browser
DEBUG - 2020-10-30 10:50:39 --> Total execution time: 0.0978
INFO - 2020-10-30 11:07:14 --> Config Class Initialized
INFO - 2020-10-30 11:07:14 --> Hooks Class Initialized
DEBUG - 2020-10-30 11:07:14 --> UTF-8 Support Enabled
INFO - 2020-10-30 11:07:14 --> Utf8 Class Initialized
INFO - 2020-10-30 11:07:14 --> URI Class Initialized
DEBUG - 2020-10-30 11:07:14 --> No URI present. Default controller set.
INFO - 2020-10-30 11:07:14 --> Router Class Initialized
INFO - 2020-10-30 11:07:14 --> Output Class Initialized
INFO - 2020-10-30 11:07:14 --> Security Class Initialized
DEBUG - 2020-10-30 11:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 11:07:14 --> Input Class Initialized
INFO - 2020-10-30 11:07:14 --> Language Class Initialized
INFO - 2020-10-30 11:07:14 --> Loader Class Initialized
INFO - 2020-10-30 11:07:14 --> Helper loaded: url_helper
INFO - 2020-10-30 11:07:14 --> Helper loaded: form_helper
INFO - 2020-10-30 11:07:14 --> Helper loaded: html_helper
INFO - 2020-10-30 11:07:14 --> Helper loaded: date_helper
INFO - 2020-10-30 11:07:14 --> Database Driver Class Initialized
INFO - 2020-10-30 11:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 11:07:14 --> Table Class Initialized
INFO - 2020-10-30 11:07:14 --> Upload Class Initialized
INFO - 2020-10-30 11:07:14 --> Controller Class Initialized
INFO - 2020-10-30 11:07:14 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 11:07:14 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 11:07:14 --> Final output sent to browser
DEBUG - 2020-10-30 11:07:14 --> Total execution time: 0.1118
INFO - 2020-10-30 11:51:07 --> Config Class Initialized
INFO - 2020-10-30 11:51:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 11:51:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 11:51:07 --> Utf8 Class Initialized
INFO - 2020-10-30 11:51:07 --> URI Class Initialized
DEBUG - 2020-10-30 11:51:07 --> No URI present. Default controller set.
INFO - 2020-10-30 11:51:07 --> Router Class Initialized
INFO - 2020-10-30 11:51:07 --> Output Class Initialized
INFO - 2020-10-30 11:51:07 --> Security Class Initialized
DEBUG - 2020-10-30 11:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 11:51:07 --> Input Class Initialized
INFO - 2020-10-30 11:51:07 --> Language Class Initialized
INFO - 2020-10-30 11:51:07 --> Loader Class Initialized
INFO - 2020-10-30 11:51:07 --> Helper loaded: url_helper
INFO - 2020-10-30 11:51:07 --> Helper loaded: form_helper
INFO - 2020-10-30 11:51:07 --> Helper loaded: html_helper
INFO - 2020-10-30 11:51:07 --> Helper loaded: date_helper
INFO - 2020-10-30 11:51:07 --> Database Driver Class Initialized
INFO - 2020-10-30 11:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 11:51:07 --> Table Class Initialized
INFO - 2020-10-30 11:51:07 --> Upload Class Initialized
INFO - 2020-10-30 11:51:07 --> Controller Class Initialized
INFO - 2020-10-30 11:51:07 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 11:51:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 11:51:07 --> Final output sent to browser
DEBUG - 2020-10-30 11:51:07 --> Total execution time: 0.1943
INFO - 2020-10-30 11:51:07 --> Config Class Initialized
INFO - 2020-10-30 11:51:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 11:51:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 11:51:07 --> Utf8 Class Initialized
INFO - 2020-10-30 11:51:07 --> URI Class Initialized
DEBUG - 2020-10-30 11:51:07 --> No URI present. Default controller set.
INFO - 2020-10-30 11:51:07 --> Router Class Initialized
INFO - 2020-10-30 11:51:07 --> Output Class Initialized
INFO - 2020-10-30 11:51:07 --> Security Class Initialized
DEBUG - 2020-10-30 11:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 11:51:07 --> Input Class Initialized
INFO - 2020-10-30 11:51:07 --> Language Class Initialized
INFO - 2020-10-30 11:51:07 --> Loader Class Initialized
INFO - 2020-10-30 11:51:07 --> Helper loaded: url_helper
INFO - 2020-10-30 11:51:07 --> Helper loaded: form_helper
INFO - 2020-10-30 11:51:07 --> Helper loaded: html_helper
INFO - 2020-10-30 11:51:07 --> Helper loaded: date_helper
INFO - 2020-10-30 11:51:07 --> Database Driver Class Initialized
INFO - 2020-10-30 11:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 11:51:07 --> Table Class Initialized
INFO - 2020-10-30 11:51:07 --> Upload Class Initialized
INFO - 2020-10-30 11:51:07 --> Controller Class Initialized
INFO - 2020-10-30 11:51:07 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 11:51:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 11:51:07 --> Final output sent to browser
DEBUG - 2020-10-30 11:51:07 --> Total execution time: 0.0938
INFO - 2020-10-30 12:35:07 --> Config Class Initialized
INFO - 2020-10-30 12:35:07 --> Config Class Initialized
INFO - 2020-10-30 12:35:07 --> Hooks Class Initialized
INFO - 2020-10-30 12:35:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 12:35:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 12:35:07 --> Utf8 Class Initialized
DEBUG - 2020-10-30 12:35:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 12:35:07 --> Utf8 Class Initialized
INFO - 2020-10-30 12:35:07 --> URI Class Initialized
DEBUG - 2020-10-30 12:35:07 --> No URI present. Default controller set.
INFO - 2020-10-30 12:35:07 --> URI Class Initialized
INFO - 2020-10-30 12:35:07 --> Router Class Initialized
DEBUG - 2020-10-30 12:35:07 --> No URI present. Default controller set.
INFO - 2020-10-30 12:35:07 --> Output Class Initialized
INFO - 2020-10-30 12:35:07 --> Router Class Initialized
INFO - 2020-10-30 12:35:07 --> Output Class Initialized
INFO - 2020-10-30 12:35:07 --> Security Class Initialized
DEBUG - 2020-10-30 12:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 12:35:07 --> Security Class Initialized
DEBUG - 2020-10-30 12:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 12:35:07 --> Input Class Initialized
INFO - 2020-10-30 12:35:07 --> Input Class Initialized
INFO - 2020-10-30 12:35:07 --> Language Class Initialized
INFO - 2020-10-30 12:35:07 --> Language Class Initialized
INFO - 2020-10-30 12:35:07 --> Loader Class Initialized
INFO - 2020-10-30 12:35:07 --> Loader Class Initialized
INFO - 2020-10-30 12:35:07 --> Helper loaded: url_helper
INFO - 2020-10-30 12:35:07 --> Helper loaded: url_helper
INFO - 2020-10-30 12:35:07 --> Helper loaded: form_helper
INFO - 2020-10-30 12:35:07 --> Helper loaded: form_helper
INFO - 2020-10-30 12:35:07 --> Helper loaded: html_helper
INFO - 2020-10-30 12:35:07 --> Helper loaded: date_helper
INFO - 2020-10-30 12:35:07 --> Helper loaded: html_helper
INFO - 2020-10-30 12:35:07 --> Database Driver Class Initialized
INFO - 2020-10-30 12:35:07 --> Helper loaded: date_helper
INFO - 2020-10-30 12:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 12:35:07 --> Database Driver Class Initialized
INFO - 2020-10-30 12:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 12:35:07 --> Table Class Initialized
INFO - 2020-10-30 12:35:07 --> Table Class Initialized
INFO - 2020-10-30 12:35:07 --> Upload Class Initialized
INFO - 2020-10-30 12:35:07 --> Controller Class Initialized
INFO - 2020-10-30 12:35:07 --> Upload Class Initialized
INFO - 2020-10-30 12:35:07 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 12:35:07 --> Controller Class Initialized
INFO - 2020-10-30 12:35:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 12:35:07 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 12:35:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 12:35:07 --> Final output sent to browser
INFO - 2020-10-30 12:35:07 --> Final output sent to browser
DEBUG - 2020-10-30 12:35:07 --> Total execution time: 0.8576
DEBUG - 2020-10-30 12:35:07 --> Total execution time: 0.7879
INFO - 2020-10-30 12:35:07 --> Config Class Initialized
INFO - 2020-10-30 12:35:07 --> Hooks Class Initialized
DEBUG - 2020-10-30 12:35:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 12:35:08 --> Utf8 Class Initialized
INFO - 2020-10-30 12:35:08 --> URI Class Initialized
DEBUG - 2020-10-30 12:35:08 --> No URI present. Default controller set.
INFO - 2020-10-30 12:35:08 --> Router Class Initialized
INFO - 2020-10-30 12:35:08 --> Output Class Initialized
INFO - 2020-10-30 12:35:08 --> Security Class Initialized
DEBUG - 2020-10-30 12:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 12:35:08 --> Input Class Initialized
INFO - 2020-10-30 12:35:08 --> Language Class Initialized
INFO - 2020-10-30 12:35:08 --> Loader Class Initialized
INFO - 2020-10-30 12:35:08 --> Helper loaded: url_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: form_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: html_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: date_helper
INFO - 2020-10-30 12:35:08 --> Database Driver Class Initialized
INFO - 2020-10-30 12:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 12:35:08 --> Table Class Initialized
INFO - 2020-10-30 12:35:08 --> Upload Class Initialized
INFO - 2020-10-30 12:35:08 --> Controller Class Initialized
INFO - 2020-10-30 12:35:08 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 12:35:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 12:35:08 --> Final output sent to browser
DEBUG - 2020-10-30 12:35:08 --> Total execution time: 0.2068
INFO - 2020-10-30 12:35:08 --> Config Class Initialized
INFO - 2020-10-30 12:35:08 --> Hooks Class Initialized
DEBUG - 2020-10-30 12:35:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 12:35:08 --> Utf8 Class Initialized
INFO - 2020-10-30 12:35:08 --> URI Class Initialized
DEBUG - 2020-10-30 12:35:08 --> No URI present. Default controller set.
INFO - 2020-10-30 12:35:08 --> Router Class Initialized
INFO - 2020-10-30 12:35:08 --> Output Class Initialized
INFO - 2020-10-30 12:35:08 --> Security Class Initialized
DEBUG - 2020-10-30 12:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 12:35:08 --> Input Class Initialized
INFO - 2020-10-30 12:35:08 --> Language Class Initialized
INFO - 2020-10-30 12:35:08 --> Loader Class Initialized
INFO - 2020-10-30 12:35:08 --> Helper loaded: url_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: form_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: html_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: date_helper
INFO - 2020-10-30 12:35:08 --> Database Driver Class Initialized
INFO - 2020-10-30 12:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 12:35:08 --> Table Class Initialized
INFO - 2020-10-30 12:35:08 --> Upload Class Initialized
INFO - 2020-10-30 12:35:08 --> Controller Class Initialized
INFO - 2020-10-30 12:35:08 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 12:35:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 12:35:08 --> Final output sent to browser
DEBUG - 2020-10-30 12:35:08 --> Total execution time: 0.0389
INFO - 2020-10-30 12:35:08 --> Config Class Initialized
INFO - 2020-10-30 12:35:08 --> Hooks Class Initialized
DEBUG - 2020-10-30 12:35:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 12:35:08 --> Utf8 Class Initialized
INFO - 2020-10-30 12:35:08 --> URI Class Initialized
DEBUG - 2020-10-30 12:35:08 --> No URI present. Default controller set.
INFO - 2020-10-30 12:35:08 --> Router Class Initialized
INFO - 2020-10-30 12:35:08 --> Output Class Initialized
INFO - 2020-10-30 12:35:08 --> Security Class Initialized
DEBUG - 2020-10-30 12:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 12:35:08 --> Input Class Initialized
INFO - 2020-10-30 12:35:08 --> Language Class Initialized
INFO - 2020-10-30 12:35:08 --> Loader Class Initialized
INFO - 2020-10-30 12:35:08 --> Helper loaded: url_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: form_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: html_helper
INFO - 2020-10-30 12:35:08 --> Helper loaded: date_helper
INFO - 2020-10-30 12:35:08 --> Database Driver Class Initialized
INFO - 2020-10-30 12:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 12:35:08 --> Table Class Initialized
INFO - 2020-10-30 12:35:08 --> Upload Class Initialized
INFO - 2020-10-30 12:35:08 --> Controller Class Initialized
INFO - 2020-10-30 12:35:08 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 12:35:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 12:35:08 --> Final output sent to browser
DEBUG - 2020-10-30 12:35:08 --> Total execution time: 0.0457
INFO - 2020-10-30 12:59:45 --> Config Class Initialized
INFO - 2020-10-30 12:59:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 12:59:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 12:59:45 --> Utf8 Class Initialized
INFO - 2020-10-30 12:59:45 --> URI Class Initialized
DEBUG - 2020-10-30 12:59:45 --> No URI present. Default controller set.
INFO - 2020-10-30 12:59:45 --> Router Class Initialized
INFO - 2020-10-30 12:59:45 --> Output Class Initialized
INFO - 2020-10-30 12:59:45 --> Security Class Initialized
DEBUG - 2020-10-30 12:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 12:59:45 --> Input Class Initialized
INFO - 2020-10-30 12:59:45 --> Language Class Initialized
INFO - 2020-10-30 12:59:45 --> Loader Class Initialized
INFO - 2020-10-30 12:59:45 --> Helper loaded: url_helper
INFO - 2020-10-30 12:59:45 --> Helper loaded: form_helper
INFO - 2020-10-30 12:59:45 --> Helper loaded: html_helper
INFO - 2020-10-30 12:59:45 --> Helper loaded: date_helper
INFO - 2020-10-30 12:59:45 --> Database Driver Class Initialized
INFO - 2020-10-30 12:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 12:59:45 --> Table Class Initialized
INFO - 2020-10-30 12:59:45 --> Upload Class Initialized
INFO - 2020-10-30 12:59:45 --> Controller Class Initialized
INFO - 2020-10-30 12:59:45 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 12:59:45 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 12:59:45 --> Final output sent to browser
DEBUG - 2020-10-30 12:59:45 --> Total execution time: 0.0408
INFO - 2020-10-30 12:59:45 --> Config Class Initialized
INFO - 2020-10-30 12:59:45 --> Hooks Class Initialized
DEBUG - 2020-10-30 12:59:45 --> UTF-8 Support Enabled
INFO - 2020-10-30 12:59:45 --> Utf8 Class Initialized
INFO - 2020-10-30 12:59:45 --> URI Class Initialized
DEBUG - 2020-10-30 12:59:45 --> No URI present. Default controller set.
INFO - 2020-10-30 12:59:45 --> Router Class Initialized
INFO - 2020-10-30 12:59:45 --> Output Class Initialized
INFO - 2020-10-30 12:59:45 --> Security Class Initialized
DEBUG - 2020-10-30 12:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 12:59:45 --> Input Class Initialized
INFO - 2020-10-30 12:59:45 --> Language Class Initialized
INFO - 2020-10-30 12:59:45 --> Loader Class Initialized
INFO - 2020-10-30 12:59:45 --> Helper loaded: url_helper
INFO - 2020-10-30 12:59:45 --> Helper loaded: form_helper
INFO - 2020-10-30 12:59:45 --> Helper loaded: html_helper
INFO - 2020-10-30 12:59:45 --> Helper loaded: date_helper
INFO - 2020-10-30 12:59:45 --> Database Driver Class Initialized
INFO - 2020-10-30 12:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 12:59:45 --> Table Class Initialized
INFO - 2020-10-30 12:59:45 --> Upload Class Initialized
INFO - 2020-10-30 12:59:45 --> Controller Class Initialized
INFO - 2020-10-30 12:59:45 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 12:59:45 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 12:59:45 --> Final output sent to browser
DEBUG - 2020-10-30 12:59:45 --> Total execution time: 0.0416
INFO - 2020-10-30 13:06:44 --> Config Class Initialized
INFO - 2020-10-30 13:06:44 --> Hooks Class Initialized
INFO - 2020-10-30 13:06:44 --> Config Class Initialized
DEBUG - 2020-10-30 13:06:44 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:06:44 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:06:44 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:06:44 --> Utf8 Class Initialized
INFO - 2020-10-30 13:06:44 --> Utf8 Class Initialized
INFO - 2020-10-30 13:06:44 --> URI Class Initialized
INFO - 2020-10-30 13:06:44 --> URI Class Initialized
DEBUG - 2020-10-30 13:06:44 --> No URI present. Default controller set.
INFO - 2020-10-30 13:06:44 --> Router Class Initialized
DEBUG - 2020-10-30 13:06:44 --> No URI present. Default controller set.
INFO - 2020-10-30 13:06:44 --> Router Class Initialized
INFO - 2020-10-30 13:06:44 --> Output Class Initialized
INFO - 2020-10-30 13:06:44 --> Output Class Initialized
INFO - 2020-10-30 13:06:44 --> Security Class Initialized
DEBUG - 2020-10-30 13:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:06:44 --> Security Class Initialized
DEBUG - 2020-10-30 13:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:06:44 --> Input Class Initialized
INFO - 2020-10-30 13:06:44 --> Language Class Initialized
INFO - 2020-10-30 13:06:44 --> Input Class Initialized
INFO - 2020-10-30 13:06:44 --> Language Class Initialized
INFO - 2020-10-30 13:06:44 --> Loader Class Initialized
INFO - 2020-10-30 13:06:44 --> Helper loaded: url_helper
INFO - 2020-10-30 13:06:44 --> Loader Class Initialized
INFO - 2020-10-30 13:06:44 --> Helper loaded: form_helper
INFO - 2020-10-30 13:06:44 --> Helper loaded: url_helper
INFO - 2020-10-30 13:06:44 --> Helper loaded: html_helper
INFO - 2020-10-30 13:06:44 --> Helper loaded: form_helper
INFO - 2020-10-30 13:06:44 --> Helper loaded: html_helper
INFO - 2020-10-30 13:06:44 --> Helper loaded: date_helper
INFO - 2020-10-30 13:06:44 --> Helper loaded: date_helper
INFO - 2020-10-30 13:06:44 --> Database Driver Class Initialized
INFO - 2020-10-30 13:06:45 --> Database Driver Class Initialized
INFO - 2020-10-30 13:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:06:45 --> Table Class Initialized
INFO - 2020-10-30 13:06:45 --> Table Class Initialized
INFO - 2020-10-30 13:06:45 --> Upload Class Initialized
INFO - 2020-10-30 13:06:45 --> Upload Class Initialized
INFO - 2020-10-30 13:06:45 --> Controller Class Initialized
INFO - 2020-10-30 13:06:45 --> Controller Class Initialized
INFO - 2020-10-30 13:06:45 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:06:45 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:06:45 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:06:45 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:06:45 --> Final output sent to browser
INFO - 2020-10-30 13:06:45 --> Final output sent to browser
DEBUG - 2020-10-30 13:06:45 --> Total execution time: 23.6380
DEBUG - 2020-10-30 13:06:45 --> Total execution time: 21.5964
INFO - 2020-10-30 13:11:04 --> Config Class Initialized
INFO - 2020-10-30 13:11:04 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:11:04 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:11:04 --> Utf8 Class Initialized
INFO - 2020-10-30 13:11:04 --> URI Class Initialized
DEBUG - 2020-10-30 13:11:04 --> No URI present. Default controller set.
INFO - 2020-10-30 13:11:04 --> Router Class Initialized
INFO - 2020-10-30 13:11:04 --> Output Class Initialized
INFO - 2020-10-30 13:11:04 --> Security Class Initialized
DEBUG - 2020-10-30 13:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:11:04 --> Input Class Initialized
INFO - 2020-10-30 13:11:04 --> Language Class Initialized
INFO - 2020-10-30 13:11:04 --> Loader Class Initialized
INFO - 2020-10-30 13:11:04 --> Helper loaded: url_helper
INFO - 2020-10-30 13:11:04 --> Helper loaded: form_helper
INFO - 2020-10-30 13:11:04 --> Helper loaded: html_helper
INFO - 2020-10-30 13:11:04 --> Helper loaded: date_helper
INFO - 2020-10-30 13:11:04 --> Database Driver Class Initialized
INFO - 2020-10-30 13:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:11:04 --> Table Class Initialized
INFO - 2020-10-30 13:11:04 --> Upload Class Initialized
INFO - 2020-10-30 13:11:04 --> Controller Class Initialized
INFO - 2020-10-30 13:11:04 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:11:04 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:11:04 --> Final output sent to browser
DEBUG - 2020-10-30 13:11:04 --> Total execution time: 0.1339
INFO - 2020-10-30 13:35:25 --> Config Class Initialized
INFO - 2020-10-30 13:35:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:35:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:35:25 --> Utf8 Class Initialized
INFO - 2020-10-30 13:35:25 --> URI Class Initialized
DEBUG - 2020-10-30 13:35:25 --> No URI present. Default controller set.
INFO - 2020-10-30 13:35:25 --> Router Class Initialized
INFO - 2020-10-30 13:35:25 --> Output Class Initialized
INFO - 2020-10-30 13:35:25 --> Security Class Initialized
DEBUG - 2020-10-30 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:35:25 --> Input Class Initialized
INFO - 2020-10-30 13:35:25 --> Language Class Initialized
INFO - 2020-10-30 13:35:25 --> Loader Class Initialized
INFO - 2020-10-30 13:35:25 --> Helper loaded: url_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: form_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: html_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: date_helper
INFO - 2020-10-30 13:35:25 --> Database Driver Class Initialized
INFO - 2020-10-30 13:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:35:25 --> Table Class Initialized
INFO - 2020-10-30 13:35:25 --> Upload Class Initialized
INFO - 2020-10-30 13:35:25 --> Controller Class Initialized
INFO - 2020-10-30 13:35:25 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:35:25 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:35:25 --> Final output sent to browser
DEBUG - 2020-10-30 13:35:25 --> Total execution time: 0.0528
INFO - 2020-10-30 13:35:25 --> Config Class Initialized
INFO - 2020-10-30 13:35:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:35:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:35:25 --> Utf8 Class Initialized
INFO - 2020-10-30 13:35:25 --> URI Class Initialized
DEBUG - 2020-10-30 13:35:25 --> No URI present. Default controller set.
INFO - 2020-10-30 13:35:25 --> Router Class Initialized
INFO - 2020-10-30 13:35:25 --> Output Class Initialized
INFO - 2020-10-30 13:35:25 --> Security Class Initialized
DEBUG - 2020-10-30 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:35:25 --> Input Class Initialized
INFO - 2020-10-30 13:35:25 --> Language Class Initialized
INFO - 2020-10-30 13:35:25 --> Loader Class Initialized
INFO - 2020-10-30 13:35:25 --> Helper loaded: url_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: form_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: html_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: date_helper
INFO - 2020-10-30 13:35:25 --> Database Driver Class Initialized
INFO - 2020-10-30 13:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:35:25 --> Table Class Initialized
INFO - 2020-10-30 13:35:25 --> Upload Class Initialized
INFO - 2020-10-30 13:35:25 --> Controller Class Initialized
INFO - 2020-10-30 13:35:25 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:35:25 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:35:25 --> Final output sent to browser
DEBUG - 2020-10-30 13:35:25 --> Total execution time: 0.0544
INFO - 2020-10-30 13:35:25 --> Config Class Initialized
INFO - 2020-10-30 13:35:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:35:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:35:25 --> Utf8 Class Initialized
INFO - 2020-10-30 13:35:25 --> URI Class Initialized
DEBUG - 2020-10-30 13:35:25 --> No URI present. Default controller set.
INFO - 2020-10-30 13:35:25 --> Router Class Initialized
INFO - 2020-10-30 13:35:25 --> Output Class Initialized
INFO - 2020-10-30 13:35:25 --> Security Class Initialized
DEBUG - 2020-10-30 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:35:25 --> Input Class Initialized
INFO - 2020-10-30 13:35:25 --> Language Class Initialized
INFO - 2020-10-30 13:35:25 --> Loader Class Initialized
INFO - 2020-10-30 13:35:25 --> Helper loaded: url_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: form_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: html_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: date_helper
INFO - 2020-10-30 13:35:25 --> Database Driver Class Initialized
INFO - 2020-10-30 13:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:35:25 --> Table Class Initialized
INFO - 2020-10-30 13:35:25 --> Upload Class Initialized
INFO - 2020-10-30 13:35:25 --> Controller Class Initialized
INFO - 2020-10-30 13:35:25 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:35:25 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:35:25 --> Final output sent to browser
DEBUG - 2020-10-30 13:35:25 --> Total execution time: 0.0519
INFO - 2020-10-30 13:35:25 --> Config Class Initialized
INFO - 2020-10-30 13:35:25 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:35:25 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:35:25 --> Utf8 Class Initialized
INFO - 2020-10-30 13:35:25 --> URI Class Initialized
DEBUG - 2020-10-30 13:35:25 --> No URI present. Default controller set.
INFO - 2020-10-30 13:35:25 --> Router Class Initialized
INFO - 2020-10-30 13:35:25 --> Output Class Initialized
INFO - 2020-10-30 13:35:25 --> Security Class Initialized
DEBUG - 2020-10-30 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:35:25 --> Input Class Initialized
INFO - 2020-10-30 13:35:25 --> Language Class Initialized
INFO - 2020-10-30 13:35:25 --> Loader Class Initialized
INFO - 2020-10-30 13:35:25 --> Helper loaded: url_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: form_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: html_helper
INFO - 2020-10-30 13:35:25 --> Helper loaded: date_helper
INFO - 2020-10-30 13:35:25 --> Database Driver Class Initialized
INFO - 2020-10-30 13:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:35:25 --> Table Class Initialized
INFO - 2020-10-30 13:35:25 --> Upload Class Initialized
INFO - 2020-10-30 13:35:25 --> Controller Class Initialized
INFO - 2020-10-30 13:35:25 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:35:25 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:35:25 --> Final output sent to browser
DEBUG - 2020-10-30 13:35:25 --> Total execution time: 0.0474
INFO - 2020-10-30 13:35:26 --> Config Class Initialized
INFO - 2020-10-30 13:35:26 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:35:26 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:35:26 --> Utf8 Class Initialized
INFO - 2020-10-30 13:35:26 --> URI Class Initialized
DEBUG - 2020-10-30 13:35:26 --> No URI present. Default controller set.
INFO - 2020-10-30 13:35:26 --> Router Class Initialized
INFO - 2020-10-30 13:35:26 --> Output Class Initialized
INFO - 2020-10-30 13:35:26 --> Security Class Initialized
DEBUG - 2020-10-30 13:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:35:26 --> Input Class Initialized
INFO - 2020-10-30 13:35:26 --> Language Class Initialized
INFO - 2020-10-30 13:35:26 --> Loader Class Initialized
INFO - 2020-10-30 13:35:26 --> Helper loaded: url_helper
INFO - 2020-10-30 13:35:26 --> Helper loaded: form_helper
INFO - 2020-10-30 13:35:26 --> Helper loaded: html_helper
INFO - 2020-10-30 13:35:26 --> Helper loaded: date_helper
INFO - 2020-10-30 13:35:26 --> Database Driver Class Initialized
INFO - 2020-10-30 13:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:35:26 --> Table Class Initialized
INFO - 2020-10-30 13:35:26 --> Upload Class Initialized
INFO - 2020-10-30 13:35:26 --> Controller Class Initialized
INFO - 2020-10-30 13:35:26 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:35:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:35:26 --> Final output sent to browser
DEBUG - 2020-10-30 13:35:26 --> Total execution time: 0.0479
INFO - 2020-10-30 13:35:26 --> Config Class Initialized
INFO - 2020-10-30 13:35:26 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:35:26 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:35:26 --> Utf8 Class Initialized
INFO - 2020-10-30 13:35:26 --> URI Class Initialized
DEBUG - 2020-10-30 13:35:26 --> No URI present. Default controller set.
INFO - 2020-10-30 13:35:26 --> Router Class Initialized
INFO - 2020-10-30 13:35:26 --> Output Class Initialized
INFO - 2020-10-30 13:35:26 --> Security Class Initialized
DEBUG - 2020-10-30 13:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:35:26 --> Input Class Initialized
INFO - 2020-10-30 13:35:26 --> Language Class Initialized
INFO - 2020-10-30 13:35:26 --> Loader Class Initialized
INFO - 2020-10-30 13:35:26 --> Helper loaded: url_helper
INFO - 2020-10-30 13:35:26 --> Helper loaded: form_helper
INFO - 2020-10-30 13:35:26 --> Helper loaded: html_helper
INFO - 2020-10-30 13:35:26 --> Helper loaded: date_helper
INFO - 2020-10-30 13:35:26 --> Database Driver Class Initialized
INFO - 2020-10-30 13:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:35:26 --> Table Class Initialized
INFO - 2020-10-30 13:35:26 --> Upload Class Initialized
INFO - 2020-10-30 13:35:26 --> Controller Class Initialized
INFO - 2020-10-30 13:35:26 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:35:26 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:35:26 --> Final output sent to browser
DEBUG - 2020-10-30 13:35:26 --> Total execution time: 0.0726
INFO - 2020-10-30 13:51:09 --> Config Class Initialized
INFO - 2020-10-30 13:51:09 --> Hooks Class Initialized
DEBUG - 2020-10-30 13:51:09 --> UTF-8 Support Enabled
INFO - 2020-10-30 13:51:09 --> Utf8 Class Initialized
INFO - 2020-10-30 13:51:09 --> URI Class Initialized
DEBUG - 2020-10-30 13:51:09 --> No URI present. Default controller set.
INFO - 2020-10-30 13:51:09 --> Router Class Initialized
INFO - 2020-10-30 13:51:09 --> Output Class Initialized
INFO - 2020-10-30 13:51:09 --> Security Class Initialized
DEBUG - 2020-10-30 13:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 13:51:09 --> Input Class Initialized
INFO - 2020-10-30 13:51:09 --> Language Class Initialized
INFO - 2020-10-30 13:51:09 --> Loader Class Initialized
INFO - 2020-10-30 13:51:09 --> Helper loaded: url_helper
INFO - 2020-10-30 13:51:09 --> Helper loaded: form_helper
INFO - 2020-10-30 13:51:09 --> Helper loaded: html_helper
INFO - 2020-10-30 13:51:09 --> Helper loaded: date_helper
INFO - 2020-10-30 13:51:09 --> Database Driver Class Initialized
INFO - 2020-10-30 13:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 13:51:09 --> Table Class Initialized
INFO - 2020-10-30 13:51:09 --> Upload Class Initialized
INFO - 2020-10-30 13:51:09 --> Controller Class Initialized
INFO - 2020-10-30 13:51:09 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 13:51:09 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 13:51:09 --> Final output sent to browser
DEBUG - 2020-10-30 13:51:09 --> Total execution time: 0.1525
INFO - 2020-10-30 15:23:18 --> Config Class Initialized
INFO - 2020-10-30 15:23:18 --> Hooks Class Initialized
DEBUG - 2020-10-30 15:23:18 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:23:18 --> Utf8 Class Initialized
INFO - 2020-10-30 15:23:18 --> URI Class Initialized
DEBUG - 2020-10-30 15:23:18 --> No URI present. Default controller set.
INFO - 2020-10-30 15:23:18 --> Router Class Initialized
INFO - 2020-10-30 15:23:18 --> Output Class Initialized
INFO - 2020-10-30 15:23:22 --> Security Class Initialized
INFO - 2020-10-30 15:23:22 --> Config Class Initialized
INFO - 2020-10-30 15:23:22 --> Config Class Initialized
DEBUG - 2020-10-30 15:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 15:23:22 --> Config Class Initialized
INFO - 2020-10-30 15:23:22 --> Hooks Class Initialized
INFO - 2020-10-30 15:23:22 --> Hooks Class Initialized
INFO - 2020-10-30 15:23:22 --> Hooks Class Initialized
DEBUG - 2020-10-30 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-30 15:23:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:23:23 --> Input Class Initialized
DEBUG - 2020-10-30 15:23:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:23:23 --> Utf8 Class Initialized
INFO - 2020-10-30 15:23:23 --> Utf8 Class Initialized
INFO - 2020-10-30 15:23:23 --> URI Class Initialized
INFO - 2020-10-30 15:23:23 --> Language Class Initialized
INFO - 2020-10-30 15:23:23 --> Utf8 Class Initialized
INFO - 2020-10-30 15:23:23 --> URI Class Initialized
DEBUG - 2020-10-30 15:23:23 --> No URI present. Default controller set.
INFO - 2020-10-30 15:23:23 --> URI Class Initialized
INFO - 2020-10-30 15:23:23 --> Loader Class Initialized
DEBUG - 2020-10-30 15:23:23 --> No URI present. Default controller set.
DEBUG - 2020-10-30 15:23:23 --> No URI present. Default controller set.
INFO - 2020-10-30 15:23:23 --> Helper loaded: url_helper
INFO - 2020-10-30 15:23:23 --> Router Class Initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: form_helper
INFO - 2020-10-30 15:23:23 --> Router Class Initialized
INFO - 2020-10-30 15:23:23 --> Output Class Initialized
INFO - 2020-10-30 15:23:23 --> Router Class Initialized
INFO - 2020-10-30 15:23:23 --> Output Class Initialized
INFO - 2020-10-30 15:23:23 --> Security Class Initialized
INFO - 2020-10-30 15:23:23 --> Output Class Initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: html_helper
INFO - 2020-10-30 15:23:23 --> Security Class Initialized
INFO - 2020-10-30 15:23:23 --> Security Class Initialized
DEBUG - 2020-10-30 15:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-30 15:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-30 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 15:23:23 --> Helper loaded: date_helper
INFO - 2020-10-30 15:23:23 --> Input Class Initialized
INFO - 2020-10-30 15:23:23 --> Input Class Initialized
INFO - 2020-10-30 15:23:23 --> Input Class Initialized
INFO - 2020-10-30 15:23:23 --> Language Class Initialized
INFO - 2020-10-30 15:23:23 --> Language Class Initialized
INFO - 2020-10-30 15:23:23 --> Database Driver Class Initialized
INFO - 2020-10-30 15:23:23 --> Language Class Initialized
INFO - 2020-10-30 15:23:23 --> Loader Class Initialized
INFO - 2020-10-30 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:23:23 --> Loader Class Initialized
INFO - 2020-10-30 15:23:23 --> Loader Class Initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: url_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: url_helper
INFO - 2020-10-30 15:23:23 --> Table Class Initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: url_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: form_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: form_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: form_helper
INFO - 2020-10-30 15:23:23 --> Upload Class Initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: html_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: html_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: html_helper
INFO - 2020-10-30 15:23:23 --> Controller Class Initialized
INFO - 2020-10-30 15:23:23 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: date_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: date_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: date_helper
INFO - 2020-10-30 15:23:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:23:23 --> Database Driver Class Initialized
INFO - 2020-10-30 15:23:23 --> Database Driver Class Initialized
INFO - 2020-10-30 15:23:23 --> Final output sent to browser
INFO - 2020-10-30 15:23:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-30 15:23:23 --> Total execution time: 4.9120
INFO - 2020-10-30 15:23:23 --> Database Driver Class Initialized
INFO - 2020-10-30 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:23:23 --> Table Class Initialized
INFO - 2020-10-30 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:23:23 --> Table Class Initialized
INFO - 2020-10-30 15:23:23 --> Table Class Initialized
INFO - 2020-10-30 15:23:23 --> Upload Class Initialized
INFO - 2020-10-30 15:23:23 --> Upload Class Initialized
INFO - 2020-10-30 15:23:23 --> Upload Class Initialized
INFO - 2020-10-30 15:23:23 --> Controller Class Initialized
INFO - 2020-10-30 15:23:23 --> Controller Class Initialized
INFO - 2020-10-30 15:23:23 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:23:23 --> Controller Class Initialized
INFO - 2020-10-30 15:23:23 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:23:23 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:23:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:23:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:23:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:23:23 --> Final output sent to browser
INFO - 2020-10-30 15:23:23 --> Final output sent to browser
INFO - 2020-10-30 15:23:23 --> Final output sent to browser
DEBUG - 2020-10-30 15:23:23 --> Total execution time: 3.0544
DEBUG - 2020-10-30 15:23:23 --> Total execution time: 0.8599
DEBUG - 2020-10-30 15:23:23 --> Total execution time: 2.8716
INFO - 2020-10-30 15:23:23 --> Config Class Initialized
INFO - 2020-10-30 15:23:23 --> Hooks Class Initialized
DEBUG - 2020-10-30 15:23:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:23:23 --> Utf8 Class Initialized
INFO - 2020-10-30 15:23:23 --> URI Class Initialized
DEBUG - 2020-10-30 15:23:23 --> No URI present. Default controller set.
INFO - 2020-10-30 15:23:23 --> Router Class Initialized
INFO - 2020-10-30 15:23:23 --> Output Class Initialized
INFO - 2020-10-30 15:23:23 --> Security Class Initialized
DEBUG - 2020-10-30 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 15:23:23 --> Input Class Initialized
INFO - 2020-10-30 15:23:23 --> Language Class Initialized
INFO - 2020-10-30 15:23:23 --> Loader Class Initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: url_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: form_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: html_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: date_helper
INFO - 2020-10-30 15:23:23 --> Database Driver Class Initialized
INFO - 2020-10-30 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:23:23 --> Table Class Initialized
INFO - 2020-10-30 15:23:23 --> Upload Class Initialized
INFO - 2020-10-30 15:23:23 --> Controller Class Initialized
INFO - 2020-10-30 15:23:23 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:23:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:23:23 --> Final output sent to browser
DEBUG - 2020-10-30 15:23:23 --> Total execution time: 0.2657
INFO - 2020-10-30 15:23:23 --> Config Class Initialized
INFO - 2020-10-30 15:23:23 --> Hooks Class Initialized
DEBUG - 2020-10-30 15:23:23 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:23:23 --> Utf8 Class Initialized
INFO - 2020-10-30 15:23:23 --> URI Class Initialized
DEBUG - 2020-10-30 15:23:23 --> No URI present. Default controller set.
INFO - 2020-10-30 15:23:23 --> Router Class Initialized
INFO - 2020-10-30 15:23:23 --> Output Class Initialized
INFO - 2020-10-30 15:23:23 --> Security Class Initialized
DEBUG - 2020-10-30 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 15:23:23 --> Input Class Initialized
INFO - 2020-10-30 15:23:23 --> Language Class Initialized
INFO - 2020-10-30 15:23:23 --> Loader Class Initialized
INFO - 2020-10-30 15:23:23 --> Helper loaded: url_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: form_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: html_helper
INFO - 2020-10-30 15:23:23 --> Helper loaded: date_helper
INFO - 2020-10-30 15:23:23 --> Database Driver Class Initialized
INFO - 2020-10-30 15:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:23:23 --> Table Class Initialized
INFO - 2020-10-30 15:23:23 --> Upload Class Initialized
INFO - 2020-10-30 15:23:23 --> Controller Class Initialized
INFO - 2020-10-30 15:23:23 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:23:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:23:23 --> Final output sent to browser
DEBUG - 2020-10-30 15:23:23 --> Total execution time: 0.3111
INFO - 2020-10-30 15:51:39 --> Config Class Initialized
INFO - 2020-10-30 15:51:39 --> Hooks Class Initialized
DEBUG - 2020-10-30 15:51:39 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:51:39 --> Utf8 Class Initialized
INFO - 2020-10-30 15:51:39 --> URI Class Initialized
DEBUG - 2020-10-30 15:51:39 --> No URI present. Default controller set.
INFO - 2020-10-30 15:51:39 --> Router Class Initialized
INFO - 2020-10-30 15:51:39 --> Output Class Initialized
INFO - 2020-10-30 15:51:39 --> Security Class Initialized
DEBUG - 2020-10-30 15:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 15:51:39 --> Input Class Initialized
INFO - 2020-10-30 15:51:39 --> Language Class Initialized
INFO - 2020-10-30 15:51:39 --> Loader Class Initialized
INFO - 2020-10-30 15:51:39 --> Helper loaded: url_helper
INFO - 2020-10-30 15:51:39 --> Helper loaded: form_helper
INFO - 2020-10-30 15:51:39 --> Helper loaded: html_helper
INFO - 2020-10-30 15:51:39 --> Helper loaded: date_helper
INFO - 2020-10-30 15:51:39 --> Database Driver Class Initialized
INFO - 2020-10-30 15:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:51:39 --> Table Class Initialized
INFO - 2020-10-30 15:51:39 --> Upload Class Initialized
INFO - 2020-10-30 15:51:39 --> Controller Class Initialized
INFO - 2020-10-30 15:51:39 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:51:39 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:51:39 --> Final output sent to browser
DEBUG - 2020-10-30 15:51:39 --> Total execution time: 0.2167
INFO - 2020-10-30 15:51:39 --> Config Class Initialized
INFO - 2020-10-30 15:51:39 --> Hooks Class Initialized
DEBUG - 2020-10-30 15:51:39 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:51:39 --> Utf8 Class Initialized
INFO - 2020-10-30 15:51:39 --> URI Class Initialized
DEBUG - 2020-10-30 15:51:39 --> No URI present. Default controller set.
INFO - 2020-10-30 15:51:39 --> Router Class Initialized
INFO - 2020-10-30 15:51:39 --> Output Class Initialized
INFO - 2020-10-30 15:51:39 --> Security Class Initialized
DEBUG - 2020-10-30 15:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 15:51:39 --> Input Class Initialized
INFO - 2020-10-30 15:51:40 --> Language Class Initialized
INFO - 2020-10-30 15:51:40 --> Loader Class Initialized
INFO - 2020-10-30 15:51:40 --> Helper loaded: url_helper
INFO - 2020-10-30 15:51:40 --> Helper loaded: form_helper
INFO - 2020-10-30 15:51:40 --> Helper loaded: html_helper
INFO - 2020-10-30 15:51:40 --> Helper loaded: date_helper
INFO - 2020-10-30 15:51:40 --> Database Driver Class Initialized
INFO - 2020-10-30 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:51:40 --> Table Class Initialized
INFO - 2020-10-30 15:51:40 --> Upload Class Initialized
INFO - 2020-10-30 15:51:40 --> Controller Class Initialized
INFO - 2020-10-30 15:51:40 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:51:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:51:40 --> Final output sent to browser
DEBUG - 2020-10-30 15:51:40 --> Total execution time: 0.1433
INFO - 2020-10-30 15:51:40 --> Config Class Initialized
INFO - 2020-10-30 15:51:40 --> Hooks Class Initialized
DEBUG - 2020-10-30 15:51:40 --> UTF-8 Support Enabled
INFO - 2020-10-30 15:51:40 --> Utf8 Class Initialized
INFO - 2020-10-30 15:51:40 --> URI Class Initialized
DEBUG - 2020-10-30 15:51:40 --> No URI present. Default controller set.
INFO - 2020-10-30 15:51:40 --> Router Class Initialized
INFO - 2020-10-30 15:51:40 --> Output Class Initialized
INFO - 2020-10-30 15:51:40 --> Security Class Initialized
DEBUG - 2020-10-30 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 15:51:40 --> Input Class Initialized
INFO - 2020-10-30 15:51:40 --> Language Class Initialized
INFO - 2020-10-30 15:51:40 --> Loader Class Initialized
INFO - 2020-10-30 15:51:40 --> Helper loaded: url_helper
INFO - 2020-10-30 15:51:40 --> Helper loaded: form_helper
INFO - 2020-10-30 15:51:40 --> Helper loaded: html_helper
INFO - 2020-10-30 15:51:40 --> Helper loaded: date_helper
INFO - 2020-10-30 15:51:40 --> Database Driver Class Initialized
INFO - 2020-10-30 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 15:51:40 --> Table Class Initialized
INFO - 2020-10-30 15:51:40 --> Upload Class Initialized
INFO - 2020-10-30 15:51:40 --> Controller Class Initialized
INFO - 2020-10-30 15:51:40 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 15:51:40 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 15:51:40 --> Final output sent to browser
DEBUG - 2020-10-30 15:51:40 --> Total execution time: 0.1318
INFO - 2020-10-30 16:35:05 --> Config Class Initialized
INFO - 2020-10-30 16:35:05 --> Hooks Class Initialized
DEBUG - 2020-10-30 16:35:05 --> UTF-8 Support Enabled
INFO - 2020-10-30 16:35:05 --> Utf8 Class Initialized
INFO - 2020-10-30 16:35:05 --> URI Class Initialized
DEBUG - 2020-10-30 16:35:05 --> No URI present. Default controller set.
INFO - 2020-10-30 16:35:05 --> Router Class Initialized
INFO - 2020-10-30 16:35:05 --> Output Class Initialized
INFO - 2020-10-30 16:35:05 --> Config Class Initialized
INFO - 2020-10-30 16:35:05 --> Hooks Class Initialized
INFO - 2020-10-30 16:35:05 --> Security Class Initialized
DEBUG - 2020-10-30 16:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-30 16:35:05 --> UTF-8 Support Enabled
INFO - 2020-10-30 16:35:05 --> Input Class Initialized
INFO - 2020-10-30 16:35:05 --> Language Class Initialized
INFO - 2020-10-30 16:35:05 --> Utf8 Class Initialized
INFO - 2020-10-30 16:35:06 --> URI Class Initialized
DEBUG - 2020-10-30 16:35:06 --> No URI present. Default controller set.
INFO - 2020-10-30 16:35:06 --> Loader Class Initialized
INFO - 2020-10-30 16:35:06 --> Router Class Initialized
INFO - 2020-10-30 16:35:06 --> Helper loaded: url_helper
INFO - 2020-10-30 16:35:06 --> Helper loaded: form_helper
INFO - 2020-10-30 16:35:06 --> Output Class Initialized
INFO - 2020-10-30 16:35:06 --> Helper loaded: html_helper
INFO - 2020-10-30 16:35:06 --> Security Class Initialized
DEBUG - 2020-10-30 16:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 16:35:06 --> Helper loaded: date_helper
INFO - 2020-10-30 16:35:06 --> Input Class Initialized
INFO - 2020-10-30 16:35:06 --> Language Class Initialized
INFO - 2020-10-30 16:35:06 --> Loader Class Initialized
INFO - 2020-10-30 16:35:06 --> Database Driver Class Initialized
INFO - 2020-10-30 16:35:06 --> Helper loaded: url_helper
INFO - 2020-10-30 16:35:06 --> Helper loaded: form_helper
INFO - 2020-10-30 16:35:06 --> Helper loaded: html_helper
INFO - 2020-10-30 16:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 16:35:06 --> Helper loaded: date_helper
INFO - 2020-10-30 16:35:06 --> Table Class Initialized
INFO - 2020-10-30 16:35:06 --> Upload Class Initialized
INFO - 2020-10-30 16:35:06 --> Controller Class Initialized
INFO - 2020-10-30 16:35:06 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 16:35:06 --> Database Driver Class Initialized
INFO - 2020-10-30 16:35:06 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 16:35:06 --> Final output sent to browser
INFO - 2020-10-30 16:35:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-30 16:35:06 --> Total execution time: 0.6097
INFO - 2020-10-30 16:35:06 --> Table Class Initialized
INFO - 2020-10-30 16:35:06 --> Upload Class Initialized
INFO - 2020-10-30 16:35:06 --> Config Class Initialized
INFO - 2020-10-30 16:35:06 --> Controller Class Initialized
INFO - 2020-10-30 16:35:06 --> Hooks Class Initialized
INFO - 2020-10-30 16:35:06 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 16:35:06 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
DEBUG - 2020-10-30 16:35:06 --> UTF-8 Support Enabled
INFO - 2020-10-30 16:35:06 --> Utf8 Class Initialized
INFO - 2020-10-30 16:35:06 --> Final output sent to browser
DEBUG - 2020-10-30 16:35:07 --> Total execution time: 0.9745
INFO - 2020-10-30 16:35:07 --> URI Class Initialized
DEBUG - 2020-10-30 16:35:07 --> No URI present. Default controller set.
INFO - 2020-10-30 16:35:07 --> Config Class Initialized
INFO - 2020-10-30 16:35:07 --> Hooks Class Initialized
INFO - 2020-10-30 16:35:07 --> Router Class Initialized
DEBUG - 2020-10-30 16:35:07 --> UTF-8 Support Enabled
INFO - 2020-10-30 16:35:07 --> Output Class Initialized
INFO - 2020-10-30 16:35:08 --> Security Class Initialized
INFO - 2020-10-30 16:35:08 --> Utf8 Class Initialized
DEBUG - 2020-10-30 16:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 16:35:08 --> URI Class Initialized
INFO - 2020-10-30 16:35:08 --> Input Class Initialized
DEBUG - 2020-10-30 16:35:08 --> No URI present. Default controller set.
INFO - 2020-10-30 16:35:08 --> Router Class Initialized
INFO - 2020-10-30 16:35:08 --> Language Class Initialized
INFO - 2020-10-30 16:35:08 --> Output Class Initialized
INFO - 2020-10-30 16:35:08 --> Loader Class Initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: url_helper
INFO - 2020-10-30 16:35:08 --> Security Class Initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: form_helper
DEBUG - 2020-10-30 16:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 16:35:08 --> Helper loaded: html_helper
INFO - 2020-10-30 16:35:08 --> Input Class Initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: date_helper
INFO - 2020-10-30 16:35:08 --> Language Class Initialized
INFO - 2020-10-30 16:35:08 --> Config Class Initialized
INFO - 2020-10-30 16:35:08 --> Loader Class Initialized
INFO - 2020-10-30 16:35:08 --> Database Driver Class Initialized
INFO - 2020-10-30 16:35:08 --> Hooks Class Initialized
INFO - 2020-10-30 16:35:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-10-30 16:35:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 16:35:08 --> Helper loaded: url_helper
INFO - 2020-10-30 16:35:08 --> Table Class Initialized
INFO - 2020-10-30 16:35:08 --> Utf8 Class Initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: form_helper
INFO - 2020-10-30 16:35:08 --> Helper loaded: html_helper
INFO - 2020-10-30 16:35:08 --> Upload Class Initialized
INFO - 2020-10-30 16:35:08 --> URI Class Initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: date_helper
INFO - 2020-10-30 16:35:08 --> Controller Class Initialized
DEBUG - 2020-10-30 16:35:08 --> No URI present. Default controller set.
INFO - 2020-10-30 16:35:08 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 16:35:08 --> Router Class Initialized
INFO - 2020-10-30 16:35:08 --> Output Class Initialized
INFO - 2020-10-30 16:35:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 16:35:08 --> Database Driver Class Initialized
INFO - 2020-10-30 16:35:08 --> Final output sent to browser
INFO - 2020-10-30 16:35:08 --> Security Class Initialized
DEBUG - 2020-10-30 16:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-30 16:35:08 --> Total execution time: 2.2968
INFO - 2020-10-30 16:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 16:35:08 --> Table Class Initialized
INFO - 2020-10-30 16:35:08 --> Input Class Initialized
INFO - 2020-10-30 16:35:08 --> Language Class Initialized
INFO - 2020-10-30 16:35:08 --> Upload Class Initialized
INFO - 2020-10-30 16:35:08 --> Controller Class Initialized
INFO - 2020-10-30 16:35:08 --> Loader Class Initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: url_helper
INFO - 2020-10-30 16:35:08 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: form_helper
INFO - 2020-10-30 16:35:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 16:35:08 --> Helper loaded: html_helper
INFO - 2020-10-30 16:35:08 --> Final output sent to browser
DEBUG - 2020-10-30 16:35:08 --> Total execution time: 1.7491
INFO - 2020-10-30 16:35:08 --> Helper loaded: date_helper
INFO - 2020-10-30 16:35:08 --> Database Driver Class Initialized
INFO - 2020-10-30 16:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 16:35:08 --> Table Class Initialized
INFO - 2020-10-30 16:35:08 --> Upload Class Initialized
INFO - 2020-10-30 16:35:08 --> Controller Class Initialized
INFO - 2020-10-30 16:35:08 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 16:35:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 16:35:08 --> Final output sent to browser
DEBUG - 2020-10-30 16:35:08 --> Total execution time: 0.4055
INFO - 2020-10-30 16:35:08 --> Config Class Initialized
INFO - 2020-10-30 16:35:08 --> Hooks Class Initialized
DEBUG - 2020-10-30 16:35:08 --> UTF-8 Support Enabled
INFO - 2020-10-30 16:35:08 --> Utf8 Class Initialized
INFO - 2020-10-30 16:35:08 --> URI Class Initialized
DEBUG - 2020-10-30 16:35:08 --> No URI present. Default controller set.
INFO - 2020-10-30 16:35:08 --> Router Class Initialized
INFO - 2020-10-30 16:35:08 --> Output Class Initialized
INFO - 2020-10-30 16:35:08 --> Security Class Initialized
DEBUG - 2020-10-30 16:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 16:35:08 --> Input Class Initialized
INFO - 2020-10-30 16:35:08 --> Language Class Initialized
INFO - 2020-10-30 16:35:08 --> Loader Class Initialized
INFO - 2020-10-30 16:35:08 --> Helper loaded: url_helper
INFO - 2020-10-30 16:35:08 --> Helper loaded: form_helper
INFO - 2020-10-30 16:35:08 --> Helper loaded: html_helper
INFO - 2020-10-30 16:35:08 --> Helper loaded: date_helper
INFO - 2020-10-30 16:35:08 --> Database Driver Class Initialized
INFO - 2020-10-30 16:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 16:35:08 --> Table Class Initialized
INFO - 2020-10-30 16:35:08 --> Upload Class Initialized
INFO - 2020-10-30 16:35:08 --> Controller Class Initialized
INFO - 2020-10-30 16:35:08 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 16:35:08 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 16:35:08 --> Final output sent to browser
DEBUG - 2020-10-30 16:35:08 --> Total execution time: 0.0640
INFO - 2020-10-30 16:36:24 --> Config Class Initialized
INFO - 2020-10-30 16:36:24 --> Hooks Class Initialized
DEBUG - 2020-10-30 16:36:24 --> UTF-8 Support Enabled
INFO - 2020-10-30 16:36:24 --> Utf8 Class Initialized
INFO - 2020-10-30 16:36:24 --> URI Class Initialized
DEBUG - 2020-10-30 16:36:24 --> No URI present. Default controller set.
INFO - 2020-10-30 16:36:24 --> Router Class Initialized
INFO - 2020-10-30 16:36:24 --> Output Class Initialized
INFO - 2020-10-30 16:36:24 --> Security Class Initialized
DEBUG - 2020-10-30 16:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 16:36:24 --> Input Class Initialized
INFO - 2020-10-30 16:36:24 --> Language Class Initialized
INFO - 2020-10-30 16:36:24 --> Loader Class Initialized
INFO - 2020-10-30 16:36:24 --> Helper loaded: url_helper
INFO - 2020-10-30 16:36:24 --> Helper loaded: form_helper
INFO - 2020-10-30 16:36:24 --> Helper loaded: html_helper
INFO - 2020-10-30 16:36:24 --> Helper loaded: date_helper
INFO - 2020-10-30 16:36:24 --> Database Driver Class Initialized
INFO - 2020-10-30 16:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 16:36:24 --> Table Class Initialized
INFO - 2020-10-30 16:36:24 --> Upload Class Initialized
INFO - 2020-10-30 16:36:24 --> Controller Class Initialized
INFO - 2020-10-30 16:36:24 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 16:36:24 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 16:36:24 --> Final output sent to browser
DEBUG - 2020-10-30 16:36:24 --> Total execution time: 0.0564
INFO - 2020-10-30 17:09:32 --> Config Class Initialized
INFO - 2020-10-30 17:09:32 --> Hooks Class Initialized
DEBUG - 2020-10-30 17:09:32 --> UTF-8 Support Enabled
INFO - 2020-10-30 17:09:32 --> Utf8 Class Initialized
INFO - 2020-10-30 17:09:32 --> URI Class Initialized
DEBUG - 2020-10-30 17:09:32 --> No URI present. Default controller set.
INFO - 2020-10-30 17:09:32 --> Router Class Initialized
INFO - 2020-10-30 17:09:32 --> Output Class Initialized
INFO - 2020-10-30 17:09:32 --> Security Class Initialized
DEBUG - 2020-10-30 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 17:09:32 --> Input Class Initialized
INFO - 2020-10-30 17:09:32 --> Language Class Initialized
INFO - 2020-10-30 17:09:32 --> Loader Class Initialized
INFO - 2020-10-30 17:09:32 --> Helper loaded: url_helper
INFO - 2020-10-30 17:09:32 --> Helper loaded: form_helper
INFO - 2020-10-30 17:09:32 --> Helper loaded: html_helper
INFO - 2020-10-30 17:09:32 --> Helper loaded: date_helper
INFO - 2020-10-30 17:09:32 --> Database Driver Class Initialized
INFO - 2020-10-30 17:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 17:09:32 --> Table Class Initialized
INFO - 2020-10-30 17:09:32 --> Upload Class Initialized
INFO - 2020-10-30 17:09:32 --> Controller Class Initialized
INFO - 2020-10-30 17:09:32 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 17:09:32 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 17:09:32 --> Final output sent to browser
DEBUG - 2020-10-30 17:09:32 --> Total execution time: 0.0616
INFO - 2020-10-30 17:09:32 --> Config Class Initialized
INFO - 2020-10-30 17:09:32 --> Hooks Class Initialized
DEBUG - 2020-10-30 17:09:32 --> UTF-8 Support Enabled
INFO - 2020-10-30 17:09:32 --> Utf8 Class Initialized
INFO - 2020-10-30 17:09:32 --> URI Class Initialized
DEBUG - 2020-10-30 17:09:32 --> No URI present. Default controller set.
INFO - 2020-10-30 17:09:32 --> Router Class Initialized
INFO - 2020-10-30 17:09:32 --> Output Class Initialized
INFO - 2020-10-30 17:09:32 --> Security Class Initialized
DEBUG - 2020-10-30 17:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 17:09:32 --> Input Class Initialized
INFO - 2020-10-30 17:09:32 --> Language Class Initialized
INFO - 2020-10-30 17:09:32 --> Loader Class Initialized
INFO - 2020-10-30 17:09:32 --> Helper loaded: url_helper
INFO - 2020-10-30 17:09:32 --> Helper loaded: form_helper
INFO - 2020-10-30 17:09:33 --> Helper loaded: html_helper
INFO - 2020-10-30 17:09:33 --> Helper loaded: date_helper
INFO - 2020-10-30 17:09:33 --> Database Driver Class Initialized
INFO - 2020-10-30 17:09:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 17:09:33 --> Table Class Initialized
INFO - 2020-10-30 17:09:33 --> Upload Class Initialized
INFO - 2020-10-30 17:09:33 --> Controller Class Initialized
INFO - 2020-10-30 17:09:33 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 17:09:33 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 17:09:33 --> Final output sent to browser
DEBUG - 2020-10-30 17:09:33 --> Total execution time: 0.0596
INFO - 2020-10-30 17:19:59 --> Config Class Initialized
INFO - 2020-10-30 17:19:59 --> Hooks Class Initialized
DEBUG - 2020-10-30 17:19:59 --> UTF-8 Support Enabled
INFO - 2020-10-30 17:19:59 --> Utf8 Class Initialized
INFO - 2020-10-30 17:19:59 --> URI Class Initialized
DEBUG - 2020-10-30 17:19:59 --> No URI present. Default controller set.
INFO - 2020-10-30 17:19:59 --> Router Class Initialized
INFO - 2020-10-30 17:19:59 --> Output Class Initialized
INFO - 2020-10-30 17:19:59 --> Security Class Initialized
DEBUG - 2020-10-30 17:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 17:19:59 --> Input Class Initialized
INFO - 2020-10-30 17:19:59 --> Language Class Initialized
INFO - 2020-10-30 17:19:59 --> Loader Class Initialized
INFO - 2020-10-30 17:19:59 --> Helper loaded: url_helper
INFO - 2020-10-30 17:19:59 --> Helper loaded: form_helper
INFO - 2020-10-30 17:19:59 --> Helper loaded: html_helper
INFO - 2020-10-30 17:19:59 --> Helper loaded: date_helper
INFO - 2020-10-30 17:19:59 --> Database Driver Class Initialized
INFO - 2020-10-30 17:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 17:19:59 --> Table Class Initialized
INFO - 2020-10-30 17:19:59 --> Upload Class Initialized
INFO - 2020-10-30 17:19:59 --> Controller Class Initialized
INFO - 2020-10-30 17:19:59 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 17:19:59 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 17:19:59 --> Final output sent to browser
DEBUG - 2020-10-30 17:19:59 --> Total execution time: 0.1779
INFO - 2020-10-30 17:54:15 --> Config Class Initialized
INFO - 2020-10-30 17:54:15 --> Hooks Class Initialized
DEBUG - 2020-10-30 17:54:15 --> UTF-8 Support Enabled
INFO - 2020-10-30 17:54:15 --> Utf8 Class Initialized
INFO - 2020-10-30 17:54:15 --> URI Class Initialized
DEBUG - 2020-10-30 17:54:15 --> No URI present. Default controller set.
INFO - 2020-10-30 17:54:15 --> Router Class Initialized
INFO - 2020-10-30 17:54:15 --> Output Class Initialized
INFO - 2020-10-30 17:54:15 --> Security Class Initialized
DEBUG - 2020-10-30 17:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 17:54:15 --> Input Class Initialized
INFO - 2020-10-30 17:54:15 --> Language Class Initialized
INFO - 2020-10-30 17:54:15 --> Loader Class Initialized
INFO - 2020-10-30 17:54:15 --> Helper loaded: url_helper
INFO - 2020-10-30 17:54:15 --> Helper loaded: form_helper
INFO - 2020-10-30 17:54:15 --> Helper loaded: html_helper
INFO - 2020-10-30 17:54:15 --> Helper loaded: date_helper
INFO - 2020-10-30 17:54:15 --> Database Driver Class Initialized
INFO - 2020-10-30 17:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 17:54:15 --> Table Class Initialized
INFO - 2020-10-30 17:54:15 --> Upload Class Initialized
INFO - 2020-10-30 17:54:15 --> Controller Class Initialized
INFO - 2020-10-30 17:54:15 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 17:54:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 17:54:15 --> Final output sent to browser
DEBUG - 2020-10-30 17:54:15 --> Total execution time: 0.0784
INFO - 2020-10-30 18:35:47 --> Config Class Initialized
INFO - 2020-10-30 18:35:47 --> Hooks Class Initialized
DEBUG - 2020-10-30 18:35:47 --> UTF-8 Support Enabled
INFO - 2020-10-30 18:35:47 --> Utf8 Class Initialized
INFO - 2020-10-30 18:35:47 --> URI Class Initialized
DEBUG - 2020-10-30 18:35:47 --> No URI present. Default controller set.
INFO - 2020-10-30 18:35:47 --> Router Class Initialized
INFO - 2020-10-30 18:35:47 --> Output Class Initialized
INFO - 2020-10-30 18:35:47 --> Security Class Initialized
DEBUG - 2020-10-30 18:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 18:35:47 --> Input Class Initialized
INFO - 2020-10-30 18:35:47 --> Language Class Initialized
INFO - 2020-10-30 18:35:47 --> Loader Class Initialized
INFO - 2020-10-30 18:35:47 --> Helper loaded: url_helper
INFO - 2020-10-30 18:35:47 --> Helper loaded: form_helper
INFO - 2020-10-30 18:35:47 --> Helper loaded: html_helper
INFO - 2020-10-30 18:35:47 --> Helper loaded: date_helper
INFO - 2020-10-30 18:35:47 --> Database Driver Class Initialized
INFO - 2020-10-30 18:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 18:35:47 --> Table Class Initialized
INFO - 2020-10-30 18:35:47 --> Upload Class Initialized
INFO - 2020-10-30 18:35:47 --> Controller Class Initialized
INFO - 2020-10-30 18:35:47 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 18:35:47 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 18:35:47 --> Final output sent to browser
DEBUG - 2020-10-30 18:35:47 --> Total execution time: 0.0747
INFO - 2020-10-30 18:35:47 --> Config Class Initialized
INFO - 2020-10-30 18:35:47 --> Hooks Class Initialized
DEBUG - 2020-10-30 18:35:47 --> UTF-8 Support Enabled
INFO - 2020-10-30 18:35:47 --> Utf8 Class Initialized
INFO - 2020-10-30 18:35:47 --> URI Class Initialized
DEBUG - 2020-10-30 18:35:47 --> No URI present. Default controller set.
INFO - 2020-10-30 18:35:47 --> Router Class Initialized
INFO - 2020-10-30 18:35:47 --> Output Class Initialized
INFO - 2020-10-30 18:35:48 --> Security Class Initialized
DEBUG - 2020-10-30 18:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 18:35:48 --> Input Class Initialized
INFO - 2020-10-30 18:35:48 --> Language Class Initialized
INFO - 2020-10-30 18:35:48 --> Loader Class Initialized
INFO - 2020-10-30 18:35:48 --> Helper loaded: url_helper
INFO - 2020-10-30 18:35:48 --> Helper loaded: form_helper
INFO - 2020-10-30 18:35:48 --> Helper loaded: html_helper
INFO - 2020-10-30 18:35:48 --> Helper loaded: date_helper
INFO - 2020-10-30 18:35:48 --> Database Driver Class Initialized
INFO - 2020-10-30 18:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 18:35:48 --> Table Class Initialized
INFO - 2020-10-30 18:35:48 --> Upload Class Initialized
INFO - 2020-10-30 18:35:48 --> Controller Class Initialized
INFO - 2020-10-30 18:35:48 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 18:35:48 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 18:35:48 --> Final output sent to browser
DEBUG - 2020-10-30 18:35:48 --> Total execution time: 0.0780
INFO - 2020-10-30 18:52:57 --> Config Class Initialized
INFO - 2020-10-30 18:52:57 --> Hooks Class Initialized
DEBUG - 2020-10-30 18:52:57 --> UTF-8 Support Enabled
INFO - 2020-10-30 18:52:57 --> Utf8 Class Initialized
INFO - 2020-10-30 18:52:57 --> URI Class Initialized
DEBUG - 2020-10-30 18:52:57 --> No URI present. Default controller set.
INFO - 2020-10-30 18:52:57 --> Router Class Initialized
INFO - 2020-10-30 18:52:57 --> Output Class Initialized
INFO - 2020-10-30 18:52:57 --> Security Class Initialized
DEBUG - 2020-10-30 18:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 18:52:57 --> Input Class Initialized
INFO - 2020-10-30 18:52:57 --> Language Class Initialized
INFO - 2020-10-30 18:52:57 --> Loader Class Initialized
INFO - 2020-10-30 18:52:57 --> Helper loaded: url_helper
INFO - 2020-10-30 18:52:57 --> Helper loaded: form_helper
INFO - 2020-10-30 18:52:57 --> Helper loaded: html_helper
INFO - 2020-10-30 18:52:57 --> Helper loaded: date_helper
INFO - 2020-10-30 18:52:57 --> Database Driver Class Initialized
INFO - 2020-10-30 18:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 18:52:57 --> Table Class Initialized
INFO - 2020-10-30 18:52:57 --> Upload Class Initialized
INFO - 2020-10-30 18:52:57 --> Controller Class Initialized
INFO - 2020-10-30 18:52:57 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 18:52:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 18:52:57 --> Final output sent to browser
DEBUG - 2020-10-30 18:52:57 --> Total execution time: 0.2460
INFO - 2020-10-30 18:52:58 --> Config Class Initialized
INFO - 2020-10-30 18:52:58 --> Hooks Class Initialized
DEBUG - 2020-10-30 18:52:58 --> UTF-8 Support Enabled
INFO - 2020-10-30 18:52:58 --> Utf8 Class Initialized
INFO - 2020-10-30 18:52:58 --> URI Class Initialized
DEBUG - 2020-10-30 18:52:58 --> No URI present. Default controller set.
INFO - 2020-10-30 18:52:58 --> Router Class Initialized
INFO - 2020-10-30 18:52:58 --> Output Class Initialized
INFO - 2020-10-30 18:52:58 --> Security Class Initialized
DEBUG - 2020-10-30 18:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-30 18:52:58 --> Input Class Initialized
INFO - 2020-10-30 18:52:58 --> Language Class Initialized
INFO - 2020-10-30 18:52:58 --> Loader Class Initialized
INFO - 2020-10-30 18:52:58 --> Helper loaded: url_helper
INFO - 2020-10-30 18:52:58 --> Helper loaded: form_helper
INFO - 2020-10-30 18:52:58 --> Helper loaded: html_helper
INFO - 2020-10-30 18:52:58 --> Helper loaded: date_helper
INFO - 2020-10-30 18:52:58 --> Database Driver Class Initialized
INFO - 2020-10-30 18:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-30 18:52:58 --> Table Class Initialized
INFO - 2020-10-30 18:52:58 --> Upload Class Initialized
INFO - 2020-10-30 18:52:58 --> Controller Class Initialized
INFO - 2020-10-30 18:52:58 --> Model "Usuarios_model" initialized
INFO - 2020-10-30 18:52:58 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-10-30 18:52:58 --> Final output sent to browser
DEBUG - 2020-10-30 18:52:58 --> Total execution time: 0.1782

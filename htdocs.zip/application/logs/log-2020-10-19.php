<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-19 15:13:14 --> Config Class Initialized
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-19 15:13:14 --> Config Class Initialized
INFO - 2020-10-19 15:13:14 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:14 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:14 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:14 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:14 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:14 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:14 --> URI Class Initialized
INFO - 2020-10-19 15:13:14 --> URI Class Initialized
DEBUG - 2020-10-19 15:13:14 --> No URI present. Default controller set.
INFO - 2020-10-19 15:13:14 --> Router Class Initialized
INFO - 2020-10-19 15:13:14 --> Router Class Initialized
INFO - 2020-10-19 15:13:14 --> Output Class Initialized
INFO - 2020-10-19 15:13:14 --> Output Class Initialized
INFO - 2020-10-19 15:13:14 --> Security Class Initialized
INFO - 2020-10-19 15:13:14 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:14 --> Input Class Initialized
INFO - 2020-10-19 15:13:14 --> Input Class Initialized
INFO - 2020-10-19 15:13:14 --> Language Class Initialized
INFO - 2020-10-19 15:13:14 --> Language Class Initialized
ERROR - 2020-10-19 15:13:14 --> 404 Page Not Found: Welcome/robots.txt
ERROR - 2020-10-19 15:13:14 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-19 15:13:14 --> Config Class Initialized
INFO - 2020-10-19 15:13:14 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:14 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:14 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:14 --> URI Class Initialized
INFO - 2020-10-19 15:13:14 --> Router Class Initialized
INFO - 2020-10-19 15:13:14 --> Output Class Initialized
INFO - 2020-10-19 15:13:14 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:14 --> Input Class Initialized
INFO - 2020-10-19 15:13:14 --> Language Class Initialized
ERROR - 2020-10-19 15:13:14 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-19 15:13:21 --> Config Class Initialized
INFO - 2020-10-19 15:13:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:21 --> URI Class Initialized
INFO - 2020-10-19 15:13:21 --> Router Class Initialized
INFO - 2020-10-19 15:13:21 --> Output Class Initialized
INFO - 2020-10-19 15:13:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:21 --> Input Class Initialized
INFO - 2020-10-19 15:13:21 --> Language Class Initialized
INFO - 2020-10-19 15:13:21 --> Loader Class Initialized
INFO - 2020-10-19 15:13:21 --> Helper loaded: url_helper
INFO - 2020-10-19 15:13:21 --> Helper loaded: form_helper
INFO - 2020-10-19 15:13:21 --> Helper loaded: html_helper
INFO - 2020-10-19 15:13:21 --> Helper loaded: date_helper
INFO - 2020-10-19 15:13:21 --> Database Driver Class Initialized
INFO - 2020-10-19 15:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:13:22 --> Table Class Initialized
INFO - 2020-10-19 15:13:22 --> Upload Class Initialized
INFO - 2020-10-19 15:13:22 --> Controller Class Initialized
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:13:22 --> Final output sent to browser
DEBUG - 2020-10-19 15:13:22 --> Total execution time: 0.2609
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
ERROR - 2020-10-19 15:13:22 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:22 --> Config Class Initialized
INFO - 2020-10-19 15:13:22 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:22 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:22 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:22 --> URI Class Initialized
INFO - 2020-10-19 15:13:22 --> Router Class Initialized
INFO - 2020-10-19 15:13:22 --> Output Class Initialized
INFO - 2020-10-19 15:13:22 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:22 --> Input Class Initialized
INFO - 2020-10-19 15:13:22 --> Language Class Initialized
INFO - 2020-10-19 15:13:22 --> Loader Class Initialized
INFO - 2020-10-19 15:13:22 --> Helper loaded: url_helper
INFO - 2020-10-19 15:13:22 --> Helper loaded: form_helper
INFO - 2020-10-19 15:13:22 --> Helper loaded: html_helper
INFO - 2020-10-19 15:13:22 --> Helper loaded: date_helper
INFO - 2020-10-19 15:13:22 --> Database Driver Class Initialized
INFO - 2020-10-19 15:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:13:22 --> Table Class Initialized
INFO - 2020-10-19 15:13:22 --> Upload Class Initialized
INFO - 2020-10-19 15:13:22 --> Controller Class Initialized
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:13:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:13:23 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:13:23 --> Final output sent to browser
DEBUG - 2020-10-19 15:13:23 --> Total execution time: 0.1662
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:23 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:23 --> Config Class Initialized
INFO - 2020-10-19 15:13:23 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:23 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:23 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:23 --> URI Class Initialized
INFO - 2020-10-19 15:13:23 --> Router Class Initialized
INFO - 2020-10-19 15:13:23 --> Output Class Initialized
INFO - 2020-10-19 15:13:23 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:23 --> Input Class Initialized
INFO - 2020-10-19 15:13:23 --> Language Class Initialized
ERROR - 2020-10-19 15:13:24 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:24 --> Config Class Initialized
INFO - 2020-10-19 15:13:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:24 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:24 --> URI Class Initialized
INFO - 2020-10-19 15:13:24 --> Router Class Initialized
INFO - 2020-10-19 15:13:24 --> Output Class Initialized
INFO - 2020-10-19 15:13:24 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:24 --> Input Class Initialized
INFO - 2020-10-19 15:13:24 --> Language Class Initialized
ERROR - 2020-10-19 15:13:24 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:24 --> Config Class Initialized
INFO - 2020-10-19 15:13:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:24 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:24 --> URI Class Initialized
INFO - 2020-10-19 15:13:24 --> Router Class Initialized
INFO - 2020-10-19 15:13:24 --> Output Class Initialized
INFO - 2020-10-19 15:13:24 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:24 --> Input Class Initialized
INFO - 2020-10-19 15:13:24 --> Language Class Initialized
ERROR - 2020-10-19 15:13:24 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:24 --> Config Class Initialized
INFO - 2020-10-19 15:13:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:24 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:24 --> URI Class Initialized
INFO - 2020-10-19 15:13:24 --> Router Class Initialized
INFO - 2020-10-19 15:13:24 --> Output Class Initialized
INFO - 2020-10-19 15:13:24 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:24 --> Input Class Initialized
INFO - 2020-10-19 15:13:24 --> Language Class Initialized
ERROR - 2020-10-19 15:13:24 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:24 --> Config Class Initialized
INFO - 2020-10-19 15:13:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:24 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:24 --> URI Class Initialized
INFO - 2020-10-19 15:13:24 --> Router Class Initialized
INFO - 2020-10-19 15:13:24 --> Output Class Initialized
INFO - 2020-10-19 15:13:24 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:24 --> Input Class Initialized
INFO - 2020-10-19 15:13:24 --> Language Class Initialized
ERROR - 2020-10-19 15:13:24 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:24 --> Config Class Initialized
INFO - 2020-10-19 15:13:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:24 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:24 --> URI Class Initialized
INFO - 2020-10-19 15:13:24 --> Router Class Initialized
INFO - 2020-10-19 15:13:24 --> Output Class Initialized
INFO - 2020-10-19 15:13:24 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:24 --> Input Class Initialized
INFO - 2020-10-19 15:13:24 --> Language Class Initialized
ERROR - 2020-10-19 15:13:24 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:24 --> Config Class Initialized
INFO - 2020-10-19 15:13:24 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:24 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:24 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:24 --> URI Class Initialized
INFO - 2020-10-19 15:13:24 --> Router Class Initialized
INFO - 2020-10-19 15:13:24 --> Output Class Initialized
INFO - 2020-10-19 15:13:24 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:24 --> Input Class Initialized
INFO - 2020-10-19 15:13:24 --> Language Class Initialized
ERROR - 2020-10-19 15:13:24 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:46 --> Config Class Initialized
INFO - 2020-10-19 15:13:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:46 --> URI Class Initialized
INFO - 2020-10-19 15:13:46 --> Router Class Initialized
INFO - 2020-10-19 15:13:46 --> Output Class Initialized
INFO - 2020-10-19 15:13:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:46 --> Input Class Initialized
INFO - 2020-10-19 15:13:46 --> Language Class Initialized
INFO - 2020-10-19 15:13:46 --> Loader Class Initialized
INFO - 2020-10-19 15:13:46 --> Helper loaded: url_helper
INFO - 2020-10-19 15:13:46 --> Helper loaded: form_helper
INFO - 2020-10-19 15:13:46 --> Helper loaded: html_helper
INFO - 2020-10-19 15:13:46 --> Helper loaded: date_helper
INFO - 2020-10-19 15:13:46 --> Database Driver Class Initialized
INFO - 2020-10-19 15:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:13:46 --> Table Class Initialized
INFO - 2020-10-19 15:13:46 --> Upload Class Initialized
INFO - 2020-10-19 15:13:46 --> Controller Class Initialized
INFO - 2020-10-19 15:13:46 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:13:46 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:13:46 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:13:46 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:13:46 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:13:46 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:13:46 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:13:46 --> Final output sent to browser
DEBUG - 2020-10-19 15:13:46 --> Total execution time: 0.1629
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:47 --> Language Class Initialized
ERROR - 2020-10-19 15:13:47 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:13:47 --> Config Class Initialized
INFO - 2020-10-19 15:13:47 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:47 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:47 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:47 --> URI Class Initialized
INFO - 2020-10-19 15:13:47 --> Router Class Initialized
INFO - 2020-10-19 15:13:47 --> Output Class Initialized
INFO - 2020-10-19 15:13:47 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:47 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:13:48 --> Config Class Initialized
INFO - 2020-10-19 15:13:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:13:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:13:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:13:48 --> URI Class Initialized
INFO - 2020-10-19 15:13:48 --> Router Class Initialized
INFO - 2020-10-19 15:13:48 --> Output Class Initialized
INFO - 2020-10-19 15:13:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:13:48 --> Input Class Initialized
INFO - 2020-10-19 15:13:48 --> Language Class Initialized
ERROR - 2020-10-19 15:13:48 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:06 --> Config Class Initialized
INFO - 2020-10-19 15:14:06 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:06 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:06 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:06 --> URI Class Initialized
INFO - 2020-10-19 15:14:06 --> Router Class Initialized
INFO - 2020-10-19 15:14:06 --> Output Class Initialized
INFO - 2020-10-19 15:14:06 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:06 --> Input Class Initialized
INFO - 2020-10-19 15:14:06 --> Language Class Initialized
INFO - 2020-10-19 15:14:06 --> Loader Class Initialized
INFO - 2020-10-19 15:14:06 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:06 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:06 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:06 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:06 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:07 --> Table Class Initialized
INFO - 2020-10-19 15:14:07 --> Upload Class Initialized
INFO - 2020-10-19 15:14:07 --> Controller Class Initialized
INFO - 2020-10-19 15:14:07 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:07 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:07 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:07 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:07 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:07 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:07 --> Total execution time: 0.2629
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Dist/img
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Input Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
INFO - 2020-10-19 15:14:07 --> Language Class Initialized
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:07 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Config Class Initialized
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:07 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:07 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> URI Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
INFO - 2020-10-19 15:14:07 --> Router Class Initialized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:07 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:07 --> Security Class Initialized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:08 --> Config Class Initialized
INFO - 2020-10-19 15:14:08 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:08 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:08 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:08 --> URI Class Initialized
INFO - 2020-10-19 15:14:08 --> Router Class Initialized
INFO - 2020-10-19 15:14:08 --> Output Class Initialized
INFO - 2020-10-19 15:14:08 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:08 --> Input Class Initialized
INFO - 2020-10-19 15:14:08 --> Language Class Initialized
ERROR - 2020-10-19 15:14:08 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:16 --> Config Class Initialized
INFO - 2020-10-19 15:14:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:16 --> URI Class Initialized
INFO - 2020-10-19 15:14:16 --> Router Class Initialized
INFO - 2020-10-19 15:14:16 --> Output Class Initialized
INFO - 2020-10-19 15:14:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:16 --> Input Class Initialized
INFO - 2020-10-19 15:14:16 --> Language Class Initialized
INFO - 2020-10-19 15:14:16 --> Loader Class Initialized
INFO - 2020-10-19 15:14:16 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:16 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:16 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:16 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:16 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:16 --> Table Class Initialized
INFO - 2020-10-19 15:14:16 --> Upload Class Initialized
INFO - 2020-10-19 15:14:16 --> Controller Class Initialized
INFO - 2020-10-19 15:14:16 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:16 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:16 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:16 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:16 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:16 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:16 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:16 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:16 --> Total execution time: 0.2627
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:17 --> Security Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:17 --> Security Class Initialized
INFO - 2020-10-19 15:14:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:17 --> Security Class Initialized
INFO - 2020-10-19 15:14:17 --> Security Class Initialized
INFO - 2020-10-19 15:14:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:17 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:17 --> Input Class Initialized
INFO - 2020-10-19 15:14:17 --> Input Class Initialized
INFO - 2020-10-19 15:14:17 --> Input Class Initialized
INFO - 2020-10-19 15:14:17 --> Input Class Initialized
INFO - 2020-10-19 15:14:17 --> Input Class Initialized
INFO - 2020-10-19 15:14:17 --> Language Class Initialized
INFO - 2020-10-19 15:14:17 --> Language Class Initialized
INFO - 2020-10-19 15:14:17 --> Language Class Initialized
INFO - 2020-10-19 15:14:17 --> Language Class Initialized
ERROR - 2020-10-19 15:14:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:17 --> Language Class Initialized
INFO - 2020-10-19 15:14:17 --> Language Class Initialized
ERROR - 2020-10-19 15:14:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:17 --> Input Class Initialized
INFO - 2020-10-19 15:14:17 --> Language Class Initialized
ERROR - 2020-10-19 15:14:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:17 --> Config Class Initialized
INFO - 2020-10-19 15:14:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:17 --> URI Class Initialized
INFO - 2020-10-19 15:14:17 --> Router Class Initialized
INFO - 2020-10-19 15:14:17 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Loader Class Initialized
INFO - 2020-10-19 15:14:18 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:18 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:18 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:18 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:18 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:18 --> Table Class Initialized
INFO - 2020-10-19 15:14:18 --> Upload Class Initialized
INFO - 2020-10-19 15:14:18 --> Controller Class Initialized
INFO - 2020-10-19 15:14:18 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:18 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:18 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:18 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:18 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:18 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:18 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:18 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:18 --> Total execution time: 0.3503
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
INFO - 2020-10-19 15:14:18 --> Input Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
INFO - 2020-10-19 15:14:18 --> Language Class Initialized
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Config Class Initialized
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:18 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> URI Class Initialized
INFO - 2020-10-19 15:14:18 --> Router Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
INFO - 2020-10-19 15:14:18 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:18 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:19 --> Input Class Initialized
INFO - 2020-10-19 15:14:19 --> Language Class Initialized
ERROR - 2020-10-19 15:14:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:19 --> Config Class Initialized
INFO - 2020-10-19 15:14:19 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:19 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:19 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:19 --> URI Class Initialized
INFO - 2020-10-19 15:14:19 --> Router Class Initialized
INFO - 2020-10-19 15:14:19 --> Output Class Initialized
INFO - 2020-10-19 15:14:19 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:20 --> Input Class Initialized
INFO - 2020-10-19 15:14:20 --> Language Class Initialized
ERROR - 2020-10-19 15:14:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:20 --> Config Class Initialized
INFO - 2020-10-19 15:14:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:20 --> URI Class Initialized
INFO - 2020-10-19 15:14:20 --> Router Class Initialized
INFO - 2020-10-19 15:14:20 --> Output Class Initialized
INFO - 2020-10-19 15:14:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:20 --> Input Class Initialized
INFO - 2020-10-19 15:14:20 --> Language Class Initialized
ERROR - 2020-10-19 15:14:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:20 --> Config Class Initialized
INFO - 2020-10-19 15:14:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:20 --> URI Class Initialized
INFO - 2020-10-19 15:14:20 --> Router Class Initialized
INFO - 2020-10-19 15:14:20 --> Output Class Initialized
INFO - 2020-10-19 15:14:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:20 --> Input Class Initialized
INFO - 2020-10-19 15:14:20 --> Language Class Initialized
ERROR - 2020-10-19 15:14:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:20 --> Config Class Initialized
INFO - 2020-10-19 15:14:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:20 --> URI Class Initialized
INFO - 2020-10-19 15:14:20 --> Router Class Initialized
INFO - 2020-10-19 15:14:20 --> Output Class Initialized
INFO - 2020-10-19 15:14:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:20 --> Input Class Initialized
INFO - 2020-10-19 15:14:20 --> Language Class Initialized
ERROR - 2020-10-19 15:14:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:20 --> Config Class Initialized
INFO - 2020-10-19 15:14:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:20 --> URI Class Initialized
INFO - 2020-10-19 15:14:20 --> Router Class Initialized
INFO - 2020-10-19 15:14:20 --> Output Class Initialized
INFO - 2020-10-19 15:14:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:20 --> Input Class Initialized
INFO - 2020-10-19 15:14:20 --> Language Class Initialized
ERROR - 2020-10-19 15:14:20 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Loader Class Initialized
INFO - 2020-10-19 15:14:33 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:33 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:33 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:33 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:33 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:33 --> Table Class Initialized
INFO - 2020-10-19 15:14:33 --> Upload Class Initialized
INFO - 2020-10-19 15:14:33 --> Controller Class Initialized
INFO - 2020-10-19 15:14:33 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:33 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:33 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:33 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:33 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:33 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:33 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:33 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:33 --> Total execution time: 0.3233
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> URI Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Router Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
INFO - 2020-10-19 15:14:33 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
INFO - 2020-10-19 15:14:33 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Input Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
INFO - 2020-10-19 15:14:33 --> Language Class Initialized
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:33 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:33 --> Config Class Initialized
INFO - 2020-10-19 15:14:33 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:33 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:34 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:34 --> Config Class Initialized
INFO - 2020-10-19 15:14:34 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:34 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:34 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:34 --> URI Class Initialized
INFO - 2020-10-19 15:14:34 --> Router Class Initialized
INFO - 2020-10-19 15:14:34 --> Output Class Initialized
INFO - 2020-10-19 15:14:34 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:34 --> Input Class Initialized
INFO - 2020-10-19 15:14:34 --> Language Class Initialized
ERROR - 2020-10-19 15:14:35 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:35 --> Config Class Initialized
INFO - 2020-10-19 15:14:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:35 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:35 --> URI Class Initialized
INFO - 2020-10-19 15:14:35 --> Router Class Initialized
INFO - 2020-10-19 15:14:35 --> Output Class Initialized
INFO - 2020-10-19 15:14:35 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:35 --> Input Class Initialized
INFO - 2020-10-19 15:14:35 --> Language Class Initialized
ERROR - 2020-10-19 15:14:35 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:35 --> Config Class Initialized
INFO - 2020-10-19 15:14:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:35 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:35 --> URI Class Initialized
INFO - 2020-10-19 15:14:35 --> Router Class Initialized
INFO - 2020-10-19 15:14:35 --> Output Class Initialized
INFO - 2020-10-19 15:14:35 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:35 --> Input Class Initialized
INFO - 2020-10-19 15:14:35 --> Language Class Initialized
ERROR - 2020-10-19 15:14:35 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:35 --> Config Class Initialized
INFO - 2020-10-19 15:14:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:35 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:35 --> URI Class Initialized
INFO - 2020-10-19 15:14:35 --> Router Class Initialized
INFO - 2020-10-19 15:14:35 --> Output Class Initialized
INFO - 2020-10-19 15:14:35 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:35 --> Input Class Initialized
INFO - 2020-10-19 15:14:35 --> Language Class Initialized
ERROR - 2020-10-19 15:14:35 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:35 --> Config Class Initialized
INFO - 2020-10-19 15:14:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:35 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:35 --> URI Class Initialized
INFO - 2020-10-19 15:14:35 --> Router Class Initialized
INFO - 2020-10-19 15:14:35 --> Output Class Initialized
INFO - 2020-10-19 15:14:35 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:35 --> Input Class Initialized
INFO - 2020-10-19 15:14:35 --> Language Class Initialized
ERROR - 2020-10-19 15:14:35 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:35 --> Config Class Initialized
INFO - 2020-10-19 15:14:35 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:35 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:35 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:35 --> URI Class Initialized
INFO - 2020-10-19 15:14:35 --> Router Class Initialized
INFO - 2020-10-19 15:14:35 --> Output Class Initialized
INFO - 2020-10-19 15:14:35 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:35 --> Input Class Initialized
INFO - 2020-10-19 15:14:35 --> Language Class Initialized
ERROR - 2020-10-19 15:14:35 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Loader Class Initialized
INFO - 2020-10-19 15:14:45 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:45 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:45 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:45 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:45 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:45 --> Table Class Initialized
INFO - 2020-10-19 15:14:45 --> Upload Class Initialized
INFO - 2020-10-19 15:14:45 --> Controller Class Initialized
INFO - 2020-10-19 15:14:45 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:45 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:45 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:45 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:45 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:45 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:45 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:45 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:45 --> Total execution time: 0.1125
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:45 --> Config Class Initialized
INFO - 2020-10-19 15:14:45 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:45 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:45 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:45 --> URI Class Initialized
INFO - 2020-10-19 15:14:45 --> Router Class Initialized
INFO - 2020-10-19 15:14:45 --> Output Class Initialized
INFO - 2020-10-19 15:14:45 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:45 --> Input Class Initialized
INFO - 2020-10-19 15:14:45 --> Language Class Initialized
ERROR - 2020-10-19 15:14:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:46 --> Config Class Initialized
INFO - 2020-10-19 15:14:46 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:46 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:46 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:46 --> URI Class Initialized
INFO - 2020-10-19 15:14:46 --> Router Class Initialized
INFO - 2020-10-19 15:14:46 --> Output Class Initialized
INFO - 2020-10-19 15:14:46 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:46 --> Input Class Initialized
INFO - 2020-10-19 15:14:46 --> Language Class Initialized
ERROR - 2020-10-19 15:14:46 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:48 --> Config Class Initialized
INFO - 2020-10-19 15:14:48 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:48 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:48 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:48 --> URI Class Initialized
INFO - 2020-10-19 15:14:48 --> Router Class Initialized
INFO - 2020-10-19 15:14:48 --> Output Class Initialized
INFO - 2020-10-19 15:14:48 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:48 --> Input Class Initialized
INFO - 2020-10-19 15:14:48 --> Language Class Initialized
INFO - 2020-10-19 15:14:48 --> Loader Class Initialized
INFO - 2020-10-19 15:14:49 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:49 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:49 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:49 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:49 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:49 --> Table Class Initialized
INFO - 2020-10-19 15:14:49 --> Upload Class Initialized
INFO - 2020-10-19 15:14:49 --> Controller Class Initialized
INFO - 2020-10-19 15:14:49 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:49 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:49 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:49 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:49 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:49 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:49 --> Total execution time: 0.1341
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:49 --> Input Class Initialized
INFO - 2020-10-19 15:14:49 --> Language Class Initialized
ERROR - 2020-10-19 15:14:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:49 --> Config Class Initialized
INFO - 2020-10-19 15:14:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:49 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:49 --> URI Class Initialized
INFO - 2020-10-19 15:14:49 --> Router Class Initialized
INFO - 2020-10-19 15:14:49 --> Output Class Initialized
INFO - 2020-10-19 15:14:49 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:50 --> Input Class Initialized
INFO - 2020-10-19 15:14:50 --> Language Class Initialized
ERROR - 2020-10-19 15:14:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:50 --> Config Class Initialized
INFO - 2020-10-19 15:14:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:50 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:50 --> URI Class Initialized
INFO - 2020-10-19 15:14:50 --> Router Class Initialized
INFO - 2020-10-19 15:14:50 --> Output Class Initialized
INFO - 2020-10-19 15:14:50 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:50 --> Input Class Initialized
INFO - 2020-10-19 15:14:50 --> Language Class Initialized
ERROR - 2020-10-19 15:14:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:50 --> Config Class Initialized
INFO - 2020-10-19 15:14:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:50 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:50 --> URI Class Initialized
INFO - 2020-10-19 15:14:50 --> Router Class Initialized
INFO - 2020-10-19 15:14:50 --> Output Class Initialized
INFO - 2020-10-19 15:14:50 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:50 --> Input Class Initialized
INFO - 2020-10-19 15:14:50 --> Language Class Initialized
ERROR - 2020-10-19 15:14:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:50 --> Config Class Initialized
INFO - 2020-10-19 15:14:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:50 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:50 --> URI Class Initialized
INFO - 2020-10-19 15:14:50 --> Router Class Initialized
INFO - 2020-10-19 15:14:50 --> Output Class Initialized
INFO - 2020-10-19 15:14:50 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:50 --> Input Class Initialized
INFO - 2020-10-19 15:14:50 --> Language Class Initialized
ERROR - 2020-10-19 15:14:50 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:50 --> Config Class Initialized
INFO - 2020-10-19 15:14:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:50 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:50 --> URI Class Initialized
INFO - 2020-10-19 15:14:50 --> Router Class Initialized
INFO - 2020-10-19 15:14:50 --> Output Class Initialized
INFO - 2020-10-19 15:14:50 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:50 --> Input Class Initialized
INFO - 2020-10-19 15:14:50 --> Language Class Initialized
ERROR - 2020-10-19 15:14:50 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Loader Class Initialized
INFO - 2020-10-19 15:14:54 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:54 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:54 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:54 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:54 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:54 --> Table Class Initialized
INFO - 2020-10-19 15:14:54 --> Upload Class Initialized
INFO - 2020-10-19 15:14:54 --> Controller Class Initialized
INFO - 2020-10-19 15:14:54 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:54 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:54 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:54 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:54 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:54 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:54 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:54 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:54 --> Total execution time: 0.1386
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
ERROR - 2020-10-19 15:14:54 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
ERROR - 2020-10-19 15:14:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:54 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
ERROR - 2020-10-19 15:14:54 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
ERROR - 2020-10-19 15:14:54 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Config Class Initialized
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> URI Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Router Class Initialized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Output Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
INFO - 2020-10-19 15:14:54 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
INFO - 2020-10-19 15:14:54 --> Input Class Initialized
ERROR - 2020-10-19 15:14:54 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
INFO - 2020-10-19 15:14:54 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:55 --> Config Class Initialized
INFO - 2020-10-19 15:14:55 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:55 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:55 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:55 --> URI Class Initialized
INFO - 2020-10-19 15:14:55 --> Router Class Initialized
INFO - 2020-10-19 15:14:55 --> Output Class Initialized
INFO - 2020-10-19 15:14:55 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:55 --> Input Class Initialized
INFO - 2020-10-19 15:14:55 --> Language Class Initialized
ERROR - 2020-10-19 15:14:55 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Loader Class Initialized
INFO - 2020-10-19 15:14:59 --> Helper loaded: url_helper
INFO - 2020-10-19 15:14:59 --> Helper loaded: form_helper
INFO - 2020-10-19 15:14:59 --> Helper loaded: html_helper
INFO - 2020-10-19 15:14:59 --> Helper loaded: date_helper
INFO - 2020-10-19 15:14:59 --> Database Driver Class Initialized
INFO - 2020-10-19 15:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:14:59 --> Table Class Initialized
INFO - 2020-10-19 15:14:59 --> Upload Class Initialized
INFO - 2020-10-19 15:14:59 --> Controller Class Initialized
INFO - 2020-10-19 15:14:59 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:14:59 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:14:59 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:14:59 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:14:59 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:14:59 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:14:59 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:14:59 --> Final output sent to browser
DEBUG - 2020-10-19 15:14:59 --> Total execution time: 0.1553
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:59 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:14:59 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> Utf8 Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> URI Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Router Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
INFO - 2020-10-19 15:14:59 --> Output Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Security Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Input Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:14:59 --> Language Class Initialized
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
ERROR - 2020-10-19 15:14:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:14:59 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:00 --> Config Class Initialized
INFO - 2020-10-19 15:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:00 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:00 --> URI Class Initialized
INFO - 2020-10-19 15:15:00 --> Router Class Initialized
INFO - 2020-10-19 15:15:00 --> Output Class Initialized
INFO - 2020-10-19 15:15:00 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:00 --> Input Class Initialized
INFO - 2020-10-19 15:15:00 --> Language Class Initialized
ERROR - 2020-10-19 15:15:00 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:01 --> Config Class Initialized
INFO - 2020-10-19 15:15:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:01 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:01 --> URI Class Initialized
INFO - 2020-10-19 15:15:01 --> Router Class Initialized
INFO - 2020-10-19 15:15:01 --> Output Class Initialized
INFO - 2020-10-19 15:15:01 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:01 --> Input Class Initialized
INFO - 2020-10-19 15:15:01 --> Language Class Initialized
ERROR - 2020-10-19 15:15:01 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:01 --> Config Class Initialized
INFO - 2020-10-19 15:15:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:01 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:01 --> URI Class Initialized
INFO - 2020-10-19 15:15:01 --> Router Class Initialized
INFO - 2020-10-19 15:15:01 --> Output Class Initialized
INFO - 2020-10-19 15:15:01 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:01 --> Input Class Initialized
INFO - 2020-10-19 15:15:01 --> Language Class Initialized
ERROR - 2020-10-19 15:15:01 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:04 --> Config Class Initialized
INFO - 2020-10-19 15:15:04 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:04 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:04 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:04 --> URI Class Initialized
INFO - 2020-10-19 15:15:04 --> Router Class Initialized
INFO - 2020-10-19 15:15:04 --> Output Class Initialized
INFO - 2020-10-19 15:15:04 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:04 --> Input Class Initialized
INFO - 2020-10-19 15:15:04 --> Language Class Initialized
INFO - 2020-10-19 15:15:04 --> Loader Class Initialized
INFO - 2020-10-19 15:15:04 --> Helper loaded: url_helper
INFO - 2020-10-19 15:15:04 --> Helper loaded: form_helper
INFO - 2020-10-19 15:15:04 --> Helper loaded: html_helper
INFO - 2020-10-19 15:15:04 --> Helper loaded: date_helper
INFO - 2020-10-19 15:15:04 --> Database Driver Class Initialized
INFO - 2020-10-19 15:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:15:04 --> Table Class Initialized
INFO - 2020-10-19 15:15:04 --> Upload Class Initialized
INFO - 2020-10-19 15:15:04 --> Controller Class Initialized
INFO - 2020-10-19 15:15:04 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:15:04 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:15:04 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:15:04 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:15:04 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:15:04 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:15:04 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:15:04 --> Final output sent to browser
DEBUG - 2020-10-19 15:15:04 --> Total execution time: 0.1718
INFO - 2020-10-19 15:15:04 --> Config Class Initialized
INFO - 2020-10-19 15:15:04 --> Config Class Initialized
INFO - 2020-10-19 15:15:04 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:04 --> Config Class Initialized
INFO - 2020-10-19 15:15:04 --> Config Class Initialized
INFO - 2020-10-19 15:15:04 --> Config Class Initialized
INFO - 2020-10-19 15:15:04 --> Config Class Initialized
INFO - 2020-10-19 15:15:04 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:04 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:04 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:04 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:04 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:04 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:04 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:04 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:05 --> URI Class Initialized
INFO - 2020-10-19 15:15:05 --> Router Class Initialized
INFO - 2020-10-19 15:15:05 --> Output Class Initialized
INFO - 2020-10-19 15:15:05 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:05 --> Input Class Initialized
INFO - 2020-10-19 15:15:05 --> Language Class Initialized
ERROR - 2020-10-19 15:15:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:05 --> Config Class Initialized
INFO - 2020-10-19 15:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:05 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:06 --> URI Class Initialized
INFO - 2020-10-19 15:15:06 --> Router Class Initialized
INFO - 2020-10-19 15:15:06 --> Output Class Initialized
INFO - 2020-10-19 15:15:06 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:06 --> Input Class Initialized
INFO - 2020-10-19 15:15:06 --> Language Class Initialized
ERROR - 2020-10-19 15:15:06 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:06 --> Config Class Initialized
INFO - 2020-10-19 15:15:06 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:06 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:06 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:06 --> URI Class Initialized
INFO - 2020-10-19 15:15:06 --> Router Class Initialized
INFO - 2020-10-19 15:15:06 --> Output Class Initialized
INFO - 2020-10-19 15:15:06 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:06 --> Input Class Initialized
INFO - 2020-10-19 15:15:06 --> Language Class Initialized
ERROR - 2020-10-19 15:15:06 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:06 --> Config Class Initialized
INFO - 2020-10-19 15:15:06 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:06 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:06 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:06 --> URI Class Initialized
INFO - 2020-10-19 15:15:06 --> Router Class Initialized
INFO - 2020-10-19 15:15:06 --> Output Class Initialized
INFO - 2020-10-19 15:15:06 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:06 --> Input Class Initialized
INFO - 2020-10-19 15:15:06 --> Language Class Initialized
ERROR - 2020-10-19 15:15:06 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:06 --> Config Class Initialized
INFO - 2020-10-19 15:15:06 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:06 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:06 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:06 --> URI Class Initialized
INFO - 2020-10-19 15:15:06 --> Router Class Initialized
INFO - 2020-10-19 15:15:06 --> Output Class Initialized
INFO - 2020-10-19 15:15:06 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:06 --> Input Class Initialized
INFO - 2020-10-19 15:15:06 --> Language Class Initialized
ERROR - 2020-10-19 15:15:06 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:15 --> Config Class Initialized
INFO - 2020-10-19 15:15:15 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:15 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:15 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:15 --> URI Class Initialized
INFO - 2020-10-19 15:15:15 --> Router Class Initialized
INFO - 2020-10-19 15:15:15 --> Output Class Initialized
INFO - 2020-10-19 15:15:15 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:15 --> Input Class Initialized
INFO - 2020-10-19 15:15:15 --> Language Class Initialized
INFO - 2020-10-19 15:15:15 --> Loader Class Initialized
INFO - 2020-10-19 15:15:15 --> Helper loaded: url_helper
INFO - 2020-10-19 15:15:15 --> Helper loaded: form_helper
INFO - 2020-10-19 15:15:15 --> Helper loaded: html_helper
INFO - 2020-10-19 15:15:15 --> Helper loaded: date_helper
INFO - 2020-10-19 15:15:15 --> Database Driver Class Initialized
INFO - 2020-10-19 15:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:15:15 --> Table Class Initialized
INFO - 2020-10-19 15:15:15 --> Upload Class Initialized
INFO - 2020-10-19 15:15:15 --> Controller Class Initialized
INFO - 2020-10-19 15:15:15 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:15:15 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:15:15 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:15:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:15:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:15:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:15:15 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:15:15 --> Final output sent to browser
DEBUG - 2020-10-19 15:15:15 --> Total execution time: 0.1800
INFO - 2020-10-19 15:15:15 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:16 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:16 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:16 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:16 --> URI Class Initialized
INFO - 2020-10-19 15:15:16 --> Router Class Initialized
INFO - 2020-10-19 15:15:16 --> Output Class Initialized
INFO - 2020-10-19 15:15:16 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:16 --> Input Class Initialized
INFO - 2020-10-19 15:15:16 --> Language Class Initialized
ERROR - 2020-10-19 15:15:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:16 --> Config Class Initialized
INFO - 2020-10-19 15:15:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:17 --> URI Class Initialized
INFO - 2020-10-19 15:15:17 --> Router Class Initialized
INFO - 2020-10-19 15:15:17 --> Output Class Initialized
INFO - 2020-10-19 15:15:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:17 --> Input Class Initialized
INFO - 2020-10-19 15:15:17 --> Language Class Initialized
ERROR - 2020-10-19 15:15:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:17 --> Config Class Initialized
INFO - 2020-10-19 15:15:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:17 --> URI Class Initialized
INFO - 2020-10-19 15:15:17 --> Router Class Initialized
INFO - 2020-10-19 15:15:17 --> Output Class Initialized
INFO - 2020-10-19 15:15:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:17 --> Input Class Initialized
INFO - 2020-10-19 15:15:17 --> Language Class Initialized
ERROR - 2020-10-19 15:15:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:17 --> Config Class Initialized
INFO - 2020-10-19 15:15:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:17 --> URI Class Initialized
INFO - 2020-10-19 15:15:17 --> Router Class Initialized
INFO - 2020-10-19 15:15:17 --> Output Class Initialized
INFO - 2020-10-19 15:15:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:17 --> Input Class Initialized
INFO - 2020-10-19 15:15:17 --> Language Class Initialized
ERROR - 2020-10-19 15:15:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:17 --> Config Class Initialized
INFO - 2020-10-19 15:15:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:17 --> URI Class Initialized
INFO - 2020-10-19 15:15:17 --> Router Class Initialized
INFO - 2020-10-19 15:15:17 --> Output Class Initialized
INFO - 2020-10-19 15:15:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:17 --> Input Class Initialized
INFO - 2020-10-19 15:15:17 --> Language Class Initialized
ERROR - 2020-10-19 15:15:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:17 --> Config Class Initialized
INFO - 2020-10-19 15:15:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:17 --> URI Class Initialized
INFO - 2020-10-19 15:15:17 --> Router Class Initialized
INFO - 2020-10-19 15:15:17 --> Output Class Initialized
INFO - 2020-10-19 15:15:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:17 --> Input Class Initialized
INFO - 2020-10-19 15:15:17 --> Language Class Initialized
ERROR - 2020-10-19 15:15:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:17 --> Config Class Initialized
INFO - 2020-10-19 15:15:17 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:17 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:17 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:17 --> URI Class Initialized
INFO - 2020-10-19 15:15:17 --> Router Class Initialized
INFO - 2020-10-19 15:15:17 --> Output Class Initialized
INFO - 2020-10-19 15:15:17 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:17 --> Input Class Initialized
INFO - 2020-10-19 15:15:17 --> Language Class Initialized
ERROR - 2020-10-19 15:15:17 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Loader Class Initialized
INFO - 2020-10-19 15:15:20 --> Helper loaded: url_helper
INFO - 2020-10-19 15:15:20 --> Helper loaded: form_helper
INFO - 2020-10-19 15:15:20 --> Helper loaded: html_helper
INFO - 2020-10-19 15:15:20 --> Helper loaded: date_helper
INFO - 2020-10-19 15:15:20 --> Database Driver Class Initialized
INFO - 2020-10-19 15:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 15:15:20 --> Table Class Initialized
INFO - 2020-10-19 15:15:20 --> Upload Class Initialized
INFO - 2020-10-19 15:15:20 --> Controller Class Initialized
INFO - 2020-10-19 15:15:20 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 15:15:20 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 15:15:20 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 15:15:20 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 15:15:20 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 15:15:20 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 15:15:20 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 15:15:20 --> Final output sent to browser
DEBUG - 2020-10-19 15:15:20 --> Total execution time: 0.1976
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> URI Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Router Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Output Class Initialized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Security Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
INFO - 2020-10-19 15:15:20 --> Input Class Initialized
INFO - 2020-10-19 15:15:20 --> Language Class Initialized
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 15:15:20 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Config Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:20 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 15:15:20 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 15:15:21 --> Config Class Initialized
INFO - 2020-10-19 15:15:21 --> Hooks Class Initialized
DEBUG - 2020-10-19 15:15:21 --> UTF-8 Support Enabled
INFO - 2020-10-19 15:15:21 --> Utf8 Class Initialized
INFO - 2020-10-19 15:15:21 --> URI Class Initialized
INFO - 2020-10-19 15:15:21 --> Router Class Initialized
INFO - 2020-10-19 15:15:21 --> Output Class Initialized
INFO - 2020-10-19 15:15:21 --> Security Class Initialized
DEBUG - 2020-10-19 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 15:15:21 --> Input Class Initialized
INFO - 2020-10-19 15:15:21 --> Language Class Initialized
ERROR - 2020-10-19 15:15:21 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:40:44 --> Config Class Initialized
INFO - 2020-10-19 17:40:44 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:44 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:44 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:44 --> URI Class Initialized
DEBUG - 2020-10-19 17:40:44 --> No URI present. Default controller set.
INFO - 2020-10-19 17:40:44 --> Router Class Initialized
INFO - 2020-10-19 17:40:44 --> Output Class Initialized
INFO - 2020-10-19 17:40:44 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:44 --> Input Class Initialized
INFO - 2020-10-19 17:40:44 --> Language Class Initialized
ERROR - 2020-10-19 17:40:44 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-19 17:40:44 --> Config Class Initialized
INFO - 2020-10-19 17:40:44 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:44 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:44 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:44 --> URI Class Initialized
INFO - 2020-10-19 17:40:44 --> Router Class Initialized
INFO - 2020-10-19 17:40:44 --> Output Class Initialized
INFO - 2020-10-19 17:40:44 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:44 --> Input Class Initialized
INFO - 2020-10-19 17:40:44 --> Language Class Initialized
ERROR - 2020-10-19 17:40:44 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Loader Class Initialized
INFO - 2020-10-19 17:40:49 --> Helper loaded: url_helper
INFO - 2020-10-19 17:40:49 --> Helper loaded: form_helper
INFO - 2020-10-19 17:40:49 --> Helper loaded: html_helper
INFO - 2020-10-19 17:40:49 --> Helper loaded: date_helper
INFO - 2020-10-19 17:40:49 --> Database Driver Class Initialized
INFO - 2020-10-19 17:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 17:40:49 --> Table Class Initialized
INFO - 2020-10-19 17:40:49 --> Upload Class Initialized
INFO - 2020-10-19 17:40:49 --> Controller Class Initialized
INFO - 2020-10-19 17:40:49 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 17:40:49 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 17:40:49 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 17:40:49 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 17:40:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 17:40:49 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 17:40:49 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 17:40:49 --> Final output sent to browser
DEBUG - 2020-10-19 17:40:49 --> Total execution time: 0.2323
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Config Class Initialized
INFO - 2020-10-19 17:40:49 --> Hooks Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
DEBUG - 2020-10-19 17:40:49 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
INFO - 2020-10-19 17:40:49 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> URI Class Initialized
INFO - 2020-10-19 17:40:49 --> Router Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
INFO - 2020-10-19 17:40:49 --> Output Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:40:49 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:49 --> Input Class Initialized
INFO - 2020-10-19 17:40:49 --> Language Class Initialized
ERROR - 2020-10-19 17:40:49 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:40:50 --> Config Class Initialized
INFO - 2020-10-19 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:50 --> URI Class Initialized
INFO - 2020-10-19 17:40:50 --> Router Class Initialized
INFO - 2020-10-19 17:40:50 --> Output Class Initialized
INFO - 2020-10-19 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:50 --> Input Class Initialized
INFO - 2020-10-19 17:40:50 --> Language Class Initialized
INFO - 2020-10-19 17:40:50 --> Loader Class Initialized
INFO - 2020-10-19 17:40:50 --> Helper loaded: url_helper
INFO - 2020-10-19 17:40:50 --> Helper loaded: form_helper
INFO - 2020-10-19 17:40:50 --> Helper loaded: html_helper
INFO - 2020-10-19 17:40:50 --> Helper loaded: date_helper
INFO - 2020-10-19 17:40:50 --> Database Driver Class Initialized
INFO - 2020-10-19 17:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 17:40:50 --> Table Class Initialized
INFO - 2020-10-19 17:40:50 --> Upload Class Initialized
INFO - 2020-10-19 17:40:50 --> Controller Class Initialized
INFO - 2020-10-19 17:40:50 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 17:40:50 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 17:40:50 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 17:40:50 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 17:40:50 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 17:40:50 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 17:40:50 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 17:40:50 --> Final output sent to browser
DEBUG - 2020-10-19 17:40:50 --> Total execution time: 0.2026
INFO - 2020-10-19 17:40:50 --> Config Class Initialized
INFO - 2020-10-19 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:50 --> URI Class Initialized
INFO - 2020-10-19 17:40:50 --> Router Class Initialized
INFO - 2020-10-19 17:40:50 --> Output Class Initialized
INFO - 2020-10-19 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:50 --> Input Class Initialized
INFO - 2020-10-19 17:40:50 --> Language Class Initialized
ERROR - 2020-10-19 17:40:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:50 --> Config Class Initialized
INFO - 2020-10-19 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:50 --> URI Class Initialized
INFO - 2020-10-19 17:40:50 --> Router Class Initialized
INFO - 2020-10-19 17:40:50 --> Output Class Initialized
INFO - 2020-10-19 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:50 --> Input Class Initialized
INFO - 2020-10-19 17:40:50 --> Language Class Initialized
ERROR - 2020-10-19 17:40:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:50 --> Config Class Initialized
INFO - 2020-10-19 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:50 --> URI Class Initialized
INFO - 2020-10-19 17:40:50 --> Router Class Initialized
INFO - 2020-10-19 17:40:50 --> Output Class Initialized
INFO - 2020-10-19 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:50 --> Input Class Initialized
INFO - 2020-10-19 17:40:50 --> Language Class Initialized
ERROR - 2020-10-19 17:40:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:50 --> Config Class Initialized
INFO - 2020-10-19 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:50 --> URI Class Initialized
INFO - 2020-10-19 17:40:50 --> Router Class Initialized
INFO - 2020-10-19 17:40:50 --> Output Class Initialized
INFO - 2020-10-19 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:50 --> Input Class Initialized
INFO - 2020-10-19 17:40:50 --> Language Class Initialized
ERROR - 2020-10-19 17:40:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:50 --> Config Class Initialized
INFO - 2020-10-19 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:50 --> URI Class Initialized
INFO - 2020-10-19 17:40:50 --> Router Class Initialized
INFO - 2020-10-19 17:40:50 --> Output Class Initialized
INFO - 2020-10-19 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:50 --> Input Class Initialized
INFO - 2020-10-19 17:40:50 --> Language Class Initialized
ERROR - 2020-10-19 17:40:50 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:50 --> Config Class Initialized
INFO - 2020-10-19 17:40:50 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:50 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:50 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:50 --> URI Class Initialized
INFO - 2020-10-19 17:40:50 --> Router Class Initialized
INFO - 2020-10-19 17:40:50 --> Output Class Initialized
INFO - 2020-10-19 17:40:50 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:50 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:40:51 --> Config Class Initialized
INFO - 2020-10-19 17:40:51 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:51 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:51 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:51 --> URI Class Initialized
INFO - 2020-10-19 17:40:51 --> Router Class Initialized
INFO - 2020-10-19 17:40:51 --> Output Class Initialized
INFO - 2020-10-19 17:40:51 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:51 --> Input Class Initialized
INFO - 2020-10-19 17:40:51 --> Language Class Initialized
ERROR - 2020-10-19 17:40:51 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:40:52 --> Config Class Initialized
INFO - 2020-10-19 17:40:52 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:40:52 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:40:52 --> Utf8 Class Initialized
INFO - 2020-10-19 17:40:52 --> URI Class Initialized
INFO - 2020-10-19 17:40:52 --> Router Class Initialized
INFO - 2020-10-19 17:40:52 --> Output Class Initialized
INFO - 2020-10-19 17:40:52 --> Security Class Initialized
DEBUG - 2020-10-19 17:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:40:52 --> Input Class Initialized
INFO - 2020-10-19 17:40:52 --> Language Class Initialized
ERROR - 2020-10-19 17:40:52 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Loader Class Initialized
INFO - 2020-10-19 17:41:01 --> Helper loaded: url_helper
INFO - 2020-10-19 17:41:01 --> Helper loaded: form_helper
INFO - 2020-10-19 17:41:01 --> Helper loaded: html_helper
INFO - 2020-10-19 17:41:01 --> Helper loaded: date_helper
INFO - 2020-10-19 17:41:01 --> Database Driver Class Initialized
INFO - 2020-10-19 17:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-19 17:41:01 --> Table Class Initialized
INFO - 2020-10-19 17:41:01 --> Upload Class Initialized
INFO - 2020-10-19 17:41:01 --> Controller Class Initialized
INFO - 2020-10-19 17:41:01 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-19 17:41:01 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-19 17:41:01 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-19 17:41:01 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-19 17:41:01 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-19 17:41:01 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-19 17:41:01 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-19 17:41:01 --> Final output sent to browser
DEBUG - 2020-10-19 17:41:01 --> Total execution time: 0.2215
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Security Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Input Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
INFO - 2020-10-19 17:41:01 --> Language Class Initialized
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:41:01 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:01 --> Config Class Initialized
INFO - 2020-10-19 17:41:01 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:01 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> URI Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Router Class Initialized
INFO - 2020-10-19 17:41:01 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Dist/img
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-19 17:41:02 --> Config Class Initialized
INFO - 2020-10-19 17:41:02 --> Hooks Class Initialized
DEBUG - 2020-10-19 17:41:02 --> UTF-8 Support Enabled
INFO - 2020-10-19 17:41:02 --> Utf8 Class Initialized
INFO - 2020-10-19 17:41:02 --> URI Class Initialized
INFO - 2020-10-19 17:41:02 --> Router Class Initialized
INFO - 2020-10-19 17:41:02 --> Output Class Initialized
INFO - 2020-10-19 17:41:02 --> Security Class Initialized
DEBUG - 2020-10-19 17:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-19 17:41:02 --> Input Class Initialized
INFO - 2020-10-19 17:41:02 --> Language Class Initialized
ERROR - 2020-10-19 17:41:02 --> 404 Page Not Found: Dist/img

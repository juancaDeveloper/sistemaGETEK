<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-02 14:08:10 --> Config Class Initialized
INFO - 2020-11-02 14:08:10 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:08:10 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:08:10 --> Utf8 Class Initialized
INFO - 2020-11-02 14:08:10 --> URI Class Initialized
DEBUG - 2020-11-02 14:08:10 --> No URI present. Default controller set.
INFO - 2020-11-02 14:08:10 --> Router Class Initialized
INFO - 2020-11-02 14:08:10 --> Output Class Initialized
INFO - 2020-11-02 14:08:10 --> Security Class Initialized
DEBUG - 2020-11-02 14:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:08:10 --> Input Class Initialized
INFO - 2020-11-02 14:08:10 --> Language Class Initialized
INFO - 2020-11-02 14:08:10 --> Loader Class Initialized
INFO - 2020-11-02 14:08:10 --> Helper loaded: url_helper
INFO - 2020-11-02 14:08:10 --> Helper loaded: form_helper
INFO - 2020-11-02 14:08:10 --> Helper loaded: html_helper
INFO - 2020-11-02 14:08:10 --> Helper loaded: date_helper
INFO - 2020-11-02 14:08:10 --> Database Driver Class Initialized
INFO - 2020-11-02 14:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:08:10 --> Table Class Initialized
INFO - 2020-11-02 14:08:10 --> Upload Class Initialized
INFO - 2020-11-02 14:08:10 --> Controller Class Initialized
INFO - 2020-11-02 14:08:10 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:08:10 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:08:10 --> Final output sent to browser
DEBUG - 2020-11-02 14:08:10 --> Total execution time: 0.1092
INFO - 2020-11-02 14:08:11 --> Config Class Initialized
INFO - 2020-11-02 14:08:11 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:08:11 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:08:11 --> Utf8 Class Initialized
INFO - 2020-11-02 14:08:11 --> URI Class Initialized
INFO - 2020-11-02 14:08:11 --> Router Class Initialized
INFO - 2020-11-02 14:08:11 --> Output Class Initialized
INFO - 2020-11-02 14:08:11 --> Security Class Initialized
DEBUG - 2020-11-02 14:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:08:11 --> Input Class Initialized
INFO - 2020-11-02 14:08:11 --> Language Class Initialized
ERROR - 2020-11-02 14:08:11 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-11-02 14:08:27 --> Config Class Initialized
INFO - 2020-11-02 14:08:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:08:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:08:27 --> Utf8 Class Initialized
INFO - 2020-11-02 14:08:27 --> URI Class Initialized
INFO - 2020-11-02 14:08:27 --> Router Class Initialized
INFO - 2020-11-02 14:08:27 --> Output Class Initialized
INFO - 2020-11-02 14:08:27 --> Security Class Initialized
DEBUG - 2020-11-02 14:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:08:27 --> Input Class Initialized
INFO - 2020-11-02 14:08:27 --> Language Class Initialized
INFO - 2020-11-02 14:08:27 --> Loader Class Initialized
INFO - 2020-11-02 14:08:27 --> Helper loaded: url_helper
INFO - 2020-11-02 14:08:27 --> Helper loaded: form_helper
INFO - 2020-11-02 14:08:27 --> Helper loaded: html_helper
INFO - 2020-11-02 14:08:27 --> Helper loaded: date_helper
INFO - 2020-11-02 14:08:27 --> Database Driver Class Initialized
INFO - 2020-11-02 14:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:08:27 --> Table Class Initialized
INFO - 2020-11-02 14:08:27 --> Upload Class Initialized
INFO - 2020-11-02 14:08:27 --> Controller Class Initialized
INFO - 2020-11-02 14:08:27 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:08:27 --> Config Class Initialized
INFO - 2020-11-02 14:08:27 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:08:27 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:08:27 --> Utf8 Class Initialized
INFO - 2020-11-02 14:08:27 --> URI Class Initialized
DEBUG - 2020-11-02 14:08:27 --> No URI present. Default controller set.
INFO - 2020-11-02 14:08:27 --> Router Class Initialized
INFO - 2020-11-02 14:08:27 --> Output Class Initialized
INFO - 2020-11-02 14:08:27 --> Security Class Initialized
DEBUG - 2020-11-02 14:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:08:27 --> Input Class Initialized
INFO - 2020-11-02 14:08:27 --> Language Class Initialized
INFO - 2020-11-02 14:08:27 --> Loader Class Initialized
INFO - 2020-11-02 14:08:27 --> Helper loaded: url_helper
INFO - 2020-11-02 14:08:27 --> Helper loaded: form_helper
INFO - 2020-11-02 14:08:27 --> Helper loaded: html_helper
INFO - 2020-11-02 14:08:27 --> Helper loaded: date_helper
INFO - 2020-11-02 14:08:27 --> Database Driver Class Initialized
INFO - 2020-11-02 14:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:08:27 --> Table Class Initialized
INFO - 2020-11-02 14:08:27 --> Upload Class Initialized
INFO - 2020-11-02 14:08:27 --> Controller Class Initialized
INFO - 2020-11-02 14:08:27 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:08:27 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:08:27 --> Final output sent to browser
DEBUG - 2020-11-02 14:08:27 --> Total execution time: 0.0553
INFO - 2020-11-02 14:08:33 --> Config Class Initialized
INFO - 2020-11-02 14:08:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:08:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:08:33 --> Utf8 Class Initialized
INFO - 2020-11-02 14:08:33 --> URI Class Initialized
INFO - 2020-11-02 14:08:33 --> Router Class Initialized
INFO - 2020-11-02 14:08:33 --> Output Class Initialized
INFO - 2020-11-02 14:08:33 --> Security Class Initialized
DEBUG - 2020-11-02 14:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:08:33 --> Input Class Initialized
INFO - 2020-11-02 14:08:33 --> Language Class Initialized
INFO - 2020-11-02 14:08:33 --> Loader Class Initialized
INFO - 2020-11-02 14:08:33 --> Helper loaded: url_helper
INFO - 2020-11-02 14:08:33 --> Helper loaded: form_helper
INFO - 2020-11-02 14:08:33 --> Helper loaded: html_helper
INFO - 2020-11-02 14:08:33 --> Helper loaded: date_helper
INFO - 2020-11-02 14:08:33 --> Database Driver Class Initialized
INFO - 2020-11-02 14:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:08:33 --> Table Class Initialized
INFO - 2020-11-02 14:08:33 --> Upload Class Initialized
INFO - 2020-11-02 14:08:33 --> Controller Class Initialized
INFO - 2020-11-02 14:08:33 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:08:33 --> Config Class Initialized
INFO - 2020-11-02 14:08:33 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:08:33 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:08:33 --> Utf8 Class Initialized
INFO - 2020-11-02 14:08:33 --> URI Class Initialized
DEBUG - 2020-11-02 14:08:33 --> No URI present. Default controller set.
INFO - 2020-11-02 14:08:33 --> Router Class Initialized
INFO - 2020-11-02 14:08:33 --> Output Class Initialized
INFO - 2020-11-02 14:08:33 --> Security Class Initialized
DEBUG - 2020-11-02 14:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:08:33 --> Input Class Initialized
INFO - 2020-11-02 14:08:33 --> Language Class Initialized
INFO - 2020-11-02 14:08:33 --> Loader Class Initialized
INFO - 2020-11-02 14:08:33 --> Helper loaded: url_helper
INFO - 2020-11-02 14:08:33 --> Helper loaded: form_helper
INFO - 2020-11-02 14:08:33 --> Helper loaded: html_helper
INFO - 2020-11-02 14:08:33 --> Helper loaded: date_helper
INFO - 2020-11-02 14:08:33 --> Database Driver Class Initialized
INFO - 2020-11-02 14:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:08:33 --> Table Class Initialized
INFO - 2020-11-02 14:08:33 --> Upload Class Initialized
INFO - 2020-11-02 14:08:33 --> Controller Class Initialized
INFO - 2020-11-02 14:08:33 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:08:33 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:08:33 --> Final output sent to browser
DEBUG - 2020-11-02 14:08:33 --> Total execution time: 0.0344
INFO - 2020-11-02 14:09:23 --> Config Class Initialized
INFO - 2020-11-02 14:09:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:23 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:23 --> URI Class Initialized
INFO - 2020-11-02 14:09:23 --> Router Class Initialized
INFO - 2020-11-02 14:09:23 --> Output Class Initialized
INFO - 2020-11-02 14:09:23 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:23 --> Input Class Initialized
INFO - 2020-11-02 14:09:23 --> Language Class Initialized
INFO - 2020-11-02 14:09:23 --> Loader Class Initialized
INFO - 2020-11-02 14:09:23 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:23 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:23 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:23 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:23 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:23 --> Table Class Initialized
INFO - 2020-11-02 14:09:23 --> Upload Class Initialized
INFO - 2020-11-02 14:09:23 --> Controller Class Initialized
INFO - 2020-11-02 14:09:23 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:09:23 --> Config Class Initialized
INFO - 2020-11-02 14:09:23 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:23 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:23 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:23 --> URI Class Initialized
DEBUG - 2020-11-02 14:09:23 --> No URI present. Default controller set.
INFO - 2020-11-02 14:09:23 --> Router Class Initialized
INFO - 2020-11-02 14:09:23 --> Output Class Initialized
INFO - 2020-11-02 14:09:23 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:23 --> Input Class Initialized
INFO - 2020-11-02 14:09:23 --> Language Class Initialized
INFO - 2020-11-02 14:09:23 --> Loader Class Initialized
INFO - 2020-11-02 14:09:23 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:23 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:23 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:23 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:23 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:23 --> Table Class Initialized
INFO - 2020-11-02 14:09:23 --> Upload Class Initialized
INFO - 2020-11-02 14:09:23 --> Controller Class Initialized
INFO - 2020-11-02 14:09:23 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:09:23 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:09:23 --> Final output sent to browser
DEBUG - 2020-11-02 14:09:23 --> Total execution time: 0.0324
INFO - 2020-11-02 14:09:29 --> Config Class Initialized
INFO - 2020-11-02 14:09:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:29 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:29 --> URI Class Initialized
INFO - 2020-11-02 14:09:29 --> Router Class Initialized
INFO - 2020-11-02 14:09:29 --> Output Class Initialized
INFO - 2020-11-02 14:09:29 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:29 --> Input Class Initialized
INFO - 2020-11-02 14:09:29 --> Language Class Initialized
INFO - 2020-11-02 14:09:29 --> Loader Class Initialized
INFO - 2020-11-02 14:09:29 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:29 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:29 --> Table Class Initialized
INFO - 2020-11-02 14:09:29 --> Upload Class Initialized
INFO - 2020-11-02 14:09:29 --> Controller Class Initialized
INFO - 2020-11-02 14:09:29 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:09:29 --> Config Class Initialized
INFO - 2020-11-02 14:09:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:29 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:29 --> URI Class Initialized
INFO - 2020-11-02 14:09:29 --> Router Class Initialized
INFO - 2020-11-02 14:09:29 --> Output Class Initialized
INFO - 2020-11-02 14:09:29 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:29 --> Input Class Initialized
INFO - 2020-11-02 14:09:29 --> Language Class Initialized
INFO - 2020-11-02 14:09:29 --> Loader Class Initialized
INFO - 2020-11-02 14:09:29 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:29 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:29 --> Table Class Initialized
INFO - 2020-11-02 14:09:29 --> Upload Class Initialized
INFO - 2020-11-02 14:09:29 --> Controller Class Initialized
INFO - 2020-11-02 14:09:29 --> Form Validation Class Initialized
INFO - 2020-11-02 14:09:29 --> Model "Crud_model" initialized
INFO - 2020-11-02 14:09:29 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-11-02 14:09:29 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-11-02 14:09:29 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-11-02 14:09:29 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-11-02 14:09:29 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-11-02 14:09:29 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-11-02 14:09:29 --> Final output sent to browser
DEBUG - 2020-11-02 14:09:29 --> Total execution time: 0.0755
INFO - 2020-11-02 14:09:29 --> Config Class Initialized
INFO - 2020-11-02 14:09:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:29 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:29 --> URI Class Initialized
INFO - 2020-11-02 14:09:29 --> Router Class Initialized
INFO - 2020-11-02 14:09:29 --> Output Class Initialized
INFO - 2020-11-02 14:09:29 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:29 --> Input Class Initialized
INFO - 2020-11-02 14:09:29 --> Language Class Initialized
ERROR - 2020-11-02 14:09:29 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-02 14:09:29 --> Config Class Initialized
INFO - 2020-11-02 14:09:29 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:29 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:29 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:29 --> URI Class Initialized
INFO - 2020-11-02 14:09:29 --> Router Class Initialized
INFO - 2020-11-02 14:09:29 --> Output Class Initialized
INFO - 2020-11-02 14:09:29 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:29 --> Input Class Initialized
INFO - 2020-11-02 14:09:29 --> Language Class Initialized
INFO - 2020-11-02 14:09:29 --> Loader Class Initialized
INFO - 2020-11-02 14:09:29 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:29 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:29 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:29 --> Table Class Initialized
INFO - 2020-11-02 14:09:29 --> Upload Class Initialized
INFO - 2020-11-02 14:09:29 --> Controller Class Initialized
INFO - 2020-11-02 14:09:29 --> Form Validation Class Initialized
INFO - 2020-11-02 14:09:29 --> Model "Crud_model" initialized
ERROR - 2020-11-02 14:09:29 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-11-02 14:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-02 14:09:30 --> Config Class Initialized
INFO - 2020-11-02 14:09:30 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:30 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:30 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:30 --> URI Class Initialized
INFO - 2020-11-02 14:09:30 --> Router Class Initialized
INFO - 2020-11-02 14:09:30 --> Output Class Initialized
INFO - 2020-11-02 14:09:30 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:30 --> Input Class Initialized
INFO - 2020-11-02 14:09:30 --> Language Class Initialized
ERROR - 2020-11-02 14:09:30 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-02 14:09:46 --> Config Class Initialized
INFO - 2020-11-02 14:09:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:46 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:46 --> URI Class Initialized
INFO - 2020-11-02 14:09:46 --> Router Class Initialized
INFO - 2020-11-02 14:09:46 --> Output Class Initialized
INFO - 2020-11-02 14:09:46 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:46 --> Input Class Initialized
INFO - 2020-11-02 14:09:46 --> Language Class Initialized
INFO - 2020-11-02 14:09:46 --> Loader Class Initialized
INFO - 2020-11-02 14:09:46 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:46 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:46 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:46 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:46 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:46 --> Table Class Initialized
INFO - 2020-11-02 14:09:46 --> Upload Class Initialized
INFO - 2020-11-02 14:09:46 --> Controller Class Initialized
INFO - 2020-11-02 14:09:46 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:09:46 --> Config Class Initialized
INFO - 2020-11-02 14:09:46 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:46 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:46 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:46 --> URI Class Initialized
DEBUG - 2020-11-02 14:09:46 --> No URI present. Default controller set.
INFO - 2020-11-02 14:09:46 --> Router Class Initialized
INFO - 2020-11-02 14:09:46 --> Output Class Initialized
INFO - 2020-11-02 14:09:46 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:46 --> Input Class Initialized
INFO - 2020-11-02 14:09:46 --> Language Class Initialized
INFO - 2020-11-02 14:09:46 --> Loader Class Initialized
INFO - 2020-11-02 14:09:46 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:46 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:46 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:46 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:46 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:46 --> Table Class Initialized
INFO - 2020-11-02 14:09:46 --> Upload Class Initialized
INFO - 2020-11-02 14:09:46 --> Controller Class Initialized
INFO - 2020-11-02 14:09:46 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:09:46 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:09:46 --> Final output sent to browser
DEBUG - 2020-11-02 14:09:46 --> Total execution time: 0.0565
INFO - 2020-11-02 14:09:50 --> Config Class Initialized
INFO - 2020-11-02 14:09:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:50 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:50 --> URI Class Initialized
INFO - 2020-11-02 14:09:50 --> Router Class Initialized
INFO - 2020-11-02 14:09:50 --> Output Class Initialized
INFO - 2020-11-02 14:09:50 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:50 --> Input Class Initialized
INFO - 2020-11-02 14:09:50 --> Language Class Initialized
INFO - 2020-11-02 14:09:50 --> Loader Class Initialized
INFO - 2020-11-02 14:09:50 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:50 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:50 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:50 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:50 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:50 --> Table Class Initialized
INFO - 2020-11-02 14:09:50 --> Upload Class Initialized
INFO - 2020-11-02 14:09:50 --> Controller Class Initialized
INFO - 2020-11-02 14:09:50 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:09:50 --> Config Class Initialized
INFO - 2020-11-02 14:09:50 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:09:50 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:09:50 --> Utf8 Class Initialized
INFO - 2020-11-02 14:09:50 --> URI Class Initialized
DEBUG - 2020-11-02 14:09:50 --> No URI present. Default controller set.
INFO - 2020-11-02 14:09:50 --> Router Class Initialized
INFO - 2020-11-02 14:09:50 --> Output Class Initialized
INFO - 2020-11-02 14:09:50 --> Security Class Initialized
DEBUG - 2020-11-02 14:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:09:50 --> Input Class Initialized
INFO - 2020-11-02 14:09:50 --> Language Class Initialized
INFO - 2020-11-02 14:09:50 --> Loader Class Initialized
INFO - 2020-11-02 14:09:50 --> Helper loaded: url_helper
INFO - 2020-11-02 14:09:50 --> Helper loaded: form_helper
INFO - 2020-11-02 14:09:50 --> Helper loaded: html_helper
INFO - 2020-11-02 14:09:50 --> Helper loaded: date_helper
INFO - 2020-11-02 14:09:50 --> Database Driver Class Initialized
INFO - 2020-11-02 14:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:09:50 --> Table Class Initialized
INFO - 2020-11-02 14:09:50 --> Upload Class Initialized
INFO - 2020-11-02 14:09:50 --> Controller Class Initialized
INFO - 2020-11-02 14:09:50 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:09:50 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:09:50 --> Final output sent to browser
DEBUG - 2020-11-02 14:09:50 --> Total execution time: 0.0398
INFO - 2020-11-02 14:54:36 --> Config Class Initialized
INFO - 2020-11-02 14:54:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:54:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:54:36 --> Utf8 Class Initialized
INFO - 2020-11-02 14:54:36 --> URI Class Initialized
DEBUG - 2020-11-02 14:54:36 --> No URI present. Default controller set.
INFO - 2020-11-02 14:54:36 --> Router Class Initialized
INFO - 2020-11-02 14:54:36 --> Output Class Initialized
INFO - 2020-11-02 14:54:36 --> Security Class Initialized
DEBUG - 2020-11-02 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:54:36 --> Input Class Initialized
INFO - 2020-11-02 14:54:36 --> Language Class Initialized
INFO - 2020-11-02 14:54:36 --> Loader Class Initialized
INFO - 2020-11-02 14:54:36 --> Helper loaded: url_helper
INFO - 2020-11-02 14:54:36 --> Helper loaded: form_helper
INFO - 2020-11-02 14:54:36 --> Helper loaded: html_helper
INFO - 2020-11-02 14:54:36 --> Helper loaded: date_helper
INFO - 2020-11-02 14:54:36 --> Database Driver Class Initialized
INFO - 2020-11-02 14:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:54:36 --> Table Class Initialized
INFO - 2020-11-02 14:54:36 --> Upload Class Initialized
INFO - 2020-11-02 14:54:36 --> Controller Class Initialized
INFO - 2020-11-02 14:54:36 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:54:36 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:54:36 --> Final output sent to browser
DEBUG - 2020-11-02 14:54:36 --> Total execution time: 0.0735
INFO - 2020-11-02 14:54:36 --> Config Class Initialized
INFO - 2020-11-02 14:54:36 --> Hooks Class Initialized
DEBUG - 2020-11-02 14:54:36 --> UTF-8 Support Enabled
INFO - 2020-11-02 14:54:36 --> Utf8 Class Initialized
INFO - 2020-11-02 14:54:36 --> URI Class Initialized
DEBUG - 2020-11-02 14:54:36 --> No URI present. Default controller set.
INFO - 2020-11-02 14:54:36 --> Router Class Initialized
INFO - 2020-11-02 14:54:36 --> Output Class Initialized
INFO - 2020-11-02 14:54:36 --> Security Class Initialized
DEBUG - 2020-11-02 14:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 14:54:36 --> Input Class Initialized
INFO - 2020-11-02 14:54:36 --> Language Class Initialized
INFO - 2020-11-02 14:54:36 --> Loader Class Initialized
INFO - 2020-11-02 14:54:36 --> Helper loaded: url_helper
INFO - 2020-11-02 14:54:36 --> Helper loaded: form_helper
INFO - 2020-11-02 14:54:37 --> Helper loaded: html_helper
INFO - 2020-11-02 14:54:37 --> Helper loaded: date_helper
INFO - 2020-11-02 14:54:37 --> Database Driver Class Initialized
INFO - 2020-11-02 14:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 14:54:37 --> Table Class Initialized
INFO - 2020-11-02 14:54:37 --> Upload Class Initialized
INFO - 2020-11-02 14:54:37 --> Controller Class Initialized
INFO - 2020-11-02 14:54:37 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 14:54:37 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 14:54:37 --> Final output sent to browser
DEBUG - 2020-11-02 14:54:37 --> Total execution time: 0.0519
INFO - 2020-11-02 15:04:52 --> Config Class Initialized
INFO - 2020-11-02 15:04:52 --> Hooks Class Initialized
DEBUG - 2020-11-02 15:04:52 --> UTF-8 Support Enabled
INFO - 2020-11-02 15:04:52 --> Utf8 Class Initialized
INFO - 2020-11-02 15:04:52 --> URI Class Initialized
DEBUG - 2020-11-02 15:04:52 --> No URI present. Default controller set.
INFO - 2020-11-02 15:04:52 --> Router Class Initialized
INFO - 2020-11-02 15:04:52 --> Output Class Initialized
INFO - 2020-11-02 15:04:52 --> Security Class Initialized
DEBUG - 2020-11-02 15:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-02 15:04:52 --> Input Class Initialized
INFO - 2020-11-02 15:04:52 --> Language Class Initialized
INFO - 2020-11-02 15:04:52 --> Loader Class Initialized
INFO - 2020-11-02 15:04:52 --> Helper loaded: url_helper
INFO - 2020-11-02 15:04:52 --> Helper loaded: form_helper
INFO - 2020-11-02 15:04:52 --> Helper loaded: html_helper
INFO - 2020-11-02 15:04:52 --> Helper loaded: date_helper
INFO - 2020-11-02 15:04:52 --> Database Driver Class Initialized
INFO - 2020-11-02 15:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-02 15:04:52 --> Table Class Initialized
INFO - 2020-11-02 15:04:52 --> Upload Class Initialized
INFO - 2020-11-02 15:04:52 --> Controller Class Initialized
INFO - 2020-11-02 15:04:52 --> Model "Usuarios_model" initialized
INFO - 2020-11-02 15:04:52 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-02 15:04:52 --> Final output sent to browser
DEBUG - 2020-11-02 15:04:52 --> Total execution time: 0.0401

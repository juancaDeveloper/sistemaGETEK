<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-09 13:23:54 --> Config Class Initialized
INFO - 2020-11-09 13:23:54 --> Hooks Class Initialized
DEBUG - 2020-11-09 13:23:54 --> UTF-8 Support Enabled
INFO - 2020-11-09 13:23:54 --> Utf8 Class Initialized
INFO - 2020-11-09 13:23:54 --> URI Class Initialized
DEBUG - 2020-11-09 13:23:54 --> No URI present. Default controller set.
INFO - 2020-11-09 13:23:54 --> Router Class Initialized
INFO - 2020-11-09 13:23:54 --> Output Class Initialized
INFO - 2020-11-09 13:23:54 --> Security Class Initialized
DEBUG - 2020-11-09 13:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 13:23:54 --> Input Class Initialized
INFO - 2020-11-09 13:23:54 --> Language Class Initialized
INFO - 2020-11-09 13:23:54 --> Loader Class Initialized
INFO - 2020-11-09 13:23:54 --> Helper loaded: url_helper
INFO - 2020-11-09 13:23:54 --> Helper loaded: form_helper
INFO - 2020-11-09 13:23:54 --> Helper loaded: html_helper
INFO - 2020-11-09 13:23:54 --> Helper loaded: date_helper
INFO - 2020-11-09 13:23:54 --> Database Driver Class Initialized
INFO - 2020-11-09 13:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 13:23:54 --> Table Class Initialized
INFO - 2020-11-09 13:23:54 --> Upload Class Initialized
INFO - 2020-11-09 13:23:54 --> Controller Class Initialized
INFO - 2020-11-09 13:23:54 --> Model "Usuarios_model" initialized
INFO - 2020-11-09 13:23:54 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-09 13:23:54 --> Final output sent to browser
DEBUG - 2020-11-09 13:23:54 --> Total execution time: 0.1457
INFO - 2020-11-09 13:23:55 --> Config Class Initialized
INFO - 2020-11-09 13:23:55 --> Hooks Class Initialized
DEBUG - 2020-11-09 13:23:55 --> UTF-8 Support Enabled
INFO - 2020-11-09 13:23:55 --> Utf8 Class Initialized
INFO - 2020-11-09 13:23:55 --> URI Class Initialized
INFO - 2020-11-09 13:23:55 --> Router Class Initialized
INFO - 2020-11-09 13:23:55 --> Output Class Initialized
INFO - 2020-11-09 13:23:55 --> Security Class Initialized
DEBUG - 2020-11-09 13:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 13:23:55 --> Input Class Initialized
INFO - 2020-11-09 13:23:55 --> Language Class Initialized
ERROR - 2020-11-09 13:23:55 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-11-09 13:24:57 --> Config Class Initialized
INFO - 2020-11-09 13:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-09 13:24:57 --> UTF-8 Support Enabled
INFO - 2020-11-09 13:24:57 --> Utf8 Class Initialized
INFO - 2020-11-09 13:24:57 --> URI Class Initialized
INFO - 2020-11-09 13:24:57 --> Router Class Initialized
INFO - 2020-11-09 13:24:57 --> Output Class Initialized
INFO - 2020-11-09 13:24:57 --> Security Class Initialized
DEBUG - 2020-11-09 13:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 13:24:57 --> Input Class Initialized
INFO - 2020-11-09 13:24:57 --> Language Class Initialized
INFO - 2020-11-09 13:24:57 --> Loader Class Initialized
INFO - 2020-11-09 13:24:57 --> Helper loaded: url_helper
INFO - 2020-11-09 13:24:57 --> Helper loaded: form_helper
INFO - 2020-11-09 13:24:57 --> Helper loaded: html_helper
INFO - 2020-11-09 13:24:57 --> Helper loaded: date_helper
INFO - 2020-11-09 13:24:57 --> Database Driver Class Initialized
INFO - 2020-11-09 13:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 13:24:57 --> Table Class Initialized
INFO - 2020-11-09 13:24:57 --> Upload Class Initialized
INFO - 2020-11-09 13:24:57 --> Controller Class Initialized
INFO - 2020-11-09 13:24:57 --> Model "Usuarios_model" initialized
INFO - 2020-11-09 13:24:57 --> Config Class Initialized
INFO - 2020-11-09 13:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-09 13:24:57 --> UTF-8 Support Enabled
INFO - 2020-11-09 13:24:57 --> Utf8 Class Initialized
INFO - 2020-11-09 13:24:57 --> URI Class Initialized
INFO - 2020-11-09 13:24:57 --> Router Class Initialized
INFO - 2020-11-09 13:24:57 --> Output Class Initialized
INFO - 2020-11-09 13:24:57 --> Security Class Initialized
DEBUG - 2020-11-09 13:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 13:24:57 --> Input Class Initialized
INFO - 2020-11-09 13:24:57 --> Language Class Initialized
INFO - 2020-11-09 13:24:57 --> Loader Class Initialized
INFO - 2020-11-09 13:24:57 --> Helper loaded: url_helper
INFO - 2020-11-09 13:24:57 --> Helper loaded: form_helper
INFO - 2020-11-09 13:24:57 --> Helper loaded: html_helper
INFO - 2020-11-09 13:24:57 --> Helper loaded: date_helper
INFO - 2020-11-09 13:24:57 --> Database Driver Class Initialized
INFO - 2020-11-09 13:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 13:24:57 --> Table Class Initialized
INFO - 2020-11-09 13:24:57 --> Upload Class Initialized
INFO - 2020-11-09 13:24:57 --> Controller Class Initialized
INFO - 2020-11-09 13:24:57 --> Form Validation Class Initialized
INFO - 2020-11-09 13:24:57 --> Model "Crud_model" initialized
INFO - 2020-11-09 13:24:57 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-11-09 13:24:57 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-11-09 13:24:57 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-11-09 13:24:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-11-09 13:24:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-11-09 13:24:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-11-09 13:24:57 --> Final output sent to browser
DEBUG - 2020-11-09 13:24:57 --> Total execution time: 0.0491
INFO - 2020-11-09 13:24:57 --> Config Class Initialized
INFO - 2020-11-09 13:24:57 --> Hooks Class Initialized
DEBUG - 2020-11-09 13:24:57 --> UTF-8 Support Enabled
INFO - 2020-11-09 13:24:57 --> Utf8 Class Initialized
INFO - 2020-11-09 13:24:57 --> URI Class Initialized
INFO - 2020-11-09 13:24:57 --> Router Class Initialized
INFO - 2020-11-09 13:24:57 --> Output Class Initialized
INFO - 2020-11-09 13:24:57 --> Security Class Initialized
DEBUG - 2020-11-09 13:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 13:24:57 --> Input Class Initialized
INFO - 2020-11-09 13:24:57 --> Language Class Initialized
ERROR - 2020-11-09 13:24:57 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-09 13:24:58 --> Config Class Initialized
INFO - 2020-11-09 13:24:58 --> Hooks Class Initialized
DEBUG - 2020-11-09 13:24:58 --> UTF-8 Support Enabled
INFO - 2020-11-09 13:24:58 --> Utf8 Class Initialized
INFO - 2020-11-09 13:24:58 --> URI Class Initialized
INFO - 2020-11-09 13:24:58 --> Router Class Initialized
INFO - 2020-11-09 13:24:58 --> Output Class Initialized
INFO - 2020-11-09 13:24:58 --> Security Class Initialized
DEBUG - 2020-11-09 13:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 13:24:58 --> Input Class Initialized
INFO - 2020-11-09 13:24:58 --> Language Class Initialized
INFO - 2020-11-09 13:24:58 --> Loader Class Initialized
INFO - 2020-11-09 13:24:58 --> Helper loaded: url_helper
INFO - 2020-11-09 13:24:58 --> Helper loaded: form_helper
INFO - 2020-11-09 13:24:58 --> Helper loaded: html_helper
INFO - 2020-11-09 13:24:58 --> Helper loaded: date_helper
INFO - 2020-11-09 13:24:58 --> Database Driver Class Initialized
INFO - 2020-11-09 13:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 13:24:58 --> Table Class Initialized
INFO - 2020-11-09 13:24:58 --> Upload Class Initialized
INFO - 2020-11-09 13:24:58 --> Controller Class Initialized
INFO - 2020-11-09 13:24:58 --> Form Validation Class Initialized
INFO - 2020-11-09 13:24:58 --> Model "Crud_model" initialized
ERROR - 2020-11-09 13:24:58 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-11-09 13:24:58 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-09 13:24:59 --> Config Class Initialized
INFO - 2020-11-09 13:24:59 --> Hooks Class Initialized
DEBUG - 2020-11-09 13:24:59 --> UTF-8 Support Enabled
INFO - 2020-11-09 13:24:59 --> Utf8 Class Initialized
INFO - 2020-11-09 13:24:59 --> URI Class Initialized
INFO - 2020-11-09 13:24:59 --> Router Class Initialized
INFO - 2020-11-09 13:24:59 --> Output Class Initialized
INFO - 2020-11-09 13:24:59 --> Security Class Initialized
DEBUG - 2020-11-09 13:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 13:24:59 --> Input Class Initialized
INFO - 2020-11-09 13:24:59 --> Language Class Initialized
ERROR - 2020-11-09 13:24:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-09 15:03:15 --> Config Class Initialized
INFO - 2020-11-09 15:03:15 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:03:15 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:03:15 --> Utf8 Class Initialized
INFO - 2020-11-09 15:03:15 --> URI Class Initialized
DEBUG - 2020-11-09 15:03:15 --> No URI present. Default controller set.
INFO - 2020-11-09 15:03:15 --> Router Class Initialized
INFO - 2020-11-09 15:03:15 --> Output Class Initialized
INFO - 2020-11-09 15:03:15 --> Security Class Initialized
DEBUG - 2020-11-09 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:03:15 --> Input Class Initialized
INFO - 2020-11-09 15:03:15 --> Language Class Initialized
INFO - 2020-11-09 15:03:15 --> Loader Class Initialized
INFO - 2020-11-09 15:03:15 --> Helper loaded: url_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: form_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: html_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: date_helper
INFO - 2020-11-09 15:03:15 --> Database Driver Class Initialized
INFO - 2020-11-09 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:03:15 --> Table Class Initialized
INFO - 2020-11-09 15:03:15 --> Upload Class Initialized
INFO - 2020-11-09 15:03:15 --> Controller Class Initialized
INFO - 2020-11-09 15:03:15 --> Model "Usuarios_model" initialized
INFO - 2020-11-09 15:03:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-09 15:03:15 --> Final output sent to browser
DEBUG - 2020-11-09 15:03:15 --> Total execution time: 0.0448
INFO - 2020-11-09 15:03:15 --> Config Class Initialized
INFO - 2020-11-09 15:03:15 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:03:15 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:03:15 --> Utf8 Class Initialized
INFO - 2020-11-09 15:03:15 --> URI Class Initialized
DEBUG - 2020-11-09 15:03:15 --> No URI present. Default controller set.
INFO - 2020-11-09 15:03:15 --> Router Class Initialized
INFO - 2020-11-09 15:03:15 --> Output Class Initialized
INFO - 2020-11-09 15:03:15 --> Security Class Initialized
DEBUG - 2020-11-09 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:03:15 --> Input Class Initialized
INFO - 2020-11-09 15:03:15 --> Language Class Initialized
INFO - 2020-11-09 15:03:15 --> Loader Class Initialized
INFO - 2020-11-09 15:03:15 --> Helper loaded: url_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: form_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: html_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: date_helper
INFO - 2020-11-09 15:03:15 --> Database Driver Class Initialized
INFO - 2020-11-09 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:03:15 --> Table Class Initialized
INFO - 2020-11-09 15:03:15 --> Upload Class Initialized
INFO - 2020-11-09 15:03:15 --> Controller Class Initialized
INFO - 2020-11-09 15:03:15 --> Model "Usuarios_model" initialized
INFO - 2020-11-09 15:03:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-09 15:03:15 --> Final output sent to browser
DEBUG - 2020-11-09 15:03:15 --> Total execution time: 0.0372
INFO - 2020-11-09 15:03:15 --> Config Class Initialized
INFO - 2020-11-09 15:03:15 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:03:15 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:03:15 --> Utf8 Class Initialized
INFO - 2020-11-09 15:03:15 --> URI Class Initialized
DEBUG - 2020-11-09 15:03:15 --> No URI present. Default controller set.
INFO - 2020-11-09 15:03:15 --> Router Class Initialized
INFO - 2020-11-09 15:03:15 --> Output Class Initialized
INFO - 2020-11-09 15:03:15 --> Security Class Initialized
DEBUG - 2020-11-09 15:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:03:15 --> Input Class Initialized
INFO - 2020-11-09 15:03:15 --> Language Class Initialized
INFO - 2020-11-09 15:03:15 --> Loader Class Initialized
INFO - 2020-11-09 15:03:15 --> Helper loaded: url_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: form_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: html_helper
INFO - 2020-11-09 15:03:15 --> Helper loaded: date_helper
INFO - 2020-11-09 15:03:15 --> Database Driver Class Initialized
INFO - 2020-11-09 15:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:03:15 --> Table Class Initialized
INFO - 2020-11-09 15:03:15 --> Upload Class Initialized
INFO - 2020-11-09 15:03:15 --> Controller Class Initialized
INFO - 2020-11-09 15:03:15 --> Model "Usuarios_model" initialized
INFO - 2020-11-09 15:03:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-09 15:03:15 --> Final output sent to browser
DEBUG - 2020-11-09 15:03:15 --> Total execution time: 0.0369
INFO - 2020-11-09 15:32:02 --> Config Class Initialized
INFO - 2020-11-09 15:32:02 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:02 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:02 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:02 --> URI Class Initialized
DEBUG - 2020-11-09 15:32:02 --> No URI present. Default controller set.
INFO - 2020-11-09 15:32:02 --> Router Class Initialized
INFO - 2020-11-09 15:32:02 --> Output Class Initialized
INFO - 2020-11-09 15:32:02 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:02 --> Input Class Initialized
INFO - 2020-11-09 15:32:02 --> Language Class Initialized
INFO - 2020-11-09 15:32:02 --> Loader Class Initialized
INFO - 2020-11-09 15:32:02 --> Helper loaded: url_helper
INFO - 2020-11-09 15:32:02 --> Helper loaded: form_helper
INFO - 2020-11-09 15:32:02 --> Helper loaded: html_helper
INFO - 2020-11-09 15:32:02 --> Helper loaded: date_helper
INFO - 2020-11-09 15:32:02 --> Database Driver Class Initialized
INFO - 2020-11-09 15:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:32:02 --> Table Class Initialized
INFO - 2020-11-09 15:32:02 --> Upload Class Initialized
INFO - 2020-11-09 15:32:02 --> Controller Class Initialized
INFO - 2020-11-09 15:32:02 --> Model "Usuarios_model" initialized
INFO - 2020-11-09 15:32:02 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-09 15:32:02 --> Final output sent to browser
DEBUG - 2020-11-09 15:32:02 --> Total execution time: 0.0523
INFO - 2020-11-09 15:32:03 --> Config Class Initialized
INFO - 2020-11-09 15:32:03 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:03 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:03 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:03 --> URI Class Initialized
INFO - 2020-11-09 15:32:03 --> Router Class Initialized
INFO - 2020-11-09 15:32:03 --> Output Class Initialized
INFO - 2020-11-09 15:32:03 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:03 --> Input Class Initialized
INFO - 2020-11-09 15:32:03 --> Language Class Initialized
ERROR - 2020-11-09 15:32:03 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-11-09 15:32:15 --> Config Class Initialized
INFO - 2020-11-09 15:32:15 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:15 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:15 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:15 --> URI Class Initialized
INFO - 2020-11-09 15:32:15 --> Router Class Initialized
INFO - 2020-11-09 15:32:15 --> Output Class Initialized
INFO - 2020-11-09 15:32:15 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:15 --> Input Class Initialized
INFO - 2020-11-09 15:32:15 --> Language Class Initialized
INFO - 2020-11-09 15:32:15 --> Loader Class Initialized
INFO - 2020-11-09 15:32:15 --> Helper loaded: url_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: form_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: html_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: date_helper
INFO - 2020-11-09 15:32:15 --> Database Driver Class Initialized
INFO - 2020-11-09 15:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:32:15 --> Table Class Initialized
INFO - 2020-11-09 15:32:15 --> Upload Class Initialized
INFO - 2020-11-09 15:32:15 --> Controller Class Initialized
INFO - 2020-11-09 15:32:15 --> Model "Usuarios_model" initialized
INFO - 2020-11-09 15:32:15 --> Config Class Initialized
INFO - 2020-11-09 15:32:15 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:15 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:15 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:15 --> URI Class Initialized
INFO - 2020-11-09 15:32:15 --> Router Class Initialized
INFO - 2020-11-09 15:32:15 --> Output Class Initialized
INFO - 2020-11-09 15:32:15 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:15 --> Input Class Initialized
INFO - 2020-11-09 15:32:15 --> Language Class Initialized
INFO - 2020-11-09 15:32:15 --> Loader Class Initialized
INFO - 2020-11-09 15:32:15 --> Helper loaded: url_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: form_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: html_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: date_helper
INFO - 2020-11-09 15:32:15 --> Database Driver Class Initialized
INFO - 2020-11-09 15:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:32:15 --> Table Class Initialized
INFO - 2020-11-09 15:32:15 --> Upload Class Initialized
INFO - 2020-11-09 15:32:15 --> Controller Class Initialized
INFO - 2020-11-09 15:32:15 --> Form Validation Class Initialized
INFO - 2020-11-09 15:32:15 --> Model "Crud_model" initialized
INFO - 2020-11-09 15:32:15 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-11-09 15:32:15 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-11-09 15:32:15 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-11-09 15:32:15 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-11-09 15:32:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-11-09 15:32:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-11-09 15:32:15 --> Final output sent to browser
DEBUG - 2020-11-09 15:32:15 --> Total execution time: 0.0490
INFO - 2020-11-09 15:32:15 --> Config Class Initialized
INFO - 2020-11-09 15:32:15 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:15 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:15 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:15 --> URI Class Initialized
INFO - 2020-11-09 15:32:15 --> Router Class Initialized
INFO - 2020-11-09 15:32:15 --> Output Class Initialized
INFO - 2020-11-09 15:32:15 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:15 --> Input Class Initialized
INFO - 2020-11-09 15:32:15 --> Language Class Initialized
ERROR - 2020-11-09 15:32:15 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-09 15:32:15 --> Config Class Initialized
INFO - 2020-11-09 15:32:15 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:15 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:15 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:15 --> URI Class Initialized
INFO - 2020-11-09 15:32:15 --> Router Class Initialized
INFO - 2020-11-09 15:32:15 --> Output Class Initialized
INFO - 2020-11-09 15:32:15 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:15 --> Input Class Initialized
INFO - 2020-11-09 15:32:15 --> Language Class Initialized
INFO - 2020-11-09 15:32:15 --> Loader Class Initialized
INFO - 2020-11-09 15:32:15 --> Helper loaded: url_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: form_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: html_helper
INFO - 2020-11-09 15:32:15 --> Helper loaded: date_helper
INFO - 2020-11-09 15:32:15 --> Database Driver Class Initialized
INFO - 2020-11-09 15:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:32:15 --> Table Class Initialized
INFO - 2020-11-09 15:32:15 --> Upload Class Initialized
INFO - 2020-11-09 15:32:15 --> Controller Class Initialized
INFO - 2020-11-09 15:32:15 --> Form Validation Class Initialized
INFO - 2020-11-09 15:32:15 --> Model "Crud_model" initialized
ERROR - 2020-11-09 15:32:15 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-11-09 15:32:15 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-09 15:32:16 --> Config Class Initialized
INFO - 2020-11-09 15:32:16 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:16 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:16 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:16 --> URI Class Initialized
INFO - 2020-11-09 15:32:16 --> Router Class Initialized
INFO - 2020-11-09 15:32:16 --> Output Class Initialized
INFO - 2020-11-09 15:32:16 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:16 --> Input Class Initialized
INFO - 2020-11-09 15:32:16 --> Language Class Initialized
ERROR - 2020-11-09 15:32:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-11-09 15:32:20 --> Config Class Initialized
INFO - 2020-11-09 15:32:20 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:20 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:20 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:20 --> URI Class Initialized
INFO - 2020-11-09 15:32:20 --> Router Class Initialized
INFO - 2020-11-09 15:32:20 --> Output Class Initialized
INFO - 2020-11-09 15:32:20 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:20 --> Input Class Initialized
INFO - 2020-11-09 15:32:20 --> Language Class Initialized
ERROR - 2020-11-09 15:32:20 --> 404 Page Not Found: Layout/top-nav.html
INFO - 2020-11-09 15:32:22 --> Config Class Initialized
INFO - 2020-11-09 15:32:22 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:22 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:22 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:22 --> URI Class Initialized
INFO - 2020-11-09 15:32:22 --> Router Class Initialized
INFO - 2020-11-09 15:32:22 --> Output Class Initialized
INFO - 2020-11-09 15:32:22 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:22 --> Input Class Initialized
INFO - 2020-11-09 15:32:22 --> Language Class Initialized
INFO - 2020-11-09 15:32:22 --> Loader Class Initialized
INFO - 2020-11-09 15:32:22 --> Helper loaded: url_helper
INFO - 2020-11-09 15:32:22 --> Helper loaded: form_helper
INFO - 2020-11-09 15:32:22 --> Helper loaded: html_helper
INFO - 2020-11-09 15:32:22 --> Helper loaded: date_helper
INFO - 2020-11-09 15:32:22 --> Database Driver Class Initialized
INFO - 2020-11-09 15:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:32:22 --> Table Class Initialized
INFO - 2020-11-09 15:32:22 --> Upload Class Initialized
INFO - 2020-11-09 15:32:22 --> Controller Class Initialized
INFO - 2020-11-09 15:32:22 --> Form Validation Class Initialized
INFO - 2020-11-09 15:32:22 --> Model "Crud_model" initialized
INFO - 2020-11-09 15:32:22 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-11-09 15:32:22 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-11-09 15:32:22 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-11-09 15:32:22 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-11-09 15:32:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-11-09 15:32:22 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-11-09 15:32:22 --> Final output sent to browser
DEBUG - 2020-11-09 15:32:22 --> Total execution time: 0.0552
INFO - 2020-11-09 15:32:22 --> Config Class Initialized
INFO - 2020-11-09 15:32:22 --> Hooks Class Initialized
DEBUG - 2020-11-09 15:32:22 --> UTF-8 Support Enabled
INFO - 2020-11-09 15:32:22 --> Utf8 Class Initialized
INFO - 2020-11-09 15:32:22 --> URI Class Initialized
INFO - 2020-11-09 15:32:22 --> Router Class Initialized
INFO - 2020-11-09 15:32:22 --> Output Class Initialized
INFO - 2020-11-09 15:32:22 --> Security Class Initialized
DEBUG - 2020-11-09 15:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-09 15:32:22 --> Input Class Initialized
INFO - 2020-11-09 15:32:22 --> Language Class Initialized
INFO - 2020-11-09 15:32:22 --> Loader Class Initialized
INFO - 2020-11-09 15:32:22 --> Helper loaded: url_helper
INFO - 2020-11-09 15:32:22 --> Helper loaded: form_helper
INFO - 2020-11-09 15:32:22 --> Helper loaded: html_helper
INFO - 2020-11-09 15:32:22 --> Helper loaded: date_helper
INFO - 2020-11-09 15:32:22 --> Database Driver Class Initialized
INFO - 2020-11-09 15:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-09 15:32:22 --> Table Class Initialized
INFO - 2020-11-09 15:32:22 --> Upload Class Initialized
INFO - 2020-11-09 15:32:22 --> Controller Class Initialized
INFO - 2020-11-09 15:32:22 --> Form Validation Class Initialized
INFO - 2020-11-09 15:32:22 --> Model "Crud_model" initialized
ERROR - 2020-11-09 15:32:22 --> Query error: Table 'ventas_ci.crud' doesn't exist - Invalid query: SELECT *
FROM `crud`
INFO - 2020-11-09 15:32:22 --> Language file loaded: language/english/db_lang.php

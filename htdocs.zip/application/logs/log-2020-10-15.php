<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-15 13:40:31 --> Config Class Initialized
INFO - 2020-10-15 13:40:31 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:40:31 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:40:31 --> Utf8 Class Initialized
INFO - 2020-10-15 13:40:31 --> URI Class Initialized
INFO - 2020-10-15 13:40:31 --> Router Class Initialized
INFO - 2020-10-15 13:40:31 --> Output Class Initialized
INFO - 2020-10-15 13:40:31 --> Security Class Initialized
DEBUG - 2020-10-15 13:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:40:31 --> Input Class Initialized
INFO - 2020-10-15 13:40:31 --> Language Class Initialized
INFO - 2020-10-15 13:40:31 --> Loader Class Initialized
INFO - 2020-10-15 13:40:31 --> Helper loaded: url_helper
INFO - 2020-10-15 13:40:31 --> Helper loaded: form_helper
INFO - 2020-10-15 13:40:31 --> Helper loaded: html_helper
INFO - 2020-10-15 13:40:31 --> Helper loaded: date_helper
INFO - 2020-10-15 13:40:31 --> Database Driver Class Initialized
ERROR - 2020-10-15 13:40:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'municoll_mpv'@'localhost' (using password: YES) C:\xampp\htdocs\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2020-10-15 13:40:31 --> Unable to connect to the database
INFO - 2020-10-15 13:40:31 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
INFO - 2020-10-15 13:43:17 --> Loader Class Initialized
INFO - 2020-10-15 13:43:17 --> Helper loaded: url_helper
INFO - 2020-10-15 13:43:17 --> Helper loaded: form_helper
INFO - 2020-10-15 13:43:17 --> Helper loaded: html_helper
INFO - 2020-10-15 13:43:17 --> Helper loaded: date_helper
INFO - 2020-10-15 13:43:17 --> Database Driver Class Initialized
INFO - 2020-10-15 13:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:43:17 --> Table Class Initialized
INFO - 2020-10-15 13:43:17 --> Upload Class Initialized
INFO - 2020-10-15 13:43:17 --> Controller Class Initialized
ERROR - 2020-10-15 13:43:17 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\templates\header.php 16
INFO - 2020-10-15 13:43:17 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:43:17 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:43:17 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:43:17 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:43:17 --> Final output sent to browser
DEBUG - 2020-10-15 13:43:17 --> Total execution time: 0.2456
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:43:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:43:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
ERROR - 2020-10-15 13:43:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
ERROR - 2020-10-15 13:43:17 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
ERROR - 2020-10-15 13:43:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:43:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:17 --> Output Class Initialized
ERROR - 2020-10-15 13:43:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:17 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:17 --> Input Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> URI Class Initialized
INFO - 2020-10-15 13:43:17 --> Security Class Initialized
INFO - 2020-10-15 13:43:17 --> Language Class Initialized
INFO - 2020-10-15 13:43:17 --> Config Class Initialized
INFO - 2020-10-15 13:43:17 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:43:18 --> Config Class Initialized
INFO - 2020-10-15 13:43:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:18 --> URI Class Initialized
INFO - 2020-10-15 13:43:18 --> Router Class Initialized
INFO - 2020-10-15 13:43:18 --> Output Class Initialized
INFO - 2020-10-15 13:43:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:18 --> Input Class Initialized
INFO - 2020-10-15 13:43:18 --> Language Class Initialized
ERROR - 2020-10-15 13:43:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:43:19 --> Config Class Initialized
INFO - 2020-10-15 13:43:19 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:43:19 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:43:19 --> Utf8 Class Initialized
INFO - 2020-10-15 13:43:19 --> URI Class Initialized
INFO - 2020-10-15 13:43:19 --> Router Class Initialized
INFO - 2020-10-15 13:43:19 --> Output Class Initialized
INFO - 2020-10-15 13:43:19 --> Security Class Initialized
DEBUG - 2020-10-15 13:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:43:19 --> Input Class Initialized
INFO - 2020-10-15 13:43:19 --> Language Class Initialized
ERROR - 2020-10-15 13:43:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:57 --> Config Class Initialized
INFO - 2020-10-15 13:44:57 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:57 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:57 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:57 --> URI Class Initialized
INFO - 2020-10-15 13:44:57 --> Router Class Initialized
INFO - 2020-10-15 13:44:57 --> Output Class Initialized
INFO - 2020-10-15 13:44:57 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:57 --> Input Class Initialized
INFO - 2020-10-15 13:44:57 --> Language Class Initialized
INFO - 2020-10-15 13:44:57 --> Loader Class Initialized
INFO - 2020-10-15 13:44:57 --> Helper loaded: url_helper
INFO - 2020-10-15 13:44:57 --> Helper loaded: form_helper
INFO - 2020-10-15 13:44:57 --> Helper loaded: html_helper
INFO - 2020-10-15 13:44:57 --> Helper loaded: date_helper
INFO - 2020-10-15 13:44:57 --> Database Driver Class Initialized
INFO - 2020-10-15 13:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:44:57 --> Table Class Initialized
INFO - 2020-10-15 13:44:57 --> Upload Class Initialized
INFO - 2020-10-15 13:44:57 --> Controller Class Initialized
ERROR - 2020-10-15 13:44:57 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\templates\header.php 16
INFO - 2020-10-15 13:44:57 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:44:57 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:44:57 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:44:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:44:57 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:44:57 --> Final output sent to browser
DEBUG - 2020-10-15 13:44:57 --> Total execution time: 0.2521
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:58 --> URI Class Initialized
INFO - 2020-10-15 13:44:58 --> Router Class Initialized
INFO - 2020-10-15 13:44:58 --> Output Class Initialized
INFO - 2020-10-15 13:44:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:58 --> Input Class Initialized
INFO - 2020-10-15 13:44:58 --> Language Class Initialized
ERROR - 2020-10-15 13:44:58 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:44:58 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:44:59 --> Config Class Initialized
INFO - 2020-10-15 13:44:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:44:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:44:59 --> Utf8 Class Initialized
INFO - 2020-10-15 13:44:59 --> URI Class Initialized
INFO - 2020-10-15 13:44:59 --> Router Class Initialized
INFO - 2020-10-15 13:44:59 --> Output Class Initialized
INFO - 2020-10-15 13:44:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:44:59 --> Input Class Initialized
INFO - 2020-10-15 13:44:59 --> Language Class Initialized
ERROR - 2020-10-15 13:44:59 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Loader Class Initialized
INFO - 2020-10-15 13:45:03 --> Helper loaded: url_helper
INFO - 2020-10-15 13:45:03 --> Helper loaded: form_helper
INFO - 2020-10-15 13:45:03 --> Helper loaded: html_helper
INFO - 2020-10-15 13:45:03 --> Helper loaded: date_helper
INFO - 2020-10-15 13:45:03 --> Database Driver Class Initialized
INFO - 2020-10-15 13:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:45:03 --> Table Class Initialized
INFO - 2020-10-15 13:45:03 --> Upload Class Initialized
INFO - 2020-10-15 13:45:03 --> Controller Class Initialized
ERROR - 2020-10-15 13:45:03 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\templates\header.php 16
INFO - 2020-10-15 13:45:03 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:45:03 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:45:03 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:45:03 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:45:03 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:45:03 --> Final output sent to browser
DEBUG - 2020-10-15 13:45:03 --> Total execution time: 0.1774
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Language Class Initialized
INFO - 2020-10-15 13:45:03 --> Config Class Initialized
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
ERROR - 2020-10-15 13:45:03 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:45:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:45:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> URI Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Router Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Output Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
INFO - 2020-10-15 13:45:03 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:03 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:04 --> Input Class Initialized
INFO - 2020-10-15 13:45:04 --> Language Class Initialized
ERROR - 2020-10-15 13:45:04 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:04 --> Config Class Initialized
INFO - 2020-10-15 13:45:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:04 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:04 --> URI Class Initialized
INFO - 2020-10-15 13:45:04 --> Router Class Initialized
INFO - 2020-10-15 13:45:04 --> Output Class Initialized
INFO - 2020-10-15 13:45:04 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:05 --> Input Class Initialized
INFO - 2020-10-15 13:45:05 --> Language Class Initialized
ERROR - 2020-10-15 13:45:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:05 --> Config Class Initialized
INFO - 2020-10-15 13:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:05 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:05 --> URI Class Initialized
INFO - 2020-10-15 13:45:05 --> Router Class Initialized
INFO - 2020-10-15 13:45:05 --> Output Class Initialized
INFO - 2020-10-15 13:45:05 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:05 --> Input Class Initialized
INFO - 2020-10-15 13:45:05 --> Language Class Initialized
ERROR - 2020-10-15 13:45:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:05 --> Config Class Initialized
INFO - 2020-10-15 13:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:05 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:05 --> URI Class Initialized
INFO - 2020-10-15 13:45:05 --> Router Class Initialized
INFO - 2020-10-15 13:45:05 --> Output Class Initialized
INFO - 2020-10-15 13:45:05 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:05 --> Input Class Initialized
INFO - 2020-10-15 13:45:05 --> Language Class Initialized
ERROR - 2020-10-15 13:45:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:05 --> Config Class Initialized
INFO - 2020-10-15 13:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:05 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:05 --> URI Class Initialized
INFO - 2020-10-15 13:45:05 --> Router Class Initialized
INFO - 2020-10-15 13:45:05 --> Output Class Initialized
INFO - 2020-10-15 13:45:05 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:05 --> Input Class Initialized
INFO - 2020-10-15 13:45:05 --> Language Class Initialized
ERROR - 2020-10-15 13:45:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:45:05 --> Config Class Initialized
INFO - 2020-10-15 13:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:05 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:05 --> URI Class Initialized
INFO - 2020-10-15 13:45:05 --> Router Class Initialized
INFO - 2020-10-15 13:45:05 --> Output Class Initialized
INFO - 2020-10-15 13:45:05 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:05 --> Input Class Initialized
INFO - 2020-10-15 13:45:05 --> Language Class Initialized
ERROR - 2020-10-15 13:45:05 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:45:05 --> Config Class Initialized
INFO - 2020-10-15 13:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:45:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:45:05 --> Utf8 Class Initialized
INFO - 2020-10-15 13:45:05 --> URI Class Initialized
INFO - 2020-10-15 13:45:05 --> Router Class Initialized
INFO - 2020-10-15 13:45:05 --> Output Class Initialized
INFO - 2020-10-15 13:45:05 --> Security Class Initialized
DEBUG - 2020-10-15 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:45:05 --> Input Class Initialized
INFO - 2020-10-15 13:45:05 --> Language Class Initialized
ERROR - 2020-10-15 13:45:05 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:12 --> Input Class Initialized
INFO - 2020-10-15 13:46:12 --> Language Class Initialized
INFO - 2020-10-15 13:46:12 --> Loader Class Initialized
INFO - 2020-10-15 13:46:12 --> Helper loaded: url_helper
INFO - 2020-10-15 13:46:12 --> Helper loaded: form_helper
INFO - 2020-10-15 13:46:12 --> Helper loaded: html_helper
INFO - 2020-10-15 13:46:12 --> Helper loaded: date_helper
INFO - 2020-10-15 13:46:12 --> Database Driver Class Initialized
INFO - 2020-10-15 13:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:46:12 --> Table Class Initialized
INFO - 2020-10-15 13:46:12 --> Upload Class Initialized
INFO - 2020-10-15 13:46:12 --> Controller Class Initialized
ERROR - 2020-10-15 13:46:12 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\templates\header.php 16
INFO - 2020-10-15 13:46:12 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:46:12 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:46:12 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:46:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:46:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:46:12 --> Final output sent to browser
DEBUG - 2020-10-15 13:46:12 --> Total execution time: 0.3938
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:12 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Language Class Initialized
INFO - 2020-10-15 13:46:12 --> Input Class Initialized
INFO - 2020-10-15 13:46:12 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:12 --> Input Class Initialized
INFO - 2020-10-15 13:46:12 --> Language Class Initialized
INFO - 2020-10-15 13:46:12 --> Language Class Initialized
INFO - 2020-10-15 13:46:12 --> Input Class Initialized
INFO - 2020-10-15 13:46:12 --> Input Class Initialized
ERROR - 2020-10-15 13:46:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:12 --> Language Class Initialized
INFO - 2020-10-15 13:46:12 --> Language Class Initialized
ERROR - 2020-10-15 13:46:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:12 --> Language Class Initialized
ERROR - 2020-10-15 13:46:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:46:12 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:46:12 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
ERROR - 2020-10-15 13:46:12 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Config Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
DEBUG - 2020-10-15 13:46:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> URI Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:12 --> Router Class Initialized
INFO - 2020-10-15 13:46:12 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:12 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:13 --> Input Class Initialized
INFO - 2020-10-15 13:46:13 --> Language Class Initialized
ERROR - 2020-10-15 13:46:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:13 --> Config Class Initialized
INFO - 2020-10-15 13:46:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:13 --> URI Class Initialized
INFO - 2020-10-15 13:46:13 --> Router Class Initialized
INFO - 2020-10-15 13:46:13 --> Output Class Initialized
INFO - 2020-10-15 13:46:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:14 --> Input Class Initialized
INFO - 2020-10-15 13:46:14 --> Language Class Initialized
ERROR - 2020-10-15 13:46:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:14 --> Config Class Initialized
INFO - 2020-10-15 13:46:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:14 --> URI Class Initialized
INFO - 2020-10-15 13:46:14 --> Router Class Initialized
INFO - 2020-10-15 13:46:14 --> Output Class Initialized
INFO - 2020-10-15 13:46:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:14 --> Input Class Initialized
INFO - 2020-10-15 13:46:14 --> Language Class Initialized
ERROR - 2020-10-15 13:46:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:14 --> Config Class Initialized
INFO - 2020-10-15 13:46:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:14 --> URI Class Initialized
INFO - 2020-10-15 13:46:14 --> Router Class Initialized
INFO - 2020-10-15 13:46:14 --> Output Class Initialized
INFO - 2020-10-15 13:46:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:14 --> Input Class Initialized
INFO - 2020-10-15 13:46:14 --> Language Class Initialized
ERROR - 2020-10-15 13:46:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:14 --> Config Class Initialized
INFO - 2020-10-15 13:46:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:14 --> URI Class Initialized
INFO - 2020-10-15 13:46:14 --> Router Class Initialized
INFO - 2020-10-15 13:46:14 --> Output Class Initialized
INFO - 2020-10-15 13:46:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:14 --> Input Class Initialized
INFO - 2020-10-15 13:46:14 --> Language Class Initialized
ERROR - 2020-10-15 13:46:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:14 --> Config Class Initialized
INFO - 2020-10-15 13:46:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:14 --> URI Class Initialized
INFO - 2020-10-15 13:46:14 --> Router Class Initialized
INFO - 2020-10-15 13:46:14 --> Output Class Initialized
INFO - 2020-10-15 13:46:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:14 --> Input Class Initialized
INFO - 2020-10-15 13:46:14 --> Language Class Initialized
ERROR - 2020-10-15 13:46:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:14 --> Config Class Initialized
INFO - 2020-10-15 13:46:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:14 --> URI Class Initialized
INFO - 2020-10-15 13:46:14 --> Router Class Initialized
INFO - 2020-10-15 13:46:14 --> Output Class Initialized
INFO - 2020-10-15 13:46:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:14 --> Input Class Initialized
INFO - 2020-10-15 13:46:14 --> Language Class Initialized
ERROR - 2020-10-15 13:46:14 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Loader Class Initialized
INFO - 2020-10-15 13:46:16 --> Helper loaded: url_helper
INFO - 2020-10-15 13:46:16 --> Helper loaded: form_helper
INFO - 2020-10-15 13:46:16 --> Helper loaded: html_helper
INFO - 2020-10-15 13:46:16 --> Helper loaded: date_helper
INFO - 2020-10-15 13:46:16 --> Database Driver Class Initialized
INFO - 2020-10-15 13:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:46:16 --> Table Class Initialized
INFO - 2020-10-15 13:46:16 --> Upload Class Initialized
INFO - 2020-10-15 13:46:16 --> Controller Class Initialized
ERROR - 2020-10-15 13:46:16 --> Severity: Notice --> Undefined variable: title C:\xampp\htdocs\application\views\templates\header.php 16
INFO - 2020-10-15 13:46:16 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:46:16 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:46:16 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:46:16 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:46:16 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:46:16 --> Final output sent to browser
DEBUG - 2020-10-15 13:46:16 --> Total execution time: 0.3378
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Config Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:16 --> Security Class Initialized
INFO - 2020-10-15 13:46:16 --> URI Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:16 --> Router Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Input Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Language Class Initialized
INFO - 2020-10-15 13:46:16 --> Output Class Initialized
ERROR - 2020-10-15 13:46:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:17 --> Config Class Initialized
INFO - 2020-10-15 13:46:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:17 --> URI Class Initialized
INFO - 2020-10-15 13:46:17 --> Router Class Initialized
INFO - 2020-10-15 13:46:17 --> Output Class Initialized
INFO - 2020-10-15 13:46:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:17 --> Input Class Initialized
INFO - 2020-10-15 13:46:17 --> Language Class Initialized
ERROR - 2020-10-15 13:46:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:18 --> Router Class Initialized
INFO - 2020-10-15 13:46:18 --> Output Class Initialized
INFO - 2020-10-15 13:46:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:18 --> Input Class Initialized
INFO - 2020-10-15 13:46:18 --> Language Class Initialized
ERROR - 2020-10-15 13:46:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:18 --> Router Class Initialized
INFO - 2020-10-15 13:46:18 --> Output Class Initialized
INFO - 2020-10-15 13:46:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:18 --> Input Class Initialized
INFO - 2020-10-15 13:46:18 --> Language Class Initialized
ERROR - 2020-10-15 13:46:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:18 --> Router Class Initialized
INFO - 2020-10-15 13:46:18 --> Output Class Initialized
INFO - 2020-10-15 13:46:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:18 --> Input Class Initialized
INFO - 2020-10-15 13:46:18 --> Language Class Initialized
ERROR - 2020-10-15 13:46:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:18 --> Router Class Initialized
INFO - 2020-10-15 13:46:18 --> Output Class Initialized
INFO - 2020-10-15 13:46:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:18 --> Input Class Initialized
INFO - 2020-10-15 13:46:18 --> Language Class Initialized
ERROR - 2020-10-15 13:46:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:18 --> Router Class Initialized
INFO - 2020-10-15 13:46:18 --> Output Class Initialized
INFO - 2020-10-15 13:46:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:18 --> Input Class Initialized
INFO - 2020-10-15 13:46:18 --> Language Class Initialized
ERROR - 2020-10-15 13:46:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:18 --> Router Class Initialized
INFO - 2020-10-15 13:46:18 --> Output Class Initialized
INFO - 2020-10-15 13:46:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:18 --> Input Class Initialized
INFO - 2020-10-15 13:46:18 --> Language Class Initialized
ERROR - 2020-10-15 13:46:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:18 --> Router Class Initialized
INFO - 2020-10-15 13:46:18 --> Output Class Initialized
INFO - 2020-10-15 13:46:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:18 --> Input Class Initialized
INFO - 2020-10-15 13:46:18 --> Language Class Initialized
ERROR - 2020-10-15 13:46:18 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:46:18 --> Config Class Initialized
INFO - 2020-10-15 13:46:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:46:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:46:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:46:18 --> URI Class Initialized
INFO - 2020-10-15 13:46:19 --> Router Class Initialized
INFO - 2020-10-15 13:46:19 --> Output Class Initialized
INFO - 2020-10-15 13:46:19 --> Security Class Initialized
DEBUG - 2020-10-15 13:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:46:19 --> Input Class Initialized
INFO - 2020-10-15 13:46:19 --> Language Class Initialized
ERROR - 2020-10-15 13:46:19 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:12 --> Config Class Initialized
INFO - 2020-10-15 13:47:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:12 --> URI Class Initialized
INFO - 2020-10-15 13:47:12 --> Router Class Initialized
INFO - 2020-10-15 13:47:12 --> Output Class Initialized
INFO - 2020-10-15 13:47:12 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:12 --> Input Class Initialized
INFO - 2020-10-15 13:47:12 --> Language Class Initialized
INFO - 2020-10-15 13:47:12 --> Loader Class Initialized
INFO - 2020-10-15 13:47:12 --> Helper loaded: url_helper
INFO - 2020-10-15 13:47:12 --> Helper loaded: form_helper
INFO - 2020-10-15 13:47:12 --> Helper loaded: html_helper
INFO - 2020-10-15 13:47:12 --> Helper loaded: date_helper
INFO - 2020-10-15 13:47:12 --> Database Driver Class Initialized
INFO - 2020-10-15 13:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:47:12 --> Table Class Initialized
INFO - 2020-10-15 13:47:12 --> Upload Class Initialized
INFO - 2020-10-15 13:47:12 --> Controller Class Initialized
INFO - 2020-10-15 13:47:12 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:47:12 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:47:12 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:47:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:47:12 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:47:12 --> Final output sent to browser
DEBUG - 2020-10-15 13:47:12 --> Total execution time: 0.4845
INFO - 2020-10-15 13:47:12 --> Config Class Initialized
INFO - 2020-10-15 13:47:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:12 --> Config Class Initialized
INFO - 2020-10-15 13:47:12 --> Config Class Initialized
INFO - 2020-10-15 13:47:12 --> Config Class Initialized
DEBUG - 2020-10-15 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:12 --> Config Class Initialized
INFO - 2020-10-15 13:47:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:12 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:12 --> URI Class Initialized
DEBUG - 2020-10-15 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:12 --> Config Class Initialized
INFO - 2020-10-15 13:47:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:12 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:12 --> URI Class Initialized
INFO - 2020-10-15 13:47:12 --> URI Class Initialized
INFO - 2020-10-15 13:47:12 --> URI Class Initialized
INFO - 2020-10-15 13:47:12 --> Router Class Initialized
INFO - 2020-10-15 13:47:12 --> Router Class Initialized
INFO - 2020-10-15 13:47:12 --> URI Class Initialized
DEBUG - 2020-10-15 13:47:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:12 --> Router Class Initialized
INFO - 2020-10-15 13:47:12 --> Router Class Initialized
INFO - 2020-10-15 13:47:12 --> Output Class Initialized
INFO - 2020-10-15 13:47:12 --> Router Class Initialized
INFO - 2020-10-15 13:47:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:12 --> Output Class Initialized
INFO - 2020-10-15 13:47:12 --> Security Class Initialized
INFO - 2020-10-15 13:47:12 --> Output Class Initialized
DEBUG - 2020-10-15 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:12 --> URI Class Initialized
INFO - 2020-10-15 13:47:12 --> Output Class Initialized
INFO - 2020-10-15 13:47:12 --> Security Class Initialized
INFO - 2020-10-15 13:47:12 --> Output Class Initialized
INFO - 2020-10-15 13:47:12 --> Security Class Initialized
INFO - 2020-10-15 13:47:12 --> Security Class Initialized
INFO - 2020-10-15 13:47:12 --> Router Class Initialized
INFO - 2020-10-15 13:47:12 --> Input Class Initialized
DEBUG - 2020-10-15 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:12 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:12 --> Input Class Initialized
INFO - 2020-10-15 13:47:12 --> Language Class Initialized
INFO - 2020-10-15 13:47:12 --> Input Class Initialized
DEBUG - 2020-10-15 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:12 --> Output Class Initialized
DEBUG - 2020-10-15 13:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:12 --> Language Class Initialized
INFO - 2020-10-15 13:47:12 --> Language Class Initialized
INFO - 2020-10-15 13:47:12 --> Input Class Initialized
INFO - 2020-10-15 13:47:12 --> Input Class Initialized
ERROR - 2020-10-15 13:47:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:47:12 --> Security Class Initialized
INFO - 2020-10-15 13:47:12 --> Language Class Initialized
ERROR - 2020-10-15 13:47:12 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:47:12 --> Language Class Initialized
ERROR - 2020-10-15 13:47:12 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-15 13:47:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
INFO - 2020-10-15 13:47:13 --> Router Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Output Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Security Class Initialized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
DEBUG - 2020-10-15 13:47:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:13 --> Input Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
INFO - 2020-10-15 13:47:13 --> Language Class Initialized
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:47:13 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Config Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:13 --> Hooks Class Initialized
INFO - 2020-10-15 13:47:13 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:13 --> URI Class Initialized
DEBUG - 2020-10-15 13:47:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> URI Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:47:14 --> Config Class Initialized
INFO - 2020-10-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:14 --> URI Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:14 --> Config Class Initialized
INFO - 2020-10-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:14 --> URI Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:14 --> Config Class Initialized
INFO - 2020-10-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:14 --> URI Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:14 --> Config Class Initialized
INFO - 2020-10-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:14 --> URI Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:14 --> Config Class Initialized
INFO - 2020-10-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:14 --> URI Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:14 --> Config Class Initialized
INFO - 2020-10-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:14 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:14 --> URI Class Initialized
INFO - 2020-10-15 13:47:14 --> Router Class Initialized
INFO - 2020-10-15 13:47:14 --> Output Class Initialized
INFO - 2020-10-15 13:47:14 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:14 --> Input Class Initialized
INFO - 2020-10-15 13:47:14 --> Language Class Initialized
ERROR - 2020-10-15 13:47:14 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:14 --> Config Class Initialized
INFO - 2020-10-15 13:47:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:15 --> URI Class Initialized
INFO - 2020-10-15 13:47:15 --> Router Class Initialized
INFO - 2020-10-15 13:47:15 --> Output Class Initialized
INFO - 2020-10-15 13:47:15 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:15 --> Input Class Initialized
INFO - 2020-10-15 13:47:15 --> Language Class Initialized
ERROR - 2020-10-15 13:47:15 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:15 --> Config Class Initialized
INFO - 2020-10-15 13:47:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:15 --> URI Class Initialized
INFO - 2020-10-15 13:47:15 --> Router Class Initialized
INFO - 2020-10-15 13:47:15 --> Output Class Initialized
INFO - 2020-10-15 13:47:15 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:15 --> Input Class Initialized
INFO - 2020-10-15 13:47:15 --> Language Class Initialized
ERROR - 2020-10-15 13:47:15 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:47:15 --> Config Class Initialized
INFO - 2020-10-15 13:47:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:47:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:47:15 --> Utf8 Class Initialized
INFO - 2020-10-15 13:47:15 --> URI Class Initialized
INFO - 2020-10-15 13:47:15 --> Router Class Initialized
INFO - 2020-10-15 13:47:15 --> Output Class Initialized
INFO - 2020-10-15 13:47:15 --> Security Class Initialized
DEBUG - 2020-10-15 13:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:47:15 --> Input Class Initialized
INFO - 2020-10-15 13:47:15 --> Language Class Initialized
ERROR - 2020-10-15 13:47:15 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:49:43 --> Config Class Initialized
INFO - 2020-10-15 13:49:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:43 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:43 --> URI Class Initialized
INFO - 2020-10-15 13:49:43 --> Router Class Initialized
INFO - 2020-10-15 13:49:43 --> Output Class Initialized
INFO - 2020-10-15 13:49:43 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:43 --> Input Class Initialized
INFO - 2020-10-15 13:49:43 --> Language Class Initialized
INFO - 2020-10-15 13:49:43 --> Loader Class Initialized
INFO - 2020-10-15 13:49:43 --> Helper loaded: url_helper
INFO - 2020-10-15 13:49:43 --> Helper loaded: form_helper
INFO - 2020-10-15 13:49:43 --> Helper loaded: html_helper
INFO - 2020-10-15 13:49:43 --> Helper loaded: date_helper
INFO - 2020-10-15 13:49:43 --> Database Driver Class Initialized
INFO - 2020-10-15 13:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:49:43 --> Table Class Initialized
INFO - 2020-10-15 13:49:43 --> Upload Class Initialized
INFO - 2020-10-15 13:49:43 --> Controller Class Initialized
INFO - 2020-10-15 13:49:43 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:49:43 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:49:43 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:49:43 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:49:43 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:49:43 --> Final output sent to browser
DEBUG - 2020-10-15 13:49:43 --> Total execution time: 0.3795
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> URI Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Router Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Output Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
INFO - 2020-10-15 13:49:44 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Input Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
INFO - 2020-10-15 13:49:44 --> Language Class Initialized
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:49:44 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
INFO - 2020-10-15 13:49:44 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:44 --> Config Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:45 --> URI Class Initialized
INFO - 2020-10-15 13:49:45 --> Router Class Initialized
INFO - 2020-10-15 13:49:45 --> Output Class Initialized
INFO - 2020-10-15 13:49:45 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:45 --> Input Class Initialized
INFO - 2020-10-15 13:49:45 --> Language Class Initialized
ERROR - 2020-10-15 13:49:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:45 --> Config Class Initialized
INFO - 2020-10-15 13:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:46 --> URI Class Initialized
INFO - 2020-10-15 13:49:46 --> Router Class Initialized
INFO - 2020-10-15 13:49:46 --> Output Class Initialized
INFO - 2020-10-15 13:49:46 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:46 --> Input Class Initialized
INFO - 2020-10-15 13:49:46 --> Language Class Initialized
ERROR - 2020-10-15 13:49:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:46 --> Config Class Initialized
INFO - 2020-10-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:46 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:46 --> URI Class Initialized
INFO - 2020-10-15 13:49:46 --> Router Class Initialized
INFO - 2020-10-15 13:49:46 --> Output Class Initialized
INFO - 2020-10-15 13:49:46 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:46 --> Input Class Initialized
INFO - 2020-10-15 13:49:46 --> Language Class Initialized
ERROR - 2020-10-15 13:49:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:46 --> Config Class Initialized
INFO - 2020-10-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:46 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:46 --> URI Class Initialized
INFO - 2020-10-15 13:49:46 --> Router Class Initialized
INFO - 2020-10-15 13:49:46 --> Output Class Initialized
INFO - 2020-10-15 13:49:46 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:46 --> Input Class Initialized
INFO - 2020-10-15 13:49:46 --> Language Class Initialized
ERROR - 2020-10-15 13:49:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:46 --> Config Class Initialized
INFO - 2020-10-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:46 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:46 --> URI Class Initialized
INFO - 2020-10-15 13:49:46 --> Router Class Initialized
INFO - 2020-10-15 13:49:46 --> Output Class Initialized
INFO - 2020-10-15 13:49:46 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:46 --> Input Class Initialized
INFO - 2020-10-15 13:49:46 --> Language Class Initialized
ERROR - 2020-10-15 13:49:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:46 --> Config Class Initialized
INFO - 2020-10-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:46 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:46 --> URI Class Initialized
INFO - 2020-10-15 13:49:46 --> Router Class Initialized
INFO - 2020-10-15 13:49:46 --> Output Class Initialized
INFO - 2020-10-15 13:49:46 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:46 --> Input Class Initialized
INFO - 2020-10-15 13:49:46 --> Language Class Initialized
ERROR - 2020-10-15 13:49:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:46 --> Config Class Initialized
INFO - 2020-10-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:46 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:46 --> URI Class Initialized
INFO - 2020-10-15 13:49:46 --> Router Class Initialized
INFO - 2020-10-15 13:49:46 --> Output Class Initialized
INFO - 2020-10-15 13:49:46 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:46 --> Input Class Initialized
INFO - 2020-10-15 13:49:46 --> Language Class Initialized
ERROR - 2020-10-15 13:49:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:46 --> Config Class Initialized
INFO - 2020-10-15 13:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:46 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:46 --> URI Class Initialized
INFO - 2020-10-15 13:49:46 --> Router Class Initialized
INFO - 2020-10-15 13:49:47 --> Output Class Initialized
INFO - 2020-10-15 13:49:47 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:47 --> Input Class Initialized
INFO - 2020-10-15 13:49:47 --> Language Class Initialized
ERROR - 2020-10-15 13:49:47 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:49:47 --> Config Class Initialized
INFO - 2020-10-15 13:49:47 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:47 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:47 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:47 --> URI Class Initialized
INFO - 2020-10-15 13:49:47 --> Router Class Initialized
INFO - 2020-10-15 13:49:47 --> Output Class Initialized
INFO - 2020-10-15 13:49:47 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:47 --> Input Class Initialized
INFO - 2020-10-15 13:49:47 --> Language Class Initialized
ERROR - 2020-10-15 13:49:47 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:49:58 --> Config Class Initialized
INFO - 2020-10-15 13:49:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:58 --> URI Class Initialized
INFO - 2020-10-15 13:49:58 --> Router Class Initialized
INFO - 2020-10-15 13:49:58 --> Output Class Initialized
INFO - 2020-10-15 13:49:58 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:58 --> Input Class Initialized
INFO - 2020-10-15 13:49:58 --> Language Class Initialized
INFO - 2020-10-15 13:49:58 --> Loader Class Initialized
INFO - 2020-10-15 13:49:58 --> Helper loaded: url_helper
INFO - 2020-10-15 13:49:58 --> Helper loaded: form_helper
INFO - 2020-10-15 13:49:58 --> Helper loaded: html_helper
INFO - 2020-10-15 13:49:58 --> Helper loaded: date_helper
INFO - 2020-10-15 13:49:58 --> Database Driver Class Initialized
INFO - 2020-10-15 13:49:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:49:58 --> Table Class Initialized
INFO - 2020-10-15 13:49:58 --> Upload Class Initialized
INFO - 2020-10-15 13:49:58 --> Controller Class Initialized
INFO - 2020-10-15 13:49:58 --> Final output sent to browser
DEBUG - 2020-10-15 13:49:58 --> Total execution time: 0.3755
INFO - 2020-10-15 13:49:58 --> Config Class Initialized
INFO - 2020-10-15 13:49:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:49:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:49:58 --> Utf8 Class Initialized
INFO - 2020-10-15 13:49:58 --> URI Class Initialized
INFO - 2020-10-15 13:49:58 --> Router Class Initialized
INFO - 2020-10-15 13:49:59 --> Output Class Initialized
INFO - 2020-10-15 13:49:59 --> Security Class Initialized
DEBUG - 2020-10-15 13:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:49:59 --> Input Class Initialized
INFO - 2020-10-15 13:49:59 --> Language Class Initialized
ERROR - 2020-10-15 13:49:59 --> 404 Page Not Found: Welcome/favicon.ico
INFO - 2020-10-15 13:50:15 --> Config Class Initialized
INFO - 2020-10-15 13:50:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:15 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:15 --> URI Class Initialized
INFO - 2020-10-15 13:50:15 --> Router Class Initialized
INFO - 2020-10-15 13:50:15 --> Output Class Initialized
INFO - 2020-10-15 13:50:15 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:15 --> Input Class Initialized
INFO - 2020-10-15 13:50:15 --> Language Class Initialized
INFO - 2020-10-15 13:50:15 --> Loader Class Initialized
INFO - 2020-10-15 13:50:15 --> Helper loaded: url_helper
INFO - 2020-10-15 13:50:15 --> Helper loaded: form_helper
INFO - 2020-10-15 13:50:15 --> Helper loaded: html_helper
INFO - 2020-10-15 13:50:15 --> Helper loaded: date_helper
INFO - 2020-10-15 13:50:15 --> Database Driver Class Initialized
INFO - 2020-10-15 13:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:50:15 --> Table Class Initialized
INFO - 2020-10-15 13:50:15 --> Upload Class Initialized
INFO - 2020-10-15 13:50:15 --> Controller Class Initialized
INFO - 2020-10-15 13:50:15 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:50:15 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:50:15 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:50:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:50:15 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:50:15 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-15 13:50:15 --> Final output sent to browser
DEBUG - 2020-10-15 13:50:15 --> Total execution time: 0.4362
INFO - 2020-10-15 13:50:15 --> Config Class Initialized
INFO - 2020-10-15 13:50:15 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:15 --> Config Class Initialized
DEBUG - 2020-10-15 13:50:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:15 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:15 --> Config Class Initialized
INFO - 2020-10-15 13:50:15 --> Config Class Initialized
INFO - 2020-10-15 13:50:15 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:15 --> Config Class Initialized
INFO - 2020-10-15 13:50:15 --> Config Class Initialized
INFO - 2020-10-15 13:50:15 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:15 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:15 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:15 --> URI Class Initialized
INFO - 2020-10-15 13:50:15 --> Router Class Initialized
INFO - 2020-10-15 13:50:15 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:50:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:15 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:15 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:15 --> URI Class Initialized
INFO - 2020-10-15 13:50:15 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> URI Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Router Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Output Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
INFO - 2020-10-15 13:50:16 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Input Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
INFO - 2020-10-15 13:50:16 --> Language Class Initialized
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:50:16 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:16 --> Config Class Initialized
DEBUG - 2020-10-15 13:50:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:16 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:50:17 --> Config Class Initialized
INFO - 2020-10-15 13:50:17 --> Config Class Initialized
INFO - 2020-10-15 13:50:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:50:17 --> Config Class Initialized
INFO - 2020-10-15 13:50:17 --> Hooks Class Initialized
INFO - 2020-10-15 13:50:17 --> Config Class Initialized
INFO - 2020-10-15 13:50:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:50:17 --> Config Class Initialized
INFO - 2020-10-15 13:50:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 13:50:17 --> Config Class Initialized
INFO - 2020-10-15 13:50:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:17 --> Config Class Initialized
INFO - 2020-10-15 13:50:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:17 --> URI Class Initialized
INFO - 2020-10-15 13:50:17 --> Router Class Initialized
INFO - 2020-10-15 13:50:17 --> Output Class Initialized
INFO - 2020-10-15 13:50:17 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:17 --> Input Class Initialized
INFO - 2020-10-15 13:50:17 --> Language Class Initialized
ERROR - 2020-10-15 13:50:17 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:18 --> Config Class Initialized
INFO - 2020-10-15 13:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:18 --> URI Class Initialized
INFO - 2020-10-15 13:50:18 --> Router Class Initialized
INFO - 2020-10-15 13:50:18 --> Output Class Initialized
INFO - 2020-10-15 13:50:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:18 --> Input Class Initialized
INFO - 2020-10-15 13:50:18 --> Language Class Initialized
ERROR - 2020-10-15 13:50:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:18 --> Config Class Initialized
INFO - 2020-10-15 13:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:18 --> URI Class Initialized
INFO - 2020-10-15 13:50:18 --> Router Class Initialized
INFO - 2020-10-15 13:50:18 --> Output Class Initialized
INFO - 2020-10-15 13:50:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:18 --> Input Class Initialized
INFO - 2020-10-15 13:50:18 --> Language Class Initialized
ERROR - 2020-10-15 13:50:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:18 --> Config Class Initialized
INFO - 2020-10-15 13:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:18 --> URI Class Initialized
INFO - 2020-10-15 13:50:18 --> Router Class Initialized
INFO - 2020-10-15 13:50:18 --> Output Class Initialized
INFO - 2020-10-15 13:50:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:18 --> Input Class Initialized
INFO - 2020-10-15 13:50:18 --> Language Class Initialized
ERROR - 2020-10-15 13:50:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:18 --> Config Class Initialized
INFO - 2020-10-15 13:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:18 --> URI Class Initialized
INFO - 2020-10-15 13:50:18 --> Router Class Initialized
INFO - 2020-10-15 13:50:18 --> Output Class Initialized
INFO - 2020-10-15 13:50:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:18 --> Input Class Initialized
INFO - 2020-10-15 13:50:18 --> Language Class Initialized
ERROR - 2020-10-15 13:50:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:18 --> Config Class Initialized
INFO - 2020-10-15 13:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:18 --> URI Class Initialized
INFO - 2020-10-15 13:50:18 --> Router Class Initialized
INFO - 2020-10-15 13:50:18 --> Output Class Initialized
INFO - 2020-10-15 13:50:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:18 --> Input Class Initialized
INFO - 2020-10-15 13:50:18 --> Language Class Initialized
ERROR - 2020-10-15 13:50:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:18 --> Config Class Initialized
INFO - 2020-10-15 13:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:18 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:18 --> URI Class Initialized
INFO - 2020-10-15 13:50:18 --> Router Class Initialized
INFO - 2020-10-15 13:50:18 --> Output Class Initialized
INFO - 2020-10-15 13:50:18 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:18 --> Input Class Initialized
INFO - 2020-10-15 13:50:18 --> Language Class Initialized
ERROR - 2020-10-15 13:50:18 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 13:50:19 --> Config Class Initialized
INFO - 2020-10-15 13:50:19 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:19 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:19 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:19 --> URI Class Initialized
INFO - 2020-10-15 13:50:19 --> Router Class Initialized
INFO - 2020-10-15 13:50:19 --> Output Class Initialized
INFO - 2020-10-15 13:50:19 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:19 --> Input Class Initialized
INFO - 2020-10-15 13:50:19 --> Language Class Initialized
ERROR - 2020-10-15 13:50:19 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 13:50:32 --> Config Class Initialized
INFO - 2020-10-15 13:50:32 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:50:32 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:50:32 --> Utf8 Class Initialized
INFO - 2020-10-15 13:50:32 --> URI Class Initialized
INFO - 2020-10-15 13:50:32 --> Router Class Initialized
INFO - 2020-10-15 13:50:32 --> Output Class Initialized
INFO - 2020-10-15 13:50:32 --> Security Class Initialized
DEBUG - 2020-10-15 13:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:50:32 --> Input Class Initialized
INFO - 2020-10-15 13:50:32 --> Language Class Initialized
INFO - 2020-10-15 13:50:32 --> Loader Class Initialized
INFO - 2020-10-15 13:50:32 --> Helper loaded: url_helper
INFO - 2020-10-15 13:50:32 --> Helper loaded: form_helper
INFO - 2020-10-15 13:50:32 --> Helper loaded: html_helper
INFO - 2020-10-15 13:50:32 --> Helper loaded: date_helper
INFO - 2020-10-15 13:50:32 --> Database Driver Class Initialized
INFO - 2020-10-15 13:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 13:50:32 --> Table Class Initialized
INFO - 2020-10-15 13:50:32 --> Upload Class Initialized
INFO - 2020-10-15 13:50:32 --> Controller Class Initialized
INFO - 2020-10-15 13:50:32 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 13:50:32 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 13:50:32 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 13:50:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 13:50:32 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 13:50:32 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-15 13:50:32 --> Final output sent to browser
DEBUG - 2020-10-15 13:50:32 --> Total execution time: 0.3982
INFO - 2020-10-15 13:52:10 --> Config Class Initialized
INFO - 2020-10-15 13:52:10 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:52:10 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:52:10 --> Utf8 Class Initialized
INFO - 2020-10-15 13:52:10 --> URI Class Initialized
DEBUG - 2020-10-15 13:52:10 --> No URI present. Default controller set.
INFO - 2020-10-15 13:52:10 --> Router Class Initialized
INFO - 2020-10-15 13:52:10 --> Output Class Initialized
INFO - 2020-10-15 13:52:10 --> Security Class Initialized
DEBUG - 2020-10-15 13:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:52:10 --> Input Class Initialized
INFO - 2020-10-15 13:52:10 --> Language Class Initialized
ERROR - 2020-10-15 13:52:10 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 13:52:12 --> Config Class Initialized
INFO - 2020-10-15 13:52:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 13:52:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 13:52:12 --> Utf8 Class Initialized
INFO - 2020-10-15 13:52:12 --> URI Class Initialized
DEBUG - 2020-10-15 13:52:12 --> No URI present. Default controller set.
INFO - 2020-10-15 13:52:12 --> Router Class Initialized
INFO - 2020-10-15 13:52:12 --> Output Class Initialized
INFO - 2020-10-15 13:52:12 --> Security Class Initialized
DEBUG - 2020-10-15 13:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 13:52:12 --> Input Class Initialized
INFO - 2020-10-15 13:52:12 --> Language Class Initialized
ERROR - 2020-10-15 13:52:12 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 14:18:13 --> Config Class Initialized
INFO - 2020-10-15 14:18:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:18:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:18:13 --> Utf8 Class Initialized
INFO - 2020-10-15 14:18:13 --> URI Class Initialized
DEBUG - 2020-10-15 14:18:13 --> No URI present. Default controller set.
INFO - 2020-10-15 14:18:13 --> Router Class Initialized
INFO - 2020-10-15 14:18:13 --> Output Class Initialized
INFO - 2020-10-15 14:18:13 --> Security Class Initialized
DEBUG - 2020-10-15 14:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:18:13 --> Input Class Initialized
INFO - 2020-10-15 14:18:13 --> Language Class Initialized
ERROR - 2020-10-15 14:18:13 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 14:21:41 --> Config Class Initialized
INFO - 2020-10-15 14:21:41 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:41 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:41 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:41 --> URI Class Initialized
INFO - 2020-10-15 14:21:41 --> Router Class Initialized
INFO - 2020-10-15 14:21:41 --> Output Class Initialized
INFO - 2020-10-15 14:21:41 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:41 --> Input Class Initialized
INFO - 2020-10-15 14:21:41 --> Language Class Initialized
INFO - 2020-10-15 14:21:41 --> Loader Class Initialized
INFO - 2020-10-15 14:21:41 --> Helper loaded: url_helper
INFO - 2020-10-15 14:21:41 --> Helper loaded: form_helper
INFO - 2020-10-15 14:21:41 --> Helper loaded: html_helper
INFO - 2020-10-15 14:21:41 --> Helper loaded: date_helper
INFO - 2020-10-15 14:21:41 --> Database Driver Class Initialized
INFO - 2020-10-15 14:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 14:21:41 --> Table Class Initialized
INFO - 2020-10-15 14:21:41 --> Upload Class Initialized
INFO - 2020-10-15 14:21:41 --> Controller Class Initialized
INFO - 2020-10-15 14:21:41 --> File loaded: C:\xampp\htdocs\application\views\templates/header.php
INFO - 2020-10-15 14:21:41 --> File loaded: C:\xampp\htdocs\application\views\templates/sidebar-menu.php
INFO - 2020-10-15 14:21:41 --> File loaded: C:\xampp\htdocs\application\views\templates/navbar.php
INFO - 2020-10-15 14:21:41 --> File loaded: C:\xampp\htdocs\application\views\paginas/prueba.php
INFO - 2020-10-15 14:21:41 --> File loaded: C:\xampp\htdocs\application\views\templates/footer-src.php
INFO - 2020-10-15 14:21:41 --> File loaded: C:\xampp\htdocs\application\views\templates/footer.php
INFO - 2020-10-15 14:21:41 --> File loaded: C:\xampp\htdocs\application\views\index.php
INFO - 2020-10-15 14:21:41 --> Final output sent to browser
DEBUG - 2020-10-15 14:21:41 --> Total execution time: 0.4779
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/plugins
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
INFO - 2020-10-15 14:21:42 --> Config Class Initialized
INFO - 2020-10-15 14:21:42 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:42 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:42 --> Utf8 Class Initialized
DEBUG - 2020-10-15 14:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:42 --> URI Class Initialized
INFO - 2020-10-15 14:21:42 --> Input Class Initialized
INFO - 2020-10-15 14:21:42 --> Language Class Initialized
INFO - 2020-10-15 14:21:42 --> Router Class Initialized
ERROR - 2020-10-15 14:21:42 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:42 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Dist/img
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:43 --> Input Class Initialized
INFO - 2020-10-15 14:21:43 --> Language Class Initialized
ERROR - 2020-10-15 14:21:43 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:43 --> Config Class Initialized
INFO - 2020-10-15 14:21:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:43 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:43 --> URI Class Initialized
INFO - 2020-10-15 14:21:43 --> Router Class Initialized
INFO - 2020-10-15 14:21:43 --> Output Class Initialized
INFO - 2020-10-15 14:21:43 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:44 --> Input Class Initialized
INFO - 2020-10-15 14:21:44 --> Language Class Initialized
ERROR - 2020-10-15 14:21:44 --> 404 Page Not Found: Assets/plugins
INFO - 2020-10-15 14:21:44 --> Config Class Initialized
INFO - 2020-10-15 14:21:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:44 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:44 --> URI Class Initialized
INFO - 2020-10-15 14:21:44 --> Router Class Initialized
INFO - 2020-10-15 14:21:44 --> Output Class Initialized
INFO - 2020-10-15 14:21:44 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:44 --> Input Class Initialized
INFO - 2020-10-15 14:21:44 --> Language Class Initialized
ERROR - 2020-10-15 14:21:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:44 --> Config Class Initialized
INFO - 2020-10-15 14:21:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:44 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:44 --> URI Class Initialized
INFO - 2020-10-15 14:21:44 --> Router Class Initialized
INFO - 2020-10-15 14:21:44 --> Output Class Initialized
INFO - 2020-10-15 14:21:44 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:44 --> Input Class Initialized
INFO - 2020-10-15 14:21:44 --> Language Class Initialized
ERROR - 2020-10-15 14:21:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:44 --> Config Class Initialized
INFO - 2020-10-15 14:21:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:44 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:44 --> URI Class Initialized
INFO - 2020-10-15 14:21:44 --> Router Class Initialized
INFO - 2020-10-15 14:21:44 --> Output Class Initialized
INFO - 2020-10-15 14:21:44 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:44 --> Input Class Initialized
INFO - 2020-10-15 14:21:44 --> Language Class Initialized
ERROR - 2020-10-15 14:21:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:44 --> Config Class Initialized
INFO - 2020-10-15 14:21:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:44 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:44 --> URI Class Initialized
INFO - 2020-10-15 14:21:44 --> Router Class Initialized
INFO - 2020-10-15 14:21:44 --> Output Class Initialized
INFO - 2020-10-15 14:21:44 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:44 --> Input Class Initialized
INFO - 2020-10-15 14:21:44 --> Language Class Initialized
ERROR - 2020-10-15 14:21:44 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:44 --> Config Class Initialized
INFO - 2020-10-15 14:21:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:44 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:44 --> URI Class Initialized
INFO - 2020-10-15 14:21:44 --> Router Class Initialized
INFO - 2020-10-15 14:21:44 --> Output Class Initialized
INFO - 2020-10-15 14:21:44 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:44 --> Input Class Initialized
INFO - 2020-10-15 14:21:45 --> Language Class Initialized
ERROR - 2020-10-15 14:21:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:45 --> Config Class Initialized
INFO - 2020-10-15 14:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:45 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:45 --> URI Class Initialized
INFO - 2020-10-15 14:21:45 --> Router Class Initialized
INFO - 2020-10-15 14:21:45 --> Output Class Initialized
INFO - 2020-10-15 14:21:45 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:45 --> Input Class Initialized
INFO - 2020-10-15 14:21:45 --> Language Class Initialized
ERROR - 2020-10-15 14:21:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:45 --> Config Class Initialized
INFO - 2020-10-15 14:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:45 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:45 --> URI Class Initialized
INFO - 2020-10-15 14:21:45 --> Router Class Initialized
INFO - 2020-10-15 14:21:45 --> Output Class Initialized
INFO - 2020-10-15 14:21:45 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:45 --> Input Class Initialized
INFO - 2020-10-15 14:21:45 --> Language Class Initialized
ERROR - 2020-10-15 14:21:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:45 --> Config Class Initialized
INFO - 2020-10-15 14:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:45 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:45 --> URI Class Initialized
INFO - 2020-10-15 14:21:45 --> Router Class Initialized
INFO - 2020-10-15 14:21:45 --> Output Class Initialized
INFO - 2020-10-15 14:21:45 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:45 --> Input Class Initialized
INFO - 2020-10-15 14:21:45 --> Language Class Initialized
ERROR - 2020-10-15 14:21:45 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:21:45 --> Config Class Initialized
INFO - 2020-10-15 14:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:45 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:45 --> URI Class Initialized
INFO - 2020-10-15 14:21:45 --> Router Class Initialized
INFO - 2020-10-15 14:21:45 --> Output Class Initialized
INFO - 2020-10-15 14:21:45 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:45 --> Input Class Initialized
INFO - 2020-10-15 14:21:45 --> Language Class Initialized
ERROR - 2020-10-15 14:21:45 --> 404 Page Not Found: Dist/img
INFO - 2020-10-15 14:21:45 --> Config Class Initialized
INFO - 2020-10-15 14:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:21:45 --> Utf8 Class Initialized
INFO - 2020-10-15 14:21:45 --> URI Class Initialized
INFO - 2020-10-15 14:21:46 --> Router Class Initialized
INFO - 2020-10-15 14:21:46 --> Output Class Initialized
INFO - 2020-10-15 14:21:46 --> Security Class Initialized
DEBUG - 2020-10-15 14:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:21:46 --> Input Class Initialized
INFO - 2020-10-15 14:21:46 --> Language Class Initialized
ERROR - 2020-10-15 14:21:46 --> 404 Page Not Found: Assets/dist
INFO - 2020-10-15 14:43:49 --> Config Class Initialized
INFO - 2020-10-15 14:43:49 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:43:49 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:43:49 --> Utf8 Class Initialized
INFO - 2020-10-15 14:43:49 --> URI Class Initialized
DEBUG - 2020-10-15 14:43:49 --> No URI present. Default controller set.
INFO - 2020-10-15 14:43:49 --> Router Class Initialized
INFO - 2020-10-15 14:43:49 --> Output Class Initialized
INFO - 2020-10-15 14:43:49 --> Security Class Initialized
DEBUG - 2020-10-15 14:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:43:49 --> Input Class Initialized
INFO - 2020-10-15 14:43:49 --> Language Class Initialized
ERROR - 2020-10-15 14:43:49 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 14:43:51 --> Config Class Initialized
INFO - 2020-10-15 14:43:51 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:43:51 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:43:51 --> Utf8 Class Initialized
INFO - 2020-10-15 14:43:51 --> URI Class Initialized
DEBUG - 2020-10-15 14:43:51 --> No URI present. Default controller set.
INFO - 2020-10-15 14:43:51 --> Router Class Initialized
INFO - 2020-10-15 14:43:51 --> Output Class Initialized
INFO - 2020-10-15 14:43:51 --> Security Class Initialized
DEBUG - 2020-10-15 14:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:43:52 --> Input Class Initialized
INFO - 2020-10-15 14:43:52 --> Language Class Initialized
ERROR - 2020-10-15 14:43:52 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 14:45:12 --> Config Class Initialized
INFO - 2020-10-15 14:45:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 14:45:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 14:45:12 --> Utf8 Class Initialized
INFO - 2020-10-15 14:45:12 --> URI Class Initialized
DEBUG - 2020-10-15 14:45:12 --> No URI present. Default controller set.
INFO - 2020-10-15 14:45:12 --> Router Class Initialized
INFO - 2020-10-15 14:45:12 --> Output Class Initialized
INFO - 2020-10-15 14:45:12 --> Security Class Initialized
DEBUG - 2020-10-15 14:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 14:45:12 --> Input Class Initialized
INFO - 2020-10-15 14:45:12 --> Language Class Initialized
ERROR - 2020-10-15 14:45:12 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 15:04:43 --> Config Class Initialized
INFO - 2020-10-15 15:04:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 15:04:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 15:04:43 --> Utf8 Class Initialized
INFO - 2020-10-15 15:04:43 --> URI Class Initialized
DEBUG - 2020-10-15 15:04:43 --> No URI present. Default controller set.
INFO - 2020-10-15 15:04:43 --> Router Class Initialized
INFO - 2020-10-15 15:04:43 --> Output Class Initialized
INFO - 2020-10-15 15:04:43 --> Security Class Initialized
DEBUG - 2020-10-15 15:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 15:04:43 --> Input Class Initialized
INFO - 2020-10-15 15:04:43 --> Language Class Initialized
ERROR - 2020-10-15 15:04:43 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 15:30:26 --> Config Class Initialized
INFO - 2020-10-15 15:30:26 --> Hooks Class Initialized
DEBUG - 2020-10-15 15:30:26 --> UTF-8 Support Enabled
INFO - 2020-10-15 15:30:26 --> Utf8 Class Initialized
INFO - 2020-10-15 15:30:26 --> URI Class Initialized
DEBUG - 2020-10-15 15:30:26 --> No URI present. Default controller set.
INFO - 2020-10-15 15:30:26 --> Router Class Initialized
INFO - 2020-10-15 15:30:26 --> Output Class Initialized
INFO - 2020-10-15 15:30:26 --> Security Class Initialized
DEBUG - 2020-10-15 15:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 15:30:26 --> Input Class Initialized
INFO - 2020-10-15 15:30:26 --> Language Class Initialized
ERROR - 2020-10-15 15:30:26 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 15:30:29 --> Config Class Initialized
INFO - 2020-10-15 15:30:29 --> Hooks Class Initialized
DEBUG - 2020-10-15 15:30:29 --> UTF-8 Support Enabled
INFO - 2020-10-15 15:30:29 --> Utf8 Class Initialized
INFO - 2020-10-15 15:30:29 --> URI Class Initialized
DEBUG - 2020-10-15 15:30:29 --> No URI present. Default controller set.
INFO - 2020-10-15 15:30:29 --> Router Class Initialized
INFO - 2020-10-15 15:30:29 --> Output Class Initialized
INFO - 2020-10-15 15:30:29 --> Security Class Initialized
DEBUG - 2020-10-15 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 15:30:29 --> Input Class Initialized
INFO - 2020-10-15 15:30:29 --> Language Class Initialized
ERROR - 2020-10-15 15:30:29 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 16:53:16 --> Config Class Initialized
INFO - 2020-10-15 16:53:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 16:53:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 16:53:16 --> Utf8 Class Initialized
INFO - 2020-10-15 16:53:16 --> URI Class Initialized
DEBUG - 2020-10-15 16:53:16 --> No URI present. Default controller set.
INFO - 2020-10-15 16:53:16 --> Router Class Initialized
INFO - 2020-10-15 16:53:16 --> Output Class Initialized
INFO - 2020-10-15 16:53:16 --> Security Class Initialized
DEBUG - 2020-10-15 16:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 16:53:16 --> Input Class Initialized
INFO - 2020-10-15 16:53:16 --> Language Class Initialized
ERROR - 2020-10-15 16:53:16 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 16:53:18 --> Config Class Initialized
INFO - 2020-10-15 16:53:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 16:53:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 16:53:18 --> Utf8 Class Initialized
INFO - 2020-10-15 16:53:18 --> URI Class Initialized
DEBUG - 2020-10-15 16:53:18 --> No URI present. Default controller set.
INFO - 2020-10-15 16:53:18 --> Router Class Initialized
INFO - 2020-10-15 16:53:18 --> Output Class Initialized
INFO - 2020-10-15 16:53:18 --> Security Class Initialized
DEBUG - 2020-10-15 16:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 16:53:18 --> Input Class Initialized
INFO - 2020-10-15 16:53:18 --> Language Class Initialized
ERROR - 2020-10-15 16:53:18 --> 404 Page Not Found: Welcome/index
INFO - 2020-10-15 16:53:20 --> Config Class Initialized
INFO - 2020-10-15 16:53:20 --> Hooks Class Initialized
DEBUG - 2020-10-15 16:53:20 --> UTF-8 Support Enabled
INFO - 2020-10-15 16:53:20 --> Utf8 Class Initialized
INFO - 2020-10-15 16:53:20 --> URI Class Initialized
DEBUG - 2020-10-15 16:53:20 --> No URI present. Default controller set.
INFO - 2020-10-15 16:53:20 --> Router Class Initialized
INFO - 2020-10-15 16:53:20 --> Output Class Initialized
INFO - 2020-10-15 16:53:20 --> Security Class Initialized
DEBUG - 2020-10-15 16:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 16:53:20 --> Input Class Initialized
INFO - 2020-10-15 16:53:20 --> Language Class Initialized
ERROR - 2020-10-15 16:53:20 --> 404 Page Not Found: Welcome/index

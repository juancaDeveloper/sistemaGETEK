<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-03 11:40:57 --> Config Class Initialized
INFO - 2020-11-03 11:40:57 --> Hooks Class Initialized
DEBUG - 2020-11-03 11:40:57 --> UTF-8 Support Enabled
INFO - 2020-11-03 11:40:57 --> Utf8 Class Initialized
INFO - 2020-11-03 11:40:57 --> URI Class Initialized
DEBUG - 2020-11-03 11:40:57 --> No URI present. Default controller set.
INFO - 2020-11-03 11:40:57 --> Router Class Initialized
INFO - 2020-11-03 11:40:57 --> Output Class Initialized
INFO - 2020-11-03 11:40:57 --> Security Class Initialized
DEBUG - 2020-11-03 11:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 11:40:57 --> Input Class Initialized
INFO - 2020-11-03 11:40:57 --> Language Class Initialized
INFO - 2020-11-03 11:40:57 --> Loader Class Initialized
INFO - 2020-11-03 11:40:57 --> Helper loaded: url_helper
INFO - 2020-11-03 11:40:57 --> Helper loaded: form_helper
INFO - 2020-11-03 11:40:57 --> Helper loaded: html_helper
INFO - 2020-11-03 11:40:57 --> Helper loaded: date_helper
INFO - 2020-11-03 11:40:57 --> Database Driver Class Initialized
INFO - 2020-11-03 11:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 11:40:57 --> Table Class Initialized
INFO - 2020-11-03 11:40:57 --> Upload Class Initialized
INFO - 2020-11-03 11:40:57 --> Controller Class Initialized
INFO - 2020-11-03 11:40:57 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 11:40:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 11:40:57 --> Final output sent to browser
DEBUG - 2020-11-03 11:40:57 --> Total execution time: 0.4568
INFO - 2020-11-03 11:40:57 --> Config Class Initialized
INFO - 2020-11-03 11:40:57 --> Hooks Class Initialized
DEBUG - 2020-11-03 11:40:57 --> UTF-8 Support Enabled
INFO - 2020-11-03 11:40:58 --> Utf8 Class Initialized
INFO - 2020-11-03 11:40:58 --> URI Class Initialized
DEBUG - 2020-11-03 11:40:58 --> No URI present. Default controller set.
INFO - 2020-11-03 11:40:58 --> Router Class Initialized
INFO - 2020-11-03 11:40:58 --> Output Class Initialized
INFO - 2020-11-03 11:40:58 --> Security Class Initialized
DEBUG - 2020-11-03 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 11:40:58 --> Input Class Initialized
INFO - 2020-11-03 11:40:58 --> Language Class Initialized
INFO - 2020-11-03 11:40:58 --> Loader Class Initialized
INFO - 2020-11-03 11:40:58 --> Helper loaded: url_helper
INFO - 2020-11-03 11:40:58 --> Helper loaded: form_helper
INFO - 2020-11-03 11:40:58 --> Helper loaded: html_helper
INFO - 2020-11-03 11:40:58 --> Helper loaded: date_helper
INFO - 2020-11-03 11:40:58 --> Database Driver Class Initialized
INFO - 2020-11-03 11:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 11:40:58 --> Table Class Initialized
INFO - 2020-11-03 11:40:58 --> Upload Class Initialized
INFO - 2020-11-03 11:40:58 --> Controller Class Initialized
INFO - 2020-11-03 11:40:58 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 11:40:58 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 11:40:58 --> Final output sent to browser
DEBUG - 2020-11-03 11:40:58 --> Total execution time: 0.1358
INFO - 2020-11-03 11:40:58 --> Config Class Initialized
INFO - 2020-11-03 11:40:58 --> Hooks Class Initialized
DEBUG - 2020-11-03 11:40:58 --> UTF-8 Support Enabled
INFO - 2020-11-03 11:40:58 --> Utf8 Class Initialized
INFO - 2020-11-03 11:40:58 --> URI Class Initialized
DEBUG - 2020-11-03 11:40:58 --> No URI present. Default controller set.
INFO - 2020-11-03 11:40:58 --> Router Class Initialized
INFO - 2020-11-03 11:40:58 --> Output Class Initialized
INFO - 2020-11-03 11:40:58 --> Security Class Initialized
DEBUG - 2020-11-03 11:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 11:40:58 --> Input Class Initialized
INFO - 2020-11-03 11:40:58 --> Language Class Initialized
INFO - 2020-11-03 11:40:58 --> Loader Class Initialized
INFO - 2020-11-03 11:40:58 --> Helper loaded: url_helper
INFO - 2020-11-03 11:40:58 --> Helper loaded: form_helper
INFO - 2020-11-03 11:40:58 --> Helper loaded: html_helper
INFO - 2020-11-03 11:40:58 --> Helper loaded: date_helper
INFO - 2020-11-03 11:40:58 --> Database Driver Class Initialized
INFO - 2020-11-03 11:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 11:40:58 --> Table Class Initialized
INFO - 2020-11-03 11:40:58 --> Upload Class Initialized
INFO - 2020-11-03 11:40:58 --> Controller Class Initialized
INFO - 2020-11-03 11:40:58 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 11:40:58 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 11:40:58 --> Final output sent to browser
DEBUG - 2020-11-03 11:40:58 --> Total execution time: 0.1400
INFO - 2020-11-03 12:00:43 --> Config Class Initialized
INFO - 2020-11-03 12:00:43 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:00:43 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:00:43 --> Utf8 Class Initialized
INFO - 2020-11-03 12:00:43 --> URI Class Initialized
DEBUG - 2020-11-03 12:00:43 --> No URI present. Default controller set.
INFO - 2020-11-03 12:00:43 --> Router Class Initialized
INFO - 2020-11-03 12:00:43 --> Output Class Initialized
INFO - 2020-11-03 12:00:43 --> Security Class Initialized
DEBUG - 2020-11-03 12:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:00:43 --> Input Class Initialized
INFO - 2020-11-03 12:00:44 --> Language Class Initialized
INFO - 2020-11-03 12:00:44 --> Loader Class Initialized
INFO - 2020-11-03 12:00:44 --> Helper loaded: url_helper
INFO - 2020-11-03 12:00:44 --> Helper loaded: form_helper
INFO - 2020-11-03 12:00:44 --> Helper loaded: html_helper
INFO - 2020-11-03 12:00:44 --> Helper loaded: date_helper
INFO - 2020-11-03 12:00:44 --> Database Driver Class Initialized
INFO - 2020-11-03 12:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:00:44 --> Table Class Initialized
INFO - 2020-11-03 12:00:44 --> Upload Class Initialized
INFO - 2020-11-03 12:00:44 --> Controller Class Initialized
INFO - 2020-11-03 12:00:44 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:00:44 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:00:44 --> Final output sent to browser
DEBUG - 2020-11-03 12:00:44 --> Total execution time: 0.1474
INFO - 2020-11-03 12:00:44 --> Config Class Initialized
INFO - 2020-11-03 12:00:44 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:00:44 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:00:44 --> Utf8 Class Initialized
INFO - 2020-11-03 12:00:44 --> URI Class Initialized
DEBUG - 2020-11-03 12:00:44 --> No URI present. Default controller set.
INFO - 2020-11-03 12:00:44 --> Router Class Initialized
INFO - 2020-11-03 12:00:44 --> Output Class Initialized
INFO - 2020-11-03 12:00:44 --> Security Class Initialized
DEBUG - 2020-11-03 12:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:00:44 --> Input Class Initialized
INFO - 2020-11-03 12:00:44 --> Language Class Initialized
INFO - 2020-11-03 12:00:44 --> Loader Class Initialized
INFO - 2020-11-03 12:00:44 --> Helper loaded: url_helper
INFO - 2020-11-03 12:00:44 --> Helper loaded: form_helper
INFO - 2020-11-03 12:00:44 --> Helper loaded: html_helper
INFO - 2020-11-03 12:00:44 --> Helper loaded: date_helper
INFO - 2020-11-03 12:00:44 --> Database Driver Class Initialized
INFO - 2020-11-03 12:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:00:44 --> Table Class Initialized
INFO - 2020-11-03 12:00:44 --> Upload Class Initialized
INFO - 2020-11-03 12:00:44 --> Controller Class Initialized
INFO - 2020-11-03 12:00:44 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:00:44 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:00:44 --> Final output sent to browser
DEBUG - 2020-11-03 12:00:44 --> Total execution time: 0.0955
INFO - 2020-11-03 12:34:56 --> Config Class Initialized
INFO - 2020-11-03 12:34:56 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:34:56 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:34:56 --> Utf8 Class Initialized
INFO - 2020-11-03 12:34:56 --> URI Class Initialized
DEBUG - 2020-11-03 12:34:56 --> No URI present. Default controller set.
INFO - 2020-11-03 12:34:56 --> Router Class Initialized
INFO - 2020-11-03 12:34:56 --> Output Class Initialized
INFO - 2020-11-03 12:34:56 --> Security Class Initialized
DEBUG - 2020-11-03 12:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:34:56 --> Input Class Initialized
INFO - 2020-11-03 12:34:56 --> Language Class Initialized
INFO - 2020-11-03 12:34:57 --> Loader Class Initialized
INFO - 2020-11-03 12:34:57 --> Helper loaded: url_helper
INFO - 2020-11-03 12:34:57 --> Helper loaded: form_helper
INFO - 2020-11-03 12:34:57 --> Helper loaded: html_helper
INFO - 2020-11-03 12:34:57 --> Helper loaded: date_helper
INFO - 2020-11-03 12:34:57 --> Database Driver Class Initialized
INFO - 2020-11-03 12:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:34:57 --> Table Class Initialized
INFO - 2020-11-03 12:34:57 --> Upload Class Initialized
INFO - 2020-11-03 12:34:57 --> Controller Class Initialized
INFO - 2020-11-03 12:34:57 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:34:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:34:57 --> Final output sent to browser
DEBUG - 2020-11-03 12:34:57 --> Total execution time: 0.1298
INFO - 2020-11-03 12:34:57 --> Config Class Initialized
INFO - 2020-11-03 12:34:57 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:34:57 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:34:57 --> Utf8 Class Initialized
INFO - 2020-11-03 12:34:57 --> URI Class Initialized
DEBUG - 2020-11-03 12:34:57 --> No URI present. Default controller set.
INFO - 2020-11-03 12:34:57 --> Router Class Initialized
INFO - 2020-11-03 12:34:57 --> Output Class Initialized
INFO - 2020-11-03 12:34:57 --> Security Class Initialized
DEBUG - 2020-11-03 12:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:34:57 --> Input Class Initialized
INFO - 2020-11-03 12:34:57 --> Language Class Initialized
INFO - 2020-11-03 12:34:57 --> Loader Class Initialized
INFO - 2020-11-03 12:34:57 --> Helper loaded: url_helper
INFO - 2020-11-03 12:34:57 --> Helper loaded: form_helper
INFO - 2020-11-03 12:34:57 --> Helper loaded: html_helper
INFO - 2020-11-03 12:34:57 --> Helper loaded: date_helper
INFO - 2020-11-03 12:34:57 --> Database Driver Class Initialized
INFO - 2020-11-03 12:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:34:57 --> Table Class Initialized
INFO - 2020-11-03 12:34:57 --> Upload Class Initialized
INFO - 2020-11-03 12:34:57 --> Controller Class Initialized
INFO - 2020-11-03 12:34:57 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:34:57 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:34:57 --> Final output sent to browser
DEBUG - 2020-11-03 12:34:57 --> Total execution time: 0.0387
INFO - 2020-11-03 12:35:25 --> Config Class Initialized
INFO - 2020-11-03 12:35:25 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:35:25 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:35:25 --> Utf8 Class Initialized
INFO - 2020-11-03 12:35:25 --> URI Class Initialized
DEBUG - 2020-11-03 12:35:25 --> No URI present. Default controller set.
INFO - 2020-11-03 12:35:25 --> Router Class Initialized
INFO - 2020-11-03 12:35:25 --> Output Class Initialized
INFO - 2020-11-03 12:35:25 --> Security Class Initialized
DEBUG - 2020-11-03 12:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:35:25 --> Input Class Initialized
INFO - 2020-11-03 12:35:25 --> Language Class Initialized
INFO - 2020-11-03 12:35:25 --> Loader Class Initialized
INFO - 2020-11-03 12:35:25 --> Helper loaded: url_helper
INFO - 2020-11-03 12:35:25 --> Helper loaded: form_helper
INFO - 2020-11-03 12:35:25 --> Helper loaded: html_helper
INFO - 2020-11-03 12:35:25 --> Helper loaded: date_helper
INFO - 2020-11-03 12:35:25 --> Database Driver Class Initialized
INFO - 2020-11-03 12:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:35:25 --> Table Class Initialized
INFO - 2020-11-03 12:35:25 --> Upload Class Initialized
INFO - 2020-11-03 12:35:25 --> Controller Class Initialized
INFO - 2020-11-03 12:35:25 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:35:25 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:35:25 --> Final output sent to browser
DEBUG - 2020-11-03 12:35:25 --> Total execution time: 0.0469
INFO - 2020-11-03 12:35:28 --> Config Class Initialized
INFO - 2020-11-03 12:35:28 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:35:28 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:35:28 --> Utf8 Class Initialized
INFO - 2020-11-03 12:35:28 --> URI Class Initialized
DEBUG - 2020-11-03 12:35:28 --> No URI present. Default controller set.
INFO - 2020-11-03 12:35:28 --> Router Class Initialized
INFO - 2020-11-03 12:35:28 --> Output Class Initialized
INFO - 2020-11-03 12:35:28 --> Security Class Initialized
DEBUG - 2020-11-03 12:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:35:28 --> Input Class Initialized
INFO - 2020-11-03 12:35:28 --> Language Class Initialized
INFO - 2020-11-03 12:35:28 --> Loader Class Initialized
INFO - 2020-11-03 12:35:28 --> Helper loaded: url_helper
INFO - 2020-11-03 12:35:28 --> Helper loaded: form_helper
INFO - 2020-11-03 12:35:28 --> Helper loaded: html_helper
INFO - 2020-11-03 12:35:28 --> Helper loaded: date_helper
INFO - 2020-11-03 12:35:28 --> Database Driver Class Initialized
INFO - 2020-11-03 12:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:35:28 --> Table Class Initialized
INFO - 2020-11-03 12:35:28 --> Upload Class Initialized
INFO - 2020-11-03 12:35:28 --> Controller Class Initialized
INFO - 2020-11-03 12:35:28 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:35:28 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:35:28 --> Final output sent to browser
DEBUG - 2020-11-03 12:35:28 --> Total execution time: 0.0373
INFO - 2020-11-03 12:35:28 --> Config Class Initialized
INFO - 2020-11-03 12:35:28 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:35:28 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:35:28 --> Utf8 Class Initialized
INFO - 2020-11-03 12:35:28 --> URI Class Initialized
DEBUG - 2020-11-03 12:35:28 --> No URI present. Default controller set.
INFO - 2020-11-03 12:35:28 --> Router Class Initialized
INFO - 2020-11-03 12:35:28 --> Output Class Initialized
INFO - 2020-11-03 12:35:28 --> Security Class Initialized
DEBUG - 2020-11-03 12:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:35:28 --> Input Class Initialized
INFO - 2020-11-03 12:35:28 --> Language Class Initialized
INFO - 2020-11-03 12:35:28 --> Loader Class Initialized
INFO - 2020-11-03 12:35:28 --> Helper loaded: url_helper
INFO - 2020-11-03 12:35:28 --> Helper loaded: form_helper
INFO - 2020-11-03 12:35:28 --> Helper loaded: html_helper
INFO - 2020-11-03 12:35:28 --> Helper loaded: date_helper
INFO - 2020-11-03 12:35:28 --> Database Driver Class Initialized
INFO - 2020-11-03 12:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:35:28 --> Table Class Initialized
INFO - 2020-11-03 12:35:28 --> Upload Class Initialized
INFO - 2020-11-03 12:35:28 --> Controller Class Initialized
INFO - 2020-11-03 12:35:28 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:35:28 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:35:28 --> Final output sent to browser
DEBUG - 2020-11-03 12:35:28 --> Total execution time: 0.0414
INFO - 2020-11-03 12:41:07 --> Config Class Initialized
INFO - 2020-11-03 12:41:07 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:41:07 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:41:07 --> Utf8 Class Initialized
INFO - 2020-11-03 12:41:07 --> URI Class Initialized
DEBUG - 2020-11-03 12:41:07 --> No URI present. Default controller set.
INFO - 2020-11-03 12:41:07 --> Router Class Initialized
INFO - 2020-11-03 12:41:07 --> Output Class Initialized
INFO - 2020-11-03 12:41:07 --> Security Class Initialized
DEBUG - 2020-11-03 12:41:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:41:07 --> Input Class Initialized
INFO - 2020-11-03 12:41:07 --> Language Class Initialized
INFO - 2020-11-03 12:41:07 --> Loader Class Initialized
INFO - 2020-11-03 12:41:07 --> Helper loaded: url_helper
INFO - 2020-11-03 12:41:07 --> Helper loaded: form_helper
INFO - 2020-11-03 12:41:07 --> Helper loaded: html_helper
INFO - 2020-11-03 12:41:07 --> Helper loaded: date_helper
INFO - 2020-11-03 12:41:07 --> Database Driver Class Initialized
INFO - 2020-11-03 12:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:41:07 --> Table Class Initialized
INFO - 2020-11-03 12:41:07 --> Upload Class Initialized
INFO - 2020-11-03 12:41:07 --> Controller Class Initialized
INFO - 2020-11-03 12:41:07 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:41:07 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:41:07 --> Final output sent to browser
DEBUG - 2020-11-03 12:41:07 --> Total execution time: 0.0587
INFO - 2020-11-03 12:50:24 --> Config Class Initialized
INFO - 2020-11-03 12:50:24 --> Hooks Class Initialized
DEBUG - 2020-11-03 12:50:24 --> UTF-8 Support Enabled
INFO - 2020-11-03 12:50:24 --> Utf8 Class Initialized
INFO - 2020-11-03 12:50:24 --> URI Class Initialized
DEBUG - 2020-11-03 12:50:24 --> No URI present. Default controller set.
INFO - 2020-11-03 12:50:24 --> Router Class Initialized
INFO - 2020-11-03 12:50:24 --> Output Class Initialized
INFO - 2020-11-03 12:50:24 --> Security Class Initialized
DEBUG - 2020-11-03 12:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 12:50:24 --> Input Class Initialized
INFO - 2020-11-03 12:50:24 --> Language Class Initialized
INFO - 2020-11-03 12:50:24 --> Loader Class Initialized
INFO - 2020-11-03 12:50:24 --> Helper loaded: url_helper
INFO - 2020-11-03 12:50:24 --> Helper loaded: form_helper
INFO - 2020-11-03 12:50:24 --> Helper loaded: html_helper
INFO - 2020-11-03 12:50:24 --> Helper loaded: date_helper
INFO - 2020-11-03 12:50:24 --> Database Driver Class Initialized
INFO - 2020-11-03 12:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 12:50:24 --> Table Class Initialized
INFO - 2020-11-03 12:50:24 --> Upload Class Initialized
INFO - 2020-11-03 12:50:24 --> Controller Class Initialized
INFO - 2020-11-03 12:50:24 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 12:50:24 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 12:50:24 --> Final output sent to browser
DEBUG - 2020-11-03 12:50:24 --> Total execution time: 0.0546
INFO - 2020-11-03 13:10:03 --> Config Class Initialized
INFO - 2020-11-03 13:10:03 --> Hooks Class Initialized
DEBUG - 2020-11-03 13:10:03 --> UTF-8 Support Enabled
INFO - 2020-11-03 13:10:03 --> Utf8 Class Initialized
INFO - 2020-11-03 13:10:03 --> URI Class Initialized
DEBUG - 2020-11-03 13:10:03 --> No URI present. Default controller set.
INFO - 2020-11-03 13:10:03 --> Router Class Initialized
INFO - 2020-11-03 13:10:03 --> Output Class Initialized
INFO - 2020-11-03 13:10:03 --> Security Class Initialized
DEBUG - 2020-11-03 13:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 13:10:03 --> Input Class Initialized
INFO - 2020-11-03 13:10:03 --> Language Class Initialized
INFO - 2020-11-03 13:10:03 --> Loader Class Initialized
INFO - 2020-11-03 13:10:03 --> Helper loaded: url_helper
INFO - 2020-11-03 13:10:03 --> Helper loaded: form_helper
INFO - 2020-11-03 13:10:03 --> Helper loaded: html_helper
INFO - 2020-11-03 13:10:03 --> Helper loaded: date_helper
INFO - 2020-11-03 13:10:03 --> Database Driver Class Initialized
INFO - 2020-11-03 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 13:10:03 --> Table Class Initialized
INFO - 2020-11-03 13:10:03 --> Upload Class Initialized
INFO - 2020-11-03 13:10:03 --> Controller Class Initialized
INFO - 2020-11-03 13:10:03 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 13:10:03 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 13:10:03 --> Final output sent to browser
DEBUG - 2020-11-03 13:10:03 --> Total execution time: 0.0534
INFO - 2020-11-03 13:10:03 --> Config Class Initialized
INFO - 2020-11-03 13:10:03 --> Hooks Class Initialized
DEBUG - 2020-11-03 13:10:03 --> UTF-8 Support Enabled
INFO - 2020-11-03 13:10:03 --> Utf8 Class Initialized
INFO - 2020-11-03 13:10:03 --> URI Class Initialized
DEBUG - 2020-11-03 13:10:03 --> No URI present. Default controller set.
INFO - 2020-11-03 13:10:03 --> Router Class Initialized
INFO - 2020-11-03 13:10:03 --> Output Class Initialized
INFO - 2020-11-03 13:10:03 --> Security Class Initialized
DEBUG - 2020-11-03 13:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-03 13:10:03 --> Input Class Initialized
INFO - 2020-11-03 13:10:03 --> Language Class Initialized
INFO - 2020-11-03 13:10:03 --> Loader Class Initialized
INFO - 2020-11-03 13:10:03 --> Helper loaded: url_helper
INFO - 2020-11-03 13:10:03 --> Helper loaded: form_helper
INFO - 2020-11-03 13:10:03 --> Helper loaded: html_helper
INFO - 2020-11-03 13:10:03 --> Helper loaded: date_helper
INFO - 2020-11-03 13:10:03 --> Database Driver Class Initialized
INFO - 2020-11-03 13:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-03 13:10:03 --> Table Class Initialized
INFO - 2020-11-03 13:10:03 --> Upload Class Initialized
INFO - 2020-11-03 13:10:03 --> Controller Class Initialized
INFO - 2020-11-03 13:10:03 --> Model "Usuarios_model" initialized
INFO - 2020-11-03 13:10:03 --> File loaded: C:\xampp\htdocs\application\views\paginas/login.php
INFO - 2020-11-03 13:10:03 --> Final output sent to browser
DEBUG - 2020-11-03 13:10:03 --> Total execution time: 0.0668
